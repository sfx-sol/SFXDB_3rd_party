#!/bin/bash
#------------------------------------------------------------------------------
# Copyright (c) 2015-2019, ScaleFlux, Inc.
#------------------------------------------------------------------------------

shopt -s xpg_echo expand_aliases

usage="Usage:
\n\tsudo $0 [...optional args...]
\n
\nOptional Args:
\n\t[-h|--help]\t\t\tPrints this help-text / usage message.
\n\t[-a|--autoload]\t\t\tAuto-load driver modules on reboot.
\n\t[-n|--no-autoload]\t\tDo not auto-load driver modules on reboot.
\n\t[-i|--ignore-rsyslogdchk]\tIgnore rsyslog version sanity check.
\n\t[-o|--install-only]\t\tOnly install SFX driver package, do not load any SFX drivers.
\n\t[-s|--modprobe-coredriver-only]\tSkip the loading of SFX block driver.
\n\t[-u|--uninstall-only]\t\tUninstall SFX driver package and unload driver modules only.
\n\t[-v|--verbose-build]\t\tEnable src_pkg makefile's verbose output mode.
\n\t[-y|--install-build-tools]\t'Yes' to auto-install all missing build/make tools.
\n
\nReturns 0 for successful operation; non-zero value for failure.
\n"

msg_todo="\nTo install software packages regardless of errors, please try either of the following:
\n\t1. Manage to unload all of the sfx drivers then rerun this script.
\n\t2. Run this script with the -o option and then reboot the system.
\n"

uninstall_only=n
ignore_rsyslogdchk=n
only_install_pkg=n
verbose_build=""
install_build_tools=""
autoload=y

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)                      echo $usage; exit 0 ;;
        -a|--autoload)                  autoload=y ;;
        -n|--no-autoload)               autoload=n ;;
        -i|--ignore-rsyslogdchk)        ignore_rsyslogdchk=y ;;
        -o|--install-only)              only_install_pkg=y ;;
        -s|--modprobe-coredriver-only)  modprobe_coredriver_only=y ;;
        -u|--uninstall-only)            uninstall_only=y ;;
        -v|--verbose-build)             verbose_build="CCSMAKE_VERBOSE=1" ;;
        -y|--install-build-tools)       install_build_tools=y ;;
        *)                              echo "unsupported options: $*\n"; echo $usage; exit -1 ;;
    esac
    shift
done

if [[ $only_install_pkg = "y" && $uninstall_only = "y" ]]; then
	echo "ERROR: conflicting options: [-o|--install-only] and [-u|--uninstall-only] used together."
    exit -2
fi

if [[ $EUID -ne 0 ]]; then
    echo "ERROR: this script must be run as root (or sudo)."
    exit -3
fi

#################################################################
# !!! Important !!!
# !!! Keep the following two arrays in sync !!!
# !!! THEY MUST BE REORDERED (if/when needed) TOGETHER !!!
#################################################################
driver_unload_ignore_failure=(0 1 0 0)
driver_unload_order=(
csszlib
sfxwrapper
sfx_bd_dev
sfxdriver
)
num_drivers=${#driver_unload_order[@]}

extradriver=${driver_unload_order[0]}
wrap_driver=${driver_unload_order[1]}
bdev_driver=${driver_unload_order[2]}
core_driver=${driver_unload_order[3]}
vdev_driver=sfv

sysctlconfile=/etc/sysctl.conf
src_rpm_tmpdir=
sfx_utils=

#------------------------------------------------------------------------------
# The bash builtin $BASH_SOURCE will ensure an absolute current directory pathname.
#------------------------------------------------------------------------------
release_dir=$(dirname "$(readlink -f "$BASH_SOURCE")")
cd $release_dir

#------------------------------------------------------------------------------
# Sanity check to ensure the integraty of the release direcotry.
#------------------------------------------------------------------------------
if [[ $uninstall_only = "n" ]]; then
	echo "Checking the release directory for binary and source package files..."
	if [[ -d $release_dir/fullsrc_pkg ]]; then
		src_pkg_folder=$release_dir/fullsrc_pkg
	else
		if [[ -d $release_dir/src_pkg ]]; then
			src_pkg_folder=$release_dir/src_pkg
		else
		    echo "ERROR: source package directory: $release_dir/src_pkg does not exist."
		    echo "Please make sure you are in the proper Scaleflux release directory."
		    exit -4
		fi
	fi
	sfxparam_file=$release_dir/sfxparam
	if [[ ! -f $sfxparam_file ]]; then
	    echo "ERROR: SFX driver param file '"$sfxparam_file"' not found."
	    exit -5
	fi
	version_file=$src_pkg_folder/include/version_tmp.h
	rev_pat='^r[0-9][0-9][0-9][0-9][0-9]$'
	svn_rev=r$(grep -m 1 -oh -e '\([0-9]\{5\}\)' $version_file)
	if [[ $? -ne 0 || ! $svn_rev =~ $rev_pat ]]; then
	    echo "ERROR: release revision file invalid: $version_file"
	    echo "Some release content may have been altered/deleted; please restore the release directory."
	    exit -6
	fi
fi

indent4() { sed 's/^/    /'; }

#------------------------------------------------------------------------------
# Kernel version (plus patch level) works for all Ubuntu/Debian kernel packages
# and all standard/official Centos kernel pacakges.  The format is: x.y.z-patch
#------------------------------------------------------------------------------
kernel_name=`uname -r`
kver_base=$(uname -r | grep -o '^[0-9]*\.[0-9]*.[0-9]*')
kver_patch=$(uname -r | sed -e 's/^\([0-9]*\)*\.\([0-9]*\)*\.\([0-9]*\)*//' | grep -o '^-[0-9]*')
kver_with_patch=$kver_base$kver_patch

#------------------------------------------------------------------------------
# For customized Centos kernel packages, there is no official naming convention
# used for the "extra kernel version strings"; so we have to accept it all.
# The extra version is extracted between the leading x.y.z-patch string and
# the trailing .el* string.  For example, for the 3.10.0-693.11.6.el7.x86_64
# kernel, the extra string would be ".11.6". In the case of the standard Centos,
# say, 4.18.1-1.el7.elrepo.x86_64, the extra string would be "" (null string).
#------------------------------------------------------------------------------
kver_centos_extra=$(uname -r | sed -e "s,^$kver_with_patch,," -e 's/\.el.*$//')

#------------------------------------------------------------------------------
# Check for supported Linux distro - Centos, Ubuntu, or Debian.
#------------------------------------------------------------------------------
if [[ -f /etc/redhat-release ]]; then
    distro="centos"
    pkg_cmd="rpm"
    pkg_query_opt="-qa"
    uname -r | grep -q alios
    if [[ $? -eq 0 ]]; then
        # This is to work around the RPM error of "failed dependencies:"
        #    kernel(module_layout) = 0x3dce2d18 is needed by sfx_bd_dev-3.10.0-327.ali2013.alios7.x86_64
        pkg_install_opt="--nodeps --force -ivh"
    else
        pkg_install_opt="-ivh"
    fi
    pkg_suffix="rpm"
    os_major=$(cat /etc/redhat-release | sed -e 's/[^0-9]*//' -e 's/\.[0-9]*.*$//' 2>/dev/null)
    if [[ "$os_major" = "6" ]]; then
        # current machine's OS is centos 6.x
        generic_os=generic-centos6
    else
        # treat all non-centos6 OSes as centos7
        generic_os=generic-centos7
    fi
    if [[ `cat /etc/redhat-release` =~ " "6\.2 ]]; then
        # echo "centos 6.2 turn on ignore_rsyslogdchk"
        ignore_rsyslogdchk=y
    fi
else
    distro="ubuntu"
    pkg_cmd="dpkg"
    pkg_query_opt="--list"
    pkg_install_opt="--install"
    pkg_suffix="deb"
    generic_os=generic-ubuntu
    cat /etc/*-release | grep -qi $distro
    if [[ $? -ne 0 ]]; then
        distro=debian
        generic_os=generic-debian
        cat /etc/*-release | grep -qi $distro
        if [[ $? -ne 0 ]]; then
            echo "ERROR: Unsupported OS: "`cat /etc/*-release | head -1`
            exit -7
        fi
    fi
fi

if [[ $ignore_rsyslogdchk = "n" ]]; then
    rsyslogd_v=$(rsyslogd -version | head -1 | grep -Po '(?<=rsyslogd )[^,]+' | sed -r 's/([0-9]+)/0000\1/g; s/0*([0-9]{4})/\1/g')
    # echo "rsyslog version $rsyslogd_v"
    if [[ (("$rsyslogd_v" < 0005.0008.0010)) ]]; then
        if [[ $distro = "centos" ]]; then
            echo "rsyslogd version $rsyslogd_v on your system is older than 5.8.10."
            echo "Please consider updating it or use -i|--ignore-rsyslogdchk to ignore this checking when you re-run this script next time"
            echo "To update rsyslog, run the following steps:"
            echo "1. wget http://rpms.adiscon.com/v8-stable/rsyslog.repo -O /etc/yum.repos.d/rsyslog.repo"
            echo "2. sudo yum install rsyslog"
            echo "3. sudo service rsyslog restart"
            echo "To persistently start rsyslogd over the reboot, do the following:"
            echo "sudo chkconfig rsyslog on"
            exit -10
        else
            echo "rsyslogd version $rsyslogd_v on your system is older than 5.8.10."
            echo "Please consider updating it or use -i|--ignore-rsyslogdchk to ignore this checking when you re-run this script next time"
            echo "To update rsyslog, run the following steps:"
            echo "1. sudo add-apt-repository ppa:adiscon/v8-stable"
            echo "2. sudo apt-get update"
            echo "3. sudo apt-get install rsyslog"
            echo "4. sudo service rsyslog restart"
            exit -11
        fi
    fi
    rsyslogd_alive=`ps -ef | grep rsyslogd | grep -v grep`
    # echo "rsyslog alive $rsyslogd_alive"
    if [[ $rsyslogd_alive = "" ]]; then
        echo "rsyslogd on your system is not running."
        echo "Please start it or use -i|--ignore-rsyslogdchk to ignore this checking when you re-run this script next time"
        exit -12
    fi
fi

#------------------------------------------------------------------------------
# Find (and optionally build from src_pkg) the sfx drivers packages
#------------------------------------------------------------------------------
blkdriver_pkg_file=""
pkgname=""
yesno=""
chk_cmd_rc=

check_command() {
    # $1 - 1=use "type" to find cmd; 2==use "locate" to find lib
    # $2 - the name (string) of cmd or lib to find
    # $3 - suggested ubuntu pkg to install
    # $4 - suggested centos pkg to install
    if [[ $1 -eq 1 ]]; then
        chk_cmd=type
        obj=command
    else
        chk_cmd=locate
        obj=library
        type locate >/dev/null 2>&1
        if [[ $? -ne 0 ]]; then
            # we need to install the locate command first
            if [[ $distro = "centos" ]]; then
                yum -y install mlocate
            else
                apt-get -y install mlocate
            fi
            # now populate the locate command database
            sudo updatedb
        fi
    fi
    $chk_cmd $2 >/dev/null 2>&1
    chk_cmd_rc=$?
    if [[ $chk_cmd_rc -ne 0 ]]; then
        echo -n "WARNING: $obj '"$2"' not found; "
        if [[ $install_build_tools = "y" ]]; then
            echo "will install it now..."
        elif [[ $install_build_tools = "n" ]]; then
            echo "SFX driver package may fail to build/install."
        else
            echo -n "would you like to install it? (y/n) "
            read yesno
            if [[ "$yesno" =~ [yY].* ]]; then
                install_build_tools=y
            else
                install_build_tools=n
                echo "WARNING: SFX driver package may fail to build/install."
            fi
        fi
        if [[ $install_build_tools = "y" ]]; then
            if [[ $distro = "centos" ]]; then
                yum -y install $4
            else
                apt-get -y install $3
            fi
            $chk_cmd $2 >/dev/null 2>&1
            chk_cmd_rc=$?
        fi
    fi
}

check_dependent_libs() {
    # Check if the libsgutils2 is installed
    check_command 2 libsgutils2.so.2 libsgutils2-dev sg3_utils-libs
    # Check if the libudev is installed
    check_command 2 libudev.so libudev-dev libudev-devel
}

check_build_tools() {
    # Check if the make command is installed
    check_command 1 make make make
    # Check if the makedepend command is installed
    check_command 1 makedepend xutils-dev imake
    # Check if the gcc command is installed
    check_command 1 gcc gcc gcc
    # Check if the m4 command is installed
    check_command 1 m4 m4 m4
    # Check if kernel pkg and package tool (rpmbuild / dpgk) command are installed
    if [[ $distro = "centos" ]]; then
        check_command 1 rpmbuild rpm-build rpm-build
        if [[ $chk_cmd_rc -eq 0 ]]; then
            rpm -qa | grep -q headers-$kernel_name
            if [[ $? -ne 0 ]]; then
                echo "WARNING: kernel-headers package not found for the running kernel $kernel_name"
            fi
            rpm -qa | grep -q devel-$kernel_name
            if [[ $? -ne 0 ]]; then
                echo "WARNING: kernel-devel package not found for the running kernel $kernel_name"
            fi
        fi
    else
        check_command 1 fakeroot fakeroot fakeroot
        type dpkg >/dev/null 2>&1
        chk_cmd_rc=$?
        if [[ $chk_cmd_rc -eq 0 ]]; then
            dpkg --list | grep -q linux-headers-$kernel_name
            if [[ $? -ne 0 ]]; then
                echo "WARNING: linux-headers package not found for the running kernel $kernel_name"
            fi
            dpkg --list | grep -q linux-image-$kernel_name
            if [[ $? -ne 0 ]]; then
                echo "WARNING: linux-image package not found for the running kernel $kernel_name"
            fi
        else
            echo "Oh no! The system tool 'dpkg' is missing!"
            echo "You will need boot to a rescue system or Live CD/USB to reinstall the 'dpkg' command."
        fi
    fi
}

generate_pkg_from_src_rpm() {
    # $1 is the src rpm build dir
    # $2 is the pkg suffix
    # We will now attempt to build the package from src rpm
    pushd $1 >/dev/null
    mkdir -p lib-output output
    #------------------------------------------------------------------------------
    # populate files from sfx_utils.tar.gz into src_pkg/output folder
    #------------------------------------------------------------------------------
    sfx_utils=$release_dir/bin_pkg/$generic_os/sfx_utils.tar.gz
    if [[ ! -f $sfx_utils ]]; then
        echo "ERROR: SFX utils tarball file '"$sfx_utils"' not found."
        echo "Some release content may have been altered/deleted; please restore/re-download the release directory."
        exit -40
    fi
    cd ./output/
    cp $release_dir/bin_pkg/$generic_os/bin/* .
    cp $release_dir/bin_pkg/$generic_os/lib/* .
    tar -zxf $sfx_utils > /dev/null
    if [[ $? -ne 0 ]]; then
        echo "ERROR: failed to extract SFX utils from '"$sfx_utils"'."
        echo "Some release content may have been altered/deleted; please restore/re-download the release directory."
        exit -41
    fi
    mv -f sfx_utils/* .
    rmdir sfx_utils
    cd ..
    echo "Building sfx driver package from $src_pkg_folder/ - this could take a few minutes...\n"
    eval $verbose_build make all $bdev_driver >make.log 2>&1
    if [[ $? -ne 0 ]]; then
        echo "Failed to make sfx driver package from the sfx_srel tarball."
        cp -f ./make.log $release_dir
        echo "Please examine the build log file: $release_dir/make.log for error info."
    else
        grep -q -e ': error: ' -e '] Error ' -e 'WARNING: \".*\" \[.*\.ko\] undefined\!' ./make.log
        if [[ $? -eq 0 ]]; then
            # build failed - .ko files cannot have undefined symbols
            echo "ERROR: kernel driver module build failed - undefined symbol found."
            cp -f ./make.log $release_dir
            echo "Please examine the build log file: $release_dir/make.log for error info."
        else
            cd output
            echo "Saving the generated driver package file *.$2 to $release_dir..."
            # keep two-level backup - rename all existing pacakge files to .bak
            for i in `ls $release_dir/$bdev_driver-*.$2 2>/dev/null`; do
                if [[ -f $i.bak ]]; then
                    mv -f $i.bak $i.bak.bak
                fi
                mv -f $i $i.bak
            done
            cp -f $bdev_driver"-"*.$2 $release_dir/bin_pkg
        fi
    fi
    popd >/dev/null
}

os_name=""
generated_pkg=0
check_and_optionally_build_driver_pkg() {
    # arg 1 - package suffix (deb or rpm)
    pkgname=$bdev_driver"-"$kver_with_patch
    if [[ "$1" = "rpm" ]]; then
        # for centos/redhat, there may be customized/extra kernel version strings
        pkgname=$pkgname$kver_centos_extra
    fi
    pkgname=$pkgname"-"$svn_rev
    # always look for a matching binary package first
    pkgs=($(ls bin_pkg/*/*.$1 2>/dev/null | grep $pkgname))
    pkg_cnt=${#pkgs[@]}
    if [[ $pkg_cnt -ge 1 ]]; then
        # found match(es) in the binary package folder - we'll use it.
        blkdriver_pkg_file=${pkgs[0]}
        os_name=${blkdriver_pkg_file#*/}
        os_name=${os_name%%/*}
    else
        # no matching binary pkg found, see if there is a locally built pkg
        pkgs=($(ls bin_pkg/*.$1 2>/dev/null | grep $pkgname))
        pkg_cnt=${#pkgs[@]}
        if [[ $pkg_cnt -eq 0 ]]; then
            # See if a srcrpm package could be built
            echo "\n$pkgname*.$1 package file not found; will try to build from src_pkg..."
            echo "Checking requisite build tools..."
            check_build_tools
            if [[ $chk_cmd_rc -ne 0 ]]; then
                echo "WARNING: Some build tools may be missing - sfx_srel build might fail.\n"
            fi
            #------------------------------------------------------------------------------
            # Validate the src_pkg by copying it into a tmp directory.
            # This tmp dir will be removed after installation step #5 is completed below
            #------------------------------------------------------------------------------
            src_rpm_tmpdir=$(mktemp -d --tmpdir=/tmp)
            cp -R $src_pkg_folder/* $src_rpm_tmpdir
            if [[ $? -ne 0 ]]; then
                echo "Failed to copy src_pkg files to temp folder; driver package would not be generated."
            fi
            #------------------------------------------------------------------------------
            # build package from src_rpm
            #------------------------------------------------------------------------------
            generate_pkg_from_src_rpm $src_rpm_tmpdir $1
            pkgs=($(ls bin_pkg/*.$1 2>/dev/null | grep $pkgname))
            pkg_cnt=${#pkgs[@]}
            if [[ $pkg_cnt -ne 1 ]]; then
                echo "ERROR: failed to find/build $pkgname*.$1 package file!"
                exit -42
            fi
        fi
        # found/built one or more packages - we'll pick the first matching one
        blkdriver_pkg_file=${pkgs[0]}
        generated_pkg=1
        os_name=$generic_os
    fi
    if [[ $pkg_cnt -eq 0 ]]; then
        echo "ERROR: failed to find/build $pkgname*.$1 package file!"
        exit -43
    elif [[ $pkg_cnt -gt 1 ]]; then
        echo "ERROR: too many matching ($pkg_cnt) $pkgname*.$1 package files found:"
        ( IFS=$'\n'; echo "${pkgs[*]}" )
        exit -44
    fi
}

unload_drivers() {
    local i
    local j
    local num_unloaded=0

    for ((j = 0; j < $num_drivers; j++)); do
        local cur_drv=${driver_unload_order[$j]}
        local ignore_fail=${driver_unload_ignore_failure[$j]}
        lsmod | grep -q "$cur_drv "
        if [[ $? -eq 0 ]]; then
            echo -n "Unloading driver module: $cur_drv... "
            if [[ $ignore_fail -eq 0 ]]; then
                for ((i=0; i<10; i++)); do
                    if ! rmmod $cur_drv; then
                        sleep 1
                    else
                        break
                    fi
                done
                if [[ $i -eq 10 ]]; then
                    echo "ERROR: Unable to remove $cur_drv"
                    echo $msg_todo
                    exit 255
                fi
            else
                # if ZFS locked wrapper, it can't be removed, but that's ok
                rmmod $cur_drv 2>/dev/null
            fi
            echo "Done."
            ((num_unloaded++))
        fi
    done
    # lastly, check and unload the virtual block driver
    lsmod | grep -q "$vdev_driver "
    if [[ $? -eq 0 ]]; then
        echo -n "Unloading driver module: $vdev_driver... "
        if ! rmmod $vdev_driver 2>/dev/null; then
            # echo "Warning: Unable to remove $vdev_driver; it will be replaced at the next reboot."
            need_probe_sfv=0
        else
            echo "Done."
            ((num_unloaded++))
        fi
    fi
    return $num_unloaded
}

remove_package() {
    if [[ $distro = "centos" ]]; then
        pkgs=`rpm -qa | grep sfx_`
        for i in $pkgs; do
            if [[ "$i" != "" ]]; then
                echo "Uninstalling driver package $i..."
                rpm -e $i
                if [[ $? -ne 0 ]]; then
                    return 1
                fi
            fi
        done
    else
        pkgs=`dpkg --list | grep $core_driver | awk '{print $2}'`
        if [[ "$pkgs" = "$core_driver" ]]; then
            echo "Uninstalling driver package $pkgs..."
            dpkg -P $pkgs
            if [[ $? -ne 0 ]]; then
                return 1
            fi
        fi
    fi
    return 0
}

#------------------------------------------------------------------------------
# 1. This has to be done first - remove sfx drivers pacakge
#------------------------------------------------------------------------------
need_probe_sfv=1
remove_package

#------------------------------------------------------------------------------
# 2. In case /etc/modprobe.d/sfx-modprobe.conf was installed by initcard.sh
#------------------------------------------------------------------------------
modprobeconfile=/etc/modprobe.d/sfx-modprobe.conf

if [[ -e $modprobeconfile ]]; then
    echo "Remove $modprobeconfile"
    rm -rf $modprobeconfile 1>/dev/null 2>&1
fi

#------------------------------------------------------------------------------
# 3. If the user asks to only uninstall sfx drivers pkgs and unload driver modules
#------------------------------------------------------------------------------
if [[ $uninstall_only = "y" ]]; then
    unload_drivers
    num_unloaded=$?
    if [[ -s $sysctlconfile ]]; then
        sed -i -e '/vm.min_free_kbytes=270336/d' $sysctlconfile
        sed -i -e '/^#vm.min_free_kbytes/s|#vm.min_free_kbytes|vm.min_free_kbytes|' $sysctlconfile
    fi
    if [[ $num_unloaded -eq 0 ]]; then
        echo "\nSuccessfully uninstalled SFX driver packages."
    else
        echo "\nSuccessfully uninstalled SFX driver packages and unloaded $num_unloaded driver modules."
    fi
    exit 0
fi

#------------------------------------------------------------------------------
# 4. Install sfx drivers packages
#------------------------------------------------------------------------------
# Pre-check and optionally install the pacakge's dependency .so libs
check_dependent_libs
# Check and optionally build the package from src rpm
check_and_optionally_build_driver_pkg $pkg_suffix

if [[ ! -f $blkdriver_pkg_file ]]; then
    echo "ERROR: failed to find/build $pkgname*.$pkg_suffix package file!"
    exit -45
fi

# Check if there are at least 50MB free space in the root file system ("/")
min_space_mb=50
max_wait=3
for ((i = 0; i < $max_wait; i++)); do
    root_avail_size=($(df -B 1M -P / | grep -e '/$'))
    if [[ ${root_avail_size[3]} -gt $min_space_mb ]]; then
        break;
    fi
    sleep 1
done
if [[ $i -eq $max_wait ]]; then
    echo ""
    echo "warning: The root file system ("/") has less than $min_space_mb MB of space left, the installation may fail."
    df -B 1M -P /
    echo ""
fi

echo "Installing driver package $blkdriver_pkg_file..."
$pkg_cmd $pkg_install_opt $blkdriver_pkg_file
sleep 1

# Remove auto-load config files to disable auto-load on reboot
if [[ $autoload = n ]]; then
    echo "Disabling driver modules auto-load on reboot..."
    case $generic_os in
        generic-centos6)    rm -f /etc/sysconfig/modules/sfx.modules ;;
        generic-centos7)    rm -f /etc/modules-load.d/sfx.conf ;;
        generic-ubuntu)     sed -i '{/^sfxdriver/d;/^sfv/d;/^sfx_bd_dev/d}' /etc/modules ;;
        generic-debian)     sed -i '{/^sfxdriver/d;/^sfv/d;/^sfx_bd_dev/d}' /etc/modules ;;
    esac
fi

# update module dependency database
depmod -a

#------------------------------------------------------------------------------
# 5. Install modprobe conf file
#------------------------------------------------------------------------------
drvparam=""
blkparam=""

if [[ ! -z $sfxparam_file ]]; then
    while read -r line; do
        mod=`echo $line | awk '{print $1}'`
        param=`echo $line | awk '{print $2}'`
        # echo "line $line, param $param"
        if [[ "$mod" = "drv" ]]; then
            if [[ "$drvparam" = "" ]]; then
                drvparam="$param"
            else
                drvparam="$drvparam $param"
            fi
        fi
        if [[ "$mod" = "blk" ]]; then
            if [[ "$blkparam" = "" ]]; then
                blkparam="$param"
            else
                blkparam="$blkparam $param"
            fi
        fi
    done < "$sfxparam_file"
fi

if [[ -e $modprobeconfile ]]; then
    if [[ -n "$drvparam" ]]; then
        sed -i -e "/sfxdriver.ko/s|sfxdriver\.ko|sfxdriver\.ko $drvparam|" $modprobeconfile
        if [[ $? -eq 0 ]]; then
            echo "$modprobeconfile is successfully modified with drvparam $drvparam"
        else
            echo "Failed to modify $modprobeconfile with drvparam $drvparam"
        fi
    fi
    if [[ -n "$blkparam" ]]; then
        sed -i -e "/sfx_bd_dev.ko/s|sfx_bd_dev\.ko|sfx_bd_dev\.ko $blkparam|" $modprobeconfile
        if [[ $? -eq 0 ]]; then
            echo "$modprobeconfile is successfully modified with blkparam $blkparam"
        else
            echo "Failed to modify $modprobeconfile with blkparam $blkparam"
        fi
    fi
else
    echo "ERROR: $modprobeconfile is not installed, no parameter can be passed to sfx driver"
    exit -50
fi

if [[ -s $sysctlconfile ]]; then
    mfkbytes_line=`grep vm.min_free_kbytes $sysctlconfile`
    if [[ -z "$mfkbytes_line" ]]; then
        echo "vm.min_free_kbytes=270336" >> $sysctlconfile
        # echo "$sysctlconfile is successfully added for vm.min_free_kbytes"
    else
        mfkbytes=`echo "${mfkbytes_line//[!0-9]/}"`
        # echo "mfkbytes $mfkbytes"
        if [[ $mfkbytes -lt 270336 ]]; then
            sed -i -e '/^vm.min_free_kbytes/s|vm.min_free_kbytes|#vm.min_free_kbytes|' $sysctlconfile
            echo "vm.min_free_kbytes=270336" >> $sysctlconfile
            # if [[ $? -ne 0 ]]; then
            #     echo "WARNING: cannot set vm.min_free_kbytes=270336 in existing $sysctlconfile"
            # else
            #     echo "$sysctlconfile is successfully modified for vm.min_free_kbytes"
            # fi
        fi
    fi
else
    echo "vm.min_free_kbytes=270336" > $sysctlconfile
fi

#------------------------------------------------------------------------------
# 6. Clean up possible src rpm build artifacts
#------------------------------------------------------------------------------
cd $release_dir
if [[ "" != "$src_rpm_tmpdir" ]]; then
    rm -rf $src_rpm_tmpdir
fi

#------------------------------------------------------------------------------
# 7. If user asks to only do the install, then we're done.
#------------------------------------------------------------------------------
if [[ "$only_install_pkg" = "y" ]]; then
    echo "\nSFX driver package installed successfully. Please reboot the system."
    exit 0
fi

#------------------------------------------------------------------------------
# 8. Unload all sfx drivers and modprobe the core and virtual drivers
#------------------------------------------------------------------------------
# unload driver - with the possibility of persistent sfv.ko, I/O will be paused!!!
ref_cnt=`lsmod | sed -n "/^sfv\>/"p | awk '{print $3}'`
if [[ $ref_cnt -gt 1 ]]; then
    build_ver=`css-status.sh | grep "Software Revision" | head -n 1 | awk '{print $3}' | awk -F '-' '{print $2}'`
    if [[ $build_ver -lt 48129 ]]; then
        echo
        echo "!!!The installed sfv driver is not compatible. Please reboot to load the new drivers."
        exit -60
    fi
fi

nvmepath=""
devices=""
pci_num=0
source /usr/bin/sfx_functions
get_cmd_path sfx_nvme nvmepath
if [[ $? -eq 0 ]]; then
    get_cmd_path nvme nvmepath
    if [[ $? -eq 0 ]]; then
        echo "nvme command not found, please 'yum install nvme-cli' and run this script again"
        exit 2
    fi
fi
pci_num=$(lspci -d cc53:0001 | sed -n '$=')
devices=`ls /dev/sfd[0-9]*n1 2>/dev/null | tr '\n' ' '`
# get current power cycle and unsafe shutdwon counter
j=0
for i in $devices; do
     power_cycle[$j]=`$nvmepath smart-log $i 2>/dev/null | grep power_cycle | awk -F ':' '{printf $2}'`
     unsafe_shutdowns[$j]=`$nvmepath smart-log $i 2>/dev/null | grep unsafe_shutdowns | awk -F ':' '{printf $2}'`
    (( j++ ))
done

unload_drivers

# probe the sfxdriver first
echo -n "modprobe $core_driver... "
modprobe $core_driver
if [[ "$(lsmod | grep -m 1 -oe "^$core_driver")" != $core_driver ]]; then
    echo "ERROR: modprobe $core_driver failed!"
    exit -80
else
    echo "Done."
fi

if [[ $need_probe_sfv -ne 0 ]]; then
    echo -n "modprobe $vdev_driver... "
    modprobe $vdev_driver
    if [[ "$(lsmod | grep -w -m 1 -oe "^$vdev_driver")" != $vdev_driver ]]; then
        echo "ERROR: modprobe $vdev_driver failed!"
        exit -81
    else
        echo "Done."
    fi
fi

sleep 1

if [[ $pci_num -gt 0 ]]; then
echo
echo 'SFX device(s) created:'
echo '======================'
ls -1 /dev/sfx[0-9]* 2>/dev/null
echo
fi

if [[ "$modprobe_coredriver_only" = "y" ]]; then
    exit 0
fi

echo 270336 > /proc/sys/vm/min_free_kbytes

#------------------------------------------------------------------------------
# 9. Modprobe the sfx_bd_dev driver
#------------------------------------------------------------------------------
echo "modprobe $bdev_driver... "
modprobe $bdev_driver
lsmod | grep -q "$bdev_driver "
if [[ $? -ne 0 ]]; then
    echo "ERROR: modprobe $bdev_driver failed!"
    exit -90
else
    echo "Done."
fi

# set current power cycle and unsafe shutdwon counter
j=0
for i in $devices; do
    $nvmepath smart-log $i -p ${power_cycle[$j]} -s ${unsafe_shutdowns[$j]} 2>/dev/null
    (( j++ ))
done



#------------------------------------------------------------------------------
# 10. Tell the user what devices have been installed.
#------------------------------------------------------------------------------
lsblk_ver=$($pkg_cmd $pkg_query_opt 2>/dev/null | grep -m 1 util-linux | grep -oE '[0-9]+\.[0-9]+' | head -1 | sed -r 's/([0-9]+)/0000\1/g; s/0*([0-9]{4})/\1/g')
if [[ "$lsblk_ver" > "0002.0022" ]]; then
    # lsblk from util-linux package version 2.23 and on supports the '-p' "print devicepath" option
    lsblk_opt="-d -p"
else
    # lsblk from util-linux package version 2.22 and older does not supports the '-p' option
    lsblk_opt="-d"
fi

if [[ $pci_num -gt 0 ]]; then
echo
echo 'SFX Block device(s) created:'
echo '============================'
lsblk $lsblk_opt | grep -E 'MOUNTPOINT|sfd[0-9]'
echo

# wait for a max of 120 seconds for the css* devices to come online. 3rd arg=0 means be quiet.
wait_probe_dev /dev/css0 300 1

echo
echo 'SFX CSS device(s) created:'
echo '=========================='
ls -1 /dev/css* 2>/dev/null
echo
fi

#------------------------------------------------------------------------------
# 11. Check if any card is gold image
#------------------------------------------------------------------------------
check_gold_img() {
    if [[ $pci_num -gt 0 ]]; then
    for ((i = 0; i < $pci_num; i++)); do
        local device="/dev/sfd${i}n1"
        if [[ -e "/sys/class/misc/sfx${i}/device/goldimg" ]]; then
            gold_img=y
        else
            gold_img=n
        fi
        # Get card info
        card=/sys/block/sfd${i}n1
        sn=$(strings $card/serial)
        fw=$(strings $card/firmware_rev 2>/dev/null | sed 's/^0*//')
        if [[ $gold_img = 'y' ]]; then
            echo
            echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
            echo "WARNING: $device SN: $sn is a Gold Image Card. Please contact admin for help."
            echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
            echo
        else
            echo "Device $device : sn=$sn fw=$fw sw=`strings $card/software`"
        fi
    done
    fi
}

check_gold_img

exit 0
