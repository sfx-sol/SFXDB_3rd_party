// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_os_headers.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_OS_HEADERS_H__
#define __SFX_OS_HEADERS_H__

#if defined(SFX_LINUX)

#include "sfx_os_headers_linux.h"

#elif defined(VMKERNEL)

#include "sfx_os_headers_esx.h"

#else

#pragma message "OS not defined ..."

#endif

#endif // __SFX_OS_HEADERS_H__
