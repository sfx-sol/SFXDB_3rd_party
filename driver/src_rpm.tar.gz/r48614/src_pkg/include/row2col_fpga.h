// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : row2col_fpga.h
//
// ---------------------------------------------------------------------------

#ifndef __ROW2COL_FPGA_H__
#define __ROW2COL_FPGA_H__

// This header files only needed when released to customers
//#include <stdint.h>

// This header file would be eliminated when released to customers
//#include "row2col.h"

#ifdef __cplusplus
extern "C" {
#endif

//#define RCDBUG (1)
//#define NEW_FEATURE_DEBUG
//#define SCHEMA_DEBUG

#define R2C_MAX_COL                     (1024)
#define R2C_MAX_ARRAY_SIZE              (1024)
#define R2C_PAGE_SIZE                   (4096)
#define R2C_PAGE_SHIFT                  (12)
#define R2C_PAGE_MASK                   (0x00000FFF)
#define R2C_BUF_SEG                     (64)    // 64: 1MB
#define R2C_PAGE_SEG                    (256)   // 256: 1MB
#define R2C_MAX_DCE                     (655360)
#define R2C_MAX_SCHEMA_ID               (16)
#define R2C_MAX_SCHEMA                  (16)
#define R2C_MAX_SESSION                 (8)
#define SESSION_BIT_NUM                 (3)
#define MAX_MEM_LOCK                    (1024<<20)
#define R2C_MAX_CID_ARRAY_INDEX         (30)
#define R2C_MAX_NVME_ARRAY_SIZE         (1024)
#define R2C_COMBINE_SIZE                (1048576)
#define NVME_READ_THRESHOLD_HIGH        (48)
#define DCE_N2B_THRESHOLD_HIGH          (160)
#define NVME_READ_THRESHOLD_LOW         (32)
#define DCE_N2B_THRESHOLD_LOW           (96)
#define RC_MAX_COND_NUM                 (16)
#define RC_MAX_IN_COND_NUM              (8)
#define RC_MAX_IN_ELEMENTS              (16)
#define RC_MAX_COND_CONST_LEN           (32)
#define RC_MAX_COND_LEN_NORMAL          (6 + RC_MAX_COND_CONST_LEN)
#define RC_MAX_ROW_FILTER_LEN_NORMAL    (RC_MAX_COND_LEN_NORMAL * RC_MAX_COND_NUM)
#define RC_MAX_COND_LEN_IN              (6 + (2 + RC_MAX_COND_CONST_LEN) * RC_MAX_IN_ELEMENTS)
#define RC_MAX_ROW_FILTER_LEN           (RC_MAX_IN_COND_NUM * RC_MAX_COND_LEN_IN + (RC_MAX_COND_NUM - RC_MAX_IN_COND_NUM) * RC_MAX_COND_LEN_NORMAL)
#define RC_MAX_IN_LEN_COPY              ((((RC_MAX_COND_CONST_LEN + 2) * RC_MAX_IN_ELEMENTS) * RC_MAX_IN_COND_NUM) + \
                                        RC_MAX_IN_COND_NUM * RC_MAX_IN_ELEMENTS + RC_MAX_IN_ELEMENTS * 2)
#define R2C_MAX_CMD_CNT                 (768)
#define R2C_MAX_BUF_LEN                 (64 << 20) // 64MB
#define R2C_MAX_QUEUE_CMD_CNT           (1000)
#define R2C_MAX_PBA_LIST_SIZE           (16)
#define RC_TIME_OUT_US                  (2500000)
#define RC_MASK_MSB_64                  (0x7FFFFFFFFFFFFFFF)

#define RC_NVME_READ_ONE_MB             (32)
#define RC_DCE_N2B_THRES                (RC_NVME_READ_ONE_MB * 4)
#define RC_NVME_READ_THRES              (RC_NVME_READ_ONE_MB * 4)
#define RC_DCE_N2B_DRIVER_THRES         (RC_NVME_READ_ONE_MB * 4)
#define RC_NVME_READ_DRIVER_THRES       (RC_NVME_READ_ONE_MB * 4)

#define RC_LOCK_MEM_LEN                 (3 + (2 * RC_NVME_READ_THRES + RC_NVME_READ_DRIVER_THRES) * 2 / R2C_BUF_SEG)

#define RC_MAX_COMP_COL_LEN             (1 << 24)
#define INVALID_16BIT                   (0xFFFF)

#define SFXDB                           (128)

#ifndef SFX_LINUX
typedef vmk_uint8           uint8_t;
typedef vmk_uint16          uint16_t;
typedef vmk_uint32          uint32_t;
typedef vmk_uint64          uint64_t;
#endif

enum {
    SCHEMA_READ   = 1,
    SCHEMA_WRITE  = 2,
    SCHEMA_LIST   = 3,
    SCHEMA_DELETE = 4,
    SCHEMA_UPDATE = 5,
};

typedef enum {
    OK            = 0,
    NOT_COMPLETED = 1000, // skip the system error code
    NOT_EXIST     = 1001,
    ERROR         = 1002,
} sfxStatus;

typedef enum {
    R2C_NO_ERROR = 0,
    R2C_COMPLETED = 0,
    R2C_SEND_ALL,
    R2C_SEND_NVME_READ,
    R2C_SEND_NVME_READ_N2B,
    R2C_SEND_DCE_N2B,
    R2C_SEND_N2B,
    R2C_RETRY_SHORT_WAIT,
    R2C_RETRY_LONG_WAIT,
    R2C_RETRY_SUBMIT_CMD,
    R2C_SEND_LEFT_CMD,
    R2C_PENDING,
    R2C_CONTINUE,
    R2C_SEND_NVME_READ_BACKUP,
    R2C_SEND_N2B_BACKUP,
    R2C_TIME_OUT,
    R2C_ECC_ERROR,
    R2C_BUF_OVERFLOW,
    R2C_VLEN_ERROR,
    R2C_DEV_NOT_FOUND,
    R2C_INPUT_INVALID,
    R2C_NO_MEMORY,
    R2C_INTERNAL_ERROR,
    R2C_KEY_OVERFLOW,
    R2C_ROW_OVERFLOW,
    R2C_ASYNC_SEND_COMPLETED,
    R2C_SESSION_UNAVAILABLE,
    R2C_INVALID_REQUEST,
    R2C_ENG_HANG,
    R2C_UNKNOWN_ERROR,
    R2C_DECOMP_ERROR,
    R2C_WAIT_IN_HANG,
    R2C_BAD_BLOCK_CRC,
    R2C_RESERVED = 0xFFFFFF,
} r2cStatus;

typedef enum {
    PK_VALUE,
    SK_PK,
} rc_row_format;

typedef enum {
    KEY,
    VALUE,
} sc_schema_part;

typedef enum {
    RC_SUCCESS       = 0,
    RC_FAIL          = 1,
    RC_ILLEGAL       = 20,
    RC_DB_TOO_LARGE  = 21,
    RC_NOT_SUPPORT   = 22,
} rc_return_result;

typedef struct {
    uint8_t  row_format;
    uint64_t key_meta;
    uint64_t val_meta;
    uint16_t key_col_num;
    uint16_t val_col_num;
    uint16_t tbl_field_num;
    uint8_t  *kv_bitmap;
    uint8_t  *val_col_map;
    uint32_t *schema;
    uint32_t filter_buf_len;
    uint8_t  *filter_buf_normal;
    uint8_t  *filter_buf_in;
    uint8_t  cond_num;
    uint8_t  in_cond_num;
    uint8_t  max_in_elem;
    uint32_t in_cond_buf_len;
} rc_schema_trans_t;

void free_schema_trans(rc_schema_trans_t *schema_trans);

int css_col_schema(uint8_t    css_dev_id,
                   uint8_t    sid,
                   uint64_t   key_meta,
                   uint64_t   val_meta,
                   uint32_t   ncol,
                   uint8_t    *col_vld,
                   uint8_t    *val_col_map,
                   uint32_t   *col_type,
                   uint32_t   nblk,
                   uint8_t    cond_num,
                   uint8_t    *filter_buf);

r2cStatus css_col_read_fpga(const char *css_dev,
                            void       *schema_trans,
                            uint32_t   ncol,
                            uint32_t   nlba,
                            uint64_t   *lbabuf,
                            uint32_t   lba_unit_size,
                            uint32_t   nblk_t,
                            uint32_t   nblk,
                            uint64_t   *blkbuf,
                            void       *hbabuf,
                            uint32_t   hba_length,
                            uint8_t    is_sync,
                            uint64_t   *sid,
                            uint32_t   *retn_length);

int css_col_read(const char *css_dev,
                 void       *schema_trans,
                 uint32_t   ncol,
                 uint32_t   nlba,
                 uint64_t   *lbabuf,
                 uint32_t   lba_unit_size,
                 uint32_t   nblk,
                 uint64_t   *blkbuf,
                 void       *hbabuf,
                 uint32_t   hba_length,
                 uint32_t   *retn_length);

r2cStatus css_query_status(const char *dev_id,
                           uint64_t   sid,
                           uint64_t   *user_buf,
                           uint32_t   *ret_len);

void *rc_malloc(uint32_t size, uint8_t value);

// OP code for hardware
typedef enum {
    RC_OP_RESERVED      = 0,
    RC_OP_IS_NULL       = 1,
    RC_OP_IS_NOT_NULL   = 2,
    RC_OP_EQ_COL        = 3,
    RC_OP_NE_COL        = 4,
    RC_OP_GT_COL        = 5,
    RC_OP_GTE_COL       = 6,
    RC_OP_LT_COL        = 7,
    RC_OP_LTE_COL       = 8,
    RC_OP_EQ_VAL        = 9,
    RC_OP_NE_VAL        = 10,
    RC_OP_GT_VAL        = 11,
    RC_OP_GTE_VAL       = 12,
    RC_OP_LT_VAL        = 13,
    RC_OP_LTE_VAL       = 14,
    RC_OP_LIKE          = 15,
    RC_OP_NOT_LIKE      = 16,
    RC_OP_FEQ_COL       = 17,
    RC_OP_IN            = 18,
} rc_filter_op;

static const uint8_t rc_opcode_trans[46] = {
    0,  3,  17, 4,  5,  6,  7,  8,
    0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  9,  9,  10,
    11, 12, 13, 14, 0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,
    0,  1,  2,  0,  0,  18
};

#ifdef __cplusplus
}
#endif

#endif // __ROW2COL_FPGA_H__
