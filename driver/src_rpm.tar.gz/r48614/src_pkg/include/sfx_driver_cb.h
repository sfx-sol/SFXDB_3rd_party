// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_driver_cb.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_DRIVER_CB_H__
#define __SFX_DRIVER_CB_H__

#include "sfx_os_headers.h"

struct sfx_dev;

struct sfx_driver
{
    struct sfx_list_head    node;
    struct sfx_list_head    probe_done_list;
    struct sfx_list_head    probe_fail_list;
    struct sfx_list_head    probe_pre_list;
    struct sfx_list_head    probe_ing_list;
    sfx_spinlock_t          probe_list_lock;
#ifdef SFX_BD_DRIVER_TEST
    char                    name[20];   // e.g. sfx_bd_dev
#else
    const char              *name;      // e.g. sfx_bd_dev
#endif
    int (*probe)(char *dfname, int nid, void *bd_param, void *ftx_mq_ctx);
    int (*remove)(ftl_mq_ctx *mq_ctx, int keep_disk);
    int (*shutdown)(ftl_mq_ctx *mq_ctx, int keep_disk);
    int (*suspend)(struct sfx_dev *dev);
    int (*cmpl_cb)(void *ftlctx, void *cqe);
    int (*resume)(struct sfx_dev *dev);
    int (*err_handler)(struct sfx_dev *dev);
    int (*dev_gone)(char *dfname);
    int (*empty_query)(void *ptr);
    void (*check_osd_req)(ftl_mq_ctx *mq_ctx);
};

int sfx_register_driver(struct sfx_driver *drv);
int sfx_dev_probe_thread(void *dev);
int sfx_unregister_driver(struct sfx_driver *drv);
void sfx_wait_probe_finish(struct sfx_driver *drv);

#endif // __SFX_DRIVER_CB_H__
