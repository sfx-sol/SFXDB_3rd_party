// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_types.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_TYPES_H__
#define __SFX_TYPES_H__

#include "sfx_os_headers.h"
#include "sfx_gendefs.h"

#ifndef __KERNEL__

// user-space setting
#include <stdint.h>
#include <pthread.h>
#include <assert.h>

#define SFX_ASSERT(a)                           assert(a)

/* The symbol CLOCK_MONOTONIC_RAW is missing from older versions of
 * GLIBC, and we want to be able to compile across versions.
 * SFX_TYPES may not be the best place for this, but it's a good
 * start */
#if (__GLIBC__<2) || ((__GLIBC__== 2 ) && (__GLIBC_MINOR__ < 19 ))
#define SFX_CLOCK_DEFAULT                       CLOCK_MONOTONIC
#else
#define SFX_CLOCK_DEFAULT                       CLOCK_MONOTONIC_RAW
#endif

typedef int8_t      xt_8;
typedef int16_t     xt_16;
typedef int32_t     xt_32;
typedef int64_t     xt_64;
typedef uint8_t     xt_u8;
typedef uint16_t    xt_u16;
typedef uint32_t    xt_u32;
typedef uint64_t    xt_u64;

#endif // for user-space

#ifdef __cplusplus
extern "C" {
#endif

#define PCI_VENDOR_ID_SFX                       0xcc53

#define CFG_UNIT_PAGE_SIZE                      (4096)  // upage=4KB, minumum HW access unit
#define TSB_MAPPAGE_NUM                         (4)     // 4x1k mem_id

#define INVALID_32BIT                           ((unsigned int)(~0))
#define INVALID_64BIT                           ((unsigned long int)(~0))
#define INVALID_FIFO_DATA                       0xDEADBEEF

#define DEBUG_ASSERT 1
#define DEBUG_RANGE_TRIM                        (0)
#define SEQ_RD_DETECT                           (1)
#define ENABLE_BLK_FTL
#define PENDING_TAIL                            (1)
#define TRIM_PF_SUPPORT
#define SURPRISE_REMOVE_DEBUG                   (0)

#define NEW_MAPLOG_DEBUG                        (0)
#define NEW_MAPLOG_DEBUG_LESS                   (0)
#define NEW_MAPLOG_DEBUG_BLK                    (0)
#define NEW_MAPLOG_DEBUG_ML                     (0)
#define NEW_MAPLOG_DEBUG_RD_ML                  (0)
#define NEW_MAPLOG_DEBUG_GATHER                 (0)
#define NEW_MAPLOG_DEBUG_REBUILD                (0)
#define NEW_MAPLOG_PF_DEBUG                     (0)
#define NEW_MAPLOG_WP                           (0)

#define SFX_BLK_FTL_IOCTL_GET_EUID              _IOWR('N', 0x222, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_EUID_SIZE         _IOWR('N', 0x223, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_RECOVER           _IOWR('N', 0x224, unsigned long)
#define SFX_BLK_FTL_IOCTL_SET_KV                _IOWR('N', 0x225, unsigned long)
#define SFX_BLK_FTL_IOCTL_LINK_BLOCK            _IOWR('N', 0x226, unsigned long)
#define SFX_BLK_FTL_IOCTL_UNLINK_BLOCK          _IOWR('N', 0x227, unsigned long)
#define SFX_BLK_FTL_IOCTL_SET_LLSID             _IOWR('N', 0x228, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_BLOCK_SIZE        _IOWR('N', 0x229, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_LBA               _IOWR('N', 0x230, unsigned long)
#define SFX_BLK_FTL_IOCTL_RECORD_STREAM         _IOWR('N', 0x231, unsigned long)
#define SFX_BLK_FTL_IOCTL_CLEAN_META            _IOWR('N', 0x233, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_OPEN_EUID          _IOR('N', 0x234, unsigned long)
#define SFX_PU_ALLOCATION                       _IOWR('N', 0x225, sfx_pu_res)
#define SFX_PU_DEALLOCATION                      _IOR('N', 0x226, unsigned long)
#define SFX_BLK_FTL_IOCTL_WRITE                 _IOWR('N', 0x237, unsigned long)
#define SFX_BLK_FTL_IOCTL_NVM_RECOVER           _IOWR('N', 0x238, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_NS_RECOVER        _IOWR('N', 0x239, unsigned long)

// this is the FTL VU command code definition
#define SFX_BLK_FTL_VU_CMD                      _IOWR('N', 0x23a, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_MOD_PARAM			_IOWR('N', 0x23b, unsigned long)
#define SFX_BLK_FTL_IOCTL_GET_BB_TABLE			_IOWR('N', 0x23c, unsigned long)

#define KV_DEBUG                                0

// Define BIT
#define SFX_8BITS                               (8)
#define SFX_16BITS                              (16)
#define SFX_32BITS                              (32)
#define SFX_64BITS                              (64)
#define SFX_BIT_NUM_XT_U8                       SFX_8BITS
#define SFX_BIT_NUM_XT_U16                      SFX_16BITS
#define SFX_BIT_NUM_XT_U32                      SFX_32BITS
#define SFX_BIT_NUM_XT_U64                      SFX_64BITS

// blk ftl features flags
#define ENABLE_METADATA_FLUSH                   1
#define ENABLE_SBLK0                            1
#define ENABLE_FREE_SPACE_OPTIMIZE              1
// Triphora plus will guarantee buffer to nand flush
// during pfail, we don't need the feature check anymore
#define ENABLE_BUFFER_TO_NAND_DONE_CHECK        0
#define ENABLE_GRACEFUL_POWER_OFF               2   // 2 = no insert power off, 1 = graceful power off with pfail supported
#define ENABLE_SIMULATE_POWER_FAIL              0   // 1 = skip all saving l2p, 2 = all power fail case cover

// debug flags for blk ftl
// unit test flags
#define ENABLE_GC_TRIGGER_FASTER                0//retired, use fast_cycle_mode instead
#define FAST_CYCLE_BLOCK_NUM                    48
#define ENABLE_UNIT_TEST                        0
#define ENABLE_MALLOC_SINGLE_LBA_LIST           0   // enable for unit test only
#define ENABLE_BLK_FTL_LOOP_BACK                0
#define MEASURE_TIME                            0
#define ENABLE_FTL_MONITER                      1

// rebuild test flag setting
#define ENABLE_REBUILD_TEST                     0
#define ENABLE_SPECIFIC_CRASH_POINT             0
#define DEBUG_CRASH_POINT                       FM_PFAIL_FLUSH_L2P_TABLE2
#define ENABLE_FILL_UP_DRIVE_BEFORE_REBUILD_TEST    0
#define ENABLE_DUC_GRACEFUL_SHUTDOWN_TEST       0
#define ENABLE_VERIFY_BEFORE_POWER_CYCLE        0
#define ENABLE_CCS_MEM_LEAK_LOOP                0
#define ENABLE_BLK_FTL_MEM_LEAK_LOOP            0
#define ENABLE_TOTAL_POWER_CYCLE_TEST_LOOP      1000000
#define ENABLE_ALL_LBA_PRINT_FOR_DEBUG          0
#define ENABLE_VERIFY_REVERSE_LBA               0
#define ENABLE_DATA_COMPARE_DEBUG               0
#define ENABLE_VERIFY_FREE_SPACE                0

#define DEBUG_TRIM_PF                           0
#define DEBUG_LBA                               (0xffffffff)
#define DEBUG_LBA_START                         (0x0)
#define DEBUG_LBA_END                           (0xf)
#define DEBUG_MEM_ID                            5
#define DEBUG_START_OFFSET                      0x0
#define DEBUG_END_OFFSET                        0x1f

#define ENABLE_NORMAL_TEST                      0
#define ENABLE_NORMAL_TRIPHORA_PLUS_TEST        0
#define ENABLE_MULTI_THREAD_TEST                0
#define ENABLE_WEAR_LEVELING_UNIT_TEST          0
#define ENABLE_FIXED_START_LBA                  0
#define ENABLE_WEAR_LEVELING_TRIGGER_FASTER     0
#define ENABLE_UNIT_TEST_FAST_CYCLE             0
#define ENABLE_SYSTEM_TABLE_TEST                0
#define ENABLE_MULTI_THREAD_TEST                0
#define ENABLE_VERIFY_MAP_LOG_TEST              0
#define ENABLE_GC_VERIFY                        0   // turn on can cause data miscompare if gc is on and do read verify
#define ENABLE_GC_VERIFY_BEFORE_SEAL 0
#define ENABLE_OVERNIGHT                        0
#define ENABLE_LOGGING                          0
#define ENABLE_VERIFY_MEM_ID                    0
#define ENABLE_LBA_LIST_TEST                    0
//unit tests inside normal code
#define ENABLE_GC_VERIFY_WRITE_BUFF             0
#define ENABLE_DEBUG_REVERSE_LBA                0
#define ENABLE_DEBUG_BLK_FTL_LOOPBACK           0
#define ENABLE_DEBUG_MAP_LOG                    0
#define ENABLE_UNALIGN_TRIM_DEBUG               0
#define ENABLE_TRIM_DEBUG                       0
#define ENABLE_PRINT_FOOTER                     0
#define ENABLE_SEAL_EARLY_TEST                  0
//end debug flag
#define MAX_PLANE_DIS                           (16)   // 4 plane: 16 possibilities
#define MAX_SIZE_PER_CH                         (16)
#define MU_L06B                                 (0)    // NAND_MU_L06B
#define TSB_BICS                                (1)    // NAND_TSB_BiCS
#define MU_B17A                                 (2)    // NAND_MU_B17A

#define PCB_PUMA_AB                             (0)
#define PCB_LYNX_A                              (1)
#define PCB_PUMA_C                              (2)
#define PCB_LYNX_B                              (3)
#define PCB_PANTHER_A                           (4)
#define PCB_LEOPARD                             (5)

#define BOARD_REV_A                             (0)
#define BOARD_REV_B                             (1)


//value is in Gigabyte
#define CAPACITY_16TB                           (1600)
#define CAPACITY_19TB                           (1920)
#define CAPACITY_20TB                           (2000)
#define CAPACITY_32TB                           (3200)
#define CAPACITY_38TB                           (3840)
#define CAPACITY_40TB                           (4000)
#define CAPACITY_64TB                           (6400)
#define CAPACITY_77TB                           (7680)
#define CAPACITY_80TB                           (8000)
#define CAPACITY_128TB                          (12800)
#define CAPACITY_154TB                          (15400)
#define CAPACITY_160TB                          (16000)

#define CASE_VARIANT_16TB                       case CAPACITY_16TB: case CAPACITY_19TB: case CAPACITY_20TB
#define CASE_VARIANT_32TB                       case CAPACITY_32TB: case CAPACITY_38TB: case CAPACITY_40TB
#define CASE_VARIANT_64TB                       case CAPACITY_64TB: case CAPACITY_77TB: case CAPACITY_80TB
#define CASE_VARIANT_128TB                      case CAPACITY_128TB: case CAPACITY_154TB: case CAPACITY_160TB

#define PUMA_16T_OPN_START                      (7)
#define PUMA_16T_OPN_END                        (9)
#define PUMA_SETTING_OPN_THRD                   (20)    // decimal

#define MAX_1_6TB_IN_GB                         2008
#define MAX_3_2TB_IN_GB                         4016
#define MAX_6_4TB_IN_GB                         8032
#define MAX_12_8TB_IN_GB                        16064

/******* multi-nvme queue define *******/
#define SFX_DRIVER_PREALLOC_QUEUE               (1)     // sfx_driver only preallocates admin queue
#define SFX_LINUX_MQ_DEPTH                      (1024)
#define HOT_IO_QD                               (1024 + 128)
#define MIX_WR_PADDING_RSVD                     (496)   //max parity group;
#define COLD_IO_QD                              (256)
#ifdef SFX_LINUX
#define NVME_MAX_OUTSTAND_WR_CMD                (HOT_IO_QD - 256)
#define NVME_MAX_OUTSTAND_RD_CMD                (HOT_IO_QD)
#define NVME_MAX_RSVD_RD_CMD                    (512)
#else
#define NVME_MAX_OUTSTAND_WR_CMD                (HOT_IO_QD)
#define NVME_MAX_OUTSTAND_RD_CMD                (HOT_IO_QD - 128)
#define NVME_MAX_RSVD_RD_CMD                    (NVME_MAX_OUTSTAND_RD_CMD - 128)
#endif

#define RETRY_FIFO_DEPTH                        (8*HOT_IO_QD)
#define MAX_STREAM_SUPPORT                      (4)
#define SFX_STREAM_ID                           (0)     // Only for single stream version
#define STREAM_ID_MIX_WR                        (MAX_STREAM_SUPPORT)
#define STREAM_ID_COLD_CHEPT                    (STREAM_ID_MIX_WR + 1)
#define STREAM_ID_WL                            (3)
/* queue id define */
#define QID_ADMIN                               (0)
#define QID_MIX_WR                              (1)
#define QID_MIX_RD                              (2)
#define QID_ERASE                               (3)
#define QID_WL                                  (4)
#define QID_CHEPT                               (5)     // cold stream checkpoint write queue
#define NON_IO_QUEUE                            (QID_CHEPT + 1)
#define HOT_RD_QID_BASE                         (NON_IO_QUEUE)  // eight compression queues allocated following IO queues
#define QID_OFF_B2N                             (0)
#define QID_OFF_META                            (1)
#define QID_OFF_WR_BASE                         (2)
#define MAX_HOT_WR_Q                            (128)
/*******  end of multi-nvmeq define *******/

#define MAX_NUM_COMP_ENG                        (4)
#define MAX_EC_QUEUE                            (2)
// TODO: Move all R2C related macros into an indpendent header file
#define R2C_MAX_SESSION                         (8)
#define MAX_R2C_QUEUE                           (R2C_MAX_SESSION * 2)
#define TOT_QUEUE                               (127 - MAX_R2C_QUEUE - 2)   /* 128 queue in total, one queue reserved for utility*/
#define MAX_SESSION_PER_ENG                     (64)
#define MAX_NUM_COMPSESSION                     (MAX_SESSION_PER_ENG * MAX_NUM_COMP_ENG)
#define BA_WK_PER_QUE                           (0x4)
#define BA_WK_ID_MASK                           (0x3)
/******* parallel unit define *********/
#define SFX_MAX_CHANNEL                         (16)    /* Maximal channel number per device */
#define SFX_MAX_SPT_DIE                         (1024)
#define SFX_MAX_PU                              (MAX_HOT_STREAM)     /* Maximal supported number of parallel unit */
#define PROG_LAT_PER_PAGE_MUL06B                (1500)  /* Typical program latency per page, in us */
#define READ_LAT_PER_PAGE_MUL06B                (100)   /* Typcial sensing latency per page, in us */
//adp:  ??? todo later
#define PROG_LAT_PER_PAGE_TSB                   (1500)  /* Typical program latency per page, in us */
#define READ_LAT_PER_PAGE_TSB                   (100)   /* Typcial sensing latency per page, in us */

#define LBA_MISMATCH_MAX                        (20)

#define SFX_HW_CHAN_BWTH                        (300)   /* Channel bandwith, in MB/s */
#define MAX_DIE_PER_CHAN                        (16)    /* Maximal die per channel */
#define PEAK_WR_THRPT_PUMA                      (2400)  /* Peak write throughput per device MB/s */
#define PEAK_RD_THRPT_PUMA                      (2800)  /* Pead read throughput per device MB/s  */
#define PEAK_WR_THRPT_LYNX                      (1800)  /* Peak write throughput per device, U.2, MB/s, may change later */
#define PEAK_RD_THRPT_LYNX                      (2800)  /* Pead read throughput per device, U.2, MB/s, may change later*/
/******* end of parallel unit define ******/

#define SFX_ADP_POLL                            (1)
#define MSIX_VECTOR_BIT_BASK_BASE               (0x200c)
/**** polling set ****/
#define MASK_POLL_ENABLE                        0x1
#define MASK_POLL_SMT                           0x2
#define MASK_POLL_BG                            0x4
#define MASK_INRT_MASK                          0x8

/* hot read performance tune */
#define LONG_LAT_TARGET                         (1000000000) // in ns, 1ms
#define DEFER_LAT_CHECK                         (256000000)  // in ns, 256ms
#define SFX_BLK_MAX_REQ                         (2048)
#define SFX_BLK_MAX_REQ_IN_4K                   (8192)

#ifdef __KERNEL__
#define HOT_READ_PERF                           (0)
#define HOT_WRITE_PERF                          (0)
#define MQ_CONFIG_DEBUG                         (0)
#define HOT_RD_DATA_DEBUG                       (0)
#define POLLING_DEBUG                           (0)
#define PERF_DEBUG                              (0)
#define HOT_RD_DEBUG                            (0)
#define DEBUG_DATA                              (0)
#define DRIVER_PRINT_NVME_CMD                   (0)
#define ADP_DEBUG                               (0)
#define TAIL_LAT_PERF                           (0)
#define READ_HW_LAT                             (0)
#else
#define PERF_DEBUG                              (0)
#define HOT_READ_PERF                           (0)
#define HOT_WRITE_PERF                          (0)
#define MQ_CONFIG_DEBUG                         (1)
#define HOT_RD_DATA_DEBUG                       (0)
#define HOT_RD_DEBUG                            (0)
#define POLLING_DEBUG                           (0)
#define DEBUG_DATA                              (0)
#define DRIVER_PRINT_NVME_CMD                   (0)
#define TAIL_LAT_PERF                           (0)
#define READ_HW_LAT                             (0)
#endif

#define SFX_SHIFT_IRQ_AFFI_MIN_CPUS             (8)
#define SFX_SHIFT_IRQ_AFFI_MAX_CPUS             (1024)
#define SFX_SHIFT_IRQ_AFFI_MAX_NODE             (32)

#define MAP_LOG_SIZE                            (32)
#define MAP_LOG_SIZE_ORDER                      (5)             // order of 4K

#define HOT_RD_DEBUG_TABLE_ENTRY_NUM            (256 * 1024)    // 256K TABLE ENTRY
#define HOT_RD_DEBUG_ENTRY_SIZE                 (32)            // each entry is 32 bytes
#define HOT_RD_DEBUG_BLK_ENTRY_SIZE             (16)

#define USER_DATA_4K_PER_STRIPE                 (sfx_mdrv->card_info.page_data_unit * 31)       // TSB CFG_FLASH_PAGE_SIZE*31//496
#define SYSTEM_UNIT                             USER_DATA_4K_PER_STRIPE
#define SYSTEM_UNIT_ALLOCATE                    (24 * 31)  //ccp->cf.page_data_unit

#define GC_WR_GRUNULARITY                       ((SYSTEM_UNIT + 4) * 4)
#define GC_WR_GRUNULARITY_ALLOCATE              ((SYSTEM_UNIT_ALLOCATE + 4) * 4)

#define MAX_MARKED_BAD                          100
#define MAX_MARKED_BAD_BLOCK                    6
#define MAX_HOT_STREAM                          (4)
#define RESULT_ERR_CHAN_MASK                    0xFFF
#define MAX_TRIM_REGION_COUNT                   (8 * 1024 * 1024 / 128)
#define TL_LBA_START                            (0x80000000)
#define TL_LBA_END                              (TL_LBA_START + MAX_TRIM_REGION_COUNT - 1)
#define READ_SCRUB_DATA_MOVEMENT                (1)
#define DR_ERR_CNT_THRESHOLD                    (ccp->cf.nand_type == TSB_BICS ? 150 : 130)
#define READ_SCRUB_KEYID                        (0xFFFF)

#ifdef SFX_LINUX
    #ifdef RHEL_RELEASE_CODE
        #if (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7,2))
            #define SFX_USE_REMOTE_CMPL         (0)
        #else
            #define SFX_USE_REMOTE_CMPL         (0)
        #endif
    #else
        #if LINUX_VERSION_CODE >= KERNEL_VERSION(3,15,0)
            #define SFX_USE_REMOTE_CMPL         (0)
        #else
            #define SFX_USE_REMOTE_CMPL         (0)
        #endif
    #endif
#else
    #define SFX_USE_REMOTE_CMPL                 (0)
#endif

#define MAX_KMEM_CACHE_SIZE                     0x20000

#ifdef SFX_LINUX
#define CACHELINE_ALIGNED                       ____cacheline_aligned
#else
#define CACHELINE_ALIGNED
#endif

#define NO_OF_HORZONTAL_4KB                     (64)
#define NUM_LOG_ENTRY_PER_BUF                   (1024 * 4 / 32)
#define NUM_LOG_BUF                             (512)
#define MU_PAGE_SIZE                            (16)
#define TSB_PAGE_SIZE                           (8)

#define HP_RD_OFF_THD                           (2000000)//2000MB
#define HP_RD_ON_THD                           (1500000)//1500MB
#define HP_RD_ON_THD_L                           (1200000)//1200MB
#define HP_RD_ON_THD_W_L                           (1000000)//1200MB
//flip high priority read bit if the whole minutes hits the
//same workload
#define HP_RD_SWITCH_CNT                           (10)


#ifdef __SFX_KERNEL__
#define sfx_thread_not_in_irq()                 (0 == sfx_irq_count())
#endif

#define NUM_LBAS_IN_MAP_PAGE (SFX_PAGE_SIZE / sizeof(lba_t)) // 1K lbas in 4k page

enum
{
    SFX_LAST_ML_SBMT = 1,
    SFX_LAST_ML_CMPL,
};
enum
{
    SFX_TYPE_INTEL_CPU = 0,
    SFX_TYPE_AMD_CPU,
    SFX_TYPE_UNKNOWN_CPU,
};

enum
{
    PERF_MODE = 0,
    POWER_MODE,
    T_16_MODE,
};

enum
{
    SFX_READ_REQ = 0,
    SFX_WRITE_REQ,
    SFX_DISCARD_REQ,
};

enum
{
    ADMIN_QUEUE = 0,
    WRITE_QUEUE,
    READ_QUEUE,
    RESERVED_QUEUE,
};

enum
{
        GC_WR_THD = 0,
        GC_RD_THD,
        COH_THD,
        APP_THD,
};

typedef enum
{
    SFX_THRD_NONE    = 0,
    SFX_THRD_CREATED,
    SFX_THRD_IDLE,
    SFX_THRD_RUNNING,
    SFX_THRD_PARKING,
    SFX_THRD_ASSERTED,
    SFX_THRD_STOPPED,
} SFX_THRD_STATE;

typedef enum
{
    SFX_DEVICE_STATE_NOT_READY,

    SFX_DEVICE_STATE_RUNNING,
    /* SFX_DEVICE_STATE_RUNNING_FROM_FREEZE, */

    SFX_DEVICE_STATE_READONLY,
    SFX_DEVICE_STATE_READONLY_BY_DATALOSS,
    SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS,

    SFX_DEVICE_STATE_FREEZE,

    SFX_DEVICE_STATE_REMOVE,
} sfx_device_state;

static inline const char *sfx_device_state_get(sfx_device_state state)
{
    return state == SFX_DEVICE_STATE_NOT_READY ? "not ready" :
           state == SFX_DEVICE_STATE_RUNNING ? "running" :
           state == SFX_DEVICE_STATE_READONLY ? "read-only" :
           state == SFX_DEVICE_STATE_READONLY_BY_DATALOSS ? "read-only by dataloss" :
           state == SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS ? "IO locked by dataloss" :
           state == SFX_DEVICE_STATE_FREEZE ? "freeze" :
           state == SFX_DEVICE_STATE_REMOVE ? "removing" :
           "UNKNOWN";
}

typedef enum
{
    SFX_DEVICE_NORMAL = 0,
    SFX_FREEZE_TO_RDONLY = 1,
    SFX_FREEZE_TO_NORMAL,
    SFX_RDONLY_TO_NORMAL,
    SFX_FREEZE_TO_STOP,
} SFX_ASSERT_HANDLE_ACTION;

typedef enum
{
    SFX_ADMINQ = 0,
    SFX_HOT_B2NQ,
    SFX_HOT_WRQ,
    SFX_HOT_METAQ,
    SFX_HOT_RDQ,
    SFX_MIXED_WRQ,
    SFX_MIXED_RDQ,
    SFX_CHEPTQ,
    SFX_WLQ,
    SFX_COLD_CHEPTQ,
    SFX_ERASEQ,
    SFX_COMPRESSIONQ,
    SFX_ECQ,
    SFX_NVMQ,
    SFX_INVALIDQ,
} SFX_QUEUE_TYPE;

enum
{
    SINGLE_STREAM_MODE = 0,
    MULTI_STREAM_MODE,
};

enum
{
    SINGLE_STREAM = 1,
    MULTI_STREAM  = 3,
};

enum
{
    CSP_NOT_READY = 0,
    CSP_READY,
    CSP_FREEZE,
    CSP_FAILURE,
};

enum
{
    POLLED_NONE = 0,
    POLLED_WRITE,
    POLLED_READ,
    POLLED_META,
    POLLED_BOTH,
    POLLED_MWR,
    POLLED_MRD,
    POLLED_ERS,
    POLLED_WL,
    POLLED_CPT,
};

enum
{
    CP_DEFAULT    = 0,
    CP_CHECKPOINT = 1,
    CP_BBD        = 2,
    CP_NANDLOG    = 3,
    CP_RD_REBLD   = 4,
    CP_RD_VU      = 5,
};

enum
{
   FALSE = 0,
   TRUE,
};

enum
{
    DISABLE_CCS_WL_RECYCLE = 0,
    ENABLE_CCS_WL_RECYCLE,
    CCS_RECING_WL_HOT,
    CCS_REC_WL_HOT_DONE,
    CCS_REC_WL_HOT_STOP,
};

typedef enum
{
    //status
    NO_ERROR = 0,
    DEVICE_READY = 0,
    CMD_PENDING = 1,
    READ_RETRY_NEEDED = 2,
    DEVICE_NOT_READY,
    DEVICE_READ_WITH_DATALOSS,
    DEVICE_FREEZE,
    DEVICE_ASSERT_READ_ONLY,
    DEVICE_NORMAL_FROM_FREEZE,
    STATUS_SEARCH_NOT_FOUND,
    STATUS_SEARCH_FOUND,
    MAP_LOG_FULL_FLUSH_REQUIRED,
    FM_SKIP_GC,
    FM_NEED_EXIT_THREAD,
    GC_NEED_GATHER_HOT_DATA,
    GC_PREAD_FULL,
    GC_SHUTDOWN_CLEAN,
    GC_SKIP_INIT_BUFFER_ENTRY,
    FM_DO_DATA_COMPARE,
    FM_FREE_STATIC_BUFFER,
    FM_FREE_BUFFER,
    FM_FLUSH_OPEN_MAP_LOG_DONE,

    ERROR_R2C_VLEN,
    ERROR_R2C_CRC,
    ERROR_R2C_BUF,
    ERROR_R2C_N2B_OVERFLOW,
    //warning statusQID_HB2N
    WARNING_START,
    //flat map module
    WARNING_FM_LBA_IS_IN_ANOTHER_OPEN_MEM_ID,
    WARNING_FM_COMPARE_AND_SWAP,
    WARNING_FM_PARTIAL_SNAPSHOT_CORRUPTED,
    WARNING_FM_MEM_ID_IS_FULL,

    ERROR_CODE = 0x80,
    ERROR_DEVICE_NOT_READY,
    ERROR_ACT_IS_FULL,
    ERROR_WS_IS_FULL,
    ERROR_WS_UNMATCH,
    ERROR_INVALID_MID,
    ERROR_NOT_SEALED_MID,
    ERROR_TOO_MANY_SESSIONS,
    ERROR_TOO_MANY_COMMANDS,
    ERROR_CARD_IS_FULL,
    ERROR_INVALID_PARAM,
    ERROR_NO_FREE_BLOCK,
    ERROR_ABORT_NON_PENDING_CMD,
    ERROR_MEDIA_ERROR,
    ERROR_MEDIA_ERROR_INJECT,
    ERROR_TIMEOUT,
    ERROR_INTERRUPT = 0x90,
    ERROR_FCQ_IS_FULL,
    ERROR_IPC_CONNECTION = 0x1000,
    ERROR_IPC_CALL,
    ERROR_DRIVER_RESOURCE_NOT_AVAILABLE,
    ERROR_ASSERT,
    ERROR_DEVICE_GONE,
    ERROR_UNKNOWN,
    //blk ftl error
    ERROR_MALLOC,
    ERROR_NO_FREE_MEM_ID_AVAILABLE,
    ERROR_OPEN_FIFO_IS_EMPTY,
    ERROR_INVALID_L2P_ENTRY,
    ERROR_GATHER_MEM_ID_FULL,
    ERROR_READ_ERROR,
    ERROR_RMW_ERROR,
    ERROR_FOOTER_CORRUPTED,
    ERROR_CRC,
    ERROR_ERASED_PAGE,
    ERROR_NULL_POINTER,
    ERROR_FEATURE_NOT_SUPPORT,

    // 0x1100~0x1199 for ParallelUnit Error Definition
    ERROR_PU_ERR_START = 0x1100,
    ERROR_PU_NOT_SUPPORTED,
    ERROR_PU_ERR_END   = 0x1199,

    // 0x1200~0x1299 for next Error Module Definition
    ERROR_NEXT_ERR_START = 0x1200,

    ERROR_MAX_NUM,
} sfxError;  //ERROR_STATUS

typedef enum
{
    CMD_IDLE = 0,           // empty command
    CMD_ALLOCATED,          // ACT slot is allocated
    CMD_IS_SUBMITTED,       // command is in ACT
    CMD_IN_PROGRESS,        // command is moved to FCQ and beinng processed
    CMD_COMPLETED,          // command is completed
} sfxCmdStatus;

typedef struct
{
    xt_u16          head;
    xt_u16          tail;
    xt_u16          cnt;
    xt_u16          group_cnt;
} __attribute__((packed)) com_queue_t;
// Please keep this packed struct 64-bit (8-byte) aligned.
CC_ASSERT((sizeof(com_queue_t) % 8) == 0);

typedef struct
{
    xt_u16          next;
    xt_u16          elem;
} __attribute__((packed)) queue_elem_t;

typedef struct
{
    com_queue_t     *que;       // 0 - (wqnum-1): working queue; (wqnum): free queue;
    queue_elem_t    *l_elems;
    xt_u16          l_wqnum;    // number of working queues
    xt_u16          l_size;     // the max capacity of linklist
} __attribute__((packed)) com_linklist_t;

typedef struct sfx_range_op
{
    xt_u64          start_lba;
    xt_u64          end_lba;
    xt_u32          flag_range_op;
    xt_u32          rsvd;
} sfx_range_op;

struct sfx_perf_opt_ctx
{
    xt_u64          do_active_thread_detec;
    xt_u64          num_detect;
#ifdef __KERNEL__
    sfx_atomic64_t  start_time;
    sfx_atomic64_t  last_req_time;
    sfx_atomic64_t  cpuid_poll;
    sfx_atomic_t    qid_async_poll;
    sfx_atomic_t    active_io_thread;
#else
    xt_u64          start_time;
    xt_u64          last_req_time;
    xt_u64          cpuid_poll;
    xt_u64          qid_async_poll;
    xt_u64          active_io_thread;
#endif
};

struct sfx_pu_thrpt
{
    xt_u32          grt_wr_thrpt;
    xt_u32          grt_rd_thrpt;
    xt_u32          peak_wr_thrpt;
    xt_u32          peak_rd_thrpt;
};

typedef struct sfx_pu_res
{
    xt_u32          free;
    xt_u32          num_die;
    xt_u32          num_chan;
    xt_u32          *die_list;
    xt_u32          *chan_list;
    xt_u32          puid;
    xt_u64          capacity;   // in unit of sector (512B)
    struct sfx_pu_thrpt pu_thrpt;
} sfx_pu_res;

typedef struct sfx_die_usage
{
    xt_u32          die_idx[MAX_DIE_PER_CHAN];
    queue_elem_t    die_elem[MAX_DIE_PER_CHAN];
    com_queue_t     die_que[2];
    com_linklist_t  die_ll;
} sfx_die_usage;

typedef struct sfx_rd_debug_entry
{
    xt_u32          memid;
    xt_u32          off;
    xt_u32          len;
    xt_u32          mask;
    xt_u32          hw_pba;
    xt_u32          rsvd1;
    xt_u64          rsvd2;
} sfx_rd_debug_entry;

typedef struct blk_rd_debug_entry
{
    xt_u32          lba;
    xt_u32          len;
    xt_u32          mid;
    xt_u32          off;
} blk_rd_debug_entry;

typedef enum io_stat_idx
{
    IO_SECS = 0,
    IO_4K,
    IO_8K,
    IO_16K,
    IO_32K,
    IO_64K,
    IO_256K,
    IO_LARGE,
    IO_unalign,
    IO_NUM_ENTRY,
} io_stat_idx;

typedef struct io_log_entry
{
    // 32 bytes
    xt_u64 ts;
    xt_u32 start_sec;
    xt_u32 len_sec;
    xt_u32 lat;
    xt_u32 ccs_lat;
    xt_u32 blk_smt_lat;
    xt_u32 type         : 10;
    xt_u32 unaligned    : 10;
    xt_u32 blk_coh_block: 12;
} io_log_entry;

typedef struct blk_io_log_ctx
{
#ifdef __KERNEL__
    sfx_spinlock_t  io_log_lock;
#endif
    void   *log_buf;
    xt_u64 tot_cmd;
    xt_u32 buf_idx;
    xt_u32 inner_idx;
} blk_io_log_ctx;

#ifdef __SFX_KERNEL__
#ifdef SFX_LINUX
typedef struct blk_io_stat
{
    xt_u64 __percpu *tot_num;
    xt_u64 __percpu *num_2ms;
    xt_u64 __percpu *num_8ms;
    xt_u64 __percpu *tot_lat;
    xt_u64 __percpu *tot_smt;
    xt_u64 __percpu *tot_ccs;
    xt_u64 __percpu *num_ccs_1ms;
    xt_u64 __percpu *num_ccs_8ms;
    xt_u64 __percpu *num_smt_1ms;
    xt_u64 __percpu *num_smt_8ms;
} blk_io_stat;

typedef struct ccs_io_stat
{
    xt_u64 __percpu *tot_num;
    xt_u64 __percpu *avg_lat;
    xt_u64 __percpu *num_2ms;
    xt_u64 __percpu *num_8ms;
} ccs_io_stat;
#endif
#endif

// Define bucket according to required latency granularity
typedef struct __io_latency_bucket {
    sfx_atomic_t	 bucket_1[32];	/* 0~1ms, step 32us */
    sfx_atomic_t	 bucket_2[31];	/* 1~32ms, step 1ms */
    sfx_atomic_t	 bucket_3[31];	/* 32ms~1s, step 32ms */
    sfx_atomic_t	 bucket_4[1];	/* 1s~2s, specifically 1024ms~2047ms */
    sfx_atomic_t	 bucket_5[1];	/* 2s~4s, specifically 2048ms~4095ms */
    sfx_atomic_t	 bucket_6[1];	/* 4s+, specifically 4096ms+ */
} io_latency_bucket_t;

// Define statistics distribution
// if there is a size distribution required, add one more layer
typedef struct __io_latency_statistics {
    io_latency_bucket_t     latency_read;
    io_latency_bucket_t     latency_write;
} io_latency_statistics_t;

// Define Latency Info
typedef struct __io_latency_management {
    union {
        struct {
            xt_u32          lat_info_valid          : 1;
            xt_u32          lat_info_read           : 1;
            xt_u32          lat_info_write          : 1;
            xt_u32          lat_info_size           : 1;
            xt_u32          lat_info_size_4K        : 1;
            xt_u32          lat_info_size_8K        : 1;
            xt_u32          lat_info_size_16K       : 1;
            xt_u32          lat_info_size_32K       : 1;
            xt_u32          lat_info_size_64K       : 1;
            xt_u32          lat_info_size_128K      : 1;
            xt_u32          lat_info_size_max       : 1;
            xt_u32          latency_ctrl            :21;
        };
        xt_u32      latency_control;
    };

    // Version Control
    xt_u16          version_major;
    xt_u16          version_minor;
    xt_u16          rsvd[4];        // up to 64bit aligned

    // IO Latency Statistics Information Buffer Pointer
    io_latency_statistics_t *latency_stats;
} io_latency_management_t;

typedef struct sfx_die_bitmap
{
    xt_u8           pu_id[SFX_MAX_SPT_DIE];
} __attribute__((packed)) sfx_die_bitmap;

struct persis_pu_res
{
    xt_u64              active_pu;
    sfx_die_bitmap      die_bm;
    struct sfx_pu_thrpt pu_thrpt[SFX_MAX_PU];
    xt_u64              capacity[SFX_MAX_PU];
};

struct sfx_pu_res_manager
{
    xt_u32          active_pu;
    xt_u32          tot_chan;           /* channle number of device */
    xt_u32          tot_die;            /* die number of device */
    xt_u32          num_prog_plane;     /* num of plane program in parallel at normal case */
    xt_u32          num_read_plane;     /* num of plane read in parallel */
    xt_u32          max_prog_plane;     /* max num of plane program in parallel */
    xt_u32          die_wr_thrpt;       /* die write throughput in normal case, MB/s */
    xt_u32          peak_wr_die_thrpt;  /* peak die write throughput MB/s*/
    xt_u32          die_rd_thrpt;       /* die read throughput MB/s */
    xt_u32          prog_lat;           /* program latency per page, nand related */
    xt_u32          sense_lat;          /* sensing latency per page, nand related */
    xt_u32          peak_wr;            /* peak write throughput */
    xt_u32          peak_rd;            /* peak read throughput */
    xt_u32          reserved;
    xt_u64          die_cap;            /* in unit of sector (512B) */
    xt_u64          user_cap;           /* in unit of sector (512B) */
    xt_u64          free_cap;           /* in unit of secotr (512B) */
    sfx_die_usage   die_usage[SFX_MAX_CHANNEL];
    sfx_pu_res      pu_res[SFX_MAX_PU];
#ifdef __KERNEL__
    sfx_spinlock_t  pu_res_mgr_lock;
#else
    pthread_mutex_t pu_res_mgr_lock;
#endif
    struct persis_pu_res persis_res;
};

typedef xt_u32      FIFO_TYPE;

typedef struct
{
    xt_u32          m_from; // pull index
    xt_u32          m_to;   // push index
    xt_u32          m_cnt;  // actual number of elements in FIFO
    xt_u32          m_size; // the max capacity of FIFO
    FIFO_TYPE       *m_array;
} __attribute__((packed)) FIFO;

typedef struct
{
    xt_u8           key[CCS_KEY_LEN];   // 128 or 256bits Key
    xt_u8           iv[CCS_IV_LEN];     // 128bits IV
} __attribute__((packed)) CCS_KEY_STRUCT;

/* Used for ioctl commands */
typedef struct sfx_mem_cmd
{
    xt_u32          *addr;
    xt_u32          length;
    xt_u32          *token_addr; //Bit63: 1, Bit[55:40]:index, 64K entries.
} sfx_mem_cmd_t;

/*
 * THREADS
 */
struct sfx_blk_ftl_thread
{
#ifdef __KERNEL__
    sfx_thread_t            thread;     // offset  0  size  8
    sfx_pid_t               pid;        // offset  8  size  4
    sfx_atomic_t            state;      // offset 12  size  4
    sfx_wait_queue_head_t   wait;       // offset 16  size 24
    struct sfx_completion   parked;     // offset 40  size 32
    struct sfx_completion   asserted;   // offset 72  size 32
    struct sfx_completion   exited;
#else
    void                    *thread;
    xt_u32                  pid;
    xt_u32                  state;
#endif
    xt_8                    stopped;    // offset 104
    xt_8                    inited;
    void                    *private_data;
};

/*
 * Used as array indices, make sure to avoid overlap.
 */
typedef enum sfx_private_thread_slot
{
    SFX_PRIV_THREAD_SLOT_ASSERT,             /* 0 */
    SFX_PRIV_THREAD_SLOT_G_MAP1,             /* 1 */
    SFX_PRIV_THREAD_SLOT_META_DATA,          /* 2 */
    SFX_PRIV_THREAD_SLOT_GC_WRITE,           /* 3 */
    SFX_PRIV_THREAD_SLOT_GC_READ,            /* 4 */
    SFX_PRIV_THREAD_SLOT_WL,                 /* 5 */
    SFX_PRIV_THREAD_SLOT_G_MIM,              /* 6 */
    SFX_PRIV_THREAD_SLOT_CCS,                /* 7 */
    SFX_PRIV_THREAD_SLOT_DEFER_SMT,          /* 8 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_CB,         /* 9 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_ERR_HANDLE, /* 10 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_READ_DISTB, /* 11 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_THROTTLE,   /* 12 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_BG,         /* 13 */
    SFX_PRIV_THREAD_SLOT_POLLING,            /* 14 */
    SFX_PRIV_THREAD_SLOT_B2N,                /* 15 */
    SFX_PRIV_THREAD_SLOT_MAPLOG_EH,          /* 16 */
    SFX_PRIV_THREAD_SLOT_BLK_FTL_COH,        /* 17 */
    SFX_PRIV_THREAD_SLOT_TOTAL = 40,
} sfx_private_thread_slot;

typedef struct thrd_pool_thread
{
    xt_u32                  thread_pid;
#ifdef __KERNEL__
    struct sfx_completion   *assert_cmpl;
#else
    void                    *assert_cmpl;
#endif
} thrd_pool_thread;

typedef struct sfx_thread_pool
{
    thrd_pool_thread            threads[SFX_PRIV_THREAD_SLOT_TOTAL];
    union {
        struct sfx_blk_ftl_thread       thread_array[SFX_PRIV_THREAD_SLOT_TOTAL];
        struct {
            struct sfx_blk_ftl_thread   assert_thread;              /* 0 */
            struct sfx_blk_ftl_thread   g_map_thread1;              /* 1 */
            struct sfx_blk_ftl_thread   meta_data_thread;           /* 2 */
            struct sfx_blk_ftl_thread   gc_write_thread;            /* 3 */
            struct sfx_blk_ftl_thread   gc_read_thread;             /* 4 */
            struct sfx_blk_ftl_thread   wl_thread;                  /* 5 */
            struct sfx_blk_ftl_thread   g_mim_thread;               /* 6 */
            struct sfx_blk_ftl_thread   ccs_thread;                 /* 7 */
            struct sfx_blk_ftl_thread   defer_smt_thread;           /* 8 */
            struct sfx_blk_ftl_thread   blk_ftl_cb_thread;          /* 9 */
            struct sfx_blk_ftl_thread   blk_ftl_err_handle_thread;  /* 10 */
            struct sfx_blk_ftl_thread   blk_ftl_read_distb_thread;  /* 11 */
            struct sfx_blk_ftl_thread   blk_ftl_throttle_thread;    /* 12 */
            struct sfx_blk_ftl_thread   blk_ftl_bg_thread;          /* 13 */
            struct sfx_blk_ftl_thread   polling_thread;             /* 14 */
            struct sfx_blk_ftl_thread   buf2nand_mgr_thread;        /* 15 */
            struct sfx_blk_ftl_thread   blk_ftl_maplog_eh_thread;   /* 16 */
            struct sfx_blk_ftl_thread** blk_ftl_coh_thread;         /* 17 */
        };
    };
} sfx_thread_pool;

#ifdef __SFX_KERNEL__
static inline void sfx_priv_thread_init(sfx_thread_pool *priv_thrds,
        struct sfx_blk_ftl_thread *thread, int slot_id)
{
    sfx_init_completion(&thread->parked);
    sfx_init_completion(&thread->asserted);
    sfx_init_completion(&thread->exited);
    priv_thrds->threads[slot_id].thread_pid = thread->pid;
    priv_thrds->threads[slot_id].assert_cmpl = &thread->asserted;
    sfx_atomic_set(&thread->state, SFX_THRD_RUNNING);
    thread->stopped = 0;
    thread->inited = 1;
}
#endif
static inline void sfx_thread_handle_freeze_to_normal(sfx_atomic_t handle_action,
        struct sfx_blk_ftl_thread *sfx_thread)
{
    if (sfx_atomic_read(&handle_action) == SFX_RDONLY_TO_NORMAL
            || sfx_atomic_read(&handle_action) == SFX_FREEZE_TO_NORMAL) {
        sfx_atomic_set(&sfx_thread->state, SFX_THRD_RUNNING);
    } else {
        sfx_atomic_set(&sfx_thread->state, SFX_THRD_STOPPED);
#ifdef __SFX_KERNEL__
        sfx_do_exit(sfx_thread->pid);
#endif
    }
}

typedef struct sfx_tk_spl_cmd
{
    xt_u32          *addr;
    xt_u32          length;
    xt_u8           *mask;
    void            *prd_buff;
    xt_u32          *token_addr; //Bit63: 1, Bit[55:40]:index, 64K entries.
    xt_u32          list[24]; //maximum 96K read (24 = 96K/4K)
} sfx_tk_spl_cmd_t;

typedef struct sfx_driver_user_set_pglist_cmd
{
    void            **pglist;
    void            *token_addr;
    xt_u32          cnt;
    int             type;
    int             offset;
} sfx_driver_user_set_pglist_cmd_t;

typedef struct
{
    xt_u32          num_blk;
    xt_u32          num_pg;
    xt_u8           num_lun;
    xt_u8           num_ce;
    xt_u8           num_ch;
    xt_u8           num_hw_pt;  // number of page type, it is hardware concept
    xt_u8           num_hw_pl;
    xt_u8           num_of;     // number of sub page(offset)
    xt_u8           num_sw_gr;  // number of group, it is software concept
    xt_u8           num_sw_ch;  // software chan num
    xt_u8           num_sw_pl;  // software plane =num_hw_pt*num_hw_pl

    xt_u8           sw_off_blk; // software offset of blk
    xt_u8           sw_off_pg;
    xt_u8           sw_off_lu;
    xt_u8           sw_off_ce;
    xt_u8           sw_off_gr;  // group
    xt_u8           sw_off_ch;
    xt_u8           sw_off_pl;

    xt_u8           hw_off_blkh;// blk high bits
    xt_u8           hw_off_blk; // hardware offset of blk
    xt_u8           hw_off_pg;
    xt_u8           hw_off_lu;
    xt_u8           hw_off_ce;
    xt_u8           hw_off_ch;
    xt_u8           hw_off_pt;  // page type
    xt_u8           hw_off_pl;
    // all mask are zero based,
    xt_u32          sw_mask_blk;// mask of blk
    xt_u32          sw_mask_pg;
    xt_u32          sw_mask_lu;
    xt_u32          sw_mask_ce;
    xt_u32          sw_mask_gr; // group
    xt_u32          sw_mask_ch;
    xt_u32          sw_mask_pl;
    // all mask are zero based,
    xt_u64          hw_mask_blk;// mask of blk
    xt_u64          hw_mask_pg;
    xt_u64          hw_mask_lu;
    xt_u64          hw_mask_ce;
    xt_u64          hw_mask_ch;
    xt_u64          hw_mask_lp; // logical plane, it is combinate of plane and type
    xt_u64          hw_mask_pt; // type
    xt_u64          hw_mask_pl;
    xt_u64          hw_mask_of; // sub page (offset)mask 0x03

    xt_u8           nand_type;  // MU_L06B,TSB_BICS, MU_B17A
    xt_u8           nand_name[32];
    xt_u8           board_type;
    xt_u8           board_rev;
    xt_u32          card_capacity;
    xt_u8           die_remap;
    xt_u32          page_data_unit;  // data unit per page
    xt_u32          free_block_fifo_size;  // free block fifo size used by gc throttle
    xt_u32          b17_logic_page_num;
    xt_u32          image_rev;
    xt_u8           b17_mlc_prog_susp;
    xt_u8           lba_chk_4B;
    xt_u8           multi_sec_nor_dump;
} sfx_board_nand_type;

typedef struct ftl_moniter_s
{
    xt_u32         erase_sampling_flag;
    xt_u16         max_erase_count;
    xt_u16         average_erase_count;
    xt_u64         host_write_bandwidth;
    xt_u64         host_write_latency; // now only record the last latency for moniter
    xt_u64         host_read_bandwidth;
    xt_u64         host_read_latency;
    xt_u64         total_write_bandwidth; //add host , gc , wl write_bandwidth together
    xt_u64         wl_write_bandwidth;
    xt_u64         gc_write_bandwidth;
    xt_u64         gc_read_bandwidth;
    xt_u64         total_wl_logicbs;
    xt_u64         total_gc_logicbs;
    xt_u32         seu_sampling_flag;
    xt_u32         seu_crc_error;
    xt_u32         in_flight_write_reqs;
} ftl_moniter_t;

typedef sfxError (*ccs_callback_t)(sfxError status, void *context);
typedef void (*fcmd_cmpl_cb) (sfxError status, void* ccs_ctrl_pt, const xt_u32 fcmd_idx);
typedef int (*ftl_cmpl_cb)(void *ftlctx, void *cqe);
typedef void (*ccs_thread_register)(void *context, struct sfx_blk_ftl_thread **ccs_thread, void *ccp);
typedef void (*sfx_mdrv_state_machine_func)(void *sfx_mdrv, sfx_device_state state);

void sfx_mdrv_state_machine(void *mdrv, sfx_device_state state);

int sfx_mdrv_restore_state(void *mdrv);
xt_u8 is_valid_mdrv(void *mdrv);

typedef struct css_io_ctx
{
    xt_u64          defer_start_time;
    xt_u32          memID;
    xt_u32          offset;
    xt_u32          length;
    xt_u32          qid;
    xt_u32          curMapEntry;
    xt_u32          pre_app_len;
    xt_u32          rsvd;
    xt_u16          keyid;
    xt_u16          padding_flag;
    xt_u16          stream;
    xt_u32          *host_addr;
    xt_u16          r2c_sid;
    xt_u8           r2c_fuse;
    ccs_callback_t  cb;
    void            *context;
    void            *lbactx;
#ifdef __KERNEL__
    struct sfx_list_head  defer_que_item;
#endif
    xt_u32          lba;
    xt_u32          read_mask;
    xt_u32          pba_base;
    xt_u32          merge_rd_en;
    xt_u32          lba_seq_off;
} css_io_ctx;

typedef struct interleaved_data_smt_ctx
{
    void            *maplog_cmd;
    void            *cmd;
    void            *Acmd_que_in;
    void            *wr_io_que_in;
    xt_u32          *ml_local_smt_index;
    xt_u32          book_off;
    xt_u32          submit_map_log;
    xt_u32          append_size;
    xt_u32          app_data;
    xt_u32          data_len;
    xt_u32          acid;
} interleaved_data_smt_ctx;

typedef struct ccs_write_ctx ccs_read_ctx;

union handle
{
    void            *fdk;
    int             fdu;
};

typedef struct sfx_lba_list
{
    xt_u32          nr_seg;
    xt_u32          nr_lba;
    struct
    {
        xt_u32      lba;
        xt_u32      nr_seg_lba;
    } lba_arr[GC_WR_GRUNULARITY_ALLOCATE / 4];
} sfx_lba_list;

typedef struct sfx_lba_list_hot
{
    xt_u32          nr_seg;
    xt_u32          nr_lba;
    struct
    {
        xt_u32      lba;
        xt_u32      nr_seg_lba;
    } lba_arr[1];
} sfx_lba_list_hot;

typedef struct lba_ctx
{
    xt_u32          start_index;
    xt_u32          single_lba;
    xt_u32          aes_bvalue;
    xt_u32          host_range_bitmap_flag; //0:host; 1:range log; 2:bit map log
    xt_u32          lens_trim;
    sfx_lba_list    *lba_list;
} lba_ctx;

struct sfx_ioq_config
{
    xt_u8           rdq_per_unit;   /* in isolation: one unit is one stream */
    xt_u8           wrq_per_stream;
    xt_u8           isolation;
    xt_u8           num_stream;
    xt_u16          tot_ioq;
    xt_u16          num_cpu;
    xt_u16          tot_active_queue;
    xt_u16          rsvd1;
};

typedef struct work_data
{
    xt_u32          total_aval_len;
    xt_u32          acmd_mid;
    xt_u32          data_len;
    sfx_atomic_t    abort_flag[MAX_HOT_WR_Q];
    xt_u16          is_worker;
}ba_work_data;

typedef struct rc_moniter_s
{
    sfx_atomic64_t time_us;
    sfx_atomic64_t page_read_cnt;
    sfx_atomic64_t byte_retn_cnt;
    sfx_atomic64_t total_col_read_cnt;
    sfx_atomic64_t total_blk_cnt;
    sfx_atomic64_t total_fpga_cmd_cnt;
    sfx_atomic_t   util;
    sfx_atomic_t   latency;
    sfx_atomic_t   latency_hw;
    sfx_atomic_t   eng_ok;
    sfx_atomic_t   session_busy;
    sfx_atomic_t   page_cnt_inteval;
    sfx_atomic_t   dce_cnt_inteval;
    sfx_atomic_t   n2b_cnt_inteval;
    sfx_atomic_t   sampling_cnt;
    sfx_atomic64_t ecc_error_cnt;
    sfx_atomic64_t rc_ecc_error_cnt;
    sfx_atomic64_t vlen_error_cnt;
    sfx_atomic64_t key_overflow_cnt;
    sfx_atomic64_t decomp_error_cnt;
    sfx_atomic64_t row_overflow_cnt;
    sfx_atomic64_t buf_overflow_cnt;
    sfx_atomic64_t bad_block_crc_cnt;
    sfx_atomic64_t unknown_error_cnt;
    sfx_atomic_t   mon_sig_out;
    sfx_atomic_t   rc_debug_0;
    sfx_atomic_t   rc_debug_1;
} rc_moniter_t;

struct ftl_ctx
{
    void            *blk_ftl_ctx;
    void            *fm_ctx;
#ifdef __KERNEL__
    sfx_worker_t    *workq;
    struct sfx_work_struct bg_work[256];
    struct sfx_work_struct polling_work[256];
    struct sfx_work_struct barrier_work[128];
    struct sfx_work_struct barrier_work0[128];
    struct sfx_work_struct barrier_work1[128];
    struct sfx_work_struct barrier_work2[128];
    struct sfx_work_struct barrier_work3[128];
    struct sfx_work_struct read_retry_work[256];
#endif
    FIFO            bg_queue[256];
    FIFO_TYPE       bg_queue_array[256][256];
    char            workq_name[32];
    xt_u32          debug_read;
    xt_u8           device_ready;
    rc_moniter_t    rc_moniter;
#if ENABLE_FTL_MONITER
    ftl_moniter_t   ftl_moniter;
#endif
};

struct sfx_driver_nvmeq_ctx
{
    xt_u16          qid;
    xt_u16          stream_id;
    xt_u16          queue_type;
    xt_u16          flag_last;
    xt_u32          numa_node;
    xt_u32          rsvd;
    //-------------------------------------------------------------------------
    // !!! WARNING: Keep "cpumask" as a pointer to sfx_cpumask_t struct !!!
    // !!! DO NOT use the schizophrenic type of sfx_cpumask_var_t !!!
    //-------------------------------------------------------------------------
#ifdef __KERNEL__
    sfx_cpumask_t   *cpumask;
#else
    void            *cpumask;
#endif
};

/*
 * sfx_drvq_ctx includes all context for a single sfx_nvme_queue
 */
struct sfx_drvq_ctx
{
    void            *blk_ftl_ctx;
    void            *driver_qp;        // driver nvme queue pointer
    void            *sfx_nvme_cmd_queue;
    void            *sfx_app_queue;
    xt_u16          stream_id;
    xt_u16          queue_type;
    xt_u32          irq;
    //-------------------------------------------------------------------------
    // !!! WARNING: Keep "cpumask" as a pointer to sfx_cpumask_t struct !!!
    // !!! DO NOT use the schizophrenic type of sfx_cpumask_var_t !!!
    //-------------------------------------------------------------------------
#ifdef __KERNEL__
    sfx_spinlock_t  lock;
    sfx_cpumask_t   *cpumask;
#else
    void            *lock;
    void            *cpumask;
#endif
};

/*
 * bd_param is used to communicated among different layers: sfx-driver, blk_ftl and ccs
 */
typedef struct bd_param
{
    xt_u32          intf_ver;
    xt_u32          goldimg;
    xt_u32          fast_cycle_mode;
    xt_u32          marked_bad_num;
    xt_u32          marked_bad[MAX_MARKED_BAD]; // blk (11 bits) | lun  (1 bit) | ce (2 bits)| ch  (4 bits)| plane (2 bits),
    xt_u32          marked_bad_block_num;       // the number of bad super blocks
    xt_u32          marked_bad_block[MAX_MARKED_BAD_BLOCK];
    xt_u8           opn[32];
    xt_u8           sn[32];
    xt_u8           firmware_rev[9];
    xt_u8           multi_stream_mode;
    xt_u8           dev_id;
    sfx_heap_id     heapid1;
    xt_u64          heapsz1;
    sfx_heap_id     heapid2;
    xt_u64          heapsz2;
    xt_u8           clean;
    xt_u8           comp_only;
    xt_u8           dbg_lvl;
    xt_u8           nor_dump;
    xt_u32          sn_start_addr;
    xt_u8           debug_mode;
    xt_u32          pe_preload;
    xt_u8           hp_read;
} bd_param_t;

typedef struct map_log_book_ctx
{
    void            *cmdp;
    xt_u32          cmd_size;
    xt_u32          book_size;
    xt_u32          submit_size;
    xt_u32          acid;
    xt_u32          cpuid;
    xt_u32          pid;
    xt_u32          prepared_size;
    xt_u32          try_prepare;
    xt_u32          iter_time;
    xt_u32          rsvd;
} map_log_book_ctx;

typedef struct map_log_flush_ctx
{
    sfx_atomic_t        ml_ready;
    sfx_atomic_t        proc_len;
    sfx_atomic_t        remain_size;
    sfx_atomic_t        booked_size;
    sfx_atomic_t        submit_order;
    sfx_atomic_t        sync_ack;
    sfx_atomic_t        pf_padding;
    ccs_callback_t      cb;
    void                *cb_ctx;
    void                *buf;
    map_log_book_ctx    ml_book_ctx[32];
#ifdef __KERNEL__
    sfx_spinlock_t      lock;
#else
    pthread_mutex_t     lock;
#endif
    xt_u32              mem_id;
    xt_u32              proc_last_ml;
} map_log_flush_ctx;

struct ftl_defer_smt_ctx
{
#ifdef __KERNEL__
    struct sfx_list_head        defer_que;
    sfx_atomic_t                defer_qd;
    sfx_spinlock_t              defer_qlock;
#endif
    struct sfx_blk_ftl_thread   *defer_smt_thread;
};

typedef struct ftl_mq_ctx
{
    struct ftl_ctx              ftl_ctx;        // includs sfx_mdrv for blk_ftl, and ccp for ccs
    void                        *driver_handle; // should be nvme_dev for sfx-driver
    void                        *pdev;
    struct sfx_drvq_ctx         *drvg_ctx;      // pointer array, each pointer represents one queue
    struct sfx_ioq_config       *ioq_config;
    struct ftl_defer_smt_ctx    *defer_smt;
    unsigned int                *cpu2wrqid_map; // cpu to wr qid mapping for each stream
    unsigned int                *cpu2rdqid_map; // cpu to rd qid mapping for each unit
    xt_u8                       rdq_numa_node[TOT_QUEUE];
    xt_u8                       wrq_numa_node[TOT_QUEUE];
#ifdef __KERNEL__
    sfx_spinlock_t              mask_lock;
    struct sfx_list_head        probe_on;
#endif
    sfx_atomic_t                active_waiting_num;
    sfx_atomic_t                ml_window_start[TOT_QUEUE];
    sfx_atomic_t                ml_window_end;  // 0: inside MAP-LOG window; 1: MAP-LOG window close; 2: MAP-LOG written
    sfx_atomic_t                ml_window_off;
    map_log_flush_ctx           ml_flush_ctx[MAX_STREAM_SUPPORT];
    sfx_atomic_t                credit;
    sfx_atomic_t                state_remove;
    sfx_atomic_t                credit_recharged;
    sfx_atomic_t                ccs_init_done;
    sfx_atomic_t                flag_barrier_rebuild[MAX_STREAM_SUPPORT];
    sfx_atomic_t                data_off_win_end1;
    sfx_atomic_t                data_off_win_end2;
    sfx_atomic_t                osd_req_num;
    sfx_atomic_t                osd_rd;
    sfx_atomic_t                osd_eh;
    sfx_atomic_t                osd_irq;
    sfx_atomic_t                vir_surprise_remove;
    sfx_atomic_t                surprise_remove_done;
#ifndef SFX_LINUX //ticket 2088
    sfx_atomic_t                hot_wr_pending;
    sfx_atomic_t                hot_rd_pending;
#endif
#if HOT_READ_PERF || HOT_WRITE_PERF
    struct {
        xt_u64                  ba_max;
        sfx_atomic64_t          max_irq_time;
        sfx_atomic64_t          num_irq;
        sfx_atomic64_t          num_irq_100;
    };
#endif

    // Declare Read Command Latency Statistics
    io_latency_management_t     latency_mgt;

    xt_u32                      debug_read;
    xt_u32                      debug_assert;
    xt_u32                      dce_feature;
    xt_u16                      next_available_qid;
    xt_u16                      comp_base_qid;
    xt_u16                      ec_base_qid;
    xt_u16                      nvm_write_qid;
    xt_u16                      r2c_base_qid;
    //-------------------------------------------------------------------------
    // WARNING:
    // The following two sfx_cpumask_var_t array members should NOT be accessed
    // by any functions in the FTL and Block FTL prebuilt libraries.
    // Any file who accesses these two members has to be release in source form
    // as part of the Source RPM release.
    //-------------------------------------------------------------------------
#ifdef __KERNEL__
    sfx_cpumask_ptr             rdq_cpumask_perunit[TOT_QUEUE];     // pointer array, for each read queue cpumask
    sfx_cpumask_ptr             wrq_cpumask_perstream[TOT_QUEUE];   // pointer array, for each write queue cpumask per stream
#endif
    xt_u32                      vu_feat_flag;
    xt_u32                      vu_feat_val;
    void                        *pdev1;
} ftl_mq_ctx;

typedef struct ftl_global_ctx
{
    struct ftl_mq_ctx       *ftl_mq_ctx;
    bd_param_t              *bd_param;
} ftl_global_ctx;

typedef struct sfx_get_user_freeslot_cmd
{
    xt_u32          fscnt;
} sfx_get_user_freeslot_cmd_t;

typedef struct sfx_nvme_cmpl
{
    xt_u32          result;     /* Used by admin commands to return data */
    xt_u32          ext_result; /* store hw pba 32-63 bits */
    xt_u16          sq_head;    /* how much of this queue may be reclaimed */
    xt_u16          sq_id;      /* submission queue that generated this entry */
    xt_u16          command_id; /* of the command which completed */
    xt_u16          status;     /* did the command fail, and if so, why? */
} sfx_nvme_cmpl;

//table shared by both ccs and blk_ftl layer
typedef struct
{
    sfx_atomic64_t  tot_cmpl_len;
    sfx_atomic_t    rec_cmpl_num;
    sfx_atomic_t    proc_cmpl_num;
    sfx_atomic_t    free_cmpl_num;
    sfx_atomic_t    finish_cmpl_num;
    xt_u32          cmpl_len;                //completion length in 4k unit
    xt_u32          cmpl_offset;             //completion offset in css mem_id
    xt_u32          cmpl_mid;                //completion css mem_id
    xt_u32          cmpl_len_split;          //completion length in 4k unit
    xt_u32          cmpl_offset_split;       //completion offset in css mem_id
    xt_u32          cmpl_mid_split;          //completion css mem_id
    xt_u32          cmpl_split;              //completion split
    xt_u32          sub_css_mid;             //submission css mem_id
    xt_u32          sub_mim_mem_id;          //submission blk ftl mem_id
    xt_u32          sub_lba;                 //submission lba
    xt_u32          sub_len;                 //submission length in 4k unit
    xt_u32          pba;
} write_callback_context_t;

typedef struct blk_ftl_read_distb_element_s
{
#ifdef __KERNEL__
    struct sfx_list_head    rd_req_head;
#endif
    xt_u32              mem_id;
    xt_u32              mim_mem_id;
    xt_u32              start_offset;
    xt_u32              end_offset;
    xt_u32              curr_offset;
    xt_u32              curr_offset_index; // index for horzntl_offset[], max value is NO_OF_HORZONTAL_4KB
    xt_u32              horzntl_offset[NO_OF_HORZONTAL_4KB];
    xt_u32              super_page_size;
    xt_u64              seq_number;
    xt_u8               read_scrub_data_move;
} blk_ftl_read_distb_element_t;

#ifdef __KERNEL__
#define get_private_thread(cmpl)            container_of(cmpl, struct sfx_blk_ftl_thread, asserted)

static inline int is_private_thrd(sfx_thread_pool *priv_tp, xt_u32 pid, struct sfx_completion **cmpl)
{
    int i;
    for (i = 0; i < SFX_PRIV_THREAD_SLOT_TOTAL; i++) {
        if (pid == priv_tp->threads[i].thread_pid) {
            *cmpl = priv_tp->threads[i].assert_cmpl;
            return 1;
        }
    }
    return 0;
}
#endif

// parity mode
enum
{
    RAID_BYPASS = 0,
    RAID_START,
    RAID_XOR,
    RAID_PARITY_WRITE,
    RAID_PAGEINOUT,
    RAID_HEADER,
    RAID_CRC_CHECK,
    RAID_BYPASS_SCAN,
    RAID_HWPBA_READ = 0x10,
    RAID_BYPASS_HWPBA = RAID_HWPBA_READ + RAID_BYPASS,
    RAID_HEADER_HWPBA = RAID_HWPBA_READ + RAID_HEADER
};

/// VU parameter definition
typedef struct
{
    // VU function id
    xt_u64 func_id;
    // if this buf is not empty, then user call this VU by UART,
    // VU should print all message to sfx_messages,
    // If this buf is NULL, then this VU is called by script, VU should
    // got parameter and put result to databuf_in_addr/databuf_out_addr/result
    xt_u8  cmdline_buf[128];

    // the data in buf addr in user space, used by script transfer parameter to VU command
    // handler
    xt_u64 databuf_in_addr;
    xt_u64 databuf_insize;

    // the data out buf prepared by user, if user need read something out, it will prepare this buffer
    xt_u64 databuf_out_addr;
    xt_u64 databuf_outsize;

    // the VU command exec status, or result
    xt_u64 result;
} vu_param_t;

struct ali_scrub_info{
    xt_u64 sw_pba;//cur sw pba
    xt_u32 loop;
    xt_u32 frequence;//unit is second
};

struct ali_gc_info{
    xt_u32 is_handling;//cur sw pba
    xt_u32 gc_level;
    xt_u32 free_block_num;//unit is second
};

//for capatitor state
enum
{
    STATE_CAP_INIT,
    STATE_CAP_SET_THRD,
    STATE_CAP_POLL,
    STATE_CAP_GET,
    STATE_CAP_STOP,
};

struct bb_static {
    xt_u32 mf_real_bad;
    xt_u32 mf_retired_good;
    xt_u32 mf_total;
    xt_u32 mf_retired_blknum;
    xt_u32 total_bad;
    xt_u32 thrs_per_sb;
};

typedef struct
{
    xt_u32 sector_size;
    xt_u32 atomic_wr;
    xt_u32 multi_stream;
}bd_mod_param_t;

#ifdef __cplusplus
}
#endif

#endif // __SFX_TYPES_H__
