/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * Definitions for the NVM Express interface
 * Copyright (c) 2011-2014, Intel Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : uapi_nvme.h
 * ---------------------------------------------------------------------------
 */

#ifndef __UAPI_NVME_H__
#define __UAPI_NVME_H__

#include "sfx_os_headers.h"

struct nvme_id_power_state {
    sfx__le16       max_power;     /* centiwatts */
    xt_u8           rsvd2;
    xt_u8           flags;
    sfx__le32       entry_lat;     /* microseconds */
    sfx__le32       exit_lat;      /* microseconds */
    xt_u8           read_tput;
    xt_u8           read_lat;
    xt_u8           write_tput;
    xt_u8           write_lat;
    sfx__le16       idle_power;
    xt_u8           idle_scale;
    xt_u8           rsvd19;
    sfx__le16       active_power;
    xt_u8           active_work_scale;
    xt_u8           rsvd23[9];
};

enum {
    NVME_PS_FLAGS_MAX_POWER_SCALE   = 1 << 0,
    NVME_PS_FLAGS_NON_OP_STATE      = 1 << 1,
};

struct nvme_id_ctrl {
    sfx__le16			vid;
    sfx__le16			ssvid;
    char			sn[20];
    char			mn[40];
    char			fr[8];
    xt_u8			rab;
    xt_u8			ieee[3];
    xt_u8			cmic;
    xt_u8			mdts;
    sfx__le16			cntlid;
    sfx__le32			ver;
    sfx__le32			rtd3r;
    sfx__le32			rtd3e;
    sfx__le32			oaes;
    sfx__le32			ctratt;
    xt_u8			rsvd100[28];
    sfx__le16			crdt1;
    sfx__le16			crdt2;
    sfx__le16			crdt3;
    xt_u8			rsvd134[122];
    sfx__le16			oacs;
    xt_u8			acl;
    xt_u8			aerl;
    xt_u8			frmw;
    xt_u8			lpa;
    xt_u8			elpe;
    xt_u8			npss;
    xt_u8			avscc;
    xt_u8			apsta;
    sfx__le16			wctemp;
    sfx__le16			cctemp;
    sfx__le16			mtfa;
    sfx__le32			hmpre;
    sfx__le32			hmmin;
    xt_u8			tnvmcap[16];
    xt_u8			unvmcap[16];
    sfx__le32			rpmbs;
    sfx__le16			edstt;
    xt_u8			dsto;
    xt_u8			fwug;
    sfx__le16			kas;
    sfx__le16			hctma;
    sfx__le16			mntmt;
    sfx__le16			mxtmt;
    sfx__le32			sanicap;
    sfx__le32			hmminds;
    sfx__le16			hmmaxd;
    xt_u8			rsvd338[4];
    xt_u8			anatt;
    xt_u8			anacap;
    sfx__le32			anagrpmax;
    sfx__le32			nanagrpid;
    xt_u8			rsvd352[160];
    xt_u8			sqes;
    xt_u8			cqes;
    sfx__le16			maxcmd;
    sfx__le32			nn;
    sfx__le16			oncs;
    sfx__le16			fuses;
    xt_u8			fna;
    xt_u8			vwc;
    sfx__le16			awun;
    sfx__le16			awupf;
    xt_u8			nvscc;
    xt_u8			nwpc;
    sfx__le16			acwu;
    xt_u8			rsvd534[2];
    sfx__le32			sgls;
    sfx__le32			mnan;
    xt_u8			rsvd544[224];
    char			subnqn[256];
    xt_u8			rsvd1024[768];
    sfx__le32			ioccsz;
    sfx__le32			iorcsz;
    sfx__le16			icdoff;
    xt_u8			ctrattr;
    xt_u8			msdbd;
    xt_u8			rsvd1804[244];
    struct nvme_id_power_state	psd[32];
    xt_u8			vs[1024];
};

enum {
    NVME_CTRL_ONCS_COMPARE			= 1 << 0,
    NVME_CTRL_ONCS_WRITE_UNCORRECTABLE	= 1 << 1,
    NVME_CTRL_ONCS_DSM			= 1 << 2,
    NVME_CTRL_ONCS_WRITE_ZEROES		= 1 << 3,
    NVME_CTRL_ONCS_FEATURE_EXT		= 1 << 4,
    NVME_CTRL_ONCS_TIMESTAMP		= 1 << 6,
    NVME_CTRL_VWC_PRESENT			= 1 << 0,
    NVME_CTRL_OACS_SEC_SUPP                 = 1 << 0,
    NVME_CTRL_OACS_DIRECTIVES		= 1 << 5,
    NVME_CTRL_OACS_DBBUF_SUPP		= 1 << 8,
    NVME_CTRL_LPA_CMD_EFFECTS_LOG		= 1 << 1,
};

struct nvme_lbaf {
    sfx__le16       ms;
    xt_u8           ds;
    xt_u8           rp;
};

struct nvme_id_ns {
    sfx__le64       nsze;
    sfx__le64       ncap;
    sfx__le64       nuse;
    xt_u8           nsfeat;
    xt_u8           nlbaf;
    xt_u8           flbas;
    xt_u8           mc;
    xt_u8           dpc;
    xt_u8           dps;
    xt_u8           nmic;
    xt_u8           rescap;
    xt_u8           fpi;
    xt_u8           rsvd33;
    sfx__le16       nawun;
    sfx__le16       nawupf;
    sfx__le16       nacwu;
    sfx__le16       nabsn;
    sfx__le16       nabo;
    sfx__le16       nabspf;
    xt_u16          rsvd46;
    sfx__le64       nvmcap[2];
    xt_u8           rsvd64[40];
    xt_u8           nguid[16];
    xt_u8           eui64[8];
    struct nvme_lbaf    lbaf[16];
    xt_u8           rsvd192[192];
    xt_u8           vs[3712];
};

enum {
    NVME_NS_FEAT_THIN       = 1 << 0,
    NVME_NS_FLBAS_LBA_MASK  = 0xf,
    NVME_NS_FLBAS_META_EXT  = 0x10,
    NVME_LBAF_RP_BEST       = 0,
    NVME_LBAF_RP_BETTER     = 1,
    NVME_LBAF_RP_GOOD       = 2,
    NVME_LBAF_RP_DEGRADED   = 3,
    NVME_NS_DPC_PI_LAST     = 1 << 4,
    NVME_NS_DPC_PI_FIRST    = 1 << 3,
    NVME_NS_DPC_PI_TYPE3    = 1 << 2,
    NVME_NS_DPC_PI_TYPE2    = 1 << 1,
    NVME_NS_DPC_PI_TYPE1    = 1 << 0,
    NVME_NS_DPS_PI_FIRST    = 1 << 3,
    NVME_NS_DPS_PI_MASK     = 0x7,
    NVME_NS_DPS_PI_TYPE1    = 1,
    NVME_NS_DPS_PI_TYPE2    = 2,
    NVME_NS_DPS_PI_TYPE3    = 3,
};

struct nvme_ns_id_desc {
    xt_u8 nidt;
    xt_u8 nidl;
    sfx__le16 reserved;
};

#define NVME_NIDT_EUI64_LEN    8
#define NVME_NIDT_NGUID_LEN    16
#define NVME_NIDT_UUID_LEN    16

enum {
    NVME_NIDT_EUI64        = 0x01,
    NVME_NIDT_NGUID        = 0x02,
    NVME_NIDT_UUID        = 0x03,
};

struct nvme_smart_log {
    xt_u8            critical_warning;
    xt_u8            temperature[2];
    xt_u8            avail_spare;
    xt_u8            spare_thresh;
    xt_u8            percent_used;
    xt_u8            rsvd6[26];
    xt_u8            data_units_read[16];
    xt_u8            data_units_written[16];
    xt_u8            host_reads[16];
    xt_u8            host_writes[16];
    xt_u8            ctrl_busy_time[16];
    xt_u8            power_cycles[16];
    xt_u8            power_on_hours[16];
    xt_u8            unsafe_shutdowns[16];
    xt_u8            media_errors[16];
    xt_u8            num_err_log_entries[16];
    sfx__le32        warning_temp_time;
    sfx__le32        critical_comp_time;
    sfx__le16        temp_sensor[8];
    xt_u8            rsvd216[296];
};

struct nvme_firmware_log_page {
    xt_u8    afi;
    xt_u8    resv[7];
    xt_u64   frs[7];
    xt_u8    resv2[448];
};


enum {
    NVME_SMART_CRIT_SPARE           = 1 << 0,
    NVME_SMART_CRIT_TEMPERATURE     = 1 << 1,
    NVME_SMART_CRIT_RELIABILITY     = 1 << 2,
    NVME_SMART_CRIT_MEDIA           = 1 << 3,
    NVME_SMART_CRIT_VOLATILE_MEMORY = 1 << 4,
};

enum {
    NVME_AER_NOTICE_NS_CHANGED      = 0x0002,
};

struct nvme_lba_range_type {
    xt_u8           type;
    xt_u8           attributes;
    xt_u8           rsvd2[14];
    xt_u64          slba;
    xt_u64          nlb;
    xt_u8           guid[16];
    xt_u8           rsvd48[16];
};

enum {
    NVME_LBART_TYPE_FS      = 0x01,
    NVME_LBART_TYPE_RAID    = 0x02,
    NVME_LBART_TYPE_CACHE   = 0x03,
    NVME_LBART_TYPE_SWAP    = 0x04,

    NVME_LBART_ATTRIB_TEMP  = 1 << 0,
    NVME_LBART_ATTRIB_HIDE  = 1 << 1,
};

struct nvme_reservation_status {
    sfx__le32       gen;
    xt_u8           rtype;
    xt_u8           regctl[2];
    xt_u8           resv5[2];
    xt_u8           ptpls;
    xt_u8           resv10[13];
    struct {
        sfx__le16   cntlid;
        xt_u8       rcsts;
        xt_u8       resv3[5];
        sfx__le64   hostid;
        sfx__le64   rkey;
    } regctl_ds[];
};

/* I/O commands */

enum nvme_opcode {
    nvme_cmd_flush          = 0x00,
    nvme_cmd_write          = 0x01,
    nvme_cmd_read           = 0x02,
    nvme_cmd_write_uncor    = 0x04,
    nvme_cmd_compare        = 0x05,
    nvme_cmd_write_zeroes   = 0x08,
    nvme_cmd_dsm            = 0x09,
    nvme_cmd_resv_register  = 0x0d,
    nvme_cmd_resv_report    = 0x0e,
    nvme_cmd_resv_acquire   = 0x11,
    nvme_cmd_resv_release   = 0x15,
};

struct nvme_common_command {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    sfx__le32       cdw2[2];
    sfx__le64       metadata;
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le32       cdw10[6];
};

struct nvme_rw_command {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    xt_u64          rsvd2;
    sfx__le64       metadata;
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le64       slba;
    sfx__le16       length;
    sfx__le16       control;
    sfx__le32       dsmgmt;
    sfx__le32       reftag;
    sfx__le16       apptag;
    sfx__le16       appmask;
};

enum {
    NVME_RW_LR                  = 1 << 15,
    NVME_RW_FUA                 = 1 << 14,
    NVME_RW_DSM_FREQ_UNSPEC     = 0,
    NVME_RW_DSM_FREQ_TYPICAL    = 1,
    NVME_RW_DSM_FREQ_RARE       = 2,
    NVME_RW_DSM_FREQ_READS      = 3,
    NVME_RW_DSM_FREQ_WRITES     = 4,
    NVME_RW_DSM_FREQ_RW         = 5,
    NVME_RW_DSM_FREQ_ONCE       = 6,
    NVME_RW_DSM_FREQ_PREFETCH   = 7,
    NVME_RW_DSM_FREQ_TEMP       = 8,
    NVME_RW_DSM_LATENCY_NONE    = 0 << 4,
    NVME_RW_DSM_LATENCY_IDLE    = 1 << 4,
    NVME_RW_DSM_LATENCY_NORM    = 2 << 4,
    NVME_RW_DSM_LATENCY_LOW     = 3 << 4,
    NVME_RW_DSM_SEQ_REQ         = 1 << 6,
    NVME_RW_DSM_COMPRESSED      = 1 << 7,
    NVME_RW_PRINFO_PRCHK_REF    = 1 << 10,
    NVME_RW_PRINFO_PRCHK_APP    = 1 << 11,
    NVME_RW_PRINFO_PRCHK_GUARD  = 1 << 12,
    NVME_RW_PRINFO_PRACT        = 1 << 13,
};

struct nvme_dsm_cmd {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    xt_u64          rsvd2[2];
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le32       nr;
    sfx__le32       attributes;
    xt_u32          rsvd12[4];
};

enum {
    NVME_DSMGMT_IDR             = 1 << 0,
    NVME_DSMGMT_IDW             = 1 << 1,
    NVME_DSMGMT_AD              = 1 << 2,
};

struct nvme_dsm_range {
    sfx__le32       cattr;
    sfx__le32       nlb;
    sfx__le64       slba;
};

struct sfx_set_smart_info {
    xt_u32 ps_cnt;
    xt_u32 pf_cnt;
};

/* Admin commands */

enum nvme_admin_opcode {
    nvme_admin_delete_sq        = 0x00,
    nvme_admin_create_sq        = 0x01,
    nvme_admin_get_log_page     = 0x02,
    nvme_admin_delete_cq        = 0x04,
    nvme_admin_create_cq        = 0x05,
    nvme_admin_identify         = 0x06,
    nvme_admin_abort_cmd        = 0x08,
    nvme_admin_set_features     = 0x09,
    nvme_admin_get_features     = 0x0a,
    nvme_admin_async_event      = 0x0c,
    nvme_admin_ns_mgmt          = 0x0d,
    nvme_admin_activate_fw      = 0x10,
    nvme_admin_download_fw      = 0x11,
    nvme_admin_format_nvm       = 0x80,
    nvme_admin_security_send    = 0x81,
    nvme_admin_security_recv    = 0x82,
    nvme_admin_reg_put          = 0xd0,
    nvme_admin_reg_get          = 0xd1,
    nvme_admin_set_smart_info   = 0xd2,
    nvme_admin_geometry         = 0xe2,
};

enum {
    NVME_QUEUE_PHYS_CONTIG      = (1 << 0),
    NVME_CQ_IRQ_ENABLED         = (1 << 1),
    NVME_SQ_PRIO_URGENT         = (0 << 1),
    NVME_SQ_PRIO_HIGH           = (1 << 1),
    NVME_SQ_PRIO_MEDIUM         = (2 << 1),
    NVME_SQ_PRIO_LOW            = (3 << 1),
    NVME_FEAT_ARBITRATION       = 0x01,
    NVME_FEAT_POWER_MGMT        = 0x02,
    NVME_FEAT_LBA_RANGE         = 0x03,
    NVME_FEAT_TEMP_THRESH       = 0x04,
    NVME_FEAT_ERR_RECOVERY      = 0x05,
    NVME_FEAT_VOLATILE_WC       = 0x06,
    NVME_FEAT_NUM_QUEUES        = 0x07,
    NVME_FEAT_IRQ_COALESCE      = 0x08,
    NVME_FEAT_IRQ_CONFIG        = 0x09,
    NVME_FEAT_WRITE_ATOMIC      = 0x0a,
    NVME_FEAT_ASYNC_EVENT       = 0x0b,
    NVME_FEAT_AUTO_PST          = 0x0c,
    NVME_FEAT_SW_PROGRESS       = 0x80,
    NVME_FEAT_HOST_ID           = 0x81,
    NVME_FEAT_RESV_MASK         = 0x82,
    NVME_FEAT_RESV_PERSIST      = 0x83,
    NVME_FEAT_CAP_SAVED         = (1 << 0),
    NVME_FEAT_CAP_PER_NS        = (1 << 1),
    NVME_FEAT_CAP_CHANGABLE     = (1 << 2),
    NVME_FEAT_SEL_CUR_VAL       = 0,
    NVME_FEAT_SEL_DEF_VAL       = 1,
    NVME_FEAT_SEL_LAST_VAL      = 2,
    NVME_FEAT_SEL_CAP           = 3,
    NVME_LOG_ERROR              = 0x01,
    NVME_LOG_SMART              = 0x02,
    NVME_LOG_FW_SLOT            = 0x03,
    NVME_LOG_RESERVATION        = 0x80,
    NVME_FWACT_REPL             = (0 << 3),
    NVME_FWACT_REPL_ACTV        = (1 << 3),
    NVME_FWACT_ACTV             = (2 << 3),
    SFX_LOG_LATENCY_READ_STATS  = 0xc1,
    SFX_LOG_SMART               = 0xc2,
    SFX_LOG_LATENCY_WRITE_STATS = 0xc3,
    SFX_LOG_IDENTIFY            = 0xcc,
    SFX_LOG_MEDIA               = 0xc6,
    SFX_LOG_QUAL                = 0xc4,
    SFX_LOG_MISMATCHLBA         = 0xc5,
    INTEL_LOG_SMART             = 0xca,
};

struct nvme_identify {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    xt_u64          rsvd2[2];
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le32       cns;
    xt_u32          rsvd11[5];
};

struct nvme_features {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    xt_u64          rsvd2[2];
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le32       fid;
    sfx__le32       dword11;
    xt_u32          rsvd12[4];
};

struct nvme_create_cq {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    xt_u32          rsvd1[5];
    sfx__le64       prp1;
    xt_u64          rsvd8;
    sfx__le16       cqid;
    sfx__le16       qsize;
    sfx__le16       cq_flags;
    sfx__le16       irq_vector;
    xt_u32          rsvd12[4];
};

struct nvme_create_sq {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    xt_u32          rsvd1[5];
    sfx__le64       prp1;
    xt_u64          rsvd8;
    sfx__le16       sqid;
    sfx__le16       qsize;
    sfx__le16       sq_flags;
    sfx__le16       cqid;
    xt_u32          rsvd12[4];
};

struct nvme_delete_queue {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    xt_u32          rsvd1[9];
    sfx__le16       qid;
    xt_u16          rsvd10;
    xt_u32          rsvd11[5];
};

struct nvme_abort_cmd {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    xt_u32          rsvd1[9];
    sfx__le16       sqid;
    sfx__le16       cid;
    xt_u32          rsvd11[5];
};

struct nvme_download_firmware {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    xt_u32          rsvd1[5];
    sfx__le64       prp1;
    sfx__le64       prp2;
    sfx__le32       numd;
    sfx__le32       offset;
    xt_u32          rsvd12[4];
};

struct nvme_format_cmd {
    xt_u8           opcode;
    xt_u8           flags;
    xt_u16          command_id;
    sfx__le32       nsid;
    xt_u64          rsvd2[4];
    sfx__le32       cdw10;
    xt_u32          rsvd11[5];
};

struct nvme_command {
    union {
        struct nvme_common_command      common;
        struct nvme_rw_command          rw;
        struct nvme_identify            identify;
        struct nvme_features            features;
        struct nvme_create_cq           create_cq;
        struct nvme_create_sq           create_sq;
        struct nvme_delete_queue        delete_queue;
        struct nvme_download_firmware   dlfw;
        struct nvme_format_cmd          format;
        struct nvme_dsm_cmd             dsm;
        struct nvme_abort_cmd           abort;
    };
};

enum {
    NVME_SC_SUCCESS                 = 0x0,
    NVME_SC_INVALID_OPCODE          = 0x1,
    NVME_SC_INVALID_FIELD           = 0x2,
    NVME_SC_CMDID_CONFLICT          = 0x3,
    NVME_SC_DATA_XFER_ERROR         = 0x4,
    NVME_SC_POWER_LOSS              = 0x5,
    NVME_SC_INTERNAL                = 0x6,
    NVME_SC_ABORT_REQ               = 0x7,
    NVME_SC_ABORT_QUEUE             = 0x8,
    NVME_SC_FUSED_FAIL              = 0x9,
    NVME_SC_FUSED_MISSING           = 0xa,
    NVME_SC_INVALID_NS              = 0xb,
    NVME_SC_CMD_SEQ_ERROR           = 0xc,
    NVME_SC_SGL_INVALID_LAST        = 0xd,
    NVME_SC_SGL_INVALID_COUNT       = 0xe,
    NVME_SC_SGL_INVALID_DATA        = 0xf,
    NVME_SC_SGL_INVALID_METADATA    = 0x10,
    NVME_SC_SGL_INVALID_TYPE        = 0x11,
    NVME_SC_LBA_RANGE               = 0x80,
    NVME_SC_CAP_EXCEEDED            = 0x81,
    NVME_SC_NS_NOT_READY            = 0x82,
    NVME_SC_RESERVATION_CONFLICT    = 0x83,
    NVME_SC_CQ_INVALID              = 0x100,
    NVME_SC_QID_INVALID             = 0x101,
    NVME_SC_QUEUE_SIZE              = 0x102,
    NVME_SC_ABORT_LIMIT             = 0x103,
    NVME_SC_ABORT_MISSING           = 0x104,
    NVME_SC_ASYNC_LIMIT             = 0x105,
    NVME_SC_FIRMWARE_SLOT           = 0x106,
    NVME_SC_FIRMWARE_IMAGE          = 0x107,
    NVME_SC_INVALID_VECTOR          = 0x108,
    NVME_SC_INVALID_LOG_PAGE        = 0x109,
    NVME_SC_INVALID_FORMAT          = 0x10a,
    NVME_SC_FIRMWARE_NEEDS_RESET    = 0x10b,
    NVME_SC_INVALID_QUEUE           = 0x10c,
    NVME_SC_FEATURE_NOT_SAVEABLE    = 0x10d,
    NVME_SC_FEATURE_NOT_CHANGEABLE  = 0x10e,
    NVME_SC_FEATURE_NOT_PER_NS      = 0x10f,
    NVME_SC_FW_NEEDS_RESET_SUBSYS   = 0x110,
    NVME_SC_NS_INSUFFICENT_CAP      = 0x115,
    NVME_SC_NS_ID_UNAVAILABLE       = 0x116,
    NVME_SC_BAD_ATTRIBUTES          = 0x180,
    NVME_SC_INVALID_PI              = 0x181,
    NVME_SC_READ_ONLY               = 0x182,
    NVME_SC_WRITE_FAULT             = 0x280,
    NVME_SC_READ_ERROR              = 0x281,
    NVME_SC_GUARD_CHECK             = 0x282,
    NVME_SC_APPTAG_CHECK            = 0x283,
    NVME_SC_REFTAG_CHECK            = 0x284,
    NVME_SC_COMPARE_FAILED          = 0x285,
    NVME_SC_ACCESS_DENIED           = 0x286,
    NVME_SC_DNR                     = 0x4000,
};

struct nvme_completion {
    sfx__le32   result;         /* commands completion status */
//    xt_u32    lba;
    sfx__le32   ext_result;     /* commands completion status */
    sfx__le16   sq_head;        /* how much of this queue may be reclaimed */
    sfx__le16   sq_id;          /* submission queue that generated this entry */
    xt_u16      command_id;     /* of the command which completed */
    sfx__le16   status;         /* did the command fail, and if so, why? */
};

struct nvme_user_io {
    xt_u8     opcode;
    xt_u8     flags;
    xt_u16    control;
    xt_u16    nblocks;
    xt_u16    rsvd;
    xt_u64    metadata;
    xt_u64    addr;
    xt_u64    slba;
    xt_u32    dsmgmt;
    xt_u32    reftag;
    xt_u16    apptag;
    xt_u16    appmask;
};

struct nvme_passthru_cmd {
    xt_u8     opcode;
    xt_u8     flags;
    xt_u16    rsvd1;
    xt_u32    nsid;
    xt_u32    cdw2;
    xt_u32    cdw3;
    xt_u64    metadata;
    xt_u64    addr;
    xt_u32    metadata_len;
    xt_u32    data_len;
    xt_u32    cdw10;
    xt_u32    cdw11;
    xt_u32    cdw12;
    xt_u32    cdw13;
    xt_u32    cdw14;
    xt_u32    cdw15;
    xt_u32    timeout_ms;
    xt_u32    result;
};

//provide info like open channel identify defined
struct nvme_lba_format {
    xt_u8			grp_len;
    xt_u8			pu_len;
    xt_u8			chk_len;
    xt_u8			lba_len;
    xt_u8			resv[4];
};

struct nvme_geometry {
    xt_u8			mjr;
    xt_u8			mnr;
    xt_u8			resv[6];

    struct nvme_lba_format	lbaf;

    sfx__le32		mccap;
    xt_u8			resv2[12];

    xt_u8			wit;
    xt_u8			resv3[31];

    /* Geometry */
    sfx__le16		num_grp;
    sfx__le16		num_pu;
    sfx__le32		num_chk;
    sfx__le32		clba;
    xt_u8			resv4[52];

    /* Write data requirements */
    sfx__le32		ws_min;
    sfx__le32		ws_opt;
    sfx__le32		mw_cunits;
    sfx__le32		maxoc;
    sfx__le32		maxocpu;
    xt_u8			resv5[44];

    /* Performance related metrics */
    sfx__le32		trdt;//ns
    sfx__le32		trdm;
    sfx__le32		twrt;
    sfx__le32		twrm;
    sfx__le32		tcrst;
    sfx__le32		tcrsm;
    xt_u8			resv6[40];

    /* Reserved area */
    xt_u8			resv7[2816];

    /* Vendor specific */
    xt_u8			vs[1024];
};


#define SFX_NVME_VS(major, minor) (((major) << 16) | ((minor) << 8))

#define nvme_admin_cmd nvme_passthru_cmd

#define NVME_IOCTL_ID                 _IO('N', 0x40)
#define SFX_NVME_IOCTL_ADMIN_CMD    _IOWR('N', 0x41, struct nvme_admin_cmd)
#define NVME_IOCTL_SUBMIT_IO         _IOW('N', 0x42, struct nvme_user_io)
#define SFX_NVME_IOCTL_IO_CMD       _IOWR('N', 0x43, struct nvme_passthru_cmd)
#define NVME_IOCTL_RESET              _IO('N', 0x44)

#endif // __UAPI_NVME_H__
