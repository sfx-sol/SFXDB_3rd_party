// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_vdev.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_VDEV_H__
#define __SFX_VDEV_H__
#include "sfx.h"

#if ENABLE_VDEV
#define IS_INVALID_VDEV_FROM_DISK(x) (((uintptr_t)(x)->private_data < MAX_NR_DRIVE) ? 1 : 0 )
#define GET_SFX_BD_FROM_DISK(x)     (((sfv_device *)(x->private_data))->sfx_bd)
#define GET_SFX_BD_FROM_QUEUE(q)    (((sfv_device *)(q->queuedata))->sfx_bd)
#else
#define GET_SFX_BD_FROM_DISK(x)     (x->private_data)
#define GET_SFX_BD_FROM_QUEUE(q)    (q->queuedata)
#endif

#define ERR_RETRY                   0x5a
#define WWID_MAX                    128
#define SN_MAX                      32

/* copied from sfx_kobj */
struct sfv_kobj
{
    struct sfx_kobject              kobject;
    struct sfx_completion           complete;
};

typedef struct sfv_device_s
{
    struct sfx_list_head            sfv_list;
    struct sfv_kobj                 smart_kobj;
    struct sfv_kobj                 debug_kobj;
    struct sfv_kobj                 debug_level_kobj;
    sfx_request_queue               *sfv_queue;
    sfx_gendisk                     *sfv_disk;
#ifdef SFX_LINUX
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
    struct blk_mq_tag_set           mq_tag_set;
#endif
    struct block_device_operations  *fops;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,0)
    blk_qc_t (*sfv_make_request)(sfx_request_queue *q, sfx_bio *bio);
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,2,0)
    int (*sfv_make_request)(sfx_request_queue *q, sfx_bio *bio);
#else
    void (*sfv_make_request)(sfx_request_queue *q, sfx_bio *bio);
#endif
#endif
#endif
    void (*sfv_request)(sfx_request_queue *q);
    void                            *sfx_bd;
    struct module                   *bd_module;
    char                            wwid[WWID_MAX];
    sfx_spinlock_t                  sfv_lock;
    sfx_atomic_t                    queue_stopped;
    int                             vdev_major;
} sfv_device;

struct vdev_register
{
    int (*sfx_bd_revalidate)(sfx_gendisk *gd);
#ifdef SFX_LINUX
    int (*sfx_bd_open)(sfx_block_device *bdev, fmode_t mode);
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
    int (*sfx_bd_release)(sfx_gendisk *disk, fmode_t mode);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
    void (*sfx_bd_release)(sfx_gendisk *disk, fmode_t mode);
#endif
    void (*sfx_bd_release_instance)(xt_32 instance);
    // for vmware compiling
    int (*sfx_bd_ioctl)(sfx_block_device *bdev, fmode_t mode, unsigned  cmd, unsigned long arg);
    int (*sfx_bd_getgeo)(sfx_block_device *bdev, struct hd_geometry *geo);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,0)
    blk_qc_t (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio);
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,2,0)
    int (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio);
#else
    void (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio);
#endif
#endif
    void (*sfx_bd_request)(sfx_request_queue *q);
    void (*sfx_bd_stop_queue)(sfx_request_queue *q);
    void (*sfx_bd_start_queue)(sfx_request_queue *q);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
    // SFX_BLK_MQ
    int (*sfx_vdev_tagset)(void *bd, struct blk_mq_tag_set *set);
#ifdef CENTOS7X_4_14_0_49_PATCH
    blk_status_t (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#else
#ifdef RHEL_RELEASE_CODE
    int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,13,0)
    blk_status_t (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3,19,0)
    int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3,18,0)
    int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, struct request *rq, bool not_used_here);
#else
    int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, struct request *rq);
#endif
#endif
#endif // CENTOS7X_4_14_0_49_PATCH
    int (*sfxdriver_blk_mq_map_queues)(struct blk_mq_tag_set *set);
    int (*sfx_mq_init_hctx)(struct blk_mq_hw_ctx *hctx, void *data, unsigned int hctx_idx);
    void (*sfx_mq_complete_rq)(sfx_bio_request *req);
#endif
#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
    int (*sfx_add_disk)(sfv_device *vdev);
    void (*reconnect_disk)(sfv_device *vdev);
    sfxError (*sfx_wait_idle)(sfv_device *vdev);

    /* sysfs related */
    struct attribute **dev_info;
    struct attribute **smart_feature_attrs;
    struct attribute **debug_attrs;
    struct attribute **debug_level_attrs;

    void *sfx_bd;
    struct module *bd_module;
    char wwid[WWID_MAX]; /* disk name */
    int nid;   /*numa id */
};

typedef struct sfv_mem_s
{
    void                            *bd_mem;
    struct sfx_list_head            mem_list;
    char                            sn[SN_MAX];
} sfv_mem;

int sfv_register(struct vdev_register *reg);
sfxError sfv_unregister(void);
void sfv_lock(void);
void sfv_unlock(void);
void sfv_disconnect_disk(char *wwid, int keep_disk);

void bd_mem_callback(sfv_mem *vmem);
void sfv_get_mem(void (*bd_mem_callback)(sfv_mem *sfvmem), char *sn);

#endif // __SFX_VDEV_H__
