// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : fifo.h
//
// ---------------------------------------------------------------------------

#ifndef __FIFO_H__
#define __FIFO_H__

#include "sfx_types.h"

void FifoPrint(FIFO *fifo, xt_u16 dev_id);
sfxError FifoSearch(FIFO *fifo, FIFO_TYPE search_value, FIFO_TYPE *found_index);

// warning this is not multi-thread safe
static inline void FifoInit(FIFO *fifo, FIFO_TYPE *array, xt_u32 size)
{
    fifo->m_from = 0;
    fifo->m_to = 0;
    fifo->m_cnt = 0;
    fifo->m_size = size;
    fifo->m_array = array;
}

// warning this is not multi-thread safe
static inline void FifoReload(FIFO *fifo, FIFO_TYPE *array)
{
    fifo->m_array = array;
}

// warning this is not multi-thread safe
static inline int FifoIsEmpty(FIFO *fifo)
{
    return fifo->m_cnt == 0;
}

// warning this is not multi-thread safe
static inline int FifoIsFull(FIFO *fifo)
{
    return fifo->m_cnt == fifo->m_size;
}

// the caller must make sure the FIFO is not full!!!
// warning this is not multi-thread safe
static inline void FifoPush(FIFO *fifo, FIFO_TYPE item)
{
    fifo->m_array[fifo->m_to++] = item;
    if (fifo->m_to >= fifo->m_size) {
        fifo->m_to = 0;
    }
    fifo->m_cnt++;
}

// the callers must make sure the FIFO is not empty!!!
// warning this is not multi-thread safe
static inline FIFO_TYPE FifoPull(FIFO *fifo)
{
    FIFO_TYPE item = fifo->m_array[fifo->m_from++];
    if (fifo->m_from >= fifo->m_size) {
        fifo->m_from = 0;
    }
    fifo->m_cnt--;
    return item;
}

// warning this is not multi-thread safe
static inline FIFO_TYPE FifoPeek(FIFO *fifo)
{
    FIFO_TYPE item = fifo->m_array[fifo->m_from];
    return item;
}

// warning this is not multi-thread safe
static inline FIFO_TYPE FifoPeekN(FIFO *fifo, xt_u32 n)
{
    FIFO_TYPE item;
    xt_u32 from = fifo->m_from + n;
    if (from >= fifo->m_size) {
        from -= fifo->m_size;
    }
    item = fifo->m_array[from];
    return item;
}

// warning this is not multi-thread safe
static inline xt_u32 FifoGetCnt(FIFO *fifo)
{
    return fifo->m_cnt;
}

// warning this is not multi-thread safe
// the callers must make sure the FIFO is not empty!!!
static inline void FifoRemove(FIFO *fifo, xt_u32 n)
{
    xt_u32 next;
    if(fifo->m_size > 1){
        if(n == fifo->m_to){
            next = (n + 1) % fifo->m_size;
            fifo->m_array[n] = fifo->m_array[next];
            n = next;
        }

        do {
            if (n == fifo->m_to) {
                fifo->m_to = (fifo->m_to == 0) ? fifo->m_size - 1 : fifo->m_to - 1;
                break;
            } else {
                if (n == fifo->m_size - 1) {
                    fifo->m_array[n] = fifo->m_array[0];    //corner case
                } else {
                    fifo->m_array[n] = fifo->m_array[n + 1];
                }
                n = (n + 1) % fifo->m_size;
            }
        } while (1);
    }
    fifo->m_cnt--;
}

// warning this is not multi-thread safe
static inline void FifoRemoveBlk(FIFO *fifo, xt_u32 blk)
{
    xt_u32 i = fifo->m_from;
     while (fifo->m_cnt != 0){
        if (blk == fifo->m_array[i]) {
            FifoRemove(fifo, i);
            break;
        }
        i = (i + 1) % fifo->m_size;
        if (i == fifo->m_to) {
            break;
        }
    };
}

// warning this is not multi-thread safe
static inline void FifoMarkInvalidAndPull(FIFO *fifo, xt_u32 fifo_data)
{
    xt_u32 i;
    FifoRemoveBlk(fifo, fifo_data);
    for (i = 0; i < fifo->m_size; i++) {
        if (fifo->m_array[i] == fifo_data) {
            fifo->m_array[i] = INVALID_FIFO_DATA;
        }
    }
}

#endif // __FIFO_H__
