// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : feat.h
//
// ---------------------------------------------------------------------------

#ifndef __FEAT_H__
#define __FEAT_H__

#define OPNSZ                           16

typedef enum
{
    FEAT_OP_CARD_ID                     = 0,
    FEAT_OP_SUB_ID,
    FEAT_OP_FPGA_VER,
    FEAT_OP_DRIV_VER,
    FEAT_OP_CP,
    FEAT_OP_OUI,
    FEAT_OP_PCIE_RX_UNCORRECT_CNT,
    FEAT_OP_PCIE_RX_CORRECT_CNT,
    FEAT_OP_SERI,
    FEAT_OP_OPN,
    FEAT_OP_CARD_INFO,
    FEAT_OP_PCIE_CRC_CNT,
    FEAT_OP_PLL_LOST_CNT,//12

    FEAT_OP_TIER_CP                     = 16,   // Need to guard this value > previous enum value.
    FEAT_OP_CACHE_CP,
    FEAT_OP_PERFM_RW,
    FEAT_OP_ACM_LATENCY,
    FEAT_OP_FPGA_tmp,
    FEAT_OP_ENDUR,

    FEAT_OP_INFO                        = 32,   // Need to guard this value > previous enum value.
    FEAT_OP_WARN,
    FEAT_OP_ERR,

    FEAT_OP_ACM_TIME_DET                = 48,   // Need to guard this value > previous enum value.
    FEAT_OP_SOFT_ERR,
    FEAT_OP_ERZ_ERR,
    FEAT_OP_PROG_ERR,
    FEAT_OP_RAID_RCV,
    FEAT_OP_RD_DATA,
    FEAT_OP_WR_DATA,
    FEAT_OP_RD_DATA_ALL,
    FEAT_OP_WR_DATA_ALL,
    FEAT_OP_PRINT,
    FEAT_OP_POWER,
    FEAT_OP_TEMP_THROTTLE,

    // nvme smart log
    FEAT_OP_CRITICAL_WARNING,
    FEAT_OP_AVAILABLE_SPARE,
    FEAT_OP_PERCENTAGE_USED,
    FEAT_OP_WR_NUM,
    FEAT_OP_RD_NUM,

    FEAT_OP_BUSY_TIME,
    FEAT_OP_PS_CNT,
    FEAT_OP_POH,
    FEAT_OP_UNSAFE_SHUTDOWN,
    FEAT_OP_MEDIA_DATA_INTEGRITY_ERR,
    FEAT_OP_NUM_ERR_INFO_ENTR,
    FEAT_OP_WARNING_COMPOSITE_TEM,
    FEAT_WARNING_TEMP_TIME,
    FEAT_CRITICAL_TEMP_TIME,
    FEAT_OP_TEM_SENSOR1,
    FEAT_OP_TEM_SENSOR2,
    FEAT_OP_TEM_SENSOR3,
    FEAT_OP_TEM_SENSOR4,
    FEAT_OP_TEM_SENSOR5,
    FEAT_OP_TEM_SENSOR6,
    FEAT_OP_TEM_SENSOR7,
    FEAT_OP_TEM_SENSOR8,
    FEAT_OP_PF_BBD_READ_CNT,


    // intel smart log
    FEAT_OP_INTEL_WR_DATA_ALL,
    FEAT_OP_INTEL_WR_DATA,
} FEAT_OP;

#endif // __FEAT_H__
