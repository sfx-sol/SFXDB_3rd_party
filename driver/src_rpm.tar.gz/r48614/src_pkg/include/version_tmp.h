// ---------------------------------------------------------------------------
// WARNING - THIS IS A GENERTAED FILE - DO NOT EDIT/ALTER MANUALLY!
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// DO NOT MODIFY THE FOLLOWING MACROS IN YOUR SOURCE CODE.
// ---------------------------------------------------------------------------
#define SFX_SW_VERSION                      "0.0.0.0-48614"
#define SFX_SW_VERSION_OFFSET               47400
#define SFX_DRIVER_VERSION                  (0x4be)
#define SFX_PREBUILT_LIB_VERSION            48614

// ---------------------------------------------------------------------------
// Please always use the following global variables when printing version info.
// ---------------------------------------------------------------------------
extern char *sfx_sw_version_str;            // = SFX_SW_VERSION;
extern xt_u32 sfx_driver_version;           // = SFX_DRIVER_VERSION

// ---------------------------------------------------------------------------
// The following global variables contain internal Prebuilt Libs version info.
// ---------------------------------------------------------------------------
extern xt_u32 libccs_ka_version;            // = SFX_PREBUILT_LIB_VERSION;
extern xt_u32 sfx_bd_dev_lib_ka_version;    // = SFX_PREBUILT_LIB_VERSION;

// ---------------------------------------------------------------------------
// WARNING! DO NOT ALTER THE git_base=nnnnn line.
// The git_base line has to be the last line of this file.
// ---------------------------------------------------------------------------
// git_base=48614
