// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_H__
#define __SFX_H__

#ifndef __KERNEL__
#include <stdint.h>
#include <pthread.h>
#endif
#include "sfx_types.h"

#define NVME_MAX_COMMAND        (2048)
#define MAX_NR_DRIVE            (32)
#define MAX_COMBINED_FCMD       (8)
#define HOT_META_CHUNK_BITS     (14)     //64M -1 byte
#define HOT_META_CHUNK          (1 << HOT_META_CHUNK_BITS)              // 64M bytes
#define HOT_META_CHUNK_HALF     ((1 << HOT_META_CHUNK_BITS) / 2)        // 32M bytes
#define HOT_META_CHECK_VAL      (256 * 256)                             // outstanding CMD number
#define HOT_META_CHUNK_MASK     ((1 << HOT_META_CHUNK_BITS) - 1)        // 64M -1 bytes
#define HOT_HEADER_SIZE         16
#define HOT_FOOTER_SIZE         16
#define HOT_METALOG_SIZE        (MAP_LOG_SIZE)
#define HOT_LAST_META_OFFSET    (HOT_METALOG_SIZE + HOT_FOOTER_SIZE)    //32 * 4k meta + 8 * 4k footer
#define HOT_BARRIER_CTRL_NUM    (8)
#define HOT_BARRIER_ID_MASK     (8 - 1)     // HOT_BARRIER_CTRL_NUM must be 2**n
#define HOT_2nd_LST_BARRIER     (8)
#define HOT_LST_BARRIER         (9)
#define HOT_META_FLAG_SIZE      (HOT_LST_BARRIER + 1)
#define RCD_CMPL_BA_CMD_NUM     (10)
#define DCE_FIFO_SIZE           4           // per HW, 16/4 = 4  16 FIFO shared by 4 compression engines
#define READ_FIFO_DEFAULT       7           // per HW, 8 may become 9 in real life
#define HOT_CMP_ML_FT_OL        (MAP_LOG_SIZE * 2 + MAP_LOG_SIZE + HOT_FOOTER_SIZE)

enum FEATURE_SET_OPS
{
    SET_READ_SCRUB=0x1,
    SET_RDD_THRD1,
    SET_WL_START_THRD,
};

enum
{
    sfx_cmd_write = 1,
    sfx_cmd_read = 2,
    sfx_cmd_admin_async = 0xc,      /* admin queue */
    sfx_cmd_erase = 0xf0,
    sfx_cmd_nand_reset = 0xf0,      /* admin queue */
    sfx_cmd_aes_program = 0xf1,
    sfx_cmd_dceread = 0xf3,         /* added for EC operation */
    sfx_cmd_nand2buf = 0xf4,
    sfx_cmd_buf2nand = 0xf5,
    sfx_cmd_loopback = 0xf6,
    sfx_cmd_barrier = 0xba,
};

enum
{
    OP_APPEND = 0,
    OP_WRITE = sfx_cmd_write,
    OP_READ = sfx_cmd_read,
    OP_ERASE = sfx_cmd_erase,
    OP_DCEREAD = sfx_cmd_dceread,   /* added for EC operation */
    OP_TRIM = 4,
    OP_SEAL = 5,
    OP_ALLOCATE = 6,
    OP_ABORT = 7,
    OP_GETSTAT = 8,
    OP_GETPARITYSIZES = 9,
    OP_NON_DATA_CMD_END,
    OP_APPEND_EC = 0x10,            /* added for EC operation */
    OP_COMP_EC,                     /* added for EC operation */
    OP_GET_EC,                      /* added for EC operation */
    OP_DCE_EC,
    OP_READBACK_EC,                 /* EC operation */
    OP_ABORT_EC,
    OP_APPEND_CMP,
    OP_DCE_CMP,
    OP_GET_CMP,
    OP_ABORT_COMP,
    OP_SCHEMA_R2C,
    OP_DCE_R2C,
    OP_N2B_R2C,
    OP_GET_R2C,
    OP_CONFIG_R2C,
    OP_ABORT_R2C,
    OP_RDBUFF,
    OP_BARRIER_CMD = sfx_cmd_barrier,
    OP_NAND2BUF = sfx_cmd_nand2buf,
    OP_BUF2NAND = sfx_cmd_buf2nand,
    OP_RESERVE
};

typedef struct
{
    union {
        struct {
            /* 4'b0000: success, 4'bxxx1: lower plane ldpc decode fail
            4'bxx1x: higher plane ldpc decode fail, 4'bx1xx: CRC error
            4'b1xxx: NAND read failure */
            xt_u32 status          : 4;
            xt_u32 ldpc_dec_iter   : 12;
            xt_u32 ldpc_error_cnt  : 12;
            xt_u32 rsvd            : 1;
            xt_u32 erased_page     : 1;
            xt_u32 internal_crc_err: 1;
            xt_u32 lba_mismatch    : 1;
        };
        xt_u32 val;
    };
} FLASH_CMD_CMPL_STATUS;

typedef struct
{
    xt_u16 result;
    xt_u16 cpuid;
    xt_u16 is_valid;
    xt_u16 qid;
    xt_u16 vt;
    xt_u16 slot;
} read_retry_context;

typedef struct
{
    xt_u32 sw_pba;
    xt_u16 cp;
    xt_u16 rsvd;
} erase_retry_context;


typedef struct
{
    xt_u16 nid;
    xt_u16 gid;
    xt_u16 comb_nid[MAX_COMBINED_FCMD];
    FLASH_CMD_CMPL_STATUS cmpl_status;
    sfx_atomic_t in_maplog;
    sfx_atomic_t flag_ml;
    sfx_atomic_t exp_off;
    sfx_atomic_t off_chk;
    sfx_atomic_t submit_off;
    sfx_atomic_t single4K;           /* For read, single 4K application cmd; For write, map-log cmd */
    xt_u8 nr_fcmd;
    xt_u8 op_code;            /* OP_XXXX */
    xt_u8 qid;                /* queue id */
    xt_u8 stream;
    xt_u8 dp;                 /* dual page programming, used for B17A two pass programming */
    xt_u8 page_type;          /* page type, currently used for read retry */
    xt_u8 direct_mode;        /* direct mode used in RAID*/
    xt_u8 prp_mask;           /* mask to read */
    xt_u8 read_mask_ones_count; /* move from fcmd */
    xt_u16 added_length;
    xt_u16 length;            /* number of 4K pages, 0s based */
    xt_u16 ssid;              /* write from buffer id. */
    xt_u16 wr_sn;             /* data sequence number in write cmd */
    xt_u32 aes_bvalue;        /* AES encryption/decryption basic value */
    xt_u32 crc_high;        /*LBA CRC high 4B*/
    xt_u32 mid;               /* mem ID */
    xt_u32 app_mid;
    xt_u64 pba;               /* 40-bit */
    xt_u32 sw_pba;
    xt_u32 *host_addr;        /* 64bit */
    xt_u32 curMapEntry;
    xt_u32 not_a_direct_read;
    xt_u32 app_qid;           /* the applicaton queue id belongs to, only use for the hot user data which is interleaved with map_log */
    xt_u32 offset;
    ccs_callback_t cb;
    //fcmd_cmpl_cb cb_dir_wr;
    void   *context;
    xt_u64 seq_id;            /* for row2col */
    read_retry_context rd_retry_ctx;
    // flags
    union {
        xt_u32 parity_mode:3;
        xt_u32 ec_id:3;
    };
    xt_u32 duplicate:3;
    xt_u32 SLC:1;
    xt_u32 encryption:1;
    xt_u32 compression:2;
    union {
        xt_u32 writesession:4;
        xt_u32 ec_cmd:4;       /* for DCE read */
    };
    union {
        xt_u32 Vt:5;
        xt_u32 ec_cid:3;       /* for DCE read */
    };
    union {
        xt_u32 DLA:1;
        xt_u32 ECWR:1;
    };
    xt_u32 buffer_mode:1;      /* read to buffer, or write from buffer */
    xt_u32 raid_bufid:3;
    xt_u32 LLC:1;
    xt_u32 flush: 2;
    xt_u32 po_offset: 2;
    xt_u32 rq_flag: 1;
    xt_u32 FUSE: 1;         /* for compression */
    xt_u32 rsvd_: 3;

    xt_u16 bufid;          /* Used for buf2nand */
    xt_u8  tag_id;      /* used by read/write/buf2nand  */
    xt_u8  stripe_id;      /* used by read/write/buf2nand  */
    xt_u8  last_stripe;    /* used by buf2nand cold stream */
    xt_u32 cmp_ctl;        // for compression
    xt_u16 pe_count;       /* used for scrambler seed */
    xt_u8  comp_sid;
    xt_u8  ec_sid;
    xt_u8  ec;             /* for erasure coding, set to 1 for nvme read cmd */
    xt_u8  snaprd;         /* Snap Read, used by read */
    xt_u8  owl;            /* close_wordline */
    xt_u8  non_susp;            /* disable suspend in b2n cmd */
    xt_u8  susp;
    xt_u8  low_priority;
    xt_u8  bd_pl_mask;     /* bad plane mask*/
    xt_u8  uis;            /* for unindex search */
    xt_u8  nvm;            /* for NVM write */
    xt_u8  cmd_status;
    xt_u8  cmd_fuse;
    xt_u8  cp;             /*check point*/
    xt_u8  padding_flag;
    xt_u8  rd_bp_bitmap;        // Read Bad Plane Mask defined in Extended Control bit[27:24]
    xt_u64 timestamp_toHW;
    xt_u64 timestamp_ret;
    xt_u32 rsvd;
    xt_u32   buf2nand_off;
    xt_u32   buf2nand_id;
    xt_u32   first_wr_cmd;
    xt_u32 cmpl_offset;
#ifdef __KERNEL__
    sfx_ktime_t ccs_smt_time;
    sfx_ktime_t ccs_ret_time;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    struct {
        sfx_ktime_t cmd_ftl_rec_time;
        sfx_ktime_t cmd_ftl_smt_time;
        sfx_ktime_t cmd_ftl_rtn_time;
        sfx_ktime_t cmd_ftl_cmplblk_time;
        sfx_ktime_t cmd_ftl_cmpl_time;
    };
#endif
#endif
    sfx_lba_list *lba_list;
    xt_u32 lba_offset;
    xt_u32 sing_lba;
    xt_u16 cmd_seq_num;
    xt_u8 rrb_submit_len;
    xt_u8 rrb_complete_len;

    xt_u8  schema_id;
    xt_u8  start_sequence_id;
    xt_u8  fuse_flag;
    xt_u8  retry_Vt;
    xt_u8  is_rmw;
    xt_u8  rebld_cnt;
    xt_u8  rebld_fail;
    xt_u32 rebld_retry_ms;
    xt_u8  rd_after_wr;
    xt_u32 merge_read;
    xt_u64 leading_lba;
    xt_u32 erase_retry;
    xt_u8  read_crc_error;
    xt_u16 keyid;
    xt_u8  seq_read;
} SFX_NVME_IO_CMD;

typedef struct
{
    sfx_atomic_t  cmd_status;
    sfx_atomic_t  num_cmd;
    sfx_atomic_t  split_flag;
    sfx_atomic_t  length;
    sfx_atomic_t  print;
    xt_u32 mid;
    xt_u32 curMapEntry;
    xt_u32 pre_app_len;
    xt_u32 mid_offset;
    xt_u32 cmpl_offset;             //for loopback cmd test only
    xt_u32 cmpl_offset_pre;
    xt_u64 hw_pba;                  //debug
    xt_u32 sw_pba;
    xt_u32 comp_sid;
    sfx_atomic_t comp_len;
    sfx_atomic_t commitLength;
    sfx_atomic_t comp_sent_cnt;
    sfx_atomic_t split_2cmd;
    xt_u64 timestamp_rec;
    xt_u64 timestamp_cmpl;
    ccs_callback_t cb;
    void   *context;
    void   *host_addr;
    xt_u32  stream;
    xt_u8  padding_flag;
    xt_u16 op_code;
    sfx_lba_list *lba_list;
    xt_u32 lba_offset;
    xt_u32 single_lba;
    xt_u16 cmd_seq_num;
    xt_u16 cmpl_status;
} APPLICATION_IO_CMD;

typedef struct
{
    xt_u16 nid;
    xt_u16 op_code;
    union {
        xt_u16 ssid:10;       /* read to buffer id, return from HW */
        xt_u16 comit_length;  /* unused,for compression only */
        xt_u32 result;
        xt_u32 pba;
    };
    xt_u16 fids[MAX_COMBINED_FCMD];
    xt_u16 nr_fcmd;
    void *comb_token;
    xt_u32 ext_result;
    xt_u64 latency;
    // xt_u32 lba;
} SFX_NVME_CMD_RESULT;

typedef struct
{
    xt_u32 status;            /* reserved */
    xt_u32 cq_len;
    SFX_NVME_CMD_RESULT cpl[NVME_MAX_COMMAND];
} SFX_CHECK_NVME_STATUS;

#ifdef USE_KTIME_CTX
typedef struct
{
    xt_u64 nandreset_rtt;
    xt_u64 nandreset_smt;
    xt_u64 nandreset_cnt;
    xt_u64 nandreset_max;
    xt_u64 aes_rtt;
    xt_u64 aes_smt;
    xt_u64 aes_cnt;
    xt_u64 aes_max;
    xt_u64 ai_rtt;
    xt_u64 ai_smt;
    xt_u64 ai_cnt;
    xt_u64 ai_max;
    xt_u64 gf_rtt;
    xt_u64 gf_smt;
    xt_u64 gf_cnt;
    xt_u64 gf_max;
    xt_u64 sf_rtt;
    xt_u64 sf_smt;
    xt_u64 sf_cnt;
    xt_u64 sf_max;
    xt_u64 dcq_rtt;
    xt_u64 dcq_smt;
    xt_u64 dcq_cnt;
    xt_u64 dcq_max;
    xt_u64 dsq_rtt;
    xt_u64 dsq_smt;
    xt_u64 dsq_cnt;
    xt_u64 dsq_max;
    xt_u64 other_rtt;
    xt_u64 other_smt;
    xt_u64 other_cnt;
    xt_u64 other_max;
    xt_u64 wr_rtt;
    xt_u64 wr_smt;
    xt_u64 wr_cnt;
    xt_u64 wr_max;
    xt_u64 rd_rtt;
    xt_u64 rd_smt;
    xt_u64 rd_cnt;
    xt_u64 rd_max;
    xt_u64 other_asyncio_rtt;
    xt_u64 other_asyncio_smt;
    xt_u64 other_asyncio_cnt;
    xt_u64 other_asyncio_max;
} SFX_NVME_QSTATS;

typedef struct
{
    xt_u32 status;     /* reserved */
    xt_u32 qcnt;
    SFX_NVME_QSTATS q_stats[NUM_MAXQ];
} SFX_GET_QSTATS;
#endif

typedef struct
{
    xt_u32 mid;
    xt_u32 wk_id;
    xt_u32 offset;
    xt_u64 seq_num;
} barrier_rcd;

typedef struct
{
    xt_u32 mid;
    xt_u32 wk_id;
    xt_u32 offset;
    xt_u32 abort_info;
    xt_u32 cpu_id;
    xt_u32 qid;
} last_ba_wk;

typedef struct
{
    SFX_NVME_IO_CMD     nvme_cmd[HOT_IO_QD];
    queue_elem_t        nvme_elem[HOT_IO_QD];
    com_queue_t         nvme_que[2];
    com_linklist_t      nvme_ll;
    xt_u16              nvme_pending_commands[2];
    xt_u16              nvmecmd_seq_num;
    sfx_atomic_t        meta_flag[HOT_META_FLAG_SIZE];
    sfx_atomic_t        barrier_cmpl_flag;
    sfx_atomic_t        barrier_otd;
    sfx_atomic_t        barrier_cnt[2];
    sfx_atomic_t        barrier_idx;
    barrier_rcd         barrier_set[RCD_CMPL_BA_CMD_NUM];
    last_ba_wk          last_ba_log;
    xt_u32              curr_mid;
    xt_u32              pre_mid;
    xt_u32              msix_mask;
    xt_u32              sub_pending;
#ifdef __KERNEL__
    sfx_spinlock_t      q_lock;
    sfx_spinlock_t      nvme_submit_lock;
#else
    pthread_mutex_t     q_lock;
    pthread_mutex_t     nvme_submit_lock;
#endif
    sfx_atomic_t        q_depth;
    sfx_atomic_t        last_4k_pba;
    sfx_atomic64_t      num_smt;
    sfx_atomic64_t      num_polled;
    xt_u64              sched; //if this queue is scheduled to be polled
    xt_u64              sched_poll_time;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    struct {
        void            *bar;
#ifdef __KERNEL__
        sfx_spinlock_t  rd_perf_lock;
#else
        pthread_mutex_t rd_perf_lock;
#endif
        xt_u64          hot_blk_req_end2end_proc;
        xt_u64          hot_req_init2smt_lat;
        xt_u64          hot_blk_cmd_smt_end2end_lat;

        xt_u64          hot_rd_blk_cmd_init2smt_lat;
        xt_u64          hot_rd_blk_cmd_rtn2cmpl_lat;
        xt_u64          hot_rd_ftl_init2smt_lat;
        xt_u64          hot_rd_ftl_smt2rtn_lat;
        xt_u64          hot_rd_ftl_rtn2cmplblk_lat;
        xt_u64          hot_rd_ftl_cmplblk2cmpl_lat;
        xt_u64          hot_rd_drv_cmd_init2smt_lat;
        xt_u64          hot_rd_drv_cmd_smt2irq_lat;
        xt_u64          hot_rd_drv_cmd_irq2cb_lat;
        xt_u64          hot_rd_drv_cmd_cb_lat;
        xt_u64          hot_rd_drv_cmd_cb2cmpl_lat;
#if (READ_HW_LAT)
        xt_u64          hot_rd_drv_hwcnt_smt2cpl_lat;
        xt_u64          hot_rd_drv_hwcnt_smt2irq_lat;
#endif
        xt_u64          hot_rd_req_intval;
        xt_u64          hot_rd_req_init2rtn_lat;
        xt_u64          hot_rd_req_rtn2cmpl_lat;
        xt_u64          num_rd_req;
        xt_u64          num_drv_read;
        xt_u64          num_hot_read;     /* number of hot read nvme cmd */

        xt_u64          blk_end2end_max;
        xt_u64          blk_coh_max;
        xt_u64          blk_init2smt_max;
        xt_u64          blk_handle2smt_max;
        xt_u64          blk_proc_wr_max;
        xt_u64          req_init2rtn_max;
        xt_u64          req_interval_max;
        xt_u64          ftl_init2smt_max;
        xt_u64          ftl_smt2rtn_max;
        xt_u64          ftl_rtn2cmplblk_max;
        xt_u64          drv_init2smt_max;
        xt_u64          drv_smt2rtn_max;
        xt_u64          drv_cmb_cb_max;

        xt_u64          hot_wr_blk_cmd_init2smt_lat;
        xt_u64          hot_wr_blk_cmd_rtn2cmpl_lat;
        xt_u64          hot_wr_ftl_init2smt_lat;
        xt_u64          hot_wr_ftl_smt2rtn_lat;
        xt_u64          hot_wr_ftl_rtn2cmplblk_lat;
        xt_u64          hot_wr_ftl_cmplblk2cmpl_lat;
        xt_u64          hot_wr_drv_cmd_init2smt_lat;
        xt_u64          hot_wr_drv_cmd_smt2irq_lat;
        xt_u64          hot_wr_drv_cmd_irq2cb_lat;
        xt_u64          hot_wr_drv_cmd_cb_lat;
        xt_u64          hot_wr_drv_cmd_cb2cmpl_lat;
        xt_u64          hot_wr_req_intval;
        xt_u64          hot_wr_req_init2rtn_lat;
        xt_u64          hot_wr_req_rtn2cmpl_lat;
        xt_u64          num_wr_req;
        xt_u64          num_drv_write;
        xt_u64          num_hot_write;     /* number of hot read nvme cmd */

        sfx_ktime_t     last_req_time;
        sfx_ktime_t     last_wr_req_time;
        xt_u64          tot_qd;
    };
#endif
} SFX_NVME_CMD_QUEUE_STRUCT;

typedef struct
{
    APPLICATION_IO_CMD  appq[HOT_IO_QD];
    queue_elem_t        appq_elem[HOT_IO_QD];
    com_queue_t         appq_que[2];
    com_linklist_t      appq_ll;
    xt_u16              appq_pending_commands[2];
    xt_u16              acmd_seq_num;
#ifdef __KERNEL__
    sfx_spinlock_t      q_lock;
#else
    pthread_mutex_t     q_lock;
#endif
} sfx_app_queue;

/* assert related */
static inline char* current_thread_state(int state)
{
    switch (state) {
    case SFX_THRD_NONE:
        return (char *)"absent";
    case SFX_THRD_CREATED:
        return (char *)"created but not running";
    case SFX_THRD_IDLE:
        return (char *)"idle";
    case SFX_THRD_RUNNING:
        return (char *)"running";
    case SFX_THRD_PARKING:
        return (char *)"parked";
    case SFX_THRD_ASSERTED:
        return (char *)"asserted";
    case SFX_THRD_STOPPED:
        return (char *)"finished";
    default:
        return (char *)"corrupted";
    }
}

static inline xt_u16 sfx_get_mq_ioqid(xt_u32 cpuid, unsigned int *map,
            xt_u8 is_read, xt_u8 stream_id, struct sfx_ioq_config *ioq_config)
{
    xt_u16 qid_base = 0, qid;
    //xt_u16 num_read_unit = ioq_config->isolation ? ioq_config->num_stream : 1;
    xt_u16 inner_qid = map[cpuid];
    if (is_read) {
        qid_base = HOT_RD_QID_BASE;
        //qid = qid_base + stream_id * ioq_config->rdq_per_unit + inner_qid;
        qid = qid_base + inner_qid;
    } else {
        qid_base = HOT_RD_QID_BASE + ioq_config->rdq_per_unit;
        qid = qid_base + stream_id * (ioq_config->wrq_per_stream + QID_OFF_WR_BASE)
                + QID_OFF_WR_BASE + inner_qid;
    }
    return qid;
}

static inline xt_u8 sfx_qid_is_rdq(xt_u16 qid, struct sfx_ioq_config *ioq_config)
{
    xt_u16 num_rd_stream = ioq_config->isolation ? ioq_config->num_stream : 1;
    xt_u16 tot_rd_queue = num_rd_stream * ioq_config->rdq_per_unit;
    return (qid >= HOT_RD_QID_BASE && qid < HOT_RD_QID_BASE + tot_rd_queue);
}

static inline xt_u8 sfx_qid_is_wrq(xt_u16 qid, struct sfx_ioq_config *ioq_config)
{
    xt_u16 num_rd_stream = ioq_config->isolation ? ioq_config->num_stream : 1;
    xt_u16 tot_rd_queue = num_rd_stream * ioq_config->rdq_per_unit;
    return (qid >= HOT_RD_QID_BASE + tot_rd_queue);
}

static inline xt_u8 sfx_qid_is_hotwrioq(xt_u16 qid, struct sfx_ioq_config *ioq_config)
{
    xt_u16 num_rd_stream = ioq_config->isolation ? ioq_config->num_stream : 1;
    xt_u16 tot_rd_queue = num_rd_stream * ioq_config->rdq_per_unit;
    return (qid >= HOT_RD_QID_BASE + tot_rd_queue + QID_OFF_WR_BASE);
}

static inline xt_u16 sfx_get_queue_type(xt_u16 qid)
{
    switch (qid) {
        case QID_ADMIN : return SFX_ADMINQ;
        case QID_MIX_WR: return SFX_MIXED_WRQ;
        case QID_MIX_RD: return SFX_MIXED_RDQ;
        case QID_ERASE : return SFX_ERASEQ;
        case QID_CHEPT : return SFX_CHEPTQ;
        case QID_WL    : return SFX_WLQ;
        default: return SFX_INVALIDQ;
    }
}

static inline void sfx_pu_res_update(sfx_die_bitmap *die_bm, xt_u32 pu_id,
                                     xt_u32 num_die, xt_u32 *die_list, xt_u32 alloc)
{
    xt_u32 idx_ide;
    for (idx_ide = 0; idx_ide < num_die; idx_ide++) {
        die_bm->pu_id[die_list[idx_ide]] = alloc ? pu_id : 0xFF;
    }
}

/** @brief Submit an command to the Arundina card
 *
 *  Each call to sfx_submit_nvme asynchronously submits the command
 *  described by "cmd." You may submit at most NVME_MAX_COMMAND commands
 *  at a time.
 *
 *  @param cmd The command to be submitted
 *  @return A status code:
 *          0: Success
 *          -1 or other negative numbers: Error
 */
xt_32 sfx_submit_nvme(union handle *hand, SFX_NVME_IO_CMD * cmd);

/** @brief Check for completed command status
 *
 *  Each call to sfx_check_nvme checks for all commands which have
 *  completed since the last call to sfx_check_nvme. It places the
 *  status values of these commands into the buffer pointed to by
 *  "status".
 *
 *  @param status A buffer in which sfx_check_nvme places status values
 *  @return A status code:
 *          0: Success
 *          1: Pending
 *          -1: Error
 */
xt_32 sfx_check_nvme(union handle *hand, SFX_CHECK_NVME_STATUS * status);
xt_32 sfx_check_nvme_q(union handle *hand, SFX_CHECK_NVME_STATUS * status);
xt_32 sfx_device_open(const char *dev_name, union handle *file_handle);
xt_32 sfx_device_close(union handle *file_handle);

#ifdef USE_KTIME_CTX
xt_32 sfx_get_qstats(union handle *hand, SFX_GET_QSTATS *qstats);
#endif

#endif // __SFX_H__
