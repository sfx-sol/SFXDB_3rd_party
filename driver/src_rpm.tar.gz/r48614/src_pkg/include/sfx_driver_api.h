/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * Definitions for the NVM Express interface
 * Copyright (c) 2011-2014, Intel Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_driver_api.h
 * ---------------------------------------------------------------------------
 */

#ifndef __SFX_DRIVER_API_H__
#define __SFX_DRIVER_API_H__

#include "sfx_api.h"

struct sfx_dev;
struct sfx_fd;

#ifdef __SFX_KERNEL__
int sfx_nand_device_reset(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce);
void sfx_fd_destroy(struct sfx_fd *fd);
int sfx_fd_init(struct sfx_fd **fd, struct sfx_dev *dev);
int sfx_submit_nvme_io(struct sfx_fd *fd, struct sfx_userio_cmd *io, sfx_bool sync, sfx_bool from_kernel);
xt_u32 sfx_get_pci_bar_cts_api(struct sfx_fd *fd);
xt_u32 sfx_indirect_read32(struct sfx_fd *fd, xt_u32 addr);
void sfx_indirect_write32(struct sfx_fd *fd, xt_u32 addr, xt_u32 value);
int sfx_kernel_check_status(struct sfx_fd *fd, void *status_struct);
int sfx_kernel_check_q_status(struct sfx_fd *fd, void *status_struct);
#ifdef USE_KTIME_CTX
int sfx_kernel_get_qstats(struct sfx_fd *fd, void *qstats_struct);
#endif
int sfx_unlock_user_pages_kernel_api(struct sfx_fd *fd, void *mem_struct);
int sfx_lock_user_pages_kernel_api(struct sfx_fd *fd, void *mem_struct);
void sfx_length_one_token_api(struct sfx_fd *fd, void *mem_struct);
int sfx_split_token_kernel_api(struct sfx_fd *fd, void *mem_struct);
int sfx_split_token_release_kernel_api(struct sfx_fd *fd, void *token);
int sfx_set_pagelist_kernel_api(struct sfx_fd *fd, void **list, void **token, unsigned count, int type, int offset);
int sfx_get_matched_sdev_fd(int minor, struct sfx_dev *idev, struct sfx_fd **ifd);
int sfx_matched_fd(struct sfx_fd *fd);
struct page **sfx_get_page_from_token(union handle *hand, xt_u32 *vaddr);
xt_u32 sfx_get_pglist_entry_nr(void);
int sfx_user_get_freeslot_kernel_api(struct sfx_fd *fd, xt_u32 *nfslotp);
int sfx_kernel_get_feature(struct sfx_fd *fd, xt_u16 op, xt_u32 *data, xt_u8 len);
int sfx_kernel_capacitor_handle(struct sfx_fd *fd, xt_u32 op, xt_u32 para);
xt_u32 sfx_kernel_read_power(struct sfx_fd * fd);
void *sfx_alloc_nvmeq(void *sfx_driver_handle, struct sfx_driver_nvmeq_ctx *init_ctx, ftl_cmpl_cb cb);
int sfx_free_nvmeq(void *sfx_driver_handle, xt_u8 qid);
void sfx_dump_driver_counter(void *sfx_driver_handle);
int sfx_assign_interrupts(struct sfx_dev *dev);
int sfx_process_cq(void *ctx, int lock_need, xt_u32 cmpl_target);
xt_u32 sfx_get_irq(void *sfx_driver_handle, xt_u16 qid);
void *sfx_get_nvmeq_lock(void *nvmeq);
void sfx_compressionq_throttle(void *sfx_driver_handle, int base_qid, int write_val);
void sfx_comp_readq_throttle(void *sfx_driver_handle, int base_qid, int write_val);
void sfx_ecq_throttle(void *sfx_driver_handle, int base_qid, int write_val);
extern struct sfx_dev *sfx_get_active_sdev(int minor);
extern int sfx_vprintk_driver(const char *fmt, va_list args);
int sfx_get_dev_count(void);
xt_u32 sfx_kernel_get_nvmeq_head(struct sfx_fd *fd, xt_u32 qid);
xt_u32 sfx_kernel_get_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid);
xt_u32 sfx_kernel_get_nvmeq_depth(struct sfx_fd *fd, xt_u32 qid);
int sfx_kernel_set_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid, xt_u32 tail);
int sfx_kernel_nvmeq_reset(struct sfx_fd *fd, xt_u32 qid);
xt_u32 sfx_kernel_spi_init(struct sfx_fd *fd);
xt_u32 sfx_kernel_spi_init_read_only(struct sfx_fd *fd);
void sfx_kernel_spi_exit(struct sfx_fd *fd);
xt_u32 sfx_kernel_spi_erase_data(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len);
xt_u32 sfx_kernel_spi_write_data(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data);
xt_u32 sfx_kernel_nor_flash_read(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len, xt_u32 *datao);
xt_u32 sfx_kernel_spi_read_nor_did(struct sfx_fd *fd, xt_u32 len, xt_u32 *datao);
void sfx_kernel_vu_get_feat_data(struct sfx_fd *fd, xt_u32 *feat_data);
void sfx_inc_blk_ref_cnt_api(struct sfx_fd *fd);
void sfx_dec_blk_ref_cnt_api(struct sfx_fd *fd);
#endif
xt_u32 sfx_read_power(struct sfx_dev *dev);
int sfx_capacitor_handle(struct sfx_dev *dev, xt_u32 op, xt_u32 para);
int sfx_kernel_lifecnt_read(struct sfx_fd *fd, xt_u32 type,
        xt_u32 *lifeCountInfo);
int sfx_lifecnt_get(struct sfx_dev *sdev, xt_u32 type,
        xt_u32 *lifeCountInfo);
xt_u32 sfx_kernel_lifecnt_update(struct sfx_fd *fd, xt_u32 ope,
        xt_u32 *lifeCountInfo);
xt_u32 sfx_lifecnt_update(struct sfx_dev *sdev, xt_u32 ope,
        xt_u32 *lifeCountInfo);
void sfx_update_nor_dump_sector(struct sfx_fd *fd, xt_u32 sector);
int sfx_nor_dump_ctrl(struct sfx_fd *fd, xt_u32 enable);

#endif // __SFX_DRIVER_API_H__
