// ---------------------------------------------------------------------------
//
// Copyright 2017-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : osal.h
//      For wrapper functions not depended on OS.
//      Please don't add OS specific functions here.
// ---------------------------------------------------------------------------

#ifndef __OSAL_H__
#define __OSAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "sfx_types.h"

#ifdef __KERNEL__

void sfx_wake_up(sfx_wait_queue_head_t* wq);
void *sfx_bd_alloc_mem(xt_u32 size, xt_u32 alignment, sfx_bool zeroed, sfx_heap_id heap_id);
void sfx_bd_free_mem(void *mem, sfx_heap_id heap_id);

#else

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/queue.h>

//these are from errno-base.h linux kernel header file
#define EPERM        1  /* Operation not permitted */
#define ENOENT       2  /* No such file or directory */
#define ESRCH        3  /* No such process */
#define EINTR        4  /* Interrupted system call */
#define EIO          5  /* I/O error */
#define ENXIO        6  /* No such device or address */
#define E2BIG        7  /* Argument list too long */
#define ENOEXEC      8  /* Exec format error */
#define EBADF        9  /* Bad file number */
#define ECHILD      10  /* No child processes */
#define EAGAIN      11  /* Try again */
#define ENOMEM      12  /* Out of memory */
#define EACCES      13  /* Permission denied */
#define EFAULT      14  /* Bad address */
#define ENOTBLK     15  /* Block device required */
#define EBUSY       16  /* Device or resource busy */
#define EEXIST      17  /* File exists */
#define EXDEV       18  /* Cross-device link */
#define ENODEV      19  /* No such device */
#define ENOTDIR     20  /* Not a directory */
#define EISDIR      21  /* Is a directory */
#define EINVAL      22  /* Invalid argument */
#define ENFILE      23  /* File table overflow */
#define EMFILE      24  /* Too many open files */
#define ENOTTY      25  /* Not a typewriter */
#define ETXTBSY     26  /* Text file busy */
#define EFBIG       27  /* File too large */
#define ENOSPC      28  /* No space left on device */
#define ESPIPE      29  /* Illegal seek */
#define EROFS       30  /* Read-only file system */
#define EMLINK      31  /* Too many links */
#define EPIPE       32  /* Broken pipe */
#define EDOM        33  /* Math argument out of domain of func */
#define ERANGE      34  /* Math result not representable */

typedef size_t sfx_stdsize_t;
typedef size_t sfx_size_t;
typedef pthread_t sfx_thread_t;
typedef unsigned long sfx_useconds_t;
typedef unsigned int atomic_t;
typedef unsigned long atomic64_t;
typedef pthread_rwlock_t sfx_rwlock_t;
typedef pthread_mutex_t sfx_mutex_t;
typedef pthread_mutex_t sfx_spinlock_t;

#define SFX_PRINTF                              printf
#define SFX_FREE(p)                             free(p)
#define SFX_TAILQ_ENTRY(type)                   TAILQ_ENTRY(type)
#define SFX_TAILQ_HEAD(type0, type1)            TAILQ_HEAD(type0 ## _s, type1); typedef struct type0 ## _s type0
#define SFX_TAILQ_INIT(pq)                      TAILQ_INIT(pq)
#define SFX_TAILQ_INSERT_TAIL(head,node,field)  TAILQ_INSERT_TAIL(head, node, field)
#define SFX_TAILQ_EMPTY(head)                   TAILQ_EMPTY(head)
#define SFX_TAILQ_FIRST(head)                   TAILQ_FIRST(head)
#define SFX_TAILQ_REMOVE(head,node,field)       TAILQ_REMOVE(head,node,field)
#define SFX_TAILQ_FOREACH(item,head,field)      TAILQ_FOREACH(item,head,field)
#define SFX_MSLEEP(ms)                          usleep(ms*1000)

#define DEBUG
#ifdef DEBUG
#define CCS_INFO(fmt,...)                       SFX_PRINTF("%s: "fmt, __FUNCTION__, ##__VA_ARGS__)
#define CCS_ERROR(fmt,...)                      SFX_PRINTF("ERROR:%s: "fmt, __FUNCTION__, ##__VA_ARGS__)
#else
#define CCS_INFO(fmt,...)
#define CCS_ERROR(fmt,...)
#endif

#define current                                 ({ \
                                                    pthread_t tid = pthread_self(); \
                                                    (void *)tid; \
                                                })
#define SFX_DEFINE_MUTEX(name)                  pthread_mutex_t name = PTHREAD_MUTEX_INITIALIZER
#define sfx_crash                               assert
#define sfx_assert                              assert
#define sfx_create_work_queue(wq_name)          assert(0)
#define sfx_init_work(work, func)               assert(0)
#define sfx_queue_work(wq, work)                assert(0)
#define sfx_queue_work_on_cpu(wq, work, cpuid)  assert(0)
#define sfx_spin_unlock_irq                     sfx_spin_unlock
#define sfx_local_irq_save
#define sfx_local_irq_restore
#define sfx_local_irq_enable_ex()
#define sfx_local_irq_disable_ex()

void sfx_spin_lock_irqsave(sfx_spinlock_t *lock, unsigned long flags);
void sfx_spin_unlock_irqrestore(sfx_spinlock_t *lock, unsigned long flags);
int sfx_wait_event_interruptible_timeout(pthread_cond_t *cond, sfx_mutex_t *cond_mutex, xt_u32 *cond_flag, xt_u32 condition);
void sfx_wake_up(pthread_cond_t *cond, sfx_mutex_t *cond_mutex, xt_u32 *cond_flag);
void sfx_spin_lock_init(sfx_spinlock_t *lock);
void sfx_spin_lock(sfx_spinlock_t *lock);
void sfx_spin_lock_irq(sfx_spinlock_t *lock);
void sfx_spin_unlock_irq(sfx_spinlock_t *lock);
void sfx_spin_unlock(sfx_spinlock_t *lock);
void sfx_mutex_init(sfx_mutex_t *mutex);
void sfx_mutex_destroy(sfx_mutex_t *mutex);
void sfx_mutex_lock(sfx_mutex_t *mutex);
void sfx_mutex_unlock(sfx_mutex_t *mutex);
void *sfx_alloc_pages(int order);
void *sfx_alloc_pages_node(int order, int nid);
sfx_thread_t sfx_thread_create(sfx_thread_t *thread, int (*thread_routine)(void *), void *data, const char *name);
sfx_thread_t sfx_thread_create_on_node(sfx_thread_t *thread, int (*thread_routine)(void *), void *data, int node, const char *name);
void sfx_set_user_nice(sfx_thread_t p, long nice);
atomic_t atomic_read(atomic_t *pvar);
void atomic_add(xt_u32 add_size, atomic_t *pvar);
void atomic_set(atomic_t *pvar, xt_u32 var);
void atomic_sub(xt_u32 sub_size, atomic_t *pvar);
xt_u32 atomic_add_return(xt_u32 add_size, atomic_t *pvar);
xt_u32 atomic_inc_return(atomic_t *pvar);
void atomic_dec(atomic_t *pvar);
void atomic_inc(atomic_t *pvar);
void atomic64_set(atomic64_t *pvar, xt_u64 var);
void atomic64_dec(atomic64_t *pvar);
void atomic64_inc(atomic64_t *pvar);

#endif // __KERNEL__

/* Both kernel and user space */

/* if any entry here got changed, three additional places also need to be added/modified:
 * 1. module name string in ccs_controller.c
 * 2. module name string in applications/sfx_util/src/sfx_nand_read_log.c
 * 3. get/set debug level function in sfx_sysfs.c
 */
enum CCS_MODULE
{
    CCS_ACT,
    CCS_RAID,
    CCS_RCYCLE,
    CCS_PF,
    CCS_WL,
    CCS_RSCRUB,
    CCS_EH,
    CCS_MAP,
    CCS_RDIS,
    CCS_PERF,
    CCS_READ,
    CCS_WRITE,
    CCS_BLK,
    CCS_FREE,
    CCS_INIT,
    CCS_LOG,
    CCS_COMP,
    CCS_EC,
    CCS_R2C,
    CCS_FLASHM,
    CCS_SCHDL,
    CCS_MODEL,
    CCS_SYS,
    NAND_PRINT,

    BLK_SYS,
    BLK_SCHD,
    BLK_COH,
    BLK_REQ,
    BLK_PERF,
    BLK_GC,
    BLK_TH,
    BLK_SECURERSE,
    BLK_ERH,
    BLK_MAPLOG_ERH,
    BLK_RDISTB,
    BLK_PF,
    BLK_MAP,
    BLK_MIM,
    BLK_PU,

    EDLFS_CALL,
    EDLFS_META,
    EDLFS_BTREE,
    EDLFS_XATTR,
    EDLFS_PF,
    EDLFS_DIR,
    EDLFS_FILE,
    EDLFS_INODE_D, /* _D to avoid definition collision with EDLFS_INODE */
    EDLFS_DEFRG,

    MODULE_END
};

enum PRINT_LEVEL
{
    PL_FATAL,
    PL_ERR,
    PL_WRN,
    PL_NOT,
    PL_INF,
    PL_LOG,
    PL_DBG
};

typedef sfx_size_t sfx_strsize_t;

enum _log_level
{
    LOG_AST = 0,
    LOG_ERR = 1,
    LOG_WRN = 2,
    LOG_RUN = 3,  // running log
    LOG_INF = 4,
    MAX_LOG  // maximin number of level
};

static inline void sfx_mb(void)
{
#ifdef __KERNEL__
    sfx_os_mb();
#else
    __sync_synchronize();
#endif
}

static inline sfx_strsize_t sfx_strlen(const char *s)
{
    const char *sc;
    for (sc = s; *sc != 0; ++sc) {
        // empty body
    }
    return sc - s;
}

static inline sfx_bool sfx_sync_cmp_and_swap_32bit(xt_u32 *pvar, xt_u32 old_val, xt_u32 new_val)
{
    return __sync_bool_compare_and_swap(pvar, old_val, new_val);
}

void *sfx_valloc(unsigned int size);
void *print_valloc_caller(const char * caller_name, xt_u32 line, xt_u32 size);
void *print_malloc_caller(const char * caller_name, xt_u32 line, xt_u32 size);
void print_free_caller(const char * caller_name, xt_u32 line, void *ptr);
int sfx_free (void* ptr);
void *sfx_malloc(int size);
void *sfx_malloc_atomic(int size);
void sfx_mfree (void* ptr);
void sfx_free_pages(void * ptr, int order);
void *sfx_malloc_l2p_map(xt_u64 offset_4gb, xt_u64 size);
long int sfx_random(void);
void sfx_srand (unsigned int seed);
void *sfx_memmove(void *dest, const void *src, sfx_strsize_t size);
void *sfx_memcpy(void *dest, const void *src, sfx_strsize_t size);
void *sfx_memset(void *ptr, int value, sfx_strsize_t num);
int sfx_strcmp (const char * str1, const char * str2);
char *sfx_strncat(char *dest, const char *src, sfx_strsize_t num);
int sfx_thread_join(sfx_thread_t *thread, int *retval);
void sfx_set_realtime_thread(sfx_thread_t thread);
void sfx_usleep(sfx_useconds_t usec);
void sfx_udelay(sfx_useconds_t usec);
void sfx_kill_ftl(void);
int sfx_kernel_get_cpu(void);
int sfx_kernel_put_cpu(void);
int sfx_get_cpu(void);
int sfx_get_cpuid(void);
int sfx_get_char(void);
int sfx_spin_lock_init_esx(sfx_spinlock_t *lock, void * ctrlr, const char *s, int line);
xt_u32 sfx_ring_buffer_atomic_inc(xt_u32 *addr, void *cap_addr, xt_u32 wrap);
void print_card_info(sfx_board_nand_type *c);
xt_u32 sfx_sync_fetch(xt_u32 *pvar);
void sfx_reset_alloc_count(xt_u32 dev_id);
void *sfx_malloc_direct(int size);
void sfx_mfree_direct(void *ptr);
xt_u32 sfx_kmem_check_slab(void *ptr);
void sfx_dump_stack(void);

#ifdef __cplusplus
}
#endif

#endif // __OSAL_H__
