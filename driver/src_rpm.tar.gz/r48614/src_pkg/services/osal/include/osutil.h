// -----------------------------------------------------------------------------
//
// Copyright 2014-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : osutil.h
//
// -----------------------------------------------------------------------------

#ifndef __OSUTIL_H__
#define __OSUTIL_H__

#include "osal.h"
#ifdef __KERNEL__
#include "ccs_api.h"
#endif

enum sfx_logtype
{
    SFX_LOG_STDOUT,
    SFX_LOG_BLOCK,
    SFX_LOG_BBD,
    SFX_LOG_SLOG,
    SFX_LOG_FCQ,
    SFX_LOG_MAP,
    SFX_LOG_JNL,
    SFX_LOG_JNLRP,
    SFX_META_BT,
    SFX_META_REMAP,
    SFX_META_HEADER,
    SFX_META_BATCH,
    SFX_META_JNL,
    SFX_LOG_REG,

    /* Not a log type, but the number of logs */
    SFX_LOG_NUMENTRIES
};

#ifdef __KERNEL__
#define sfx_writelog(log, devId, module, severity, format, ...) \
                                { \
                                    sfd_dbgmsg_1(0, devId, module, severity, format, ##__VA_ARGS__); \
                                    sfx_dbgmsg(devId, module, severity, format, ##__VA_ARGS__); \
                                }
#define sfx_writelogslow(log, devId, module, severity, format, ...) \
                                { \
                                    sfd_dbgmsg_1(0, devId, module, severity, format, ##__VA_ARGS__); \
                                    sfx_dbgmsg(devId, module, severity, format, ##__VA_ARGS__); \
                                    sfx_udelay(2); \
                                }
#define sfx_print(devId, module, severity, format, ...) \
                                { \
                                    sfd_dbgmsg_1(0, devId, module, severity, format, ##__VA_ARGS__); \
                                    sfx_dbgmsg(devId, module, severity, format, ##__VA_ARGS__); \
                                }

extern xt_u32 logtime;
#define LOG_INTERVAL 10000
#define sfx_tprint(devId, module, severity, format, ...) \
{ \
    static xt_u32 last = 0;\
    if ((logtime-last)>=LOG_INTERVAL){\
        sfd_dbgmsg_1(0, devId, module, severity, format, ##__VA_ARGS__); \
        sfx_dbgmsg(devId, module, severity, format, ##__VA_ARGS__); \
        last = logtime;\
    }\
}

#else
void sfx_writelog(enum sfx_logtype log, xt_u8 devId, xt_u8 module, xt_u8 severity, const char *fmt, ...);
#define sfx_writelogslow        sfx_writelog
#define sfx_print(devId, module, severity, format, ...) \
                                { \
                                    sfx_writelog(SFX_LOG_SLOG, devId, module, severity, "[%10u] ", (xt_u32)sfx_gettimeus()); \
                                    sfx_writelog(SFX_LOG_SLOG, devId, module, severity, format, ##__VA_ARGS__); \
                                    sfx_flushlog(SFX_LOG_SLOG); \
                                }
#define tag()                   sfx_print(0, 0, 0, "%s: %s line %d", __FILE__, __FUNCTION__, __LINE__);
#define sfx_tprint(devId,module,severity,format,...)
#endif

int sfx_initlog(enum sfx_logtype log);
int sfx_delete_log(enum sfx_logtype log);
void sfx_closelog(enum sfx_logtype log);
void sfx_flushlog(enum sfx_logtype log);
void sfx_panic(xt_u8 ccs_devID, const char *str);
xt_u64 sfx_gettimeus(void);
xt_u32 sfx_sync_fetch(xt_u32 *pvar);
void sfx_sync_set_32bit(xt_u32 *pvar, xt_u32 var);

#endif // __OSUTIL_H__
