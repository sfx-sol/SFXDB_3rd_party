/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2016-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : osal_kernel_linux.c
 * ---------------------------------------------------------------------------
 */

#include <linux/version.h>
#include <linux/types.h>
#include <linux/completion.h>
#include <linux/device.h>
#include <linux/bitops.h>
#include <linux/cpu.h>
#include <linux/blkdev.h>
#include <linux/kthread.h>
#include <linux/gfp.h>
#include <linux/wait.h>
#include <linux/kobject.h>
#include <linux/string.h>
#include <linux/stat.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/random.h>
#include <linux/uaccess.h>
#include <linux/vmalloc.h>
#include <linux/mm.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include "osal.h"
#include "ccs_api.h"
#include "sfx_driver_api.h"

// <lnux/list.h>
// all are static inline functions
void linux_INIT_LIST_HEAD(struct list_head *list)
{
	INIT_LIST_HEAD(list);
}
void linux_list_add_tail(struct list_head *new, struct list_head *head)
{
	list_add_tail(new, head);
}
void linux_list_del(struct list_head *entry)
{
	list_del(entry);
}
void linux_list_del_init(struct list_head *entry)
{
	list_del_init(entry);
}
int linux_list_empty(const struct list_head *head)
{
	return list_empty(head);
}
void linux_list_splice_tail(struct list_head *list, struct list_head *head)
{
	list_splice_tail(list, head);
}

// asmlinkage void schedule(void);
// <linux/sched.h>
void sfx_schedule(void)
{
	schedule();
}

// bool capable(int cap);
// <linux/capability.h>
bool sfx_capable(int cap)
{
	return capable(cap);
}

// void dump_stack(void)
// <linux/printk.h>
void sfx_dump_stack(void)
{
	dump_stack();
}

// void kfree(const void *);
// <linux/slab.h>
void sfx_kfree(const void *p_mem)
{
	kfree(p_mem);
}

// void *vmalloc(unsigned long size);
// void vfree(const void *addr);
// <linux/vmalloc.h>
void *sfx_vmalloc(unsigned long size)
{
	return vmalloc(size);
}
void sfx_vfree(const void *addr)
{
	vfree(addr);
}

// millisecond sleep
// void msleep(unsigned int msecs);
// <inux/delay.h>
void sfx_msleep(unsigned int msecs)
{
	msleep(msecs);
}

// void do_gettimeofday(struct timeval *tv);
// <linux/timekeeping.h>
void sfx_do_gettimeofday(struct timeval *tv)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0))
	struct timespec64 now;
	ktime_get_real_ts64(&now);
	tv->tv_sec = now.tv_sec;
	tv->tv_usec = now.tv_nsec / 1000;
#else
	do_gettimeofday(tv);
#endif
}

// struct file *filp_open(const char *filename, int flags, int mode);
// int filp_close(struct file *filp, fl_owner_t id);
// loff_t vfs_llseek(struct file *file, loff_t offset, int origin);
// <linux/fs.h>
struct file *sfx_filp_open(const char *filename, int flags, int mode)
{
	return filp_open(filename, flags, mode);
}
int sfx_filp_close(struct file *filp, fl_owner_t id)
{
	return filp_close(filp, id);
}
loff_t sfx_vfs_llseek(struct file *filp, loff_t offset, int origin)
{
	return vfs_llseek(filp, offset, origin);
}

// extern ktime_t ktime_get(void);
// <linux/timekeeping.h>
ktime_t linux_ktime_get(void)
{
	return sfxdriver_ktime_get();
}

// bool kthread_should_stop(void);
// <linux/kthread.h>
bool linux_kthread_should_stop(void)
{
	return kthread_should_stop();
}

// int kthread_stop(struct task_struct *k);
// <linux/kthread.h>
int linux_kthread_stop(struct task_struct *k)
{
	return kthread_stop(k);
}

// void complete(struct completion *);
// <linux/completion.h>
void linux_complete(struct completion *p_comp)
{
	complete(p_comp);
}

// static inline void init_completion(struct completion *x);
// <linux/completion.h>
void linux_init_completion(struct completion *p_comp)
{
	init_completion(p_comp);
}

// void wait_for_completion(struct completion *);
// <linux/completion.h>
void linux_wait_for_completion(struct completion *p_comp)
{
	wait_for_completion(p_comp);
}

// unsigned long wait_for_completion_timeout(struct completion *x unsigned long timeout);
// <linux/completion.h>
unsigned long linux_wait_for_completion_timeout(struct completion *p_comp, unsigned long timeout)
{
	return wait_for_completion_timeout(p_comp, timeout);
}

// int wait_for_completion_interruptible(struct completion *x);
// <linux/completion.h>
int linux_wait_for_completion_interruptible(struct completion *p_comp)
{
	return wait_for_completion_interruptible(p_comp);
}

void *sfx_valloc(unsigned int size)
{
	xt_u32 *ret, *org;
	while (!(org = (int *)kmalloc(size + 0x1000, GFP_NOIO | __GFP_NOWARN))) {
		schedule();
	}
	ret = org + 0x1000 / sizeof(int);
	ret = (int *)((long long int)ret & 0xFFFFFFFFFFFFF000);
	sfx_assert((char *)ret - (char *)org >= sizeof(long long int));
	*(((long long int *)ret) - 1) = (long long int)org;
	return (void *)ret;
}

// sfx_free is only for memory allocated by sfx_valloc()
int sfx_free(void *ptr)
{
	kfree((void *)*((long long int *)ptr - 1));
	return 0;
}

void *sfx_malloc(int size)
{
	void *ret;
	while (!(ret = kmalloc(size, GFP_NOIO | __GFP_NOWARN))) {
		schedule();
	}
	return ret;
}

void *sfx_malloc_atomic(int size)
{
	void *ret;
	ret = kmalloc(size, GFP_ATOMIC);
	return ret;
}

void *sfx_malloc_direct(int size)
{
	void *ret;
	while (!(ret = kmalloc(size, GFP_NOIO | __GFP_NOWARN))) {
		schedule();
	}
	return ret;
}

// sfx_mfree() is only for memory allocated by sfx_malloc()
void sfx_mfree(void *ptr)
{
	kfree(ptr);
}

void sfx_mfree_direct(void *ptr)
{
	kfree(ptr);
}

// Alloc 2^order pages (i.e. 4KB)
void *sfx_alloc_pages(int order)
{
	void *addr = NULL;
	while (!(addr = (void *)__get_free_pages(GFP_NOIO | __GFP_NOWARN, order))) {
		sfx_schedule();
	}
	return addr;
}

void *sfx_alloc_pages_node(int order, int nodeid)
{
	void *p;
	if (unlikely(nodeid == -1)) {
		p = sfx_alloc_pages_address(order);
	} else {
		struct page *page;
		page = alloc_pages_node(nodeid, GFP_NOIO, order);
		if (!page) {
			p = sfx_alloc_pages_address(order);
		} else {
			p = page_address(page);
		}
	}
	return p;
}

void sfx_free_pages(void *ptr, int order)
{
	free_pages((uintptr_t)ptr, order);
}

void *sfx_memmove(void *dest, const void *src, sfx_strsize_t size)
{
	// use kernel's fast version
	return memmove(dest, src, size);
}

void *sfx_memcpy(void *dest, const void *src, sfx_strsize_t size)
{
	// use kernel's fast version
	return memcpy(dest, src, size);
}

void *sfx_memset(void *ptr, int value, sfx_strsize_t num)
{
	// use kernel's fast version
	return memset(ptr, value, num);
}

int sfx_strcmp(const char *str1, const char *str2)
{
	return strcmp(str1, str2);
}

char *sfx_strncat(char *dest, const char *src, sfx_strsize_t num)
{
	return strncat(dest, src, num);
}

char *sfx_strcpy(char *destination, const char *source)
{
	return strcpy(destination, source);
}

sfx_thread_t sfx_thread_create(sfx_thread_t *thread, int (*thread_routine)(void *), void *data,
			       const char *name)
{
	*thread = kthread_create(thread_routine, data, "%s", name);
	if (!IS_ERR_OR_NULL(*thread)) {
		wake_up_process(*thread);
	}
	return (*thread);
}

sfx_thread_t sfx_thread_create_on_node(sfx_thread_t *thread, int (*thread_routine)(void *), void *data,
				       int node, const char *name)
{
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(6, 5))
	*thread = kthread_create_on_node(thread_routine, data, node, "%s", name);
#else
	*thread = kthread_create(thread_routine, data, "%s", name);
#endif
#else
	// Ubuntu and Ucloud
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39))
	*thread = kthread_create_on_node(thread_routine, data, node, "%s", name);
#else
	*thread = kthread_create(thread_routine, data, "%s", name);
#endif
#endif

	if (!IS_ERR_OR_NULL(*thread)) {
		wake_up_process(*thread);
	}
	return (*thread);
}

void sfx_set_user_nice(sfx_thread_t p, long nice)
{
	return set_user_nice(p, nice);
}

int sfx_thread_join(sfx_thread_t *thread, int *retval)
{
	return kthread_stop(*thread);
}

void sfx_set_realtime_thread(sfx_thread_t thread)
{
	sfxdriver_sched_setscheduler(thread);
}

void sfx_usleep(sfx_useconds_t usec)
{
#if 1
	ktime_t period;
	period = ktime_set(0, 1000 * usec);
	set_current_state(TASK_INTERRUPTIBLE);
	sfxdriver_schedule_hrtimeout(&period, HRTIMER_MODE_REL);
#else
	return udelay(usec);
#endif
}

void sfx_udelay(sfx_useconds_t usec)
{
	//sfx_usleep(usec);
	return udelay(usec);
}

long int sfx_random(void)
{
	long int val;
	get_random_bytes(&val, sizeof(val));
	return abs(val);
}

void sfx_srand(unsigned int seed)
{
}

int sfx_spin_lock_init(sfx_spinlock_t *lock)
{
	spin_lock_init(lock);
	return 0;
}

int sfx_spin_lock_irq(sfx_spinlock_t *lock)
{
	spin_lock_irq(lock);
	return 0;
}

int sfx_spin_unlock_irq(sfx_spinlock_t *lock)
{
	spin_unlock_irq(lock);
	return 0;
}

int sfx_spin_lock(sfx_spinlock_t *lock)
{
	spin_lock(lock);
	return 0;
}

int sfx_spin_unlock(sfx_spinlock_t *lock)
{
	spin_unlock(lock);
	return 0;
}

int sfx_read_lock(sfx_rwlock_t *lock)
{
	read_lock(lock);
	return 0;
}

int sfx_read_trylock(sfx_rwlock_t *lock)
{
	return read_trylock(lock);
}

int sfx_read_unlock(sfx_rwlock_t *lock)
{
	read_unlock(lock);
	return 0;
}

int sfx_write_lock(sfx_rwlock_t *lock)
{
	write_lock(lock);
	return 0;
}

int sfx_write_trylock(sfx_rwlock_t *lock)
{
	return write_trylock(lock);
}

int sfx_write_unlock(sfx_rwlock_t *lock)
{
	write_unlock(lock);
	return 0;
}

int sfx_get_cpu(void)
{
	int cpu_id;
	cpu_id = get_cpu();
	put_cpu();
	return cpu_id;
}

int sfx_get_cpuid(void)
{
	return sfx_get_cpu();
}

int sfx_kernel_get_cpu(void)
{
	return get_cpu();
}

int sfx_kernel_put_cpu(void)
{
	put_cpu();
	return 0;
}

int sfx_printk(char *format, ...)
{
	va_list argList;
	int ret;

	va_start(argList, format);
	ret = vprintk(format, argList);
	va_end(argList);
	return ret;
}

int sfx_vprintk(const char *fmt, va_list args)
{
#ifdef SFX_MODEL_DRIVER
	return vprintk(fmt, args);
#else
	return sfx_vprintk_driver(fmt, args);
#endif
}

xt_u32 sfx_ring_buffer_atomic_inc(xt_u32 *addr, void *cap_addr, xt_u32 wrap)
{
	xt_u32 old_val;
	xt_u32 new_val;
	do {
		old_val = *addr;
		new_val = (old_val == wrap - 1) ? 0 : (old_val + 1);
		if (new_val == atomic_read((atomic_t *)cap_addr)) {
			continue;
		} else if (__sync_bool_compare_and_swap(addr, old_val, new_val)) {
			break;
		}
	} while (1);
	return old_val;
}

#ifdef USE_SFX_LINUX_WRAPPER

// ---------------------------------------------------------------------------
// The functions within the USE_SFX_LINUX_WRAPPER ifdef-block maybe left alone.
// These functions' API has remained the same across all known linux releases.
//
// Please only enable a wrapper when the function is showing bad side-effects,
// internally or externally when it is invoked across linux releases.
// ---------------------------------------------------------------------------

// void blk_end_request_all(struct request *rq, int error);
// <linux/blkdev.h>
void sfx_blk_end_request_all(struct request *rq, int error)
{
	blk_end_request_all(rq, error);
}

// int kobject_add(struct kobject *kobj, struct kobject *parent, const char *fmt, ...)
// <linux/kobject.h>
int sfx_kobject_add(struct kobject *kobj, struct kobject *parent, char *name)
{
	return kobject_add(kobj, parent, "%s", name);
}

// void kobject_del(struct kobject *kobj);
// <linux/kobject.h>
void sfx_kobject_del(struct kobject *kobj)
{
	kobject_del(kobj);
}

// void kobject_init(struct kobject *kobj, struct kobj_type *ktype);
// <linux/kobject.h>
void sfx_kobject_init(struct kobject *kobj, struct kobj_type *ktype)
{
	kobject_init(kobj, ktype);
}

// void kobject_put(struct kobject *kobj);
// <linux/kobject.h>
void sfx_kobject_put(struct kobject *kobj)
{
	kobject_put(kobj);
}

#endif // USE_SFX_LINUX_WRAPPER

//-----------------------------------------------------------------------------
// The linux wrappers below CANNOT be turned off.
// Reasons are:
// - it is a macro; but with different definition due to config or between linux releases
// - function args changed between linux releases; but the function name stayed the same
// - static inline functions contains local/static vars and/or other kernel macros
//-----------------------------------------------------------------------------

void sfx_thread_wait_event_interruptible(sfx_wait_queue_head_t *wq, cond_func cond, void *p_data)
{
	wait_event_interruptible(*wq, cond(p_data));
}

void sfx_thread_wait_event_timeout(sfx_wait_queue_head_t *wq, cond_func cond, void *p_data, long timeout)
{
	wait_event_interruptible_timeout(*wq, cond(p_data), timeout);
}

// #define wake_up_interruptible(x)		__wake_up(x, TASK_INTERRUPTIBLE, 1, NULL)
// <linux/wait.h>
//
void linux_wake_up_interruptible(wait_queue_head_t *q)
{
	wake_up_interruptible(q);
}

void linux_wake_up(wait_queue_head_t *q)
{
	wake_up(q);
}

// 2.6.32
// <linux/workqueue.h>
// #define INIT_WORK(_work, _func)	do {
//		(_work)->data = (atomic_long_t) WORK_DATA_INIT();
//		INIT_LIST_HEAD(&(_work)->entry);
//		PREPARE_WORK((_work), (_func));
//	} while (0)
//
// 4.13.0
// <linux/workqueue.h>
// #define __INIT_WORK(_work, _func, _onstack)	do {
//		__init_work((_work), _onstack);
//		(_work)->data = (atomic_long_t) WORK_DATA_INIT();
//		INIT_LIST_HEAD(&(_work)->entry);
//		(_work)->func = (_func);
//	} while (0)
// #define INIT_WORK(_work, _func)	__INIT_WORK((_work), (_func), 0)
//
void linux_bd_init_work(struct sfx_work_struct *work, xt_u32 cpu_id, sfx_work_func_t func)
{
	INIT_WORK(&work[cpu_id], func);
}

// <linux/workqueue.h>
// extern int queue_work_on(int cpu, struct workqueue_struct *wq, struct work_struct *work);
//
bool linux_queue_work_on(int cpu, struct workqueue_struct *wq, struct sfx_work_struct *work)
{
	return sfxdriver_queue_work_on(cpu, wq, work);
}

// #define mutex_init(mutex)	do {
//		static struct lock_class_key __key;
//		__mutex_init((mutex), #mutex, &__key);
//	} while (0)
// <linux/mutex.h>
//
void __linux_mutex_init(sfx_mutex_t *mutex, const char *mutex_name)
{
	struct lock_class_key mutex_key;
	__mutex_init(&(mutex->mutex), mutex_name, &mutex_key);
}

void linux_mutex_destroy(sfx_mutex_t *mutex)
{
	mutex_destroy(&(mutex->mutex));
}

void linux_mutex_lock(sfx_mutex_t *mutex)
{
	mutex_lock(&(mutex->mutex));
}

void linux_mutex_unlock(sfx_mutex_t *mutex)
{
	mutex_unlock(&(mutex->mutex));
}

// #define spin_lock_irqsave(lock, flags)	do { raw_spin_lock_irqsave(spinlock_check(lock), flags); } while (0)
// <linux/spinlock.h>
//
void linux_spin_lock_irqsave(sfx_spinlock_t *lock, unsigned long *flag)
{
	spin_lock_irqsave(lock, *flag);
}

// This static inline function, so we need to wrap them in a function.
// static __always_inline void spin_unlock_irqrestore(spinlock_t *lock, unsigned long flags)
// {
// 	raw_spin_unlock_irqrestore(&lock->rlock, flags);
// }
// <linux/spinlock.h>
//
void linux_spin_unlock_irqrestore(sfx_spinlock_t *lock, unsigned long flags)
{
	spin_unlock_irqrestore(lock, flags);
}

// These are all macros, so we need to wrap them in a function.
// #define local_irq_save(flags)	do { raw_local_irq_save(flags); trace_hardirqs_off(); } while (0)
// <asm-generic/irqflags.h>
//
void linux_local_irq_save(unsigned long flags)
{
	local_irq_save(flags);
}
void linux_local_irq_restore(unsigned long flags)
{
	local_irq_restore(flags);
}
void linux_local_irq_disable(void)
{
	local_irq_disable();
}
void linux_local_irq_enable(void)
{
	local_irq_enable();
}

// #ifdef CONFIG_TRACE_IRQFLAGS_SUPPORT
// #define irqs_disabled()  ({ unsigned long _flags; raw_local_save_flags(_flags); raw_irqs_disabled_flags(_flags); })
// #else
// #define irqs_disabled()	 raw_irqs_disabled()
// #endif
// <linux/irqflags.h>
//
int linux_irqs_disabled(void)
{
	return irqs_disabled();
}

// linux 2.6.32
// #define smp_processor_id() raw_smp_processor_id()
// #define raw_smp_processor_id() (percpu_read(cpu_number))
// <x86/include/asm/smp.h>
// linux 4.4.0
// #define smp_processor_id() raw_smp_processor_id()
// #define raw_smp_processor_id() (this_cpu_read(cpu_number))
// <x86/include/asm/smp.h>
//
int linux_smp_processor_id(void)
{
	return smp_processor_id();
}

// 4.4.0
// static inline int cpu_to_node(int cpu) { return per_cpu(numa_node, cpu); }
// <linux/topology.h>
// 2.6.32
// static inline int cpu_to_node(int cpu) { return per_cpu(x86_cpu_to_node_map, cpu); }
// <asm/topology.h>
//
int linux_cpu_to_node(int cpu)
{
	return cpu_to_node(cpu);
}

// #define num_online_nodes()	num_node_state(N_ONLINE)
// <linux/nodemask.h>
//
int linux_num_online_nodes(void)
{
	return num_online_nodes();
}
// 4.9.75
// #define cpu_possible_mask ((const struct cpumask *)&__cpu_possible_mask)
// #define cpu_online_mask   ((const struct cpumask *)&__cpu_online_mask)
// 4.4.0
// const struct cpumask *const cpu_possible_mask = to_cpumask(cpu_possible_bits);
// const struct cpumask *const cpu_online_mask = to_cpumask(cpu_online_bits);
// <linux/cpumask.h>
//
const struct cpumask *linux_cpu_online_mask(void)
{
	return cpu_online_mask;
}
const struct cpumask *linux_cpu_possible_mask(void)
{
	return cpu_possible_mask;
}
int sfx_nr_cpu_ids(void)
{
	return nr_cpu_ids;
}
unsigned int sfx_cpumask_next(int n, const struct cpumask *srcp)
{
	return cpumask_next(n, srcp);
}
// indirect caller of __bitmap_weight() function
// #define num_online_cpus()	cpumask_weight(cpu_online_mask)
// <linux/cpumask.h>
//
unsigned int linux_num_online_cpus(void)
{
	return num_online_cpus();
}

// cpumask_first - get the first cpu in a cpumask
// Returns >= nr_cpu_ids if no cpus set.
// <linux/cpumask.h>
unsigned int linux_cpumask_first(const struct cpumask *srcp)
{
	return cpumask_first(srcp);
}

// indirect ref to the exported node_to_cpumask_map[] array
// static inline const struct cpumask *cpumask_of_node(int node);
// <asm/topology.h>
//
const struct cpumask *linux_cpumask_of_node(int node)
{
	return cpumask_of_node(node);
}

// >= 4.2.0
// Just use cpumask_of(cpu)
// 2.6.32 to 4.1.0
// #define topology_thread_cpumask(cpu)		(per_cpu(cpu_sibling_map, cpu))
// <asm/topology.h>
//
const struct cpumask *sfx_topology_thread_cpumask(unsigned int cpu)
{
#ifndef topology_sibling_cpumask
#ifndef topology_thread_cpumask
	return sfxdriver_cpumask_of(cpu);
#else
	return topology_thread_cpumask(cpu);
#endif
#else
	return topology_sibling_cpumask(cpu);
#endif
}

// static inline void cpumask_clear_cpu(int cpu, struct cpumask *dstp)
// static inline void cpumask_clear(struct cpumask *dstp)
// static inline void cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp)
// static inline int cpumask_test_cpu(int cpu, const struct cpumask *cpumask)
// <linux/cpumask.h>
//
void linux_cpumask_clear_cpu(int cpu, struct cpumask *dstp)
{
	cpumask_clear_cpu(cpu, dstp);
}
void linux_cpumask_copy(struct cpumask *dstp, const struct cpumask *srcp)
{
	cpumask_copy(dstp, srcp);
}
bool linux_cpumask_full(const struct cpumask *srcp)
{
	return cpumask_full(srcp);
}
bool linux_cpumask_equal(const struct cpumask *src1p, const struct cpumask *src2p)
{
	return cpumask_equal(src1p, src2p);
}
void linux_cpumask_clear(struct cpumask *dstp)
{
	bitmap_zero(cpumask_bits(dstp), nr_cpumask_bits);
}
void linux_cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp)
{
	set_bit(cpumask_check(cpu), cpumask_bits(dstp));
}
int linux_cpumask_test_cpu(int cpu, const struct cpumask *cpumask)
{
	return test_bit(cpumask_check(cpu), cpumask_bits((cpumask)));
}
void linux_cpumask_setall(struct cpumask *dstp)
{
	cpumask_setall(dstp);
}
// static inline int set_cpus_allowed_ptr(struct task_struct *p, const struct cpumask *new_mask)
// <inux/sched.h>
//
int linux_set_cpus_allowed_ptr(struct task_struct *p, const struct cpumask *new_mask)
{
	return sfxdriver_set_cpus_allowed_ptr(p, new_mask);
}

// 4.4.0
// #define alloc_percpu(type)	(typeof(type) __percpu *)__alloc_percpu(sizeof(type), __alignof__(type))
// void __percpu *__alloc_percpu(size_t size, size_t align);
// 2.6.32
// #define alloc_percpu(type)	(type *)__alloc_percpu(sizeof(type), __alignof__(type))
// static inline void *__alloc_percpu(size_t size, size_t align)
//
void __percpu *linux_alloc_percpu(size_t size, size_t align)
{
	return sfxdriver_alloc_percpu(size, align);
}
void linux_free_percpu(void __percpu *pdata)
{
	sfxdriver_free_percpu(pdata);
}

// #define get_cpu_ptr(var) ({ preempt_disable(); this_cpu_ptr(var); })
// #define put_cpu_ptr(var) do { (void)(var); preempt_enable(); } while (0)
// <linux/percpu-defs.h>
//
sfx_die_busy_t *linux_get_cpu_ptr_to_die_busy(sfx_die_busy_t *pdb)
{
	return get_cpu_ptr(pdb);
}
xt_32 *linux_get_cpu_ptr_to_xt_32(xt_32 *px32)
{
	return get_cpu_ptr(px32);
}
xt_64 *linux_get_cpu_ptr_to_xt_64(xt_64 *px64)
{
	return get_cpu_ptr(px64);
}
void linux_put_cpu_ptr(void *ptr)
{
	put_cpu_ptr(ptr);
}

// > 2.6.32
// #define per_cpu_ptr(ptr, cpu) ({ __verify_pcpu_ptr(ptr); SHIFT_PERCPU_PTR((ptr), per_cpu_offset((cpu))); })
// <linux/percpu-defs.h>
// <= 2.6.32
// #define per_cpu_ptr(ptr, cpu) ({ struct percpu_data *__p = __percpu_disguise(ptr); (__typeof__(ptr))__p->ptrs[(cpu)]; })
// <linux/percpu.h>
//
sfx_die_busy_t *linux_per_cpu_ptr_to_die_busy(sfx_die_busy_t *pdb, xt_32 cpu_iter)
{
	return per_cpu_ptr(pdb, cpu_iter);
}
xt_32 *linux_per_cpu_ptr_to_xt_32(xt_32 *px32, xt_32 cpu_iter)
{
	return per_cpu_ptr(px32, cpu_iter);
}
xt_64 *linux_per_cpu_ptr_to_xt_64(xt_64 *px64, xt_32 cpu_iter)
{
	return per_cpu_ptr(px64, cpu_iter);
}

// static inline void *page_address(const struct page *page);
// <linux/mm.h>
//
void *linux_page_address(const struct page *page)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 1, 0)
	// this old fellow only take non-const arg.
	return page_address((struct page *)page);
#else
	return page_address(page);
#endif
}

unsigned long linux_copy_to_user(void __user *to, const void *from, unsigned long num_bytes)
{
	return copy_to_user(to, from, num_bytes);
}

unsigned long linux_copy_from_user(void *to, const void __user *from, unsigned long num_bytes)
{
	return copy_from_user(to, from, num_bytes);
}

// static __always_inline void *kmalloc(size_t size, gfp_t flags)
// <linux/slab.h>
//
void *linux_kmalloc(size_t size, gfp_t flags)
{
	return kmalloc(size, flags);
}

// static inline void *kcalloc(size_t n, size_t size, gfp_t flags)
// <linux/slab.h>
//
void *linux_kcalloc(size_t n, size_t size, gfp_t flags)
{
	return kcalloc(n, size, flags);
}

// static inline void *kzalloc(size_t size, gfp_t flags);
// <linux/slab.h>
//
void *linux_kzalloc(size_t size, gfp_t flags)
{
	return kzalloc(size, flags);
}

// static inline void *kzalloc_node(size_t size, gfp_t flags, int node) { return kmalloc_node(size, flags | __GFP_ZERO, node); }
// <linux/slab.h>
//
void *linux_kzalloc_node(size_t size, gfp_t flags, int node)
{
	return kzalloc_node(size, flags, node);
}

// #define alloc_page(gfp_mask) alloc_pages(gfp_mask, 0)
// <linux/gfp.h>
//
struct page *linux_alloc_page(gfp_t gfp_mask)
{
	return alloc_page(gfp_mask);
}

// bool alloc_cpumask_var(cpumask_var_t *mask, gfp_t flags);
// void free_cpumask_var(cpumask_var_t mask);
// <linux/cpumask.h>
//
bool linux_alloc_cpumask_var(cpumask_var_t *mask, gfp_t flags)
{
	return alloc_cpumask_var(mask, flags);
}
void linux_free_cpumask_var(cpumask_var_t mask)
{
	free_cpumask_var(mask);
}
bool linux_zalloc_cpumask_struct_ptr(struct cpumask **mask, gfp_t flags)
{
	*mask = kmalloc_node(cpumask_size(), flags | __GFP_ZERO, NUMA_NO_NODE);
	return *mask != NULL;
}

// <  3.3.0 #define init_waitqueue_head(q)	do { static struct lock_class_key __key; __init_waitqueue_head((q), &__key);} while (0)
// >= 3.3.0 #define init_waitqueue_head(q)	do { static struct lock_class_key __key; __init_waitqueue_head((q), #q, &__key);} while (0)
// <linux/wait.h>
//
void linux_init_waitqueue_head(wait_queue_head_t *q)
{
	init_waitqueue_head(q);
}

//	DECLARE_PER_CPU(struct task_struct *, current_task);
// < 3.5.0
//	static __always_inline struct task_struct *get_current(void)
//	{
//		return percpu_read_stable(current_task);
//	}
// >= 3.5.0
//	static __always_inline struct task_struct *get_current(void)
//	{
//		return this_cpu_read_stable(current_task);
//	}
//#define current	get_current()
//<asm/current.h>
//
struct task_struct *linux_get_current(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 5, 0)
	return percpu_read_stable(current_task);
#else
	return this_cpu_read_stable(current_task);
#endif
}

// <asm/uaccess.h> < 4.14.0
// #define get_ds()	(KERNEL_DS)
// #define get_fs()	(current->thread.addr_limit)
// #define set_fs(x)	(current->thread.addr_limit = (x))
//
// <asm/uaccess.h> >= 4.14.0
// #define get_ds()	(KERNEL_DS)
// #define get_fs()	(current->thread.addr_limit)
// static inline void set_fs(mm_segment_t fs)
// {
//		current->thread.addr_limit = fs;
//		/* On user-mode return, check fs is correct */
//		set_thread_flag(TIF_FSCHECK);
// }
//
mm_segment_t linux_get_ds(void)
{
	return (KERNEL_DS);
}
mm_segment_t linux_get_fs(void)
{
	return get_fs();
}
void linux_set_fs(mm_segment_t fs)
{
	set_fs(fs);
}

// <linux/fs.h> >= 4.14.0
// ssize_t kernel_write(struct file *, const char *, size_t, loff_t *);
// <linux/fs.h> < 4.14.0
// ssize_t vfs_write(struct file *, const char __user *, size_t, loff_t *);
//
ssize_t linux_vfs_write(struct file *fp, const char *buf, size_t count, loff_t *pos)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	return kernel_write(fp, buf, count, pos);
#else
	return vfs_write(fp, buf, count, pos);
#endif
}

void linux_set_device_ro(sfx_gendisk *bd_disk, xt_8 read_only_mode)
{
	/*
     * Check NULL pointer according to kernel functions.
     */
	if (bd_disk != NULL && bdget(disk_devt(bd_disk)) != NULL &&
	    bdget(disk_devt(bd_disk))->bd_part != NULL) {
		set_device_ro(bdget(disk_devt(bd_disk)), read_only_mode);
	}
}

int linux_bdev_read_only(sfx_gendisk *bd_disk)
{
	/*
     * Check NULL pointer according to kernel functions.
     */
	if (bd_disk == NULL || bdget(disk_devt(bd_disk)) == NULL ||
	    bdget(disk_devt(bd_disk))->bd_part == NULL)
		return 0;

	return bdev_read_only(bdget(disk_devt(bd_disk)));
}

xt_u32 linux_get_single_job_pid(void)
{
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32)
	return sfx_get_current()->pid;
#else
	return smp_processor_id();
#endif
}

//	< 3.9.0
//	<asm/page.h>
//	#define virt_to_page(kaddr)	pfn_to_page(__pa(kaddr) >> PAGE_SHIFT)
//	#define __pa(x)			__phys_addr((unsigned long)(x))
//	<asm/page_64_types.h>
//	extern unsigned long __phys_addr(unsigned long);
//
//	>= 3.9.0
//	<asm/page.h>
//	#define virt_to_page(kaddr)	pfn_to_page(__pa(kaddr) >> PAGE_SHIFT)
//	#define __pa(x)			__phys_addr((unsigned long)(x))
//	<asm/page_64.h>
//	#define __phys_addr(x)		__phys_addr_nodebug(x)
//	static inline unsigned long __phys_addr_nodebug(unsigned long x)
//	{
//		unsigned long y = x - __START_KERNEL_map;
//		/* use the carry flag to determine if x was < __START_KERNEL_map */
//		x = y + ((x > y) ? phys_base : (__START_KERNEL_map - PAGE_OFFSET));
//		return x;
//	}
// #undef virt_to_page
// #define virt_to_page(pp)						linux_virt_to_page(void *pp)
struct page *linux_virt_to_page(void *pp)
{
	return virt_to_page(pp);
}

// void do_gettimeofday(struct timeval *tv);
// <linux/time.h>
//
void linux_get_ts_and_tz(uint16_t *tz, uint64_t *ts)
{
	// Record the log's timestamp as near as possible to when the write log call is made.
	struct timeval time;
	sfx_do_gettimeofday(&time);
	*tz = (uint16_t)sys_tz.tz_minuteswest; // minuteswest could be a negative value
	*ts = (uint64_t)time.tv_sec * 1000000 + (uint64_t)time.tv_usec;
}

// #undef HZ
// #define HZ		CONFIG_HZ	/* Internal kernel timer frequency */
// #define USER_HZ	100		/* some user interfaces are */
// #define CLOCKS_PER_SEC	(USER_HZ)       /* in "ticks" like times() */
// <asm-generic/param.h>
//
unsigned long linux_get_hz(void)
{
	return HZ;
}

// #define cmpxchg_local(ptr, o, n) ({ ((__typeof__(*(ptr)))__cmpxchg_local_generic((ptr), (unsigned long)(o), (unsigned long)(n), sizeof(*(ptr)))); })
// #define cmpxchg(ptr, o, n)	cmpxchg_local((ptr), (o), (n))
// <asm-generic/cmpxchg-local.h>
//
xt_32 linux_cmpxchg_xt_u32(xt_32 *ptr, xt_32 old, xt_32 new)
{
	return cmpxchg(ptr, old, new);
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 39)) && defined(RHEL_RELEASE_CODE)
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(6, 4))

#include <linux/ctype.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/math64.h>
#include <linux/module.h>
#include <linux/types.h>

static inline char _tolower(const char c)
{
	return c | 0x20;
}

static int _kstrtoull(const char *s, unsigned int base, unsigned long long *res)
{
	unsigned long long acc;
	int ok;

	if (base == 0) {
		if (s[0] == '0') {
			if (_tolower(s[1]) == 'x' && isxdigit(s[2])) {
				base = 16;
			} else {
				base = 8;
			}
		} else {
			base = 10;
		}
	}
	if (base == 16 && s[0] == '0' && _tolower(s[1]) == 'x') {
		s += 2;
	}

	acc = 0;
	ok = 0;
	while (*s) {
		unsigned int val;

		if ('0' <= *s && *s <= '9') {
			val = *s - '0';
		} else if ('a' <= _tolower(*s) && _tolower(*s) <= 'f') {
			val = _tolower(*s) - 'a' + 10;
		} else if (*s == '\n' && *(s + 1) == '\0') {
			break;
		} else {
			return -EINVAL;
		}
		if (val >= base) {
			return -EINVAL;
		}
		if (acc > div_u64(ULLONG_MAX - val, base)) {
			return -ERANGE;
		}
		acc = acc * base + val;
		ok = 1;
		s++;
	}
	if (!ok) {
		return -EINVAL;
	}
	*res = acc;
	return 0;
}

int kstrtoull(const char *s, unsigned int base, unsigned long long *res)
{
	if (s[0] == '+') {
		s++;
	}
	return _kstrtoull(s, base, res);
}

int kstrtou8(const char *s, unsigned int base, u8 *res)
{
	unsigned long long tmp;
	int rv;

	rv = kstrtoull(s, base, &tmp);
	if (rv < 0) {
		return rv;
	}
	if (tmp != (unsigned long long)(u8)tmp) {
		return -ERANGE;
	}
	*res = tmp;
	return 0;
}

int kstrtou32(const char *s, unsigned int base, u32 *res)
{
	unsigned long long tmp;
	int rv;

	rv = kstrtoull(s, base, &tmp);
	if (rv < 0) {
		return rv;
	}
	if (tmp != (unsigned long long)(u32)tmp) {
		return -ERANGE;
	}
	*res = tmp;
	return 0;
}

static int _kstrtoul(const char *s, unsigned int base, unsigned long *res)
{
	unsigned long acc;
	int ok;

	if (base == 0) {
		if (s[0] == '0') {
			if (_tolower(s[1]) == 'x' && isxdigit(s[2])) {
				base = 16;
			} else {
				base = 8;
			}
		} else {
			base = 10;
		}
	}
	if (base == 16 && s[0] == '0' && _tolower(s[1]) == 'x') {
		s += 2;
	}

	acc = 0;
	ok = 0;
	while (*s) {
		unsigned int val;

		if ('0' <= *s && *s <= '9') {
			val = *s - '0';
		} else if ('a' <= _tolower(*s) && _tolower(*s) <= 'f') {
			val = _tolower(*s) - 'a' + 10;
		} else if (*s == '\n' && *(s + 1) == '\0') {
			break;
		} else {
			return -EINVAL;
		}
		if (val >= base) {
			return -EINVAL;
		}
		if (acc > div_u64(ULLONG_MAX - val, base)) {
			return -ERANGE;
		}
		acc = acc * base + val;
		ok = 1;
		s++;
	}
	if (!ok) {
		return -EINVAL;
	}
	*res = acc;
	return 0;
}

int kstrtoul(const char *s, unsigned int base, unsigned long *res)
{
	if (s[0] == '+') {
		s++;
	}
	return _kstrtoul(s, base, res);
}

int kstrtouint(const char *s, unsigned int base, unsigned int *res)
{
	unsigned long long tmp;
	int rv;

	rv = kstrtoull(s, base, &tmp);
	if (rv < 0)
		return rv;
	if (tmp != (unsigned long long)(unsigned int)tmp)
		return -ERANGE;
	*res = tmp;
	return 0;
}

#endif
#endif // (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39)) && (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(6,4))

//#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 16, 0)

void sfx_kv_set_rq_start(sfx_bio_request *sfxrq)
{
	sfxrq->atomic_flags |= SFX_KV_REQ_ATOM_STARTED;
	sfxrq->atomic_flags &= ~SFX_KV_REQ_ATOM_COMPLETE;
}
sfx_bool sfx_kv_check_rq_done(sfx_bio_request *sfxrq)
{
	return (!(sfxrq->atomic_flags & SFX_KV_REQ_ATOM_STARTED) &&
		(sfxrq->atomic_flags & SFX_KV_REQ_ATOM_COMPLETE));
}
void sfx_kv_set_rq_done(sfx_bio_request *sfxrq)
{
	sfxrq->atomic_flags &= ~SFX_KV_REQ_ATOM_STARTED;
	sfxrq->atomic_flags |= SFX_KV_REQ_ATOM_COMPLETE;
}

//#else
//
//void sfx_kv_set_rq_start(sfx_bio_request *sfxrq)
//{
//	blk_mq_start_request(sfxrq);
//}
//sfx_bool sfx_kv_check_rq_done(sfx_bio_request *sfxrq)
//{
//#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 18, 0)
//	return (READ_ONCE(sfxrq->gstate) & SFX_MQ_RQ_STATE_MASK) == SFX_MQ_RQ_COMPLETE;
//#else
//	return (READ_ONCE(sfxrq->state) == SFX_MQ_RQ_COMPLETE);
//#endif
//}
//void sfx_kv_set_rq_done(sfx_bio_request *sfxrq)
//{
//	blk_mq_complete_request(sfxrq);
//}
//
//#endif // LINUX_VERSION_CODE < KERNEL_VERSION(4,16,0)

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 17, 0)

void sfx_queue_flag_set(unsigned int flag, sfx_request_queue *q)
{
	spin_lock_irq(q->queue_lock);
	queue_flag_set(flag, q);
	spin_unlock_irq(q->queue_lock);
}
void sfx_queue_flag_set_unlocked(unsigned int flag, struct request_queue *q)
{
	queue_flag_set_unlocked(flag, q);
}
void sfx_queue_flag_clear_unlocked(unsigned int flag, struct request_queue *q)
{
	queue_flag_clear_unlocked(flag, q);
}
#else

void sfx_queue_flag_set(unsigned int flag, sfx_request_queue *q)
{
	blk_queue_flag_set(flag, q);
}
void sfx_queue_flag_set_unlocked(unsigned int flag, struct request_queue *q)
{
	if (test_bit(QUEUE_FLAG_INIT_DONE, &q->queue_flags) && kref_read(&q->kobj.kref)) {
		lockdep_assert_held(q->queue_lock);
	}
	__set_bit(flag, &q->queue_flags);
}
void sfx_queue_flag_clear_unlocked(unsigned int flag, struct request_queue *q)
{
	if (test_bit(QUEUE_FLAG_INIT_DONE, &q->queue_flags) && kref_read(&q->kobj.kref)) {
		lockdep_assert_held(q->queue_lock);
	}
	__clear_bit(flag, &q->queue_flags);
}

#endif // LINUX_VERSION_CODE < KERNEL_VERSION(4,17,0)

void linux_tasklet_init(struct tasklet_struct *t, void (*func)(unsigned long), unsigned long data)
{
	tasklet_init(t, func, data);
}

void linux_tasklet_schedule(struct tasklet_struct *t)
{
	tasklet_schedule(t);
}

pid_t linux_get_thread_pid(struct task_struct *ptask)
{
	return ptask->pid;
}

// 4.13.0
// static __always_inline int preempt_count(void) { return raw_cpu_read_4(__preempt_count) & ~PREEMPT_NEED_RESCHED; }
// 4.4.0
// static __always_inline int preempt_count(void) { return raw_cpu_read_4(__preempt_count) & ~PREEMPT_NEED_RESCHED; }
// 3.10.0
// #define preempt_count()  (current_thread_info()->preempt_count)
// 2.6.32
// #define preempt_count()  (current_thread_info()->preempt_count)
// <linux/preempt.h>
xt_u32 linux_preempt_count(void)
{
	return preempt_count();
}

// #define irq_count()  (preempt_count() & (HARDIRQ_MASK | SOFTIRQ_MASK | NMI_MASK))
// <linux/preempt.h>
xt_u32 linux_irq_count(void)
{
	return irq_count();
}

// <linux/slab.h>
// struct kmem_cache *kmem_cache_create(const char *name, size_t size, size_t align, unsigned long flags, void (*ctor)(void *));
struct kmem_cache *linux_kmem_cache_create_wrapper(const char *pname, xt_u32 size)
{
	return kmem_cache_create(pname, size, 0, SLAB_NOLEAKTRACE | SLAB_MEM_SPREAD | SLAB_HWCACHE_ALIGN,
				 NULL);
}
struct kmem_cache *linux_kmem_cache_create(const char *name, size_t size, size_t align, unsigned long flags,
					   void (*ctor)(void *))
{
	return kmem_cache_create(name, size, align, flags, ctor);
}

// sfx kmem cache alloc wrapper
void *linux_kmem_cache_alloc_wrapper(void *sid)
{
	void *ret;
	while (1) {
		ret = kmem_cache_alloc(sid, SFX_GFP_ATOMIC);
		if (ret) {
			break;
		}
		sfx_udelay(1);
	}
	return ret;
}
// <mm/slab.c>
// void *kmem_cache_alloc(struct kmem_cache *cachep, gfp_t flags);
void *linux_kmem_cache_alloc(struct kmem_cache *cachep, gfp_t flags)
{
	return kmem_cache_alloc(cachep, flags);
}

// sfx kmem cache free wrapper
void linux_kmem_cache_free_wrapper(void *ptr)
{
	struct page *page = virt_to_head_page(ptr);
	struct kmem_cache *slab;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 6, 0)
	slab = page->slab_cache;
#else
	page = compound_head(page);
	slab = (struct kmem_cache *)page->lru.next;
#endif
	if (slab) {
		kmem_cache_free(slab, ptr);
	} else {
		printk("warning slab is null. ptr %p\n", ptr);
		sfx_dump_stack();
	}
}
// <mm/slab.c>
// void kmem_cache_free(struct kmem_cache *cachep, void *objp);
void linux_kmem_cache_free(struct kmem_cache *cachep, void *objp)
{
	kmem_cache_free(cachep, objp);
}

// <mm/slab.c>
// void kmem_cache_destroy(void *ptr);
void linux_kmem_cache_destroy(void *ptr)
{
	kmem_cache_destroy(ptr);
}

xt_u32 sfx_kmem_check_slab(void *ptr)
{
	struct page *page = virt_to_head_page(ptr);
	struct kmem_cache *slab;
	xt_u32 status = NO_ERROR;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 6, 0)
	slab = page->slab_cache;
#else
	slab = page->slab;
#endif
	if (slab == NULL) {
		printk("err slab is null ptr %p\n", ptr);
		sfx_dump_stack();
		status = ERROR_NULL_POINTER;
	}
	return status;
}

// linux/blkdev.h
//          #define blk_queue_tagged(q)     test_bit(QUEUE_FLAG_QUEUED, &(q)->queue_flags)
// wrapped  #define blk_queue_stopped(q)    test_bit(QUEUE_FLAG_STOPPED, &(q)->queue_flags)
//          #define blk_queue_dying(q)      test_bit(QUEUE_FLAG_DYING, &(q)->queue_flags)
//          #define blk_queue_dead(q)       test_bit(QUEUE_FLAG_DEAD, &(q)->queue_flags)
//          #define blk_queue_bypass(q)     test_bit(QUEUE_FLAG_BYPASS, &(q)->queue_flags)
//          #define blk_queue_init_done(q)  test_bit(QUEUE_FLAG_INIT_DONE, &(q)->queue_flags)
//          #define blk_queue_nomerges(q)   test_bit(QUEUE_FLAG_NOMERGES, &(q)->queue_flags)
//          #define blk_queue_noxmerges(q)  test_bit(QUEUE_FLAG_NOXMERGES, &(q)->queue_flags)
//          #define blk_queue_nonrot(q)     test_bit(QUEUE_FLAG_NONROT, &(q)->queue_flags)
//          #define blk_queue_io_stat(q)    test_bit(QUEUE_FLAG_IO_STAT, &(q)->queue_flags)
//          #define blk_queue_add_random(q) test_bit(QUEUE_FLAG_ADD_RANDOM, &(q)->queue_flags)
//          #define blk_queue_stackable(q)  test_bit(QUEUE_FLAG_STACKABLE, &(q)->queue_flags)
//          #define blk_queue_discard(q)    test_bit(QUEUE_FLAG_DISCARD, &(q)->queue_flags)
//          #define blk_queue_secdiscard(q) (blk_queue_discard(q) && test_bit(QUEUE_FLAG_SECDISCARD, &(q)->queue_flags))
//
int sfx_blk_queue_stopped(struct request_queue *q)
{
	return blk_queue_stopped(q);
}
