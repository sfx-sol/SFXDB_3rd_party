/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : ut_ccs_ioctl.c
 * ---------------------------------------------------------------------------
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/namei.h>
#include <asm/page.h>
#include "sfx_types.h"
#include "ccs_api.h"
#include "ccs_api_conn.h"
#include "osal.h"
#include "sfx.h"
#include "version_tmp.h"
#include "sfx_driver_api.h"

#define MAX_CLIENT_CONNECTIONS 256
#define ut_ccs_DEVICE_NAME "css"

struct ccs_dev {
	int minor;
	dev_t dev_no;
	struct cdev *cdev_ptr;
	struct device *device_ptr;
	struct id_item idlist[MAX_CLIENT_CONNECTIONS];
	struct list_head freelist_head; /* need to initialize freelist_head */
	sfx_mutex_t freelist_lock; /* need to initialize freelist_lock */
};

struct ccs_dev_ctrl {
	int inited;
	struct class *class_ptr;
	dev_t dev_no;
	int major;
	xt_u32 count;
	xt_u32 max_count;
	struct ccs_dev ccs_dev[MAX_NR_DRIVE];
};

static struct ccs_dev_ctrl ccs_dev_ctrl = {
	.inited = 0,
	.count = 0,
};

static int is_ccs_dev_ctrl_inited(void)
{
	return ccs_dev_ctrl.inited;
}

static void ccs_dev_ctrl_reset(void)
{
	ccs_dev_ctrl.inited = 0;
	ccs_dev_ctrl.count = 0;
}

int get_ccs_dev_ctrl_count(void)
{
	return ccs_dev_ctrl.count;
}

int get_ccs_dev_ctrl_max_count(void)
{
	return ccs_dev_ctrl.max_count;
}

static void ccs_dev_ctrl_count_increment(void)
{
	ccs_dev_ctrl.count++;
}

static void ccs_dev_ctrl_count_decrement(void)
{
	ccs_dev_ctrl.count--;
}

static void ccs_dev_ctrl_init(void)
{
	int i;

	ccs_dev_ctrl.count = 0;
	ccs_dev_ctrl.max_count = MAX_NR_DRIVE;
	ccs_dev_ctrl.major = 0xFFFF;

	for (i = 0; i < MAX_NR_DRIVE; i++) {
		ccs_dev_ctrl.ccs_dev[i].minor = 0xFFFF;
		ccs_dev_ctrl.ccs_dev[i].cdev_ptr = NULL;
		ccs_dev_ctrl.ccs_dev[i].device_ptr = NULL;
	}
}

/*
 * need to pass struct id_item* item_ptr to ccs_conn_ioctl
 */
static long ut_ccs_dev_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
	struct id_item *item = f->private_data;
	return ccs_conn_ioctl(item, cmd, arg);
}

/*
 * Need to find out the corresponding ccs_dev_id
 */
static int ut_ccs_dev_open(struct inode *i, struct file *f)
{
	unsigned int minor = iminor(i);
	unsigned int major = imajor(i);

	struct id_item *item;

	struct ccs_dev *cd_ptr = &ccs_dev_ctrl.ccs_dev[minor];

	sfx_mutex_lock(&cd_ptr->freelist_lock);

	/* show struct path f_path and struct inode *f_inode */
	/* Get a unique client ID */
	if (list_empty(&cd_ptr->freelist_head)) {
		sfx_mutex_unlock(&cd_ptr->freelist_lock);
		sfx_pr_err("%s: out of ccs device file descriptors\n", __FUNCTION__);
		return -EMFILE;
	}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 13, 0)
	item = list_last_entry(&cd_ptr->freelist_head, struct id_item, q);
#else
	item = list_entry((&cd_ptr->freelist_head)->prev, struct id_item, q);
#endif
	list_del(&item->q);
	INIT_LIST_HEAD(&item->q);
	item->major = major;
	item->minor = minor;
	f->private_data = item;
	sfx_mutex_unlock(&cd_ptr->freelist_lock);

	sfx_pr_info("%s: open ccs device file %p, item %d, major = %u, minor = %u\n", __FUNCTION__, f,
		    item->id, major, minor);

	return 0;
}

static int ut_ccs_dev_release(struct inode *i, struct file *f)
{
	struct id_item *item = f->private_data;

	unsigned int minor = iminor(i);
	// unsigned int major = imajor(i);
	struct ccs_dev *cd_ptr = &ccs_dev_ctrl.ccs_dev[minor];

	sfx_mutex_lock(&cd_ptr->freelist_lock);
	list_add_tail(&item->q, &cd_ptr->freelist_head);
	sfx_mutex_unlock(&cd_ptr->freelist_lock);
	return 0;
}

struct file_operations ccsk_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = ut_ccs_dev_ioctl,
	.compat_ioctl = ut_ccs_dev_ioctl,
	.open = ut_ccs_dev_open,
	.release = ut_ccs_dev_release,
};

int sfx_base_init(void);
void sfx_base_close(void);

void ccs_per_dev_init_idlist(struct ccs_dev *cd_ptr)
{
	int i;

	sfx_mutex_init(&cd_ptr->freelist_lock);

	INIT_LIST_HEAD(&cd_ptr->freelist_head);
	for (i = 0; i < MAX_CLIENT_CONNECTIONS; i++) {
		cd_ptr->idlist[i].id = i;
		INIT_LIST_HEAD(&cd_ptr->idlist[i].q);
		list_add_tail(&cd_ptr->idlist[i].q, &cd_ptr->freelist_head);
	}
}

int ccs_per_dev_init(xt_u8 minor)
{
	char ccs_dev_name[80];
	int ret;

	if (minor > get_ccs_dev_ctrl_max_count()) {
		sfx_pr_info("%s: unexpected ccs dev minor = %d\n", __FUNCTION__, minor);
		return 1;
	}

	ccs_dev_ctrl.ccs_dev[minor].cdev_ptr = cdev_alloc();
	ccs_dev_ctrl.ccs_dev[minor].cdev_ptr->ops = &ccsk_fops;
	ccs_dev_ctrl.ccs_dev[minor].cdev_ptr->owner = THIS_MODULE;

	ccs_dev_ctrl.major = MAJOR(ccs_dev_ctrl.dev_no);
	ccs_dev_ctrl.ccs_dev[minor].dev_no = MKDEV(ccs_dev_ctrl.major, minor);

	ret = cdev_add(ccs_dev_ctrl.ccs_dev[minor].cdev_ptr, ccs_dev_ctrl.ccs_dev[minor].dev_no, 1);
	if (ret < 0) {
		sfx_pr_info("Unable to allocate cdev");
		return ret;
	}

	/* Handle associated ccs device */
	sprintf(ccs_dev_name, "%s%d", ut_ccs_DEVICE_NAME, minor);
	ccs_dev_ctrl.ccs_dev[minor].device_ptr = sfxdriver_device_create(
		ccs_dev_ctrl.class_ptr, NULL, ccs_dev_ctrl.ccs_dev[minor].dev_no, NULL, ccs_dev_name);

	if (IS_ERR(ccs_dev_ctrl.ccs_dev[minor].device_ptr)) {
		sfx_pr_err("%s: Error - devptr_ppt[%d] = %p, device creation failed\n", __FUNCTION__, minor,
			   ccs_dev_ctrl.ccs_dev[minor].device_ptr);
		return 1;
	}

	ccs_dev_ctrl.inited = 1;

	ccs_per_dev_init_idlist(&ccs_dev_ctrl.ccs_dev[minor]);

	ccs_dev_ctrl_count_increment();

	/*
     * setup server side ccs handler etc.
     */
	ccs_server_loop(minor);

	return 0;
}

int ccs_dev_init(void)
{
	int ret;

	if (is_ccs_dev_ctrl_inited()) {
		return 0;
	}

	ccs_dev_ctrl_init();

	ret = alloc_chrdev_region(&ccs_dev_ctrl.dev_no, 0, ccs_dev_ctrl.max_count, ut_ccs_DEVICE_NAME);
	if (ret < 0) {
		sfx_pr_err("Major number allocation is failed, %d\n", ret);
		return ret;
	}

	ccs_dev_ctrl.class_ptr = sfxdriver_class_create(THIS_MODULE, "char");
	if (IS_ERR(ccs_dev_ctrl.class_ptr)) {
		sfx_pr_err("Error: class creation failed");
	}

#ifndef IOCTL_CHR_DEV_EXTRA
	sfx_base_init();
	InitializeTable();
#endif

	sfx_pr_info("%s: Done\n", __FUNCTION__);

	return 0;
}

/*
 * This is to maintain single ccs device for backward compatability
 */
int ut_ccs_dev_init(void)
{
	int ret;

	/* check ret with more error handling */
	ret = ccs_dev_init();
	ret = ccs_per_dev_init(0);

	return 0;
}

void ccs_per_dev_exit(xt_u8 minor)
{
	if (minor > get_ccs_dev_ctrl_max_count()) {
		sfx_pr_info("%s: unexpected ccs dev minor = %d\n", __FUNCTION__, minor);
		return;
	}

	/* Make sure my_dev_no == s_dev_no */
	if (ccs_dev_ctrl.dev_no != ccs_dev_ctrl.ccs_dev[minor].dev_no) {
		sfx_pr_info("%s: g_dev_no = %d, s_dev_no = %d, minor = %d\n", __FUNCTION__,
			    ccs_dev_ctrl.dev_no, ccs_dev_ctrl.ccs_dev[minor].dev_no, minor);
	}

	sfxdriver_device_destroy(ccs_dev_ctrl.class_ptr, ccs_dev_ctrl.ccs_dev[minor].dev_no);
	if (ccs_dev_ctrl.ccs_dev[minor].cdev_ptr != NULL && is_ccs_dev_ctrl_inited()) {
		cdev_del(ccs_dev_ctrl.ccs_dev[minor].cdev_ptr);
	}

	ccs_dev_ctrl_count_decrement();

	//sfx_pr_info("%s: Done, minor = %d\n", __FUNCTION__, minor);
}

void ccs_dev_exit(void)
{
#ifndef IOCTL_CHR_DEV_EXTRA
	DestroyTable();
	sfx_base_close();
#endif

	sfxdriver_class_destroy(ccs_dev_ctrl.class_ptr);
	unregister_chrdev_region(ccs_dev_ctrl.dev_no, ccs_dev_ctrl.max_count);

	ccs_dev_ctrl_reset();
}

/*
 * This is to maintain single ccs device for backward compatability
 */
void __exit ut_ccs_dev_exit(void)
{
	ccs_per_dev_exit(0);
	ccs_dev_exit();
}

#ifndef IOCTL_CHR_DEV_EXTRA
module_init(ut_ccs_dev_init);
module_exit(ut_ccs_dev_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("UnitTest for CCS IOCTL module");
/* SFX_SW_VERSION is dynamically defined in version_tmp.h */
MODULE_VERSION(SFX_SW_VERSION);
#endif
