/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : ccs_api_conn.h
 * ---------------------------------------------------------------------------
 */

#ifndef __CCS_API_IPC_H__
#define __CCS_API_IPC_H__

#include "sfx_types.h"

#define EC_CHUNK_SIZE               (64*1024)
#define COMP_HW_16KB_SHIFT_BITS     (14)
#define COMP_DATA_UNIT_PG_NUM       (4)     /* 16KB data align */
#define EC_DATA_UNIT_PG_NUM         (4)     /* 16KB data align */
#define R2C_DATA_UNIT_PG_NUM        (4)     /* 16KB data align? TODO */

#ifndef MAX_CLIENTS

#define MAX_CLIENTS                 256
#define MSG_CLIENT_ABORT            0xFFFF
#define MSG_OOB_BASE                0x7F00
#define MSG_OOB_DISCONNECT          (MSG_OOB_BASE+0)

typedef enum {
    MSG_CLIENT_SHUTDOWN = 0,
    MSG_CLIENT_INFO,  //Registration
    MSG_CLIENT_CALL,
    MSG_SERVER_INFO_RESPONSE = 0x100,
    MSG_CLIENT_USER_BASE     = 0x1000,
    MSG_SYSTEM_BASE          = MSG_OOB_BASE,
} message_type_t;

#endif // MAX_CLIENTS

typedef enum {
    //ccs_func_base
    ccs_func_Open_ccs_dev,
    ccs_func_IdentifyDevice,
    ccs_func_AllocateMem,
    ccs_func_AllocateMemType,
    ccs_func_AllocateMemSize,
    ccs_func_SetKey,
    ccs_func_ReleaseKey,
    ccs_func_SnapshotTables,

    /*
     * Multi-driver APIs (not added to ccs_server)
     */
    ccs_func_CCS_IdentifyDevice,
    ccs_func_CCS_AppendMem_Async,
    ccs_func_CCS_AllocateMem,        //not supported
    ccs_func_CCS_AllocateMemType,
    ccs_func_CCS_AppendMem,
    ccs_func_CCS_GetCCSCmdStatus,
    ccs_func_CCS_DeallocateMem,
    ccs_func_CCS_TrimMem,
    ccs_func_CCS_SealMem,
    ccs_func_CCS_ReadMem,
    ccs_func_CCS_ReadMem_Async,

    /* CCS DCE related entries including Compression and EC */
    ccs_func_CCS_Comp_Append_Data_Async,
    ccs_func_CCS_Comp_Get_Data_Async,
    ccs_func_CCS_Comp_Append_Get_Data_Async,
    ccs_func_CCS_Comp_Open_Session,
    ccs_func_CCS_Comp_Close_Session,
    ccs_func_CCS_Get_Dev_Count,
    ccs_func_CCS_Comp_Get_Runtime_Status,

    ccs_func_CCS_EC_Append_Data_Async,
    ccs_func_CCS_EC_Get_Data_Async,
    ccs_func_CCS_EC_Open_Session,
    ccs_func_CCS_EC_Close_Session,
    ccs_func_CCS_EC_Get_Runtime_Status,
    ccs_func_CCS_EC_Append_Get_Data_Async,
    ccs_func_CCS_GetECCmdStatus,

    // Reserve specific ID range 0x30~0x80 for RC
    ccs_func_CCS_RC_Open_Session       = 0x30,
    ccs_func_CCS_RC_Send_Cmd           = 0x31,
    ccs_func_CCS_RC_Query_Status       = 0x32,
    ccs_func_CCS_RC_Query_Status_Group = 0x33,
    ccs_func_CCS_RC_LBA_PBA            = 0x34,

    ccs_func_CCS_RC_64_Col_Schema      = 0x40,
    ccs_func_CCS_RC_128_Col_Schema     = 0x41,
    ccs_func_CCS_RC_256_Col_Schema     = 0x42,
    ccs_func_CCS_RC_384_Col_Schema     = 0x43,
    ccs_func_CCS_RC_512_Col_Schema     = 0x44,
    ccs_func_CCS_RC_640_Col_Schema     = 0x45,
    ccs_func_CCS_RC_768_Col_Schema     = 0x46,
    ccs_func_CCS_RC_896_Col_Schema     = 0x47,
    ccs_func_CCS_RC_1024_Col_Schema    = 0x48,

    ccs_func_CCS_RC_256_In_Cond        = 0x50,
    ccs_func_CCS_RC_512_In_Cond        = 0x51,
    ccs_func_CCS_RC_1024_In_Cond       = 0x52,
    ccs_func_CCS_RC_1536_In_Cond       = 0x53,
    ccs_func_CCS_RC_2048_In_Cond       = 0x54,
    ccs_func_CCS_RC_2560_In_Cond       = 0x55,
    ccs_func_CCS_RC_3072_In_Cond       = 0x56,
    ccs_func_CCS_RC_3584_In_Cond       = 0x57,
    ccs_func_CCS_RC_4096_In_Cond       = 0x58,
    ccs_func_CCS_RC_4608_In_Cond       = 0x59,
    ccs_func_CCS_RC_5120_In_Cond       = 0x5A,
    ccs_func_CCS_RC_5632_In_Cond       = 0x5B,
    ccs_func_CCS_RC_6144_In_Cond       = 0x5C,
    ccs_func_CCS_RC_6656_In_Cond       = 0x5D,
    ccs_func_CCS_RC_7168_In_Cond       = 0x5E,
    ccs_func_CCS_RC_7680_In_Cond       = 0x5F,
    ccs_func_CCS_RC_8192_In_Cond       = 0x60,
    ccs_func_CCS_RC_9216_In_Cond       = 0x61,

    ccs_func_CCS_RC_RESERVED           = 0x80,

    ccs_func_CCS_DeleteAllData         = 0x81,
    ccs_func_CCS_GetStats,
    ccs_func_CCS_GetParitySizes,
    ccs_func_CCS_get_feature,
    ccs_func_CCS_GetCardSize,
    ccs_func_CCS_SnapshotTables,
    ccs_func_CCS_Abort_Cmd,
    ccs_func_LockMem,
    ccs_func_UnlockMem,

    ccs_func_last_tag            //not supported
} ccs_func_id_t;

// Callback

int ccs_conn_init(int, void *);
int ccs_conn_uninit(int, void *);

// Client

int ccs_client_call(int msg_id, ccs_message_t *m, int length);
// int rc_client_call(int msg_id, void *msg, xt_u8 dev_id);
// Server

typedef int (*ccs_request_handler_t)(int client_id, int msg_id, void *data );

int ccs_conn_loop(xt_u8 ccs_dev_id, ccs_request_handler_t h);
int ccs_response(int cid, void *data);
int ccs_server_loop(xt_u8 ccs_dev_id);
int ccs_request_handler( int client_id, int msg_id, void *data );

#endif // __CCS_API_IPC_H__
