/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_api_common.c
 * ---------------------------------------------------------------------------
 */

#include "osutil.h"
#ifndef __KERNEL__
// for sfx_fill_and_print
#include <stdio.h>
#include "sfx_int_user.h"
#endif
#include "sfx_api.h"
#include "sfx_int_common.h"

xt_u64 g_pba_log[2048];

xt_32 sfx_lock_mem(union handle *hand, xt_u32 *vaddr, xt_u32 length, xt_u32 **paddr)
{
	sfx_mem_cmd_t cmd;
	xt_32 rtn;

	cmd.addr = vaddr;
	cmd.length = length;
	rtn = sfx_lock_mem_core(hand, &cmd);
	*paddr = cmd.token_addr;
#ifdef LOCKMEM_DEBUG
#ifndef __KERNEL__
	printf("sfx_lock_mem: ===paddr %p cmd.token_addr 0x%p *paddr %p\n", paddr, cmd.token_addr, *paddr);
#else
	sfx_pr_info("%s: ===paddr %p cmd.token_addr 0x%p *paddr %p\n", __FUNCTION__, paddr, cmd.token_addr,
		    *paddr);
#endif
#endif

	return rtn;
}

void sfx_length_one_token(union handle *hand, xt_u32 *vaddr, xt_u32 offset, xt_u32 length, xt_u8 *mask,
			  void *prd_buff)
{
	sfx_tk_spl_cmd_t cmd;

	cmd.addr = vaddr;
	cmd.length = length;
	cmd.mask = mask;
	cmd.prd_buff = prd_buff;
	cmd.list[0] = offset;

	sfx_length_one_token_core(hand, &cmd);
}

xt_32 sfx_split_token(union handle *hand, xt_u32 *vaddr, xt_u32 *list, xt_u32 length, xt_u8 *mask,
		      void *prd_buff, xt_u32 **paddr)
{
	sfx_tk_spl_cmd_t cmd;
	xt_32 ret = 0;
	cmd.addr = vaddr;
	cmd.length = length;
	cmd.mask = mask;
	cmd.prd_buff = prd_buff;
	sfx_memcpy(cmd.list, list, length * sizeof(xt_u32));
	ret = sfx_split_token_core(hand, &cmd, vaddr, length);
	*paddr = cmd.token_addr;
	return ret;
}

xt_32 sfx_user_set_pagelist(union handle *hand, void **list, void **token, unsigned count, int type,
			    int offset)
{
	return sfx_set_pagelist_core(hand, list, token, count, type, offset);
}

#define CMD_COMBINE 0

void sfx_fill_iocmd(sfx_userio_cmd_t *userCmd, SFX_NVME_IO_CMD *nvmeCmd)
{
	sfx_memset(userCmd, 0, sizeof(sfx_userio_cmd_t));

	userCmd->opcode = nvmeCmd->op_code;
	userCmd->qid = nvmeCmd->qid;
	userCmd->reftag = nvmeCmd->cmp_ctl; //for compression
	userCmd->dsmgmt = (nvmeCmd->FUSE & 0x1) << 6; //for compression
	userCmd->nblocks = nvmeCmd->length;

	if (userCmd->opcode == sfx_cmd_erase) {
		//  userCmd->slba = nvmeCmd->pba;
		userCmd->slba = ((nvmeCmd->SLC & 0x1) << 18);
		userCmd->slba = nvmeCmd->pba | (userCmd->slba << 32);
		userCmd->dsmgmt = 0; // 1<<2; //Erase control, alwasy 2 plane erase
		userCmd->extended_ctrl |= ((nvmeCmd->bd_pl_mask & 0xF) << 13);
	} else if (userCmd->opcode == sfx_cmd_buf2nand) {
#ifndef MQ_NEWHW
		userCmd->slba = ((nvmeCmd->flush & 0x1) << 5) | ((nvmeCmd->stream & 0x3) << 6) |
				((nvmeCmd->ssid & 0x3FF) << 20) | ((nvmeCmd->SLC & 1) << 18) |
				((nvmeCmd->parity_mode & 0x7) << 24) // RAID Cmd=4:RAID_PAGE_OUT/IN
				| ((nvmeCmd->LLC & 1) << 31);
		userCmd->slba = nvmeCmd->pba | (userCmd->slba << 32);
		userCmd->extended_ctrl = ((nvmeCmd->pe_count & 0x7) << 6) |
					 ((nvmeCmd->last_stripe & 0x1) << 5) | (nvmeCmd->stripe_id & 0x1F) |
					 ((nvmeCmd->bd_pl_mask & 0xF) << 13);
#else
		userCmd->slba = ((nvmeCmd->ssid & 0x3FF) << 20) | ((nvmeCmd->SLC & 1) << 18) |
				((nvmeCmd->dp & 1) << 17) |
				((nvmeCmd->parity_mode & 0x7) << 24) // RAID Cmd=4:RAID_PAGE_OUT/IN
				| ((nvmeCmd->LLC & 1) << 31);
		userCmd->slba = (nvmeCmd->pba & 0xFFFFFFFFFF) | (userCmd->slba << 32);
		userCmd->extended_ctrl = (nvmeCmd->bd_pl_mask & 0xF) | ((nvmeCmd->pe_count & 0x7) << 4) |
					 ((nvmeCmd->non_susp & 0x1) << 20) | ((nvmeCmd->stream & 0xF) << 8);
#endif
	} else if (userCmd->opcode == sfx_cmd_dceread) {
		// treat DCE read
		userCmd->slba = (nvmeCmd->stream & 0xFF) | ((nvmeCmd->ec_cmd & 0x7) << 8) |
				((nvmeCmd->buffer_mode & 0x3) << 12) |
				((nvmeCmd->ec_cid & 0x7) << 14)
				// | ( (nvmeCmd->SLC & 0x1) << 18 )
				// | ( (nvmeCmd->DLA & 0x1) << 19 )
				// | ( (nvmeCmd->Vt & 0x7) << 20 )
				| ((nvmeCmd->ec_id & 0x7) << 24) | ((nvmeCmd->LLC & 0x1) << 31);
		userCmd->slba = nvmeCmd->pba | (userCmd->slba << 32);
	} else { // only covers sfx_cmd_read & sfx_cmd_write?
		userCmd->slba = ((nvmeCmd->po_offset & 0x3) << 3)
#ifndef MQ_NEWHW
				| ((nvmeCmd->stream & 0x3) << 6)
#endif
				| ((nvmeCmd->writesession & 0xF) << 8) |
				((nvmeCmd->buffer_mode & 0x3) << 12) // DSID=1
				| ((nvmeCmd->encryption & 0x1) << 14) // E
				| ((nvmeCmd->compression & 0x3) << 15) | ((nvmeCmd->SLC & 0x1) << 18) |
				((nvmeCmd->DLA & 0x1) << 19) | ((nvmeCmd->Vt & 0x7) << 20) |
				((nvmeCmd->parity_mode & 0x7) << 24) // RAID Cmd=4:RAID_PAGE_OUT/IN
				| ((nvmeCmd->raid_bufid & 0x7) << 27) | ((nvmeCmd->LLC & 0x1) << 31);

		if (userCmd->opcode == sfx_cmd_write) {
			userCmd->slba |= ((nvmeCmd->uis & 0x1) << 23);
			userCmd->slba |= ((nvmeCmd->nvm & 0x1) << 30);
			userCmd->extended_ctrl |= (nvmeCmd->nvm & 0x2);
		} else {
			//  userCmd->slba |= ( ((nvmeCmd->Vt >> 3) & 0x3) << 1 );  // moved to extended_ctrl
		}

		userCmd->metadata = (userCmd->opcode == sfx_cmd_read) ? nvmeCmd->crc_high : nvmeCmd->mid;
		userCmd->metadata = (userCmd->metadata << 32) | nvmeCmd->aes_bvalue;
		userCmd->slba = (userCmd->slba << 32) | nvmeCmd->pba;

#ifndef MQ_NEWHW
		userCmd->extended_ctrl = ((nvmeCmd->ec & 0x1) << 12) | ((nvmeCmd->comp_sid & 0x7) << 9) |
					 ((nvmeCmd->pe_count & 0x7) << 6) | (nvmeCmd->stripe_id & 0x1F);
#else
		userCmd->extended_ctrl = ((nvmeCmd->ec & 0x1) << 12) | ((nvmeCmd->comp_sid & 0x7) << 9) |
					 ((nvmeCmd->pe_count & 0x7) << 6) | (nvmeCmd->stripe_id & 0x1F);
#endif
		if (userCmd->opcode == sfx_cmd_read || userCmd->opcode == sfx_cmd_nand2buf) {
#ifndef MQ_NEWHW
			userCmd->extended_ctrl |=
				((nvmeCmd->bd_pl_mask & 0xF) << 24 | (nvmeCmd->prp_mask & 0xFF) << 16 |
				 (nvmeCmd->uis & 0x1) << 15 | (nvmeCmd->susp & 0x1) << 14 |
				 (nvmeCmd->snaprd & 0x1) << 13);
#else
			userCmd->extended_ctrl =
				((nvmeCmd->low_priority & 0x1) << 28) | ((nvmeCmd->bd_pl_mask & 0xF) << 24) |
				((nvmeCmd->prp_mask & 0xFF) << 16) | ((nvmeCmd->uis & 0x1) << 15) |
				((nvmeCmd->susp & 0x1) << 14) | ((nvmeCmd->snaprd & 0x1) << 13) |
				((nvmeCmd->ec & 0x1) << 12) | ((nvmeCmd->comp_sid & 0x7) << 9) |
				((nvmeCmd->pe_count & 0x7) << 6) | ((nvmeCmd->owl & 0x1) << 5) |
				((nvmeCmd->page_type & 0x7) << 2) | ((nvmeCmd->Vt >> 3) & 0x3);
#endif
			if (userCmd->opcode == sfx_cmd_nand2buf) {
				userCmd->prp1 = nvmeCmd->seq_id;
			}
#if CMD_COMBINE
			sfx_memcpy(userCmd->fids, nvmeCmd->comb_nid, MAX_COMBINED_FCMD * sizeof(xt_u16));
			userCmd->nr_fcmd = nvmeCmd->nr_fcmd;
#endif
		} else {
#ifndef MQ_NEWHW
			userCmd->extended_ctrl |= ((nvmeCmd->bd_pl_mask & 0xF) << 13);
#else
			userCmd->extended_ctrl = ((nvmeCmd->stream & 0xF) << 8) | (nvmeCmd->comp_sid & 0x7);
#endif
		}
	}
	userCmd->addr = (void *)nvmeCmd->host_addr;
	userCmd->apptag = nvmeCmd->nid;
}

#ifndef FTL_AS_MODEL_LIB
// return value: 0:success, 1:pending, -1: error

/* The issue_func executes the very base system function; an ioctl
 * for the user mode and a call into the driver for kernel mode.
 * Both calls rely on a lot of non-common information, hence the
 * function pointer */
xt_32 sfx_submit_nvme(union handle *hand, SFX_NVME_IO_CMD *cmd)
{
	xt_32 ret = 0;
	sfx_userio_cmd_t userio_cmd;

	sfx_assert(cmd != NULL);

#ifndef __KERNEL__
	sfx_fill_and_print(hand, &userio_cmd, cmd);
#else
	sfx_fill_iocmd(&userio_cmd, cmd);
#endif
	if ((ret = sfx_submit_issue_core(hand, &userio_cmd))) {
		return ret;
	}

	if (cmd->nid < 2048) {
		// Only log R/W commands
		g_pba_log[cmd->nid] = cmd->pba;
	}

	return ret;
}
#endif // FTL_AS_MODEL_LIB

xt_32 sfx_get_free_slot_cnt(union handle *hand, xt_u32 *cntp)
{
	return sfx_get_free_slot_core(hand, cntp);
}
