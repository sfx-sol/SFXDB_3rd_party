/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_api_kernel.c
 * ---------------------------------------------------------------------------
 */

#include "sfx_driver_api.h"

SFX_DEFINE_MUTEX(dev_mutex_k);

struct sfx_dev;
struct sfx_fd;

static struct sfx_dev *sdev = NULL;
static struct pci_dev *dev = NULL;
static struct sfx_fd *sfd = NULL;

int sfx_base_init(void)
{
	int ret;

	if (dev != NULL) {
		return 0;
	}
	SFX_INFO("\n");

	/* Get a reference to the first Arundina card found
     * Question: what if the sfx_driver init failed? Do we
     * still see a device? */
	dev = pci_get_device(0xCC53, PCI_ANY_ID, NULL);

	if (dev == NULL) {
		SFX_INFO("Could not find Arundina PCIe device\n");
		ret = -EINVAL;
		goto err_cleanup;
	}

	sdev = pci_get_drvdata(dev);

	if (sdev == NULL) {
		SFX_INFO("Invalid sdev in sfx api init\n");
		ret = -EINVAL;
		goto dev_cleanup;
	}

	sfx_fd_init(&sfd, sdev);

	if (sfd == NULL) {
		SFX_INFO("Could not find Arundina PCIe device\n");
		ret = -EINVAL;
		goto dev_cleanup;
	}

	return 0;

dev_cleanup:
	pci_dev_put(dev);
	dev = NULL;
	sdev = NULL;
	sfd = NULL;

err_cleanup:
	return ret;
}

void sfx_base_close(void)
{
	if (dev) {
		if (sfd) {
			sfx_fd_destroy(sfd);
		}
		pci_dev_put(dev);
	}
	dev = NULL;
	sdev = NULL;
	sfd = NULL;
}

xt_32 sfx_create_nvmeq(union handle *hand, xt_u8 qid, xt_u8 q_type, xt_u8 stream_id, unsigned long imask,
		       xt_u8 flag)
{
	sfx_cpumask_var_t mask;
	int i, bit_count;
	unsigned long smask = imask;
	struct sfx_driver_nvmeq_ctx init_ctx = { 0 };

	if (!sfx_alloc_cpumask_var(&mask, GFP_KERNEL)) {
		return -1;
	}
	cpumask_clear(mask);
	bit_count = 8 * sizeof(smask);
	for (i = 1; i <= bit_count; i++) {
		if (smask % 2) {
			cpumask_set_cpu(i, mask);
		}
		smask >>= 1;
	}
	init_ctx.qid = qid;
	init_ctx.queue_type = q_type;
	init_ctx.stream_id = stream_id;
	init_ctx.cpumask = mask;
	init_ctx.flag_last = flag;
	if (sfx_alloc_nvmeq(hand, &init_ctx, NULL)) {
		sfx_free_cpumask_var(mask);
		return 0;
	} else {
		sfx_free_cpumask_var(mask);
		return -1;
	}
}
