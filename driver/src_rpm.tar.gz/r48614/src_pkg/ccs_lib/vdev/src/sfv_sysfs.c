// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfv_sysfs.c
//
// ---------------------------------------------------------------------------

#include "sfx_os_headers.h"
#include "sfx_types.h"
#include "sfx_vdev.h"
#include "sfv_sysfs.h"

#define SYSFS_NAME_MAX 128

// reserve more than enough to accommodate future (block driver) expansion
#define INFO_MAX 20 // 7 currently
#define SMART_MAX 20 // 11 currently
#define DEBUG_MAX 80 // 64 currently
#define DEBUG_LEVEL_MAX 60 // 38 currently

#define GET_VDEV_FROM_DEV(x) ((sfv_device *)(dev_to_disk(x)->private_data))
#define IS_INVALID_VDEV_FROM_DEV(x) IS_INVALID_VDEV_FROM_DISK(dev_to_disk(x))

// borrowed from struct sfx_sysfs_attr in sfx_sysfs.c
struct sfv_sysfs_attr {
	struct attribute attr;
	ssize_t (*show)(char *buf, void *vdev);
	ssize_t (*store)(const char *buf, size_t count, void *vdev);
};

/* =========== below are placeholder for the imported attributes from block driver ================ */

static struct device_attribute info[INFO_MAX];
static struct attribute *info_attrs[INFO_MAX + 1];
static struct attribute_group dev_attr_group;
static char info_name[INFO_MAX][SYSFS_NAME_MAX]; /* store names copied from block driver */
static int info_cnt;

static struct sfv_sysfs_attr smart[SMART_MAX];
static struct attribute *smart_attrs[SMART_MAX + 1];
static char smart_name[SMART_MAX][SYSFS_NAME_MAX]; /* store names copied from block driver */
static int smart_cnt;

static struct sfv_sysfs_attr debug[DEBUG_MAX];
static struct attribute *debug_attrs[DEBUG_MAX + 1];
static char debug_name[DEBUG_MAX][SYSFS_NAME_MAX]; /* store names copied from block driver */
static int debug_cnt;

static struct sfv_sysfs_attr debug_level[DEBUG_LEVEL_MAX];
static struct attribute *debug_level_attrs[DEBUG_LEVEL_MAX + 1];
static char debug_level_name[DEBUG_LEVEL_MAX][SYSFS_NAME_MAX]; /* store names copied from block driver */
static int debug_level_cnt;

static inline struct device_attribute *to_dev_attr(struct attribute *attr)
{
	return container_of(attr, struct device_attribute, attr);
}

static inline struct sfv_kobj *to_kobj(struct kobject *kobject)
{
	return container_of(kobject, struct sfv_kobj, kobject);
}

static inline struct sfv_sysfs_attr *to_attr(struct attribute *attr)
{
	return container_of(attr, struct sfv_sysfs_attr, attr);
}

static inline sfv_device *smart_to_vdev(struct kobject *kobject)
{
	struct sfv_kobj *kobj = to_kobj(kobject);

	return container_of(kobj, sfv_device, smart_kobj);
}

static inline sfv_device *debug_to_vdev(struct kobject *kobject)
{
	struct sfv_kobj *kobj = to_kobj(kobject);

	return container_of(kobj, sfv_device, debug_kobj);
}

static inline sfv_device *debug_level_to_vdev(struct kobject *kobject)
{
	struct sfv_kobj *kobj = to_kobj(kobject);

	return container_of(kobj, sfv_device, debug_level_kobj);
}

static inline void sfv_sysfs_release(struct kobject *kobject)
{
	struct sfv_kobj *kobj = to_kobj(kobject);

	complete(&kobj->complete);
}

int sfv_init_sysfs(struct sfv_kobj *kobj, struct kobject *k_parent, struct kobj_type *ktype, char *name)
{
	memset(kobj, 0x00, sizeof(struct sfv_kobj));
	init_completion(&kobj->complete);
	return kobject_init_and_add(&kobj->kobject, ktype, k_parent, "%s", name);
}

void sfv_exit_sysfs(struct sfv_kobj *kobj)
{
	if (kobj->kobject.state_initialized) {
		kobject_del(&kobj->kobject);
		kobject_put(&kobj->kobject);
		kobj->kobject.state_initialized = 0;
		wait_for_completion(&kobj->complete);
	}
}

static ssize_t sfv_smart_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfv_device *vdev = smart_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->show) {
		rc = sfv_attr->show(buf, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static ssize_t sfv_smart_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
				    size_t count)
{
	sfv_device *vdev = smart_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->store) {
		rc = sfv_attr->store(buf, count, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static const struct sysfs_ops sfv_smart_ops = {
	.show = sfv_smart_attr_show,
	.store = sfv_smart_attr_store,
};

struct kobj_type smart_feature_ktype = {
	.sysfs_ops = &sfv_smart_ops,
	.default_attrs = smart_attrs,
	.release = sfv_sysfs_release,
};

int sfv_add_dev_smart(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg)
{
	struct sfv_sysfs_attr *dev;

	smart_cnt = 0;
	/* run through passed back smart attribute list */
	while ((smart_cnt < SMART_MAX) && reg->smart_feature_attrs[smart_cnt]) {
		/* transfer block driver's attribute to our loacl data structure */
		dev = to_attr(reg->smart_feature_attrs[smart_cnt]);
		smart[smart_cnt].attr = dev->attr;
		/* need to duplicate name to our own space */
		strncpy(smart_name[smart_cnt], dev->attr.name, SYSFS_NAME_MAX);
		smart[smart_cnt].attr.name = smart_name[smart_cnt];

		/* save block driver callbacks */
		smart[smart_cnt].show = dev->show;
		smart[smart_cnt].store = dev->store;

		smart_attrs[smart_cnt] = &smart[smart_cnt].attr;
		smart_cnt++;
	}
	smart_attrs[smart_cnt] = NULL;

	return sfv_init_sysfs(kobj, k_parent, &smart_feature_ktype, "sfx_smart_features");
}

static ssize_t sfv_debug_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfv_device *vdev = debug_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->show) {
		rc = sfv_attr->show(buf, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static ssize_t sfv_debug_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
				    size_t count)
{
	sfv_device *vdev = debug_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->store) {
		rc = sfv_attr->store(buf, count, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static const struct sysfs_ops sfv_debug_ops = {
	.show = sfv_debug_attr_show,
	.store = sfv_debug_attr_store,
};

struct kobj_type debug_ktype = {
	.sysfs_ops = &sfv_debug_ops,
	.default_attrs = debug_attrs,
	.release = sfv_sysfs_release,
};

int sfv_add_dev_debug(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg)
{
	struct sfv_sysfs_attr *dev;

	debug_cnt = 0;
	/* run through passed back debug attribute list */
	while ((debug_cnt < DEBUG_MAX) && reg->debug_attrs[debug_cnt]) {
		/* transfer block driver's attribute to our loacl data structure */
		dev = to_attr(reg->debug_attrs[debug_cnt]);
		debug[debug_cnt].attr = dev->attr;
		/* need to duplicate name to our own space */
		strncpy(debug_name[debug_cnt], dev->attr.name, SYSFS_NAME_MAX);
		debug[debug_cnt].attr.name = debug_name[debug_cnt];

		/* save block driver callbacks */
		debug[debug_cnt].show = dev->show;
		debug[debug_cnt].store = dev->store;

		debug_attrs[debug_cnt] = &debug[debug_cnt].attr;
		debug_cnt++;
	}
	debug_attrs[debug_cnt] = NULL;

	return sfv_init_sysfs(kobj, k_parent, &debug_ktype, "sfx_debug");
}

static ssize_t sfv_debug_level_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfv_device *vdev = debug_level_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->show) {
		rc = sfv_attr->show(buf, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static ssize_t sfv_debug_level_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
					  size_t count)
{
	sfv_device *vdev = debug_level_to_vdev(kobject);
	struct sfv_sysfs_attr *sfv_attr = to_attr(attr);
	ssize_t rc = -EIO;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfv_attr->store) {
		rc = sfv_attr->store(buf, count, vdev->sfx_bd);
	}
	module_put(vdev->bd_module);
	return rc;
}

static const struct sysfs_ops sfv_debug_level_ops = {
	.show = sfv_debug_level_attr_show,
	.store = sfv_debug_level_attr_store,
};

struct kobj_type debug_level_ktype = {
	.sysfs_ops = &sfv_debug_level_ops,
	.default_attrs = debug_level_attrs,
	.release = sfv_sysfs_release,
};

int sfv_add_dev_debug_level(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg)
{
	struct sfv_sysfs_attr *dev;

	debug_level_cnt = 0;
	/* run through passed back debug level attribute list */
	while ((debug_level_cnt < DEBUG_LEVEL_MAX) && reg->debug_level_attrs[debug_level_cnt]) {
		/* transfer block driver's attribute to our loacl data structure */
		dev = to_attr(reg->debug_level_attrs[debug_level_cnt]);
		debug_level[debug_level_cnt].attr = dev->attr;
		/* need to duplicate name to our own space */
		strncpy(debug_level_name[debug_level_cnt], dev->attr.name, SYSFS_NAME_MAX);
		debug_level[debug_level_cnt].attr.name = debug_level_name[debug_level_cnt];

		/* save block driver callbacks */
		debug_level[debug_level_cnt].show = dev->show;
		debug_level[debug_level_cnt].store = dev->store;

		debug_level_attrs[debug_level_cnt] = &debug_level[debug_level_cnt].attr;
		debug_level_cnt++;
	}
	debug_level_attrs[debug_level_cnt] = NULL;

	return sfv_init_sysfs(kobj, k_parent, &debug_level_ktype, "debug_level");
}

static ssize_t delete_disk_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfv_device *vdev = GET_VDEV_FROM_DEV(dev);
	if (IS_INVALID_VDEV_FROM_DEV(dev))
		return sfx_snprintf(buf, SFX_PAGE_SIZE, "Invalid gendisk\n");

	if (vdev->sfx_bd) {
		return sfx_snprintf(buf, SFX_PAGE_SIZE, "Disk in use, cannot be deleted\n");
	} else {
		return sfx_snprintf(buf, SFX_PAGE_SIZE,
				    "\"echo 1 > /sys/block/sfd.../delete_disk\" to remove disk\n");
	}
}

static int delete_disk_thread(void *data)
{
	sfv_device *vdev = (sfv_device *)data;

	msleep_interruptible(
		100); /* ensure user call to delete_disk_store() has finished, i.e. disk unlocked */
	sfv_lock();
	sfv_disconnect_disk(vdev->wwid, 0);
	sfv_unlock();

	do_exit(0);
}

static ssize_t delete_disk_store(struct device *dev, struct device_attribute *attr, const char *buf,
				 size_t count)
{
	sfv_device *vdev = GET_VDEV_FROM_DEV(dev);

	if (IS_INVALID_VDEV_FROM_DEV(dev) == 0 && !vdev->sfx_bd) {
		/* disk is locked during this call, launch a thread to do it later */
		kthread_run(delete_disk_thread, vdev, "delete_disk_thread");
	}

	return count;
}

static DEVICE_ATTR(delete_disk, S_IWUSR | S_IRUGO, delete_disk_show, delete_disk_store);

int sfv_add_dev_info(struct kobject *dev_kobj, struct vdev_register *reg)
{
	struct device_attribute *dev;
	int rc;

	/* create sfv's own attribute */
	rc = sysfs_create_file(dev_kobj, &dev_attr_delete_disk.attr);
	if (rc)
		return rc;

	info_cnt = 0;
	/* run through passed back dev_info attribute list */
	while ((info_cnt < INFO_MAX) && reg->dev_info[info_cnt]) {
		/* transfer block driver's attribute to our loacl data structure */
		dev = to_dev_attr(reg->dev_info[info_cnt]);
		info[info_cnt].attr = dev->attr;
		/* need to duplicate name to our own space */
		strncpy(info_name[info_cnt], dev->attr.name, SYSFS_NAME_MAX);
		info[info_cnt].attr.name = info_name[info_cnt];

		/* save block driver callbacks */
		info[info_cnt].show = dev->show;
		info[info_cnt].store = dev->store;

		info_attrs[info_cnt] = &info[info_cnt].attr;
		info_cnt++;
	}
	info_attrs[info_cnt] = NULL;

	dev_attr_group.attrs = info_attrs;
	return sysfs_create_group(dev_kobj, &dev_attr_group);
}

void sfv_clear_sysfs_callbacks(void)
{
	int i;

	for (i = 0; i < info_cnt; i++) {
		info[i].show = NULL;
		info[i].store = NULL;
	}
	for (i = 0; i < smart_cnt; i++) {
		smart[i].show = NULL;
		smart[i].store = NULL;
	}
	for (i = 0; i < debug_cnt; i++) {
		debug[i].show = NULL;
		debug[i].store = NULL;
	}
	for (i = 0; i < debug_level_cnt; i++) {
		debug_level[i].show = NULL;
		debug_level[i].store = NULL;
	}
}

void sfv_refill_sysfs_callbacks(struct vdev_register *reg)
{
	int i;

	i = 0;
	while (i < info_cnt && reg->dev_info[i]) {
		struct device_attribute *dev;

		dev = to_dev_attr(reg->dev_info[i]);
		info[i].show = dev->show;
		info[i].store = dev->store;
		i++;
	}
	i = 0;
	while (i < smart_cnt && reg->smart_feature_attrs[i]) {
		struct sfv_sysfs_attr *dev;

		dev = to_attr(reg->smart_feature_attrs[i]);
		smart[i].show = dev->show;
		smart[i].store = dev->store;
		i++;
	}
	i = 0;
	while (i < debug_cnt && reg->debug_attrs[i]) {
		struct sfv_sysfs_attr *dev;

		dev = to_attr(reg->debug_attrs[i]);
		debug[i].show = dev->show;
		debug[i].store = dev->store;
		i++;
	}
	i = 0;
	while (i < debug_level_cnt && reg->debug_level_attrs[i]) {
		struct sfv_sysfs_attr *dev;

		dev = to_attr(reg->debug_level_attrs[i]);
		debug_level[i].show = dev->show;
		debug_level[i].store = dev->store;
		i++;
	}
}
