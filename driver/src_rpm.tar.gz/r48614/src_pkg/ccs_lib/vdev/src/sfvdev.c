/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * ScaleFlux SFV Linux device driver
 * ---------------------------------------------------------------------------
 */

#include <linux/module.h>
#include <linux/blkdev.h>
#include "sfx_os_headers.h"
#include "sfx_types.h"
#include "sfx_vdev.h"
#include "sfv_sysfs.h"
#include "version_tmp.h"

#ifdef sfx_pr_info
#undef sfx_pr_info
#define sfx_pr_info(fmt, ...) printk(KERN_INFO "SFXPK: [SFV] " fmt, ##__VA_ARGS__)
#endif

static int vdev_major;
static char *vdev_name = "nvme"; /* use this particular name only */
static int bd_registered = 0;
static int disk_created = 0;
SFX_LIST_HEAD(vdev_list); /* track each created vdev/disk */
SFX_LIST_HEAD(vmem_list); /* track each created vmem */
static struct mutex vdev_mutex;

/*
 * generally, using hooks of sfx_bd_dev provided should put the hook invoking between
 * moudle_get and module_put so that sfx_bd_dev can't be removed until invoking finish.
 * However, sometimes, we can't hode the module reference as vdev is free, eg invoke
 * sfx_bd_release_instance. In this case, we has to using spin_lock to protect it.
 * */
DEFINE_SPINLOCK(sfv_hooks_lock);
/* function pointers to corresponding block driver entries */
static int (*sfx_bd_open)(sfx_block_device *bdev, fmode_t mode) = NULL;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
static int (*sfx_bd_release)(sfx_gendisk *disk, fmode_t mode) = NULL;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
static void (*sfx_bd_release)(sfx_gendisk *disk, fmode_t mode) = NULL;
#endif
static void (*sfx_bd_release_instance)(xt_32 instance) = NULL;
static int (*sfx_bd_revalidate)(sfx_gendisk *gd) = NULL;
static int (*sfx_bd_ioctl)(sfx_block_device *bdev, fmode_t mode, unsigned cmd, unsigned long arg) = NULL;
static int (*sfx_bd_getgeo)(sfx_block_device *bdev, struct hd_geometry *geo) = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
static blk_qc_t (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio) = NULL;
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 2, 0)
static int (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio) = NULL;
#else
static void (*sfx_bd_make_request)(sfx_request_queue *q, sfx_bio *bio) = NULL;
#endif
#endif
static void (*sfx_bd_request)(sfx_request_queue *q) = NULL;
static void (*sfx_bd_stop_queue)(sfx_request_queue *q) = NULL;
static void (*sfx_bd_start_queue)(sfx_request_queue *q) = NULL;
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
#ifdef CENTOS7X_4_14_0_49_PATCH
static blk_status_t (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd) = NULL;
#else
#ifdef RHEL_RELEASE_CODE
static int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd) = NULL;
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static blk_status_t (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd) = NULL;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
static int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd) = NULL;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
static int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, struct request *rq, bool not_used_here) = NULL;
#else
static int (*sfx_mq_queue_rq)(struct blk_mq_hw_ctx *hctx, struct request *rq) = NULL;
#endif
#endif
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
static int (*sfvdriver_blk_mq_map_queues)(struct blk_mq_tag_set *set) = NULL;
#endif
static int (*sfx_mq_init_hctx)(struct blk_mq_hw_ctx *hctx, void *data, unsigned int hctx_idx) = NULL;
static void (*sfx_mq_complete_rq)(sfx_bio_request *req) = NULL;
#endif // SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ
static sfxError (*sfx_wait_idle)(sfv_device *vdev) = NULL;

int sfv_open(sfx_block_device *bdev, fmode_t mode)
{
	sfx_gendisk *disk = bdev->bd_disk;
	sfv_device *vdev = (sfv_device *)disk->private_data;
	int rc = 0;

	if (IS_INVALID_VDEV_FROM_DISK(disk))
		return -ENODEV;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfx_bd_open) {
		rc = sfx_bd_open(bdev, mode);
	}
	module_put(vdev->bd_module);
	return rc;
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
int sfv_release(sfx_gendisk *disk, fmode_t mode)
{
	int rc = 0;
	sfv_device *vdev = (sfv_device *)disk->private_data;

	if (IS_INVALID_VDEV_FROM_DISK(disk)) {
		spin_lock(&sfv_hooks_lock);
		if (sfx_bd_release_instance)
			sfx_bd_release_instance((uintptr_t)disk->private_data);
		spin_unlock(&sfv_hooks_lock);
		return rc;
	}
	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfx_bd_release) {
		rc = sfx_bd_release(disk, mode);
	}
	module_put(vdev->bd_module);
	return rc;
}

#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
void sfv_release(sfx_gendisk *disk, fmode_t mode)
{
	sfv_device *vdev = (sfv_device *)disk->private_data;
	if (IS_INVALID_VDEV_FROM_DISK(disk)) {
		spin_lock(&sfv_hooks_lock);
		if (sfx_bd_release_instance)
			sfx_bd_release_instance((uintptr_t)disk->private_data);
		spin_unlock(&sfv_hooks_lock);
		return;
	}
	if (atomic_read(&vdev->queue_stopped) == 1) {
		return;
	}
	if (!try_module_get(vdev->bd_module)) {
		return;
	}

	if (sfx_bd_release) {
		sfx_bd_release(disk, mode);
	}
	module_put(vdev->bd_module);
	return;
}
#endif

int sfv_revalidate(sfx_gendisk *gd)
{
	sfv_device *vdev = (sfv_device *)gd->private_data;
	int rc = 0;
	static int printed = 0;

	if (IS_INVALID_VDEV_FROM_DISK(gd))
		return -ENODEV;
	if (atomic_read(&vdev->queue_stopped) == 1) {
		if (!printed) {
			sfx_pr_info("%s, queue stopped\n", __FUNCTION__);
			printed = 1;
		}
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		if (!printed) {
			sfx_pr_info("%s, block driver gone\n", __FUNCTION__);
			printed = 1;
		}
		return rc;
	}

	if (sfx_bd_revalidate) {
		rc = sfx_bd_revalidate(gd);
	}
	module_put(vdev->bd_module);
	return rc;
}

int sfv_ioctl(sfx_block_device *bdev, fmode_t mode, unsigned cmd, unsigned long arg)
{
	sfx_gendisk *disk = bdev->bd_disk;
	sfv_device *vdev = (sfv_device *)disk->private_data;
	int rc = 1;

	if (IS_INVALID_VDEV_FROM_DISK(disk))
		return -ENODEV;
	if (atomic_read(&vdev->queue_stopped) == 1) {
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		return rc;
	}

	if (sfx_bd_ioctl) {
		rc = sfx_bd_ioctl(bdev, mode, cmd, arg);
	}
	module_put(vdev->bd_module);
	return rc;
}

int sfv_getgeo(sfx_block_device *bdev, struct hd_geometry *geo)
{
	sfx_gendisk *disk = bdev->bd_disk;
	sfv_device *vdev = (sfv_device *)disk->private_data;
	int rc = 0;
	static int printed = 0;

	if (IS_INVALID_VDEV_FROM_DISK(disk))
		return -ENODEV;
	if (atomic_read(&vdev->queue_stopped) == 1) {
		if (!printed) {
			sfx_pr_info("%s, queue stopped\n", __FUNCTION__);
			printed = 1;
		}
		return rc;
	}
	if (!try_module_get(vdev->bd_module)) {
		if (!printed) {
			sfx_pr_info("%s, block driver gone\n", __FUNCTION__);
			printed = 1;
		}
		return rc;
	}

	if (sfx_bd_getgeo) {
		rc = sfx_bd_getgeo(bdev, geo);
	}
	module_put(vdev->bd_module);
	return rc;
}

static struct block_device_operations sfv_fops = { .owner = THIS_MODULE,
						   .open = sfv_open,
						   .release = sfv_release,
						   .revalidate_disk = sfv_revalidate,
						   .ioctl = sfv_ioctl,
						   .getgeo = sfv_getgeo };

sfxError sfv_bd_stop_queue(sfx_request_queue *q)
{
	sfv_device *vdev = (sfv_device *)q->queuedata;

	if (atomic_read(&vdev->queue_stopped) == 1) {
		/* calling stop queue more than once will ruin your day */
		return NO_ERROR;
	}
	atomic_set(&vdev->queue_stopped, 1);

	if (sfx_bd_stop_queue) {
		sfx_bd_stop_queue(q);
		msleep_interruptible(100); /* give block driver some time to digest */
		sfx_pr_info("%s, vdev %p queue stopped\n", __FUNCTION__, vdev);
	}

	return NO_ERROR;
}

void sfv_bd_start_queue(sfx_request_queue *q)
{
	sfv_device *vdev = (sfv_device *)q->queuedata;

	if (sfx_bd_start_queue)
		sfx_bd_start_queue(q);
	sfx_pr_info("%s, vdev %p queue starting\n", __FUNCTION__, vdev);

	atomic_set(&vdev->queue_stopped, 0);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
static blk_qc_t sfv_make_request(sfx_request_queue *q, sfx_bio *bio)
{
	sfv_device *vdev = (sfv_device *)q->queuedata;
	blk_qc_t rc;

retry:
	while (atomic_read(&vdev->queue_stopped) == 1) {
		schedule();
	}

	if (sfx_bd_make_request) {
		rc = sfx_bd_make_request(q, bio);
		if (rc == ERR_RETRY) {
			sfx_pr_info("%s, IO went over stop queue\n", __FUNCTION__);
			goto retry;
		}
		return rc;
	} else {
		return -1;
	}
}
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 2, 0)
static int sfv_make_request(sfx_request_queue *q, sfx_bio *bio)
{
	sfv_device *vdev = (sfv_device *)q->queuedata;
	int rc;

retry:
	while (atomic_read(&vdev->queue_stopped) == 1) {
		schedule();
	}

	if (sfx_bd_make_request) {
		rc = sfx_bd_make_request(q, bio);
		if (rc == ERR_RETRY) {
			sfx_pr_info("%s, IO went over stop queue\n", __FUNCTION__);
			goto retry;
		}
		return rc;
	} else {
		return 1;
	}
}
#else
static void sfv_make_request(sfx_request_queue *q, sfx_bio *bio)
{
	sfv_device *vdev = (sfv_device *)q->queuedata;

	while (atomic_read(&vdev->queue_stopped) == 1) {
		schedule();
	}

	if (sfx_bd_make_request) {
		sfx_bd_make_request(q, bio);
	}
}
#endif
#endif

static void sfv_request(sfx_request_queue *q)
{
	if (sfx_bd_request)
		sfx_bd_request(q);
}

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
#ifdef CENTOS7X_4_14_0_49_PATCH
static blk_status_t sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
{
	return sfx_mq_queue_rq(hctx, bd);
}
#else
#ifdef RHEL_RELEASE_CODE
static int sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
			   const struct blk_mq_queue_data *bd) //same as sfx_bd_request in sq
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static blk_status_t sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
static int sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
			   const struct blk_mq_queue_data *bd) //same as sfx_bd_request in sq
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
static int sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx, struct request *rq,
			   bool not_used_here) //same as sfx_bd_request in sq
#else
static int sfv_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
			   struct request *rq) //same as sfx_bd_request in sq
#endif
#endif // RHEL_RELEASE_CODE
{
#ifdef RHEL_RELEASE_CODE
	return sfx_mq_queue_rq(hctx, bd);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
	return sfx_mq_queue_rq(hctx, bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
	return sfx_mq_queue_rq(hctx, bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
	return sfx_mq_queue_rq(hctx, rq, 0);
#else
	return sfx_mq_queue_rq(hctx, rq);
#endif
#endif // RHEL_RELEASE_CODE
}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
static int sfv_blk_mq_map_queues(struct blk_mq_tag_set *set)
{
	return sfvdriver_blk_mq_map_queues(set);
}
#endif

static int sfv_mq_init_hctx(struct blk_mq_hw_ctx *hctx, void *data, unsigned int hctx_idx)
{
	return sfx_mq_init_hctx(hctx, data, hctx_idx);
}

static void sfv_mq_complete_rq(sfx_bio_request *req)
{
	sfx_mq_complete_rq(req);
}

#endif // SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ

/* save callback passed from block driver */
static void save_callbacks(struct vdev_register *reg)
{
	spin_lock(&sfv_hooks_lock);
	sfx_bd_open = reg->sfx_bd_open;
	sfx_bd_release = reg->sfx_bd_release;
	sfx_bd_release_instance = reg->sfx_bd_release_instance;
	sfx_bd_revalidate = reg->sfx_bd_revalidate;
	sfx_bd_ioctl = reg->sfx_bd_ioctl;
	sfx_bd_getgeo = reg->sfx_bd_getgeo;
	sfx_bd_request = reg->sfx_bd_request;
	sfx_bd_stop_queue = reg->sfx_bd_stop_queue;
	sfx_bd_start_queue = reg->sfx_bd_start_queue;
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	// SFX_BLK_MQ
	sfx_mq_queue_rq = reg->sfx_mq_queue_rq;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
	// Between 4.9.0 and 4.10.0, the blk_mq_map_queues() function was not exported by the kernel.
	// So we have to borrowed it from the internal Linux 4.9.0 source file - <block/blk-mq-cpumap.c>
	sfvdriver_blk_mq_map_queues = reg->sfxdriver_blk_mq_map_queues;
#endif
	sfx_mq_init_hctx = reg->sfx_mq_init_hctx;
	sfx_mq_complete_rq = reg->sfx_mq_complete_rq;
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	// SFX_BLK_SQ_BIO
	sfx_bd_make_request = reg->sfx_bd_make_request;
#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	sfx_wait_idle = reg->sfx_wait_idle;
	spin_unlock(&sfv_hooks_lock);
}

static void clear_callbacks(void)
{
	spin_lock(&sfv_hooks_lock);
	sfx_bd_open = NULL;
	sfx_bd_release = NULL;
	sfx_bd_release_instance = NULL;
	sfx_bd_revalidate = NULL;
	sfx_bd_ioctl = NULL;
	sfx_bd_getgeo = NULL;
	sfx_bd_request = NULL;
	sfx_bd_stop_queue = NULL;
	sfx_bd_start_queue = NULL;
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	// SFX_BLK_MQ
	sfx_mq_queue_rq = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
	sfvdriver_blk_mq_map_queues = NULL;
#endif
	sfx_mq_init_hctx = NULL;
	sfx_mq_complete_rq = NULL;
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	// SFX_BLK_SQ_BIO
	sfx_bd_make_request = NULL;
#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	sfx_wait_idle = NULL;

	sfv_clear_sysfs_callbacks();
	spin_unlock(&sfv_hooks_lock);
}

static sfv_device *find_disk(char *wwid)
{
	sfv_device *vdev, *next;

	list_for_each_entry_safe (vdev, next, &vdev_list, sfv_list) {
		if (!(strncmp(vdev->wwid, wwid, WWID_MAX))) {
			return vdev;
		}
	}

	return NULL;
}

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
static struct blk_mq_ops sfv_mq_ops = {
	.queue_rq = sfv_mq_queue_rq,
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 9, 0)
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7, 5)) && (LINUX_VERSION_CODE == KERNEL_VERSION(3, 10, 0))
	{ .aux_ops = NULL },
#else
	.map_queue = blk_mq_map_queue,
#endif
#else
	.map_queue = blk_mq_map_queue,
#endif
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0)
	.map_queues = sfv_blk_mq_map_queues,
#endif
	.init_hctx = sfv_mq_init_hctx,
	.complete = sfv_mq_complete_rq,
};
#endif

static inline int sfv_add_sysfs(sfv_device *vdev, struct vdev_register *reg)
{
	sfx_device *dev;
	/* adding sysfs stuff */
	dev = disk_to_dev(vdev->sfv_disk);

	if (sfv_add_dev_smart(&vdev->smart_kobj, kobject_get(&dev->kobj), reg)) {
		sfx_pr_info("%s, failed to add smart\n", __FUNCTION__);
		return -1;
	}

	if (sfv_add_dev_debug(&vdev->debug_kobj, kobject_get(&dev->kobj), reg)) {
		sfx_pr_info("%s, failed to add debug\n", __FUNCTION__);
		sfv_exit_sysfs(&vdev->smart_kobj);
		return -1;
	}

	if (sfv_add_dev_debug_level(&vdev->debug_level_kobj, kobject_get(&dev->kobj), reg)) {
		sfx_pr_info("%s, failed to add debug_level\n", __FUNCTION__);
		sfv_exit_sysfs(&vdev->smart_kobj);
		sfv_exit_sysfs(&vdev->debug_kobj);
		return -1;
	}
	return 0;
}
int sfv_register(struct vdev_register *reg)
{
	sfv_device *vdev;
	sfx_device *dev;

	sfx_pr_info("%s, wwid %s\n", __FUNCTION__, reg->wwid);

	if (!bd_registered) {
		save_callbacks(reg);
		bd_registered = 1;
	}

	if (disk_created) {
		/*  try to find the disk from our tracking list */
		if ((vdev = find_disk(reg->wwid))) {
			vdev->sfx_bd = reg->sfx_bd;
			vdev->bd_module = reg->bd_module;
			reg->reconnect_disk(vdev);
			sfv_refill_sysfs_callbacks(reg);
			sfv_add_sysfs(vdev, reg);
			sfv_bd_start_queue(vdev->sfv_queue);
			sfx_pr_info("%s, reconnect disk %p\n", __FUNCTION__, vdev->sfv_disk);
			return 0;
		}
		/* cannot find the disk, fall through to create one */
	}

	if (!(vdev = kzalloc_node(sizeof(sfv_device), SFX_GFP_KERNEL, reg->nid))) {
		sfx_pr_info("%s, Fail to alloc vdev\n", __FUNCTION__);
		goto out_free_dev;
	}

	vdev->vdev_major = vdev_major;
	vdev->fops = &sfv_fops;
	vdev->sfx_bd = reg->sfx_bd;
	vdev->bd_module = reg->bd_module;

	/* initialize stuff that we need to take ownership before asking block driver to add disk */
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	vdev->mq_tag_set.driver_data = vdev;
	vdev->mq_tag_set.ops = &sfv_mq_ops;

	if (reg->sfx_vdev_tagset(reg->sfx_bd, &vdev->mq_tag_set)) {
		sfx_pr_info("%s, Fail to alloc tag set\n", __FUNCTION__);
		goto free_vdev;
	}
#endif
	vdev->sfv_make_request = sfv_make_request;
	vdev->sfv_request = sfv_request;

	if (reg->sfx_add_disk(vdev)) {
		sfx_pr_info("%s, failed to add disk\n", __FUNCTION__);
		goto free_tag_set;
	}

	/* adding sysfs stuff */
	dev = disk_to_dev(vdev->sfv_disk);

	if (sfv_add_dev_info(&dev->kobj, reg)) {
		sfx_pr_info("%s, failed to add info\n", __FUNCTION__);
		goto free_disk;
	}

	if (sfv_add_sysfs(vdev, reg))
		goto free_disk;

	strncpy(vdev->wwid, reg->wwid, WWID_MAX);
	atomic_set(&vdev->queue_stopped, 0);
	list_add_tail(&vdev->sfv_list, &vdev_list); /* add to tracking list */

	disk_created = 1;
	return 0;

free_disk:
	del_gendisk(vdev->sfv_disk);
	put_disk(vdev->sfv_disk);
	sfx_blk_cleanup_queue(vdev->sfv_queue);
	kfree(vdev->sfx_bd);

free_tag_set:
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	blk_mq_free_tag_set(&vdev->mq_tag_set);

free_vdev:
#endif
	kfree(vdev);

out_free_dev:
	return -EIO;
}
EXPORT_SYMBOL(sfv_register);

static sfxError clear_disk_info(void)
{
	sfv_device *vdev, *next;

	sfx_pr_info("%s\n", __FUNCTION__);

	/* workaround for multiple namespaces, stop every disk queue first */
	list_for_each_entry_safe (vdev, next, &vdev_list, sfv_list) {
		sfxError error = sfv_bd_stop_queue(vdev->sfv_queue);
		if (error != NO_ERROR) {
			//TODO: add dev name in print
			sfx_pr_info("%s sfv_bd_stop_queue() failed error code %d\n", __FUNCTION__, error);
			return error;
		}
	}
	/* move wait idle to the second loop */
	list_for_each_entry_safe (vdev, next, &vdev_list, sfv_list) {
		if (vdev->sfx_bd) {
			sfxError error = sfx_wait_idle(vdev);
			if (error != NO_ERROR) {
				sfx_pr_info("%s sfx_wait_idle() failed error code %d\n", __FUNCTION__, error);
				return error;
			}
			vdev->sfx_bd = 0;
			vdev->bd_module = 0;
		} else {
			sfx_pr_info("%s, disk %p already disconnected\n", __FUNCTION__, vdev->sfv_disk);
		}
	}
	return NO_ERROR;
}
static inline void sfv_del_sysfs(sfv_device *vdev)
{
	sfv_exit_sysfs(&vdev->smart_kobj);
	sfv_exit_sysfs(&vdev->debug_kobj);
	sfv_exit_sysfs(&vdev->debug_level_kobj);
}
static void free_disk(void)
{
	sfv_device *vdev, *next;

	list_for_each_entry_safe (vdev, next, &vdev_list, sfv_list) {
		list_del(&vdev->sfv_list);
		del_gendisk(vdev->sfv_disk);
		sfv_del_sysfs(vdev);
		put_disk(vdev->sfv_disk);
		sfx_blk_cleanup_queue(vdev->sfv_queue);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		blk_mq_free_tag_set(&vdev->mq_tag_set);
#endif
		kfree(vdev);
	}
}

sfxError sfv_unregister(void)
{
	sfx_pr_info("%s\n", __FUNCTION__);

	if (!list_empty(&vdev_list)) {
		xt_u32 error = clear_disk_info();
		if (error != NO_ERROR) {
			sfx_pr_info("%s failed error code %d\n", __FUNCTION__, error);
			return error;
		}
	}
	clear_callbacks();

	bd_registered = 0;
	return NO_ERROR;
}
EXPORT_SYMBOL(sfv_unregister);

void sfv_lock(void)
{
	mutex_lock(&vdev_mutex);
}
EXPORT_SYMBOL(sfv_lock);

void sfv_unlock(void)
{
	mutex_unlock(&vdev_mutex);
}
EXPORT_SYMBOL(sfv_unlock);

void sfv_disconnect_disk(char *wwid, int keep_disk)
{
	sfv_device *vdev;

	sfx_pr_info("%s, %s, keep_disk %d\n", __FUNCTION__, wwid, keep_disk);

	if ((vdev = find_disk(wwid))) {
		sfv_bd_stop_queue(vdev->sfv_queue);
		if (vdev->sfx_bd) {
			sfx_wait_idle(vdev);
		} else {
			sfx_pr_info("%s, disk %p already disconnected\n", __FUNCTION__, vdev->sfv_disk);
		}

		/* if the sfv is being referenced, do not remove the disk */
		if (keep_disk) {
			vdev->sfx_bd = 0;
			vdev->bd_module = 0;
			sfv_del_sysfs(vdev);
		} else {
			list_del(&vdev->sfv_list);
			del_gendisk(vdev->sfv_disk);
			sfv_del_sysfs(vdev);
			put_disk(vdev->sfv_disk);
			sfx_blk_cleanup_queue(vdev->sfv_queue);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
			blk_mq_free_tag_set(&vdev->mq_tag_set);
#endif
			kfree(vdev);
		}
	}
}
EXPORT_SYMBOL(sfv_disconnect_disk);

static sfv_mem *find_mem(char *sn)
{
	sfv_mem *vmem, *next;

	list_for_each_entry_safe (vmem, next, &vmem_list, mem_list) {
		if (!(strncmp(vmem->sn, sn, SN_MAX))) {
			return vmem;
		}
	}

	return NULL;
}

void sfv_get_mem(void (*bd_mem_callback)(sfv_mem *sfvmem), char *sn)
{
	sfv_mem *vmem;

	sfx_pr_info("%s(), serial number: %s\n", __FUNCTION__, sn);

	sfv_lock();
	vmem = find_mem(sn);

	if (!vmem) {
		if (!(vmem = kzalloc(sizeof(sfv_mem), SFX_GFP_KERNEL))) {
			sfx_pr_info("%s, Fail to alloc vmem\n", __FUNCTION__);
			sfv_unlock();
			return;
		}
		strncpy(vmem->sn, sn, SN_MAX);
		list_add_tail(&vmem->mem_list, &vmem_list); /* add to tracking list */
	}
	sfv_unlock();

	if (bd_mem_callback) {
		bd_mem_callback(vmem);
	}
}
EXPORT_SYMBOL(sfv_get_mem);

static void free_vmem(void)
{
	sfv_mem *vmem, *next;

	list_for_each_entry_safe (vmem, next, &vmem_list, mem_list) {
		list_del(&vmem->mem_list);
		kfree(vmem);
	}
}

static int __init sfv_init(void)
{
	sfx_pr_info("%s: SFX_SW_VERSION %s\n", __FUNCTION__, SFX_SW_VERSION);

	vdev_major = register_blkdev(0, vdev_name);
	if (vdev_major < 0) {
		sfx_pr_info("%s, register_blkdev failed: %d\n", __FUNCTION__, vdev_major);
		return -EIO;
	}
	mutex_init(&vdev_mutex);

	return 0;
}

static void __exit sfv_exit(void)
{
	sfx_pr_info("%s\n", __FUNCTION__);

	if (!list_empty(&vdev_list)) {
		sfx_pr_info("%s: free all registered disk(s)\n", __FUNCTION__);
		free_disk();
	}
	if (!list_empty(&vmem_list)) {
		sfx_pr_info("%s: free all BD memory tracker\n", __FUNCTION__);
		free_vmem();
	}
	mutex_destroy(&vdev_mutex);

	unregister_blkdev(vdev_major, vdev_name);
}

module_init(sfv_init);
module_exit(sfv_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("ScaleFlux Virtual Block Driver Module");
/* SFX_SW_VERSION is dynamically defined in version_tmp.h */
MODULE_VERSION(SFX_SW_VERSION);
