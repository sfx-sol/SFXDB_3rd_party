/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_mq_config.c
 * ---------------------------------------------------------------------------
 */

#include "sfx_bd_dev.h"

/*
 * In the target of isolation, each stream/PU has its
 * own read queues and write queues. '
 * In the target of non-isolation, each stream has its
 * own write queues while the read queues will be  global
 * shared by all streams.
 *
 * Define read write queue ratio K, and read queue
 * stream factor S as:
 *        tot_rd_queue : tot_write_queue = num_stream/S : K*num_stream
 *
 * S represents how many stream one read queue is shared.
 * In isolation mode, S=1; otherwise, S=num_stream;
 *
 * K represents the share level ratio between write queue
 * and read queue. Furthermore,
 * if S=1, K represents the ratio between write queue
 * and read queue within one stream;
 * if S=num_stream, K represents the ratio between write
 * queue per stream and total read queue.
 *
 * E.g., if S=num_stream, and K=1, it means the the num of
 * write queue per stream is identical with the num of
 * total read queue.
 *
 * In initial design, We set S=1 and K=1 in isolation mode;
 * set S=num_stream and K=1 in non-isoliatoin mode.
 */
#define WRQ_RDQ_RATIO (1)

void sfx_ioq_config_change(struct sfx_ioq_config *ioq_config, xt_u16 set_cpu_num, xt_u8 set_stream_num,
			   xt_u8 set_isolation)
{
	ioq_config->num_cpu = set_cpu_num;
	ioq_config->isolation = set_isolation;
	ioq_config->num_stream = set_stream_num;
}

static void _init_ioqconfig(struct sfx_ioq_config *ioq_config, xt_u8 stream_num)
{
	ioq_config->num_cpu = sfx_num_online_cpus();
	ioq_config->num_stream = stream_num;
	ioq_config->isolation = 0;
	ioq_config->tot_ioq = TOT_QUEUE - NON_IO_QUEUE - (ioq_config->num_stream * QID_OFF_WR_BASE);
}

static void _get_ioqconfig(struct sfx_ioq_config *ioq_config)
{
	xt_u8 k, s;
	xt_u16 tot_rdq, rdq_per_unit, wrq_per_stream, num_cpu;

	k = WRQ_RDQ_RATIO;
	s = ioq_config->isolation ? 1 : ioq_config->num_stream;
	tot_rdq = ioq_config->tot_ioq / (1 + k * s);
	rdq_per_unit = tot_rdq / (ioq_config->num_stream / s);
	wrq_per_stream = (ioq_config->tot_ioq - tot_rdq) / ioq_config->num_stream;

	num_cpu = ioq_config->num_cpu;

	while (wrq_per_stream < num_cpu) {
		num_cpu >>= 1;
	}
	wrq_per_stream = num_cpu;

	num_cpu = ioq_config->num_cpu;
	if (!ioq_config->isolation) {
		rdq_per_unit = (ioq_config->tot_ioq - wrq_per_stream * ioq_config->num_stream) /
			       (ioq_config->num_stream / s);
	}
	while (rdq_per_unit < num_cpu) {
		num_cpu >>= 1;
	}
	rdq_per_unit = num_cpu;

	ioq_config->rdq_per_unit = rdq_per_unit;
	ioq_config->wrq_per_stream = wrq_per_stream;

#ifdef __SFX_KERNEL__
	sfx_print(-1, BLK_SYS, PL_INF,
		  "IO queue configuration (cpu, ioq, iso, str, rq, wqps): "
		  "%u, %u, %u, %u, %u, %u\n",
		  ioq_config->num_cpu, ioq_config->tot_ioq, ioq_config->isolation, ioq_config->num_stream,
		  ioq_config->rdq_per_unit, ioq_config->wrq_per_stream);
#endif
}

xt_32 sfx_mq_get_cpu_queue_mapping(xt_u32 *cpu2wrqid_map, xt_u32 *cpu2rdqid_map,
				   const struct cpumask *online_mask, struct sfx_ioq_config *ioq_config,
				   xt_u32 stream_num)
{
	xt_u8 rdq_config;
	xt_u32 nr_queues;
	xt_u32 *map;

#ifdef SFX_LINUX
	sfx_cpumask_var_t cpus;
#endif

#ifdef SFX_LINUX
	if (!sfx_alloc_cpumask_var(&cpus, GFP_ATOMIC)) {
		return 1;
	}
#endif
	_init_ioqconfig(ioq_config, stream_num);
	_get_ioqconfig(ioq_config);

	rdq_config = 0xFF;
	map = cpu2wrqid_map;
	nr_queues = ioq_config->wrq_per_stream;

	do {
		xt_u32 nr_cpus, nr_uniq_cpus, queue, first_sibling;
		unsigned int cpu_iter;
		rdq_config = ~rdq_config;
		if (!nr_queues) {
			goto RD_QUEUE;
		}
#ifdef SFX_LINUX
		sfx_cpumask_clear(cpus);
#endif
		nr_cpus = nr_uniq_cpus = 0;
		/* calculate unique cpu number */
		sfx_for_each_cpu(cpu_iter, online_mask)
		{
			nr_cpus++;
#ifdef SFX_LINUX
			first_sibling = get_first_sibling(cpu_iter);
			if (!sfx_cpumask_test_cpu(first_sibling, cpus)) {
				nr_uniq_cpus++;
			}
			sfx_cpumask_set_cpu(cpu_iter, cpus);
#else
			nr_uniq_cpus++;
#endif
		}
		queue = 0;
		sfx_for_each_cpu(cpu_iter, online_mask)
		{
			if (!sfx_cpumask_test_cpu(cpu_iter, online_mask)) {
				map[cpu_iter] = 0;
				continue;
			}
			/*
             * Easy case - we have equal or more hardware queues. Or
             * there are no thread siblings to take into account. Do
             * 1:1 if enough, or sequential mapping if less.
             */
			if (nr_queues >= nr_cpus || nr_cpus == nr_uniq_cpus) {
				//map[cpu_iter] = cpu_to_queue_index(nr_cpus, nr_queues, queue);
				map[cpu_iter] = cpu_to_queue_index(nr_cpus, nr_queues, cpu_iter);
				queue++;
				continue;
			}
			/*
             * Less then nr_cpus queues, and we have some number of
             * threads per cores. Map sibling threads to the same queue.
             */
			first_sibling = get_first_sibling(cpu_iter);
			if (first_sibling == cpu_iter) {
				//map[cpu_iter] = cpu_to_queue_index(nr_uniq_cpus, nr_queues, queue);
				map[cpu_iter] = cpu_to_queue_index(nr_uniq_cpus, nr_queues, cpu_iter);
				queue++;
			} else {
				map[cpu_iter] = map[first_sibling];
			}
		}
	RD_QUEUE:
		map = cpu2rdqid_map;
		nr_queues = ioq_config->rdq_per_unit;
	} while (!rdq_config);

#ifdef SFX_LINUX
	sfx_free_cpumask_var(cpus);
#endif

	return 0;
}
