/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_bd_dev_src.c
 *
 * Implementation of the ScaleFlux Block FTL device driver
 * ---------------------------------------------------------------------------
 */

#include "sfx_bd_dev.h"
#include "sfx_bd_dev_exp.h"
#include "sfx_driver_cb.h"
#include "sfx_driver_api.h"
#include "blk_ftl_coh.h"
#include "blk_ftl_ops.h"
#include "flat_map.h"
#include "blk_ftl_throttle.h"
#include "blk_ftl_req_handler.h"
#include "blk_ftl_maplog_eh.h"
#include "linklist.h"
#include "feat.h"
#include "version_tmp.h"
#include "gc.h"
#include "sfx_vdev.h"

// The following two global variables will be set to the generated driver version, version_tmp.h
char *sfx_sw_version_str = SFX_SW_VERSION;
xt_u32 sfx_driver_version = SFX_DRIVER_VERSION;

xt_u32 sfx_get_pglist_entry_nr(void);
xt_u32 sfx_get_irq(void *sfx_driver_handle, xt_u16 qid);
static void sfx_set_bd_ro_force(sfx_mul_drv *sfx_mdrv, xt_8 read_only_mode);

xt_u32 sfx_bd_dev_major;
EXPORT_SYMBOL(sfx_bd_dev_major);

static xt_u32 fast_cycle_mode = 0;
static xt_u32 multi_stream = 0;
static xt_u64 time_record = 0;

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
static xt_u32 queue_mode = SFX_BD_MQ;
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ)
static xt_u32 queue_mode = SFX_BD_RQ;
#else
static xt_u32 queue_mode = SFX_BD_BIO;
#endif

#ifdef SFX_LINUX
module_param(sfx_bd_dev_major, int, S_IRUGO);
MODULE_PARM_DESC(sfx_bd_dev_major, "SFX_BD_DEV Major number");

module_param(queue_mode, int, S_IRUGO);
MODULE_PARM_DESC(queue_mode, "Block interface to use (0=bio,1=rq,2=multiqueue)");

module_param(fast_cycle_mode, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(fast_cycle_mode, "fast cycle mode");

module_param(multi_stream, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(multi_stream, "multi-stream mode");

static xt_u32 sfx_numa_switch = CHECK_TO_NUMA_SWITCH;
module_param(sfx_numa_switch, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sfx_numa_switch, "numa_switch");

static xt_u32 discard_write_zeros = 0;
module_param(discard_write_zeros, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(discard_write_zeros, "discard_write_zeros");

static xt_u32 sfx_cpu_pinning = 0;
module_param(sfx_cpu_pinning, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sfx_cpu_pinning, "cpu pinning for Ali server!");

static xt_u32 sfx_cgroup = 0;
module_param(sfx_cgroup, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sfx_cgroup, "enable cpu group!");

static xt_u32 sfx_cgroup_step = 4;
module_param(sfx_cgroup_step, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sfx_cgroup_step, "cpu group step");

static xt_u32 sfx_app_pin = 0;
module_param(sfx_app_pin, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sfx_app_pin, "automatic pin application thread!");
#endif

xt_u32 high_priority_read = 1;
module_param(high_priority_read, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(high_priority_read, "high priority read");

// over provision percent from 0-100%, set default to 28%
// not used replaced with capacity
static unsigned int op_percent = 28;
module_param(op_percent, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(op_percent, "op_percent");

static unsigned int nor_dump;
module_param(nor_dump, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(nor_dump, "nor_dump");

static unsigned int pe_preload = 0;
module_param(pe_preload, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(pe_preload, "pe_preload");

static unsigned int debug_mode;
module_param(debug_mode, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(debug_mode, "debug_mode");

static unsigned int capacity = 0xdeadbeef;
module_param(capacity, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(capacity, "capacity");

static unsigned int atomic_wr = 0; //default disable atomic write group
module_param(atomic_wr, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(atomic_wr, "atomic_wr");

static xt_u32 change_dbg_lvl = 0xff;
module_param(change_dbg_lvl, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(change_dbg_lvl, "change_dbg_lvl");

xt_u32 verbose = 1;
module_param(verbose, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(verbose, "verbose");

SFX_LIST_HEAD(sfx_mul_drv_list);
EXPORT_SYMBOL(sfx_mul_drv_list);
SFX_LIST_HEAD(sfx_probing_mul_drv_list);
EXPORT_SYMBOL(sfx_probing_mul_drv_list);

sfx_spinlock_t g_sfx_mul_drv_list_lock;
sfx_spinlock_t g_sfx_probing_mul_drv_list_lock;

sfx_mutex_t g_create_nvmeq_lock;

#ifdef SFX_LINUX
struct sfx_cpu_map_mgm g_cpu_map_mgm;
#endif
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
#ifdef SFX_LINUX

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
static void sfx_part_inc_in_flight(struct request_queue *q, struct hd_struct *part, int rw)
{
	if (q->mq_ops) {
		return;
	}
	atomic_inc(&part->in_flight[rw]);
	if (part->partno) {
		atomic_inc(&part_to_disk(part)->part0.in_flight[rw]);
	}
}

static void sfx_part_dec_in_flight(struct request_queue *q, struct hd_struct *part, int rw)
{
	if (q->mq_ops) {
		return;
	}
	atomic_dec(&part->in_flight[rw]);
	if (part->partno) {
		atomic_dec(&part_to_disk(part)->part0.in_flight[rw]);
	}
}
#endif

void sfx_start_io_acct(sfx_mul_drv *sfx_mdrv, sfx_bio *bio)
{
	struct gendisk *disk;
	xt_u32 cpu;
	const xt_u32 rw = bio_data_dir(bio);
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(6, 5))
	unsigned long flags = 0;
	sfx_spin_lock_irqsave(&sfx_mdrv->io_acct_flag, flags);
#endif
#endif
	if (bio == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio is NULL.\n", __func__);
		goto out;
	}
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	if (bio->bi_disk == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_disk is NULL.\n", __func__);
		goto out;
	}
	disk = bio->bi_disk;
#else
	if (bio->bi_bdev == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_bdev is NULL.\n", __func__);
		goto out;
	}
	if (bio->bi_bdev->bd_disk == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_bdev->bd_disk is NULL.\n",
			  __func__);
		goto out;
	}
	disk = bio->bi_bdev->bd_disk;
#endif

	cpu = part_stat_lock();
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	sfxdriver_part_round_stats(disk->queue, cpu, &disk->part0);
#else
	sfxdriver_part_round_stats(cpu, &disk->part0);
#endif
	part_stat_inc(cpu, &disk->part0, ios[rw]);
	part_stat_add(cpu, &disk->part0, sectors[rw], bio_sectors(bio));
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	sfx_part_inc_in_flight(disk->queue, &disk->part0, rw);
#else
	part_inc_in_flight(&disk->part0, rw);
#endif
	part_stat_unlock();

out:
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(6, 5))
	sfx_spin_unlock_irqrestore(&sfx_mdrv->io_acct_flag, flags);
#endif
#endif
	return;
}

void sfx_end_io_acct(sfx_mul_drv *sfx_mdrv, struct bio *bio, xt_u64 start_time)
{
	struct gendisk *disk;
	xt_u32 cpu;
	const xt_u32 rw = bio_data_dir(bio);
	xt_u64 duration = jiffies - start_time;
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(6, 5))
	unsigned long flags = 0;
	sfx_spin_lock_irqsave(&sfx_mdrv->io_acct_flag, flags);
#endif
#endif
	if (bio == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio is NULL.\n", __func__);
		goto out;
	}
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	if (bio->bi_disk == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_disk is NULL.\n", __func__);
		goto out;
	}
	disk = bio->bi_disk;
#else
	if (bio->bi_bdev == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_bdev is NULL.\n", __func__);
		goto out;
	}
	if (bio->bi_bdev->bd_disk == NULL) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: error, bio->bi_bdev->bd_disk is NULL.\n",
			  __func__);
		goto out;
	}
	disk = bio->bi_bdev->bd_disk;
#endif

	cpu = part_stat_lock();
	part_stat_add(cpu, &disk->part0, ticks[rw], duration);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
	sfxdriver_part_round_stats(disk->queue, cpu, &disk->part0);
	sfx_part_dec_in_flight(disk->queue, &disk->part0, rw);
#else
	sfxdriver_part_round_stats(cpu, &disk->part0);
	part_dec_in_flight(&disk->part0, rw);
#endif
	part_stat_unlock();

out:
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(6, 5))
	sfx_spin_unlock_irqrestore(&sfx_mdrv->io_acct_flag, flags);
#endif
#endif
	return;
}

#endif // SFX_LINUX
#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)

#ifdef SFX_LINUX
void sfx_bd_set_queue_dying(sfx_request_queue *q)
{
	sfxdriver_set_queue_dying(q);
}
#endif

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

void sfx_bd_stop_queue(sfx_request_queue *q)
{
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7, 4))
	sfxdriver_blk_mq_freeze_queue_start(q);
#else
	sfxdriver_blk_mq_freeze_queue(q);
#endif
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0))
	sfxdriver_blk_mq_freeze_queue_start(q);
#endif
#endif

	sfx_queue_flag_set(QUEUE_FLAG_STOPPED, q);

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0) /* patch 9402909 */
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7, 4))
	sfxdriver_blk_mq_cancel_requeue_work(q);
#endif
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
	sfxdriver_blk_mq_cancel_requeue_work(q);
#endif
#endif
#endif

	blk_mq_stop_hw_queues(q);
}

void sfx_bd_start_queue(sfx_request_queue *q)
{
	if (sfx_blk_queue_stopped(q)) {
		sfx_queue_flag_clear_unlocked(QUEUE_FLAG_STOPPED, q);

#ifdef RHEL_RELEASE_CODE
		sfxdriver_blk_mq_unfreeze_queue(q);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
		sfxdriver_blk_mq_unfreeze_queue(q);
#endif
#endif
		blk_mq_start_stopped_hw_queues(q, true);
		blk_mq_kick_requeue_list(q);
	}
}

#else

void sfx_bd_stop_queue(sfx_request_queue *q)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(q);
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s queue_mode: %d\n", __FUNCTION__, queue_mode);
	}
	if (queue_mode == SFX_BD_BIO) {
		sfx_atomic_set(&sfx_mdrv->queue_stop, 1);
	} else {
		sfx_blk_stop_queue(q);
	}
	if (sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s queue_stop: %d\n", __FUNCTION__,
			  sfx_atomic_read(&sfx_mdrv->queue_stop));
	}
}

void sfx_bd_start_queue(sfx_request_queue *q)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(q);
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	if (sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s queue_mode: %d\n", __FUNCTION__, queue_mode);
	}
	if (queue_mode == SFX_BD_BIO) {
		sfx_atomic_set(&sfx_mdrv->queue_stop, 0);
	} else {
		if (sfx_blk_queue_stopped(q)) {
			unsigned long flags = 0;
			sfx_spin_lock_irqsave(q->queue_lock, flags);
			sfx_blk_start_queue(q);
			sfx_spin_unlock_irqrestore(q->queue_lock, flags);
		}
	}
	if (sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s queue_start: %d\n", __FUNCTION__,
			  sfx_atomic_read(&sfx_mdrv->queue_stop));
	}
}

#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

void sfx_bd_start_queue_conditional(sfx_mul_drv *sfx_mdrv, struct sfx_request *req)
{
#if (SFX_BLK_QUEUE_TYPE != SFX_BLK_SQ_BIO)
	if (!sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		// if secure_erase is in progress, don't start the queue
		sfx_bd_start_queue(sfx_get_req_q_from_sfx_req(req));
	}
#endif
}

int sfx_is_remote_cmpl_supported(void)
{
	return SFX_USE_REMOTE_CMPL;
}

struct sfx_request *sfx_alloc_sfx_request(sfx_bd_device *sfx_bd, sfx_bio_request *req, xt_u32 flag)
{
	struct sfx_request *ret;

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	if (!sfx_is_discard_request(req) && (flag != SFX_DSM_DISCARD)) {
		ret = blk_mq_rq_to_pdu(req);
	} else {
		ret = kmem_malloc(sfx_bd->sfx_mdrv->devId, SFX_PAGE_SIZE);
	}
#else
	ret = kmem_malloc(sfx_bd->sfx_mdrv->devId, SFX_PAGE_SIZE);
#endif

	if (!ret) {
		return NULL;
	}

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	ret->start = jiffies;
#endif
	sfx_atomic_set(&ret->finish_tag, 0);
	sfx_atomic_set(&ret->cmpl_flag, 0);
	ret->req = req;
	ret->sfx_dev = sfx_bd;

	return ret;
}

/**
 * @brief:   zero the range [start_lba, end_lba] of sfx_bio.
 *
 * @para[in] bio        :  a pointer to the structure bio
 * @para[in] start_lba  :  range start point (4k unit)
 * @para[in] end_lba    :  range ending point (4k unit)
 *
 * @retv: None
 */
void sfx_zero_set_bio_range(sfx_bio *bio, xt_u32 lba, xt_u32 start_lba, xt_u32 end_lba)
{
	unsigned long flags;
	sfx_bio_vec bvec;
	sfx_bvec_iter iter;
	xt_u32 off = sfx_bio_offset(bio);
	xt_u32 left_space = 0, lba_iter = 0;

	sfx_bio_for_each_segment(bvec, bio, iter)
	{
		if (lba >= start_lba && lba <= end_lba) {
			char *data = sfx_bvec_kmap_irq(bvec, &flags);
			xt_u32 reset_len = sfx_bveclen(bvec);

			if (left_space)
				sfx_memset(data, 0, left_space);
			if (lba_iter) {
				data = (char *)((xt_u64)data + off);
				reset_len -= off;
			}
			sfx_memset(data, 0, reset_len);
			flush_dcache_page(sfx_bvecpage(bvec));
			bvec_kunmap_irq(data, &flags);
			left_space = off;
		} else if (left_space) {
			char *data = sfx_bvec_kmap_irq(bvec, &flags);
			sfx_memset(data, 0, left_space);
			flush_dcache_page(sfx_bvecpage(bvec));
			bvec_kunmap_irq(data, &flags);
			break;
		}
		lba++;
		lba_iter++;
	}
}

#ifdef SFX_LINUX
static xt_u8 _get_iostat_index(struct sfx_request *sfx_req)
{
	xt_u8 mod_num = ((sfx_req->size) & ((1 << (SFX_PAGE_SHIFT - SECTOR_SHIFT)) - 1));
	xt_u8 div_num = (sfx_req->size >> (SFX_PAGE_SHIFT - SECTOR_SHIFT));

	if (unlikely(mod_num)) {
		if (div_num > 0)
			return IO_unalign;
		else
			return IO_SECS;
	} else {
		if (div_num == 1)
			return IO_4K;
		else if (div_num == 2)
			return IO_8K;
		else if (div_num == 3 || div_num == 4)
			return IO_16K;
		else if (div_num > 4 && div_num <= 8)
			return IO_32K;
		else if (div_num > 8 && div_num <= 16)
			return IO_64K;
		else if (div_num > 16 && div_num <= 64)
			return IO_256K;
		else
			return IO_LARGE;
	}
}
static void sfx_req_log(sfx_mul_drv *sfx_mdrv, struct sfx_request *sfx_req, xt_u32 lat, xt_u32 smt_lat,
			xt_u32 ccs_lat)
{
	blk_io_log_ctx *log_ctx = &sfx_mdrv->io_log_ctx;
	io_log_entry *log_entry;
	unsigned long flags = 0;
	sfx_spin_lock_irqsave(&log_ctx->io_log_lock, flags);
	log_ctx->tot_cmd++;
	if (log_ctx->inner_idx == NUM_LOG_ENTRY_PER_BUF - 1) {
		log_ctx->inner_idx = 0;
		if (log_ctx->buf_idx == NUM_LOG_BUF - 1) {
			log_ctx->buf_idx = 0;
		} else {
			log_ctx->buf_idx++;
		}
	} else {
		log_ctx->inner_idx++;
	}
	log_entry = (void *)(((xt_u64 *)log_ctx->log_buf)[log_ctx->buf_idx]);
	log_entry[log_ctx->inner_idx].ts = sfx_ktime_to_ns(sfx_ktime_get());
	log_entry[log_ctx->inner_idx].start_sec = sfx_bsec(sfx_req->req->bio);
	log_entry[log_ctx->inner_idx].len_sec = sfx_bsz(sfx_req->req->bio);
	log_entry[log_ctx->inner_idx].type = sfx_req->req_type;
	log_entry[log_ctx->inner_idx].unaligned = sfx_req->is_unalign;
	log_entry[log_ctx->inner_idx].blk_coh_block = sfx_req->is_coh_block;
	log_entry[log_ctx->inner_idx].lat = (xt_u32)lat;
	log_entry[log_ctx->inner_idx].blk_smt_lat = (xt_u32)smt_lat;
	log_entry[log_ctx->inner_idx].ccs_lat = (xt_u32)ccs_lat;
	sfx_spin_unlock_irqrestore(&log_ctx->io_log_lock, flags);
}

static inline xt_u32 sfx_io_latency_update(sfx_mul_drv *sfx_mdrv, struct sfx_request *sfx_req)
{
	io_latency_management_t *latency_mgt;
	io_latency_statistics_t *latency_stats;
	io_latency_bucket_t *bucket_head;
	sfx_atomic_t *bucket;
	xt_u32 bucket_index = 0;
	xt_u64 latency_time, start_time = 0, end_time = 0;
	xt_u32 latency_count = 0;
	xt_u16 cpu_id = sfx_get_cpuid();

	// Check if a valid parameter passed in
	if ((NULL == sfx_mdrv) || (NULL == sfx_req)) {
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_WRN,
			  "LATENCY: %s(cpu=%02d): invalid parameters, "
			  "sfx_mdrv=%p, sfx_req=%p \n",
			  __FUNCTION__, cpu_id, sfx_mdrv, sfx_req);

		return latency_count;
	}

	// Update IO Latency statistics requested
	// by apps $> nvme sfx lat-stats /dev/sfd0n1
	// time unit for lat is us
	latency_mgt = &sfx_mdrv->ftl_mq_ctx->latency_mgt;
	if ((NULL != latency_mgt) && (1 == latency_mgt->lat_info_valid)) {
		latency_stats = latency_mgt->latency_stats;

		// Get Current I/O Latency
		end_time = sfx_ktime_to_us(sfx_ktime_get());
		start_time = sfx_ktime_to_us(sfx_req->init_time);
		if (end_time >= start_time) {
			latency_time = end_time - start_time;
		} else {
			latency_time = INVALID_64BIT - start_time + end_time;
		}

		switch (sfx_req->req_type) {
		case SFX_READ_REQ: {
			sfx_mdrv->ftl_mq_ctx->ftl_ctx.ftl_moniter.host_read_latency = latency_time;

			if (1 != latency_mgt->lat_info_read) {
				return latency_count;
			}
			bucket_head = &latency_stats->latency_read;
		} break;

		case SFX_WRITE_REQ: {
			sfx_mdrv->ftl_mq_ctx->ftl_ctx.ftl_moniter.host_write_latency = latency_time;

			if (1 != latency_mgt->lat_info_write) {
				return latency_count;
			}
			bucket_head = &latency_stats->latency_write;
		} break;

		case SFX_DISCARD_REQ:
		default:
			// nothing to do
			return latency_count;
		}

		// Get group_id based on defined io_latency_group_t
		if ((latency_time >> 10) < 1) { /* 0~1ms */
			bucket = bucket_head->bucket_1;
			bucket_index = latency_time >> 5;
		} else if ((latency_time >> 10) < 32) { /* 1~32ms */
			bucket = bucket_head->bucket_2;
			bucket_index = (latency_time >> 10) - 1;
		} else if ((latency_time >> 20) < 1) { /* 32ms~1s */
			bucket = bucket_head->bucket_3;
			bucket_index = (latency_time >> 15) - 1;
		} else if ((latency_time >> 21) < 1) { /* 1s~2s */
			bucket = bucket_head->bucket_4;
		} else if ((latency_time >> 22) < 1) { /* 2~4s */
			bucket = bucket_head->bucket_5;
		} else { /* 4s+ */
			bucket = bucket_head->bucket_6;
		}

		latency_count = sfx_atomic_inc_return(&(bucket[bucket_index]));
	}

	return latency_count;
}

static inline void sfx_io_statistic_func(sfx_mul_drv *sfx_mdrv, struct sfx_request *sfx_req,
					 blk_io_stat *io_stat, xt_u32 thrd)
{
	xt_u32 idx;
	xt_64 lat = sfx_ktime_to_us(sfx_ktime_get()) - sfx_ktime_to_us(sfx_req->init_time);
	xt_64 smt_lat = sfx_ktime_to_us(sfx_req->sub_time) - sfx_ktime_to_us(sfx_req->init_time);
	xt_64 ccs_lat = sfx_ktime_to_us(sfx_req->rtn_time) - sfx_ktime_to_us(sfx_req->sub_time);

	idx = _get_iostat_index(sfx_req);
	add_per_cpu64(io_stat[idx].tot_num, 1);
	if (lat > 0)
		add_per_cpu64(io_stat[idx].tot_lat, lat);
	if (smt_lat > 0)
		add_per_cpu64(io_stat[idx].tot_smt, smt_lat);
	if (ccs_lat > 0)
		add_per_cpu64(io_stat[idx].tot_ccs, ccs_lat);
	if (lat > 2000) {
		if (lat > 8000) {
			add_per_cpu64(io_stat[idx].num_8ms, 1);
		} else if (lat > 2000) {
			add_per_cpu64(io_stat[idx].num_2ms, 1);
		}
		if (lat > thrd) {
			if (sfx_mdrv->en_outlier_print) {
				sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN,
					  "Outlier request %s: "
					  "tot_lat: %u us, blk_smt %u us, ccs_lat %u us, num_outlier %u\n",
					  ((sfx_req->req_type == SFX_WRITE_REQ) ? "write" : "read"), lat,
					  smt_lat, ccs_lat, sfx_mdrv->num_outlier);
				sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN,
					  "BIO: sector %x, len (sec) %x, %s\n", sfx_bsec(sfx_req->req->bio),
					  (sfx_bsz(sfx_req->req->bio) >> SECTOR_SHIFT),
					  (sfx_req->is_unalign ? "unalign_bio" : "align_bio"));
				sfx_print(
					sfx_mdrv->devId, BLK_REQ, PL_WRN,
					"Req ts: init %llu, "
					"coh_init %llu, coh_active %llu, coh_release %llu, coh_block %u blk_smt %llu "
					"ccs_rtn %llu, blk_cmpl %llu, req_cmpl %llu\n",
					sfx_ktime_to_us(sfx_req->init_time),
					sfx_ktime_to_us(sfx_req->coh_init_time),
					sfx_ktime_to_us(sfx_req->coh_active_time),
					sfx_ktime_to_us(sfx_req->coh_release_time), sfx_req->is_coh_block,
					sfx_ktime_to_us(sfx_req->sub_time),
					sfx_ktime_to_us(sfx_req->rtn_time),
					sfx_ktime_to_us(sfx_req->finish_time),
					sfx_ktime_to_us(sfx_ktime_get()));
			}
		}
	}

	if (smt_lat > 8000) {
		add_per_cpu64(io_stat[idx].num_smt_8ms, 1);
	} else if (smt_lat > 1000) {
		add_per_cpu64(io_stat[idx].num_smt_1ms, 1);
	}

	if (ccs_lat > 8000) {
		add_per_cpu64(io_stat[idx].num_ccs_8ms, 1);
	} else if (ccs_lat > 1000) {
		add_per_cpu64(io_stat[idx].num_ccs_1ms, 1);
	}
	if (sfx_mdrv->en_req_log) {
		sfx_req_log(sfx_mdrv, sfx_req, lat, smt_lat, ccs_lat);
	}
	if ((lat > thrd) && (sfx_req->req_type == SFX_READ_REQ) &&
	    ((sfx_bsz(sfx_req->req->bio) >> SECTOR_SHIFT) == 8)) {
		sfx_mdrv->num_outlier++;
		if (sfx_mdrv->num_outlier >= 10) {
			sfx_mdrv->en_req_log = 0;
		}
	}
	return;
}
#endif
void sfx_bio_end_request_free_req(sfx_mul_drv *sfx_mdrv, struct sfx_request *sfx_req, xt_u32 end_req,
				  xt_u32 free_res)
{
#ifdef SFX_LINUX
	// Out of en_sts control due to requirement
	sfx_io_latency_update(sfx_mdrv, sfx_req);

	if (sfx_mdrv->en_sts) {
		xt_u32 wr_thrd = sfx_mdrv->wr_outlier_thrd * 1000;
		xt_u32 rd_thrd = sfx_mdrv->rd_outlier_thrd * 1000;
		if (sfx_req->req_type == SFX_READ_REQ) {
			sfx_io_statistic_func(sfx_mdrv, sfx_req, sfx_mdrv->rd_io_stat, rd_thrd);
		} else if (sfx_req->req_type == SFX_WRITE_REQ) {
			sfx_io_statistic_func(sfx_mdrv, sfx_req, sfx_mdrv->wr_io_stat, wr_thrd);
		}
	}
#endif
	if (end_req) {
#ifndef SFX_LINUX //ticket 2088
		if (!sfx_is_discard_request(sfx_req->req)) {
			xt_u32 io_type = sfx_is_write_request(sfx_req->req) ? SFX_WRITE : SFX_READ;
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_DBG, "outstanding read %d write %d\n",
				  sfx_atomic_read(&(sfx_mdrv->ftl_mq_ctx->hot_rd_pending)),
				  sfx_atomic_read(&(sfx_mdrv->ftl_mq_ctx->hot_wr_pending)));
			if (io_type == SFX_WRITE) {
				sfx_atomic_sub(sfx_req->pre_rw_cnt, &(sfx_mdrv->ftl_mq_ctx->hot_wr_pending));
				if (sfx_req->pre_read_rmw) {
					sfx_atomic_sub(sfx_req->pre_read_rmw,
						       &(sfx_mdrv->ftl_mq_ctx->hot_rd_pending));
				}
			} else {
				sfx_atomic_sub(sfx_req->pre_rw_cnt, &(sfx_mdrv->ftl_mq_ctx->hot_rd_pending));
			}
		}

#endif
		if (sfx_req->req_type != SFX_DISCARD_REQ) {
			sfx_atomic_sub(sfx_req->bvec_tot_len, &sfx_mdrv->outstanding_size);
		}
		sfx_blk_ftl_complete_request(sfx_mdrv, sfx_req->req, sfx_req->error, sfx_req->start);
	}
	if (free_res) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ)
		kmem_mfree(sfx_req);
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
		kmem_mfree(sfx_req->req);
		sfx_req->req = NULL;
		kmem_mfree(sfx_req);
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		if (sfx_req->req_type == SFX_DISCARD_REQ) {
			kmem_mfree(sfx_req);
		}
#endif
	}
}

void sfx_align_nodemask_to_numa_id(sfx_mul_drv *sfx_mdrv)
{
#if SFX_ALIGN_NODEMASK_TO_NUMA_ID
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32)
	if (INVALID_32BIT != sfx_mdrv->numa_id) {
		const sfx_cpumask_t *nodemask = sfx_cpumask_of_node(sfx_mdrv->numa_id);
		sfx_set_cpus_allowed_ptr(sfx_get_current(), (void *)nodemask);
		sfx_print(sfx_mdrv->devId, BLK_GC, PL_LOG, "%s: align to numa id %u\n", __FUNCTION__,
			  sfx_mdrv->numa_id);
	}
#endif
#endif
#endif
}

xt_u32 blk_ftl_cmpl_cmds(sfx_mul_drv *sfx_mdrv, xt_u32 cpuid, xt_u8 poll_type, int num_poll)
{
	xt_u32 qd, did_poll;
	xt_u16 qid;
	void *nvmeq;
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;

	//TODO:QI change to non-atomic?
	if (sfx_atomic_read(&sfx_mdrv->flag_dev_freeze) || sfx_atomic_read(&sfx_mdrv->surprising_remove)) {
		return 0;
	}

	if (POLLED_READ == poll_type) {
		qid = sfx_get_mq_ioqid(cpuid, sfx_mdrv->cpu2rdqid_map, 1, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	} else if (POLLED_WRITE == poll_type) {
		qid = sfx_get_mq_ioqid(cpuid, sfx_mdrv->cpu2wrqid_map, 0, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	} else if (POLLED_META == poll_type) {
		qid = sfx_mdrv->ioq_config.rdq_per_unit + HOT_RD_QID_BASE + 1;
	} else if (POLLED_MWR == poll_type) {
		qid = QID_MIX_WR;
	} else if (POLLED_MRD == poll_type) {
		qid = QID_MIX_RD;
	} else if (POLLED_ERS == poll_type) {
		qid = QID_ERASE;
	} else if (POLLED_WL == poll_type) {
		qid = QID_WL;
	} else if (POLLED_CPT == poll_type) {
		qid = QID_CHEPT;
	} else {
		return 0;
	}

	nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[qid].driver_qp;
	sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[qid].sfx_nvme_cmd_queue;
	if ((!(qd = sfx_atomic_read(&sfx_nvmeq->q_depth))) &&
	    ((POLLED_READ == poll_type) || (POLLED_WRITE == poll_type))) {
		return 0;
	}

	if (!nvmeq || !sfx_nvmeq) {
		sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_WRN,
			  "QUEUE pointer is "
			  "corrupted: driver nvmeq %p, sfx nvmeq %p!\n",
			  nvmeq, sfx_nvmeq);
		return 0;
	}

	sfx_atomic_inc(&sfx_mdrv->ftl_mq_ctx->osd_irq);
	did_poll = sfx_process_cq(nvmeq, 1, ((num_poll > 0) ? num_poll : 0));
	sfx_atomic_dec(&sfx_mdrv->ftl_mq_ctx->osd_irq);

	return did_poll;
}

void req_handle_perf_debug_enable(sfx_mul_drv *sfx_mdrv, xt_u32 val)
{
#if MEASURE_TIME
	sfx_mdrv->open_measure_time = val;
#endif
	sfx_mdrv->io_trace = val;
}

void interleave_max_read_slot(sfx_mul_drv *sfx_mdrv, xt_u8 val)
{
	sfx_mdrv->read_slot_interleave = val & 0x1;
	sfx_mdrv->max_read_per_die_strategy = (val >> 4) & 0x3;
	sfx_print(sfx_mdrv->devId, BLK_PERF, PL_INF,
		  "%s: read_slot_interleave %d, "
		  "max_read_per_die_strategy %d \n",
		  __FUNCTION__, sfx_mdrv->read_slot_interleave, sfx_mdrv->max_read_per_die_strategy);
}

void req_handle_perf_debug(sfx_mul_drv *sfx_mdrv)
{
#if MEASURE_TIME
	if (sfx_mdrv->open_measure_time) {
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request queue callback number %d\n",
			  sfx_atomic_read(&sfx_mdrv->req_call_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request handled number %d\n",
			  sfx_atomic64_read(&sfx_mdrv->req_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request process number %d\n",
			  sfx_atomic_read(&sfx_mdrv->req_proc_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request end number %d\n",
			  sfx_atomic_read(&sfx_mdrv->req_end_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request end linux number %d\n",
			  sfx_atomic_read(&sfx_mdrv->req_end_num_linux));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "bio callback number %d\n",
			  sfx_atomic_read(&sfx_mdrv->bio_callback_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Total "
			  "request handled in blk_ftl_coh number  %d\n",
			  sfx_atomic_read(&sfx_mdrv->req_handle_coh_num));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Maximum "
			  "request queue callback interval %llu ns\n",
			  sfx_atomic_read(&sfx_mdrv->req_time_max));
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
			  "request handler: Maximum "
			  "request handled time %llu ns\n",
			  sfx_atomic_read(&sfx_mdrv->req_handle_time_max));
		if (sfx_atomic_read(&sfx_mdrv->req_call_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average request queue callback interval %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->req_time) /
					  sfx_atomic_read(&sfx_mdrv->req_call_num));
		}
		if (sfx_atomic64_read(&sfx_mdrv->req_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average request handled time %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->req_handle_time) /
					  sfx_atomic64_read(&sfx_mdrv->req_num));
		}
		if (sfx_atomic_read(&sfx_mdrv->req_proc_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average request process time %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->req_proc_time) /
					  sfx_atomic_read(&sfx_mdrv->req_proc_num));
		}
		if (sfx_atomic_read(&sfx_mdrv->req_end_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average request end time %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->req_end_time) /
					  sfx_atomic_read(&sfx_mdrv->req_end_num));
		}
		if (sfx_atomic_read(&sfx_mdrv->bio_callback_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average bio callback  process time %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->bio_cb_time) /
					  sfx_atomic_read(&sfx_mdrv->bio_callback_num));
		}
		if (sfx_atomic_read(&sfx_mdrv->req_handle_coh_num)) {
			sfx_print(sfx_mdrv->devId, BLK_PERF, PL_DBG,
				  "request handler: "
				  "Average request handled in blk_ftl_coh time %d ns\n",
				  sfx_atomic_read(&sfx_mdrv->req_handle_coh_time) /
					  sfx_atomic_read(&sfx_mdrv->req_handle_coh_num));
		}

		sfx_atomic_set(&sfx_mdrv->req_call_num, 0);
		sfx_atomic64_set(&sfx_mdrv->req_num, 0);
		sfx_atomic_set(&sfx_mdrv->req_proc_num, 0);
		sfx_atomic_set(&sfx_mdrv->req_end_num, 0);
		sfx_atomic_set(&sfx_mdrv->req_end_num_linux, 0);
		sfx_atomic_set(&sfx_mdrv->req_time, 0);
		sfx_atomic_set(&sfx_mdrv->req_time_max, 0);
		sfx_atomic_set(&sfx_mdrv->req_handle_time, 0);
		sfx_atomic_set(&sfx_mdrv->req_handle_time_max, 0);
		sfx_atomic_set(&sfx_mdrv->req_proc_time, 0);
		sfx_atomic_set(&sfx_mdrv->req_end_time, 0);
		sfx_atomic_set(&sfx_mdrv->bio_cb_time, 0);
		sfx_atomic_set(&sfx_mdrv->bio_callback_num, 0);
		sfx_atomic_set(&sfx_mdrv->req_handle_coh_time, 0);
		sfx_atomic_set(&sfx_mdrv->req_handle_coh_num, 0);
	}
#endif
}

void sfx_blk_ftl_complete_and_free_req(sfx_mul_drv *sfx_mdrv, sfx_bio_request *req)
{
	xt_u64 start;
#ifdef SFX_LINUX
	start = jiffies;
#else
	start = 0;
#endif

	sfx_blk_ftl_complete_request(sfx_mdrv, req, 1, start);

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	sfx_mfree(req);
#endif
}

void blk_ftl_req_handler(sfx_bd_device *sfx_bd, sfx_bio_request *req, xt_u32 flag)
{
#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_ktime_t start_time = sfx_ktime_get();
#endif
	sfxError status;
	xt_u64 start = 0;

#if (SFX_BLK_QUEUE_TYPE != SFX_BLK_SQ_BIO)
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	//TODO:QI change to non-atomic?
	if (((sfx_rq_data_dir(req) == SFX_WRITE) && sfx_atomic_read(&sfx_mdrv->read_mode)) ||
	    sfx_atomic_read(&sfx_mdrv->flag_dev_freeze) || sfx_atomic_read(&sfx_mdrv->surprising_remove) ||
	    sfx_atomic_read(&sfx_mdrv->device_state) == SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS) {
#ifdef SFX_LINUX
		start = jiffies;
#endif
		sfx_blk_ftl_complete_request(sfx_bd->sfx_mdrv, req, 1, start);
		return;
	}
#endif

	status = blk_ftl_handle_req(sfx_bd, req, flag);
	if (status) {
		sfx_blk_ftl_complete_request(sfx_bd->sfx_mdrv, req, status, start);
	}

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_atomic64_add((sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(start_time)),
			 &sfx_mdrv->func_req_handle_lat);
#endif
}
#ifdef SFX_LINUX
static void pin_multi_job(xt_u32 dev_id)
{
	struct task_struct *p = sfx_get_current();
	if (g_cpu_map_mgm.cpu_pinning && g_cpu_map_mgm.app_pin && g_cpu_map_mgm.proc_map->filled &&
	    g_cpu_map_mgm.core_map->filled && sfx_cpumask_full(&p->cpus_allowed)) {
		sfx_cpumask_var_t mask;
		if (!sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
			return;
		}

		sfx_cgroup_config(dev_id, mask);
		sfx_set_cpus_allowed_ptr(p, mask);
		sfx_free_cpumask_var(mask);
	}
}
#endif

int sfx_req_generic_handler(void *device, void *gen_request, xt_u32 flag)
{
	sfx_bd_device *sfx_bd = (sfx_bd_device *)device;
	sfx_bio_request *rq = (sfx_bio_request *)gen_request;
#ifdef SFX_LINUX
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#endif
	xt_32 status = 0;
	xt_u32 is_rdq, cpuid;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
	sfx_ktime_t rec_time = sfx_ktime_get();
	xt_u32 qid;
#endif
#ifdef SFX_LINUX
	pin_multi_job(sfx_mdrv->devId);
#endif
	//TODO;QI get flag instead of check type directly
	//since later in the same function, we are going
	//to check the request flat again.
	is_rdq = (!(sfx_is_write_request(rq)));
	cpuid = sfx_get_cpuid();
	if (!sfx_irqs_disabled()) {
		sfx_local_irq_disable();
	}
	blk_ftl_req_handler(sfx_bd, rq, flag);

#if (HOT_READ_PERF || HOT_WRITE_PERF)
	if (is_rdq) {
		qid = sfx_get_mq_ioqid(sfx_get_cpuid(), sfx_mdrv->cpu2rdqid_map, 1, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	} else {
		qid = sfx_get_mq_ioqid(sfx_get_cpuid(), sfx_mdrv->cpu2wrqid_map, 0, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	}
	sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[qid].sfx_nvme_cmd_queue;
	sfx_nvmeq->hot_blk_req_end2end_proc += sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time);
	if (sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time) >= LONG_LAT_TARGET) {
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_INF,
			  "%s %d: Function blk_ftl_req_handler"
			  " takes too long %llu us\n",
			  __FUNCTION__, __LINE__,
			  (sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time)) / 1000);
	}
	if (sfx_nvmeq->blk_end2end_max < sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time)) {
		sfx_nvmeq->blk_end2end_max = sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time);
	}
#endif
#ifdef SFX_LINUX
	if (!sfx_single_thread_detection(sfx_mdrv)) {
		if (!sfx_is_discard_request(rq)) {
			if (is_rdq) {
				blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_READ, -1);
			} else {
				blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_WRITE, -1);
			}
		}
	}
#endif
	if (sfx_irqs_disabled()) {
		sfx_local_irq_enable();
	}
#if (HOT_READ_PERF || HOT_WRITE_PERF)
	sfx_nvmeq->hot_blk_req_end2end_proc += sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time);
	if (sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time) >= LONG_LAT_TARGET) {
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_INF,
			  "%s %d: Function blk_ftl_req_handler"
			  " takes too long %llu us\n",
			  __FUNCTION__, __LINE__,
			  (sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time)) / 1000);
	}
	if (sfx_nvmeq->blk_end2end_max < sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time)) {
		sfx_nvmeq->blk_end2end_max = sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(rec_time);
	}
#endif
	return status;
}

#if (HOT_READ_PERF || HOT_WRITE_PERF)
inline void sfx_blk_req_interval_lat_statistic(sfx_mul_drv *sfx_mdrv, sfx_bio_request *req)
{
	sfx_ktime_t stime = sfx_ktime_get();
	xt_u64 local_intval_time;
	xt_u32 qid, is_rdq;
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
	is_rdq = (!(sfx_is_write_request(req)));
	if (is_rdq) {
		qid = sfx_get_mq_ioqid(sfx_get_cpuid(), sfx_mdrv->cpu2rdqid_map, 1, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	} else {
		qid = sfx_get_mq_ioqid(sfx_get_cpuid(), sfx_mdrv->cpu2wrqid_map, 0, SFX_STREAM_ID,
				       &sfx_mdrv->ioq_config);
	}
	sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[qid].sfx_nvme_cmd_queue;
	if (!(sfx_is_write_request(req))) {
		if (!sfx_atomic64_read(&sfx_mdrv->hot_rd_req_intval)) {
			sfx_atomic64_set(&sfx_mdrv->last_req_time, sfx_ktime_to_ns(stime));
			sfx_atomic64_set(&sfx_mdrv->hot_rd_req_intval, 1);
		} else {
			local_intval_time =
				sfx_ktime_to_ns(stime) - sfx_atomic64_read(&sfx_mdrv->last_req_time);
			sfx_atomic64_add(local_intval_time, &sfx_mdrv->hot_rd_req_intval);
			if (sfx_atomic64_read(&sfx_mdrv->req_interval_max) < local_intval_time) {
				sfx_atomic64_set(&sfx_mdrv->req_interval_max, local_intval_time);
			}
		}
		sfx_nvmeq->num_rd_req++;
		sfx_nvmeq->tot_qd += sfx_atomic_read(&sfx_nvmeq->q_depth);
		sfx_atomic64_inc(&sfx_mdrv->num_rd_req);
	} else if (!sfx_is_discard_request(req)) {
		if (!sfx_atomic64_read(&sfx_mdrv->hot_wr_req_intval)) {
			sfx_atomic64_set(&sfx_mdrv->last_req_time, sfx_ktime_to_ns(stime));
			sfx_atomic64_set(&sfx_mdrv->hot_wr_req_intval, 1);
		} else {
			local_intval_time =
				sfx_ktime_to_ns(stime) - sfx_atomic64_read(&sfx_mdrv->last_req_time);
			sfx_atomic64_add(local_intval_time, &sfx_mdrv->hot_wr_req_intval);
			if (sfx_atomic64_read(&sfx_mdrv->req_interval_max) < local_intval_time) {
				sfx_atomic64_set(&sfx_mdrv->req_interval_max, local_intval_time);
			}
		}
		sfx_nvmeq->num_wr_req++;
		sfx_nvmeq->tot_qd += sfx_atomic_read(&sfx_nvmeq->q_depth);
		sfx_atomic64_inc(&sfx_mdrv->num_wr_req);
	}
}
#endif

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

#ifdef CENTOS7X_4_14_0_49_PATCH

blk_status_t sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(hctx->queue);
	sfx_bio_request *req;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#ifdef CONFIG_PREEMPT_COUNT
	xt_u32 prem_count;
#endif

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_ktime_t start_time, end_time;
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	start_time = sfx_ktime_get();
#endif

	req = bd->rq;
#ifdef CONFIG_PREEMPT_COUNT
	prem_count = sfx_preempt_count();
	if (prem_count) {
		sfx_kernel_put_cpu();
	}
#endif

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_blk_req_interval_lat_statistic(sfx_mdrv, req);
#endif
	if (sfx_is_write_request(req)) {
		while (sfx_atomic_read(
			&sfx_mdrv->is_eh_halt_for_sync)) { //halt here to wait blk ftl sync memid info
			sfx_usleep(10);
			printk("halt req handling, total pending :%x\n",
			       sfx_atomic_read(&sfx_mdrv->outstanding_size));
		}
		add_per_cpu64(sfx_mdrv->total_wr_cmds_rcvd_from_host_req, 1);
	}

	blk_mq_start_request(req);
	if (sfx_mdrv->goldimg_dev) {
		sfx_blk_ftl_complete_request(sfx_mdrv, req, 0, 0);
	} else {
		sfx_req_generic_handler((void *)sfx_bd, (void *)req, 0);
	}

#if HOT_READ_PERF || HOT_WRITE_PERF
	end_time = sfx_ktime_get();
	sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd);
	if (sfx_ktime_to_ns(end_time) - sfx_ktime_to_ns(start_time) > 100000) {
		sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd_100);
	}
	sfx_atomic64_set(&sfx_mdrv->last_req_time, sfx_ktime_to_ns(sfx_ktime_get()));
#endif
#ifdef CONFIG_PREEMPT_COUNT
	if (prem_count) {
		sfx_kernel_get_cpu();
	}
#endif

	return 0;
}

#else

#ifdef RHEL_RELEASE_CODE
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
		    const struct blk_mq_queue_data *bd) //same as sfx_bd_request in sq
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
blk_status_t sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
		    const struct blk_mq_queue_data *bd) //same as sfx_bd_request in sq
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, struct request *rq,
		    bool not_used_here) //same as sfx_bd_request in sq
#else
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx,
		    struct request *rq) //same as sfx_bd_request in sq
#endif
#endif
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(hctx->queue);
	sfx_bio_request *req;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#ifdef CONFIG_PREEMPT_COUNT
	xt_u32 prem_count;
#endif

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_ktime_t start_time, end_time;
	sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	start_time = sfx_ktime_get();
#endif
#ifndef RHEL_RELEASE_CODE
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 19, 0)
	req = rq;
#else
	req = bd->rq;
#endif
#else
	req = bd->rq;
#endif
#ifdef CONFIG_PREEMPT_COUNT
	prem_count = sfx_preempt_count();
	if (prem_count) {
		sfx_kernel_put_cpu();
	}
#endif

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_blk_req_interval_lat_statistic(sfx_mdrv, req);
#endif
	if (sfx_is_write_request(req)) {
		while (sfx_atomic_read(
			&sfx_mdrv->is_eh_halt_for_sync)) { //halt here to wait blk ftl sync memid info
			sfx_usleep(10);
		}
		add_per_cpu64(sfx_mdrv->total_wr_cmds_rcvd_from_host_req, 1);
	}

#ifdef RHEL_RELEASE_CODE
	blk_mq_start_request(bd->rq);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
	blk_mq_start_request(req);
#endif
#endif
	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
		sfx_blk_ftl_complete_request(sfx_mdrv, req, 0, 0);
	} else {
		sfx_req_generic_handler((void *)sfx_bd, (void *)req, 0);
	}

#if HOT_READ_PERF || HOT_WRITE_PERF
	end_time = sfx_ktime_get();
	sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd);
	if (sfx_ktime_to_ns(end_time) - sfx_ktime_to_ns(start_time) > 100000) {
		sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd_100);
	}
	sfx_atomic64_set(&sfx_mdrv->last_req_time, sfx_ktime_to_ns(sfx_ktime_get()));
#endif
#ifdef CONFIG_PREEMPT_COUNT
	if (prem_count) {
		sfx_kernel_get_cpu();
	}
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 13, 0)
	return BLK_MQ_RQ_QUEUE_OK;
#else
	return 0;
#endif
}

#endif // CENTOS7X_4_14_0_49_PATCH

int sfx_mq_init_hctx(struct blk_mq_hw_ctx *hctx, void *data, unsigned int hctx_idx)
{
#if ENABLE_VDEV
	sfv_device *vdev = data;
	sfx_bd_device *sfx_bd = vdev->sfx_bd;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#else
	sfx_mul_drv *sfx_mdrv = data;
#endif // ENABLE_VDEV
	sfx_mdrv->ftl_mq_ctx->drvg_ctx[hctx_idx].blk_ftl_ctx = sfx_mdrv;
	hctx->driver_data = &sfx_mdrv->ftl_mq_ctx->drvg_ctx[hctx_idx];
	sfx_mdrv->nr_queues++;

	return 0;
}

/* The comprehensive way to implement complete() hook
 * function requests to check the request's status,
 * and do appropriate error handle if in error status.
 */
void sfx_mq_complete_rq(sfx_bio_request *req)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 12, 0))
	// kernel version >= 4.12.0
	blk_mq_end_request(req, 0);
#else
#ifdef RHEL_RELEASE_CODE
	blk_mq_end_request(req, req->errors);
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0))
	// kernel version >= 3.18.0
	blk_mq_end_request(req, req->errors);
#else
	// kernel version < 3.18.0
	blk_mq_end_io(req, req->errors);
#endif
#endif
#endif // (LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0))
}

#ifdef SFX_LINUX
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
// Between 4.9.0 and 4.10.0, the blk_mq_map_queues() function was not exported by the kernel.
// So we have to borrowed it from the internal Linux 4.9.0 source file - <block/blk-mq-cpumap.c>
int sfxdriver_blk_mq_map_queues(struct blk_mq_tag_set *set)
{
	unsigned int *map = set->mq_map;
	unsigned int nr_queues = set->nr_hw_queues;
	const sfx_cpumask_t *online_mask = sfx_cpu_online_mask;
	unsigned int cpu_iter, nr_cpus, nr_uniq_cpus, queue, first_sibling;
	sfx_cpumask_var_t cpus;

	if (!sfx_alloc_cpumask_var(&cpus, GFP_ATOMIC)) {
		return SFX_ERR_ENOMEM; // -12
	}

	cpumask_clear(cpus);
	nr_cpus = nr_uniq_cpus = 0;
	for_each_cpu (cpu_iter, online_mask) {
		nr_cpus++;
		first_sibling = get_first_sibling(cpu_iter);
		if (!cpumask_test_cpu(first_sibling, cpus)) {
			nr_uniq_cpus++;
		}
		cpumask_set_cpu(cpu_iter, cpus);
	}

	queue = 0;
	sfx_for_each_possible_cpu(cpu_iter)
	{
		if (!cpumask_test_cpu(cpu_iter, online_mask)) {
			map[cpu_iter] = 0;
			continue;
		}
		/*
         * Easy case - we have equal or more hardware queues. Or
         * there are no thread siblings to take into account. Do
         * 1:1 if enough, or sequential mapping if less.
         */
		if (nr_queues >= nr_cpus || nr_cpus == nr_uniq_cpus) {
			map[cpu_iter] = cpu_to_queue_index(nr_cpus, nr_queues, cpu_iter);
			queue++;
			continue;
		}
		/*
         * Less then nr_cpus queues, and we have some number of
         * threads per cores. Map sibling threads to the same
         * queue.
         */
		first_sibling = get_first_sibling(cpu_iter);
		if (first_sibling == cpu_iter) {
			map[cpu_iter] = cpu_to_queue_index(nr_uniq_cpus, nr_queues, cpu_iter);
			queue++;
		} else {
			map[cpu_iter] = map[first_sibling];
		}
	}

	sfx_free_cpumask_var(cpus);
	return 0;
}
#endif
#endif // SFX_LINUX

#if ENABLE_VDEV
#else
static struct blk_mq_ops sfx_mq_ops = {
	.queue_rq = sfx_mq_queue_rq,
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 9, 0)
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7, 5)) && (LINUX_VERSION_CODE == KERNEL_VERSION(3, 10, 0))
	// Much trouble for Centos 7.5's trickery RH_KABI_REPLACE() macro
	{ .aux_ops = NULL },
#else
	.map_queue = blk_mq_map_queue,
#endif
#else
	.map_queue = blk_mq_map_queue,
#endif
#elif (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0))
	// Between 4.9.0 and 4.10.0, the blk_mq_map_queues() function was not exported by the kernel.
	// So we have to borrowed it from the internal Linux 4.9.0 source file - <block/blk-mq-cpumap.c>
	.map_queues = sfxdriver_blk_mq_map_queues,
#endif
	.init_hctx = sfx_mq_init_hctx,
	.complete = sfx_mq_complete_rq,
};
#endif // ENABLE_VDEV

#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

xt_u32 sfx_op_is_discard(sfx_bio *bio)
{
#ifdef SFX_LINUX

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 35)
	return (bio->bi_rw & SFX_REQ_DISCARD);
#else
	return (bio_rw_flagged(bio, BIO_RW_DISCARD));
#endif
#else
	return (bio_op(bio) == SFX_REQ_DISCARD);
#endif

#else

	return (bio->bi_rw & SFX_REQ_DISCARD);

#endif
}

xt_u32 sfx_is_discard_request(sfx_bio_request *req)
{
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	return req->cmd_flags & SFX_REQ_DISCARD;
#else
	return req_op(req) == SFX_REQ_DISCARD;
#endif
#else
	return (req->cmd_flags & SFX_REQ_DISCARD);
#endif
}

xt_u32 sfx_is_write_request(sfx_bio_request *req)
{
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	return req->cmd_flags & REQ_WRITE;
#else
	return req_op(req) == REQ_OP_WRITE;
#endif
#else
	return (req->cmd_flags & SFX_REQ_WRITE);
#endif
}

xt_u32 sfx_op_is_write(struct bio *bio)
{
#ifdef SFX_LINUX
	return (bio_data_dir(bio) == SFX_WRITE);
#else
	return (sfx_bio_rw(bio) == SFX_WRITE);
#endif
}

xt_u32 sfx_op_is_readahead(struct bio *bio)
{
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	// from 3.10.0 <linux/fs.h> LINE 2160
	// // return READ, READA, or WRITE
	// #define bio_rw(bio)			((bio)->bi_rw & (RW_MASK | RWA_MASK))
	return bio_rw(bio) == SFX_READA;
#else
	// from 4.8.0 <linux/fs.h> line 2485
	// static inline bool op_is_write(unsigned int op) { return op == REQ_OP_READ ? false : true; }
	// // return data direction, READ or WRITE
	// static inline int bio_data_dir(struct bio *bio) { return op_is_write(bio_op(bio)) ? WRITE : READ; }
	return (bio->bi_opf & REQ_RAHEAD);
#endif
#else
	return (sfx_bio_rw(bio) == SFX_READA);
#endif
}

void *sfx_get_qdata_from_sfx_req(struct sfx_request *sfx_req)
{
	return GET_SFX_BD_FROM_QUEUE(sfx_req->req->q);
}

sfx_request_queue *sfx_get_req_q_from_sfx_req(struct sfx_request *sfx_req)
{
	return sfx_req->req->q;
}

unsigned int sfx_get_cmd_flags_from_request(sfx_bio_request *req)
{
	return req->cmd_flags;
}

int sfx_mdrv_empty_query(void *ptr)
{
	sfx_mul_drv *sfx_mdrv = ptr;

	if (!ptr || ((xt_u64)ptr) == INVALID_64BIT) {
		sfx_print(-1, BLK_SYS, PL_WRN, "%s: Received invalid parameter %p\n", __FUNCTION__, ptr);
		return 0;
	}
	sfx_usleep(1000);

	if (sfx_atomic_read(&sfx_mdrv->se_in_progress)) {
		return 0;
	}

	if (sfx_atomic_read(&sfx_mdrv->flag_dev_freeze)) {
		sfx_usleep(10000);
		return 1;
	}

	return (sfx_atomic_read(&sfx_mdrv->outstanding_req) ? 0 : 1);
}

#ifndef SFX_LINUX
#define KBUILD_MODNAME "sfx_bd_dev"
#endif
struct sfx_driver sfx_bd_driver = {
	.name = KBUILD_MODNAME,
	.probe = sfx_bd_probe,
	.remove = sfx_mdrv_single_remove,
	.shutdown = sfx_mdrv_single_remove,
	.cmpl_cb = ccs_cmpl_driver_cb,
	.suspend = NULL,
	.resume = NULL,
	.err_handler = NULL,
	.dev_gone = sfx_mdrv_single_dev_gone,
	.empty_query = sfx_mdrv_empty_query,
	.check_osd_req = sfx_mdrv_check_osd_req,
};

/*
 * Function and variable to init/exit ccs devices
 */
#ifdef SFX_LINUX
int ccs_dev_init(void);
void ccs_dev_exit(void);
int ccs_per_dev_init(xt_u8 minor);
void ccs_per_dev_exit(xt_u8 minor);

static xt_u16 sfx_dev_name_to_ccs_dev_minor(const char *d_name)
{
	xt_u8 minor;
	char *numstr;

	numstr = (char *)d_name;
	while (*numstr) {
		if ('0' <= *numstr && *numstr <= '9')
			break;
		numstr++;
	}
	if (!*numstr)
		return ERROR_BAD_CCS_MINOR_NUMBER;
	if (kstrtou8(numstr, 0, &minor))
		return ERROR_BAD_CCS_MINOR_NUMBER;
	return (xt_u16)minor;
}
#endif

static int bd_ccs_dev_init(char *d_name)
{
	int ret = 0;

#ifdef SFX_LINUX
	xt_u16 minor;

	ccs_dev_init();

	minor = sfx_dev_name_to_ccs_dev_minor(d_name);
	if (minor == ERROR_BAD_CCS_MINOR_NUMBER || minor >= MAX_NR_DRIVE)
		return 1;
	ret = ccs_per_dev_init((xt_u8)minor);
#endif

	return ret;
}

/*
 * clean up ccs per dev
 */
static void bd_ccs_per_dev_exit(char *dev_name)
{
#ifdef SFX_LINUX
	ccs_per_dev_exit(sfx_dev_name_to_ccs_dev_minor(dev_name));
#endif
}

/*
 * ccs per dev has been removed before calling this function. clean up the remaining ccs dev base structures
 */
static void bd_ccs_dev_exit(void)
{
#ifdef SFX_LINUX
	ccs_dev_exit();
#endif
}

int _quit_priv_thread(sfx_mul_drv *sfx_mdrv)
{
	xt_u32 i;
	while (!sfx_atomic_read(&sfx_mdrv->assert_handled)) {
		if (sfx_atomic_read(&sfx_mdrv->surprising_remove))
			break;
		sfx_schedule();
	}
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "Remove blk_ftl in freeze case\n");
	blk_ftl_cleanup_priv_thrd(sfx_mdrv);
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "block FTL callback thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_cb_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_cb_thread.state));
	for (i = 0; i < sfx_mdrv->coh_thd_num; i++) {
		struct sfx_blk_ftl_thread *coh_thd = sfx_mdrv->priv_thrds.blk_ftl_coh_thread[i];
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "coh thread %d stat %s[%u]\n", i,
			  current_thread_state(sfx_atomic_read(&coh_thd->state)),
			  sfx_atomic_read(&coh_thd->state));
	}
	sfx_print(
		sfx_mdrv->devId, BLK_SYS, PL_INF, "err handle thread stat %s[%u]\n",
		current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_err_handle_thread.state)),
		sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_err_handle_thread.state));
	sfx_print(
		sfx_mdrv->devId, BLK_SYS, PL_INF, "read distb thread stat %s[%u]\n",
		current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_read_distb_thread.state)),
		sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_read_distb_thread.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "throttle thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_throttle_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_throttle_thread.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "gc write thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.gc_write_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.gc_write_thread.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "gc read thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.gc_read_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.gc_read_thread.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "g_mim thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.g_mim_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.g_mim_thread.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "rebuild thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.g_map_thread1.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.g_map_thread1.state));
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "map log error handle thread stat %s[%u]\n",
		  current_thread_state(sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_maplog_eh_thread.state)),
		  sfx_atomic_read(&sfx_mdrv->priv_thrds.blk_ftl_maplog_eh_thread.state));
	if (sfx_mdrv->map) {
		release_flat_map(sfx_mdrv->map, sfx_mdrv);
		sfx_mdrv->map = NULL;
	}
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "free map\n");
	DestroyTable();
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "Release CCS\n");
	return -EIO;
}

static int sfx_alloc_nvmeioq(sfx_mul_drv *sfx_mdrv, struct sfx_driver_nvmeq_ctx *qctx)
{
	ftl_mq_ctx *ftl_cntx;
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
	sfx_app_queue *sfx_appq;

	ftl_cntx = sfx_mdrv->ftl_mq_ctx;
	ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue = sfx_nvmeq =
		sfx_kzalloc_node0(sizeof(SFX_NVME_CMD_QUEUE_STRUCT), SFX_GFP_NOIO, qctx->numa_node);
	if (!sfx_nvmeq) {
		return 1;
	}
	ftl_cntx->drvg_ctx[qctx->qid].sfx_app_queue = sfx_appq =
		sfx_kzalloc_node0(sizeof(sfx_app_queue), SFX_GFP_NOIO, qctx->numa_node);
	if (!sfx_appq) {
		sfx_kfree(sfx_nvmeq);
		ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue = NULL;
		return 1;
	}
	ll_init(&sfx_nvmeq->nvme_ll, sfx_nvmeq->nvme_que, sfx_nvmeq->nvme_elem, HOT_IO_QD, 2);
	sfx_memset(sfx_nvmeq->meta_flag, 0, sizeof(xt_u32) * (HOT_META_FLAG_SIZE));
	sfx_memset(sfx_nvmeq->barrier_cnt, 0, sizeof(sfx_nvmeq->barrier_cnt));
	sfx_memset(sfx_nvmeq->barrier_set, 0, sizeof(sfx_nvmeq->barrier_set));
	sfx_atomic_set(&sfx_nvmeq->barrier_idx, 0);
	sfx_atomic_set(&sfx_nvmeq->barrier_otd, 0);
	sfx_nvmeq->curr_mid = INVALID_32BIT;
	ll_init(&sfx_appq->appq_ll, sfx_appq->appq_que, sfx_appq->appq_elem, HOT_IO_QD, 2);
	sfx_spin_lock_init(&sfx_nvmeq->q_lock);
	sfx_spin_lock_init(&sfx_nvmeq->nvme_submit_lock);
	sfx_spin_lock_init(&sfx_appq->q_lock);
	sfx_spin_lock_init(&ftl_cntx->drvg_ctx[qctx->qid].lock);
	sfx_nvmeq->nvme_pending_commands[PENDING_TAIL] = 0;
	sfx_nvmeq->msix_mask = MSIX_VECTOR_BIT_BASK_BASE + (qctx->qid << 4);
	sfx_appq->appq_pending_commands[PENDING_TAIL] = 0;
	sfx_atomic_set(&sfx_nvmeq->q_depth, 0);
	sfx_atomic64_set(&sfx_nvmeq->num_smt, 0);
	sfx_atomic64_set(&sfx_nvmeq->num_polled, 0);
#if MQ_CONFIG_DEBUG
	sfx_print(-1, BLK_SYS, PL_INF,
		  "SFX BLOCK DEV: Allocate sfx-nvme-cmdq=%p appq=%p for qid=%u with "
		  "msix vector mask %u\n",
		  ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue,
		  ftl_cntx->drvg_ctx[qctx->qid].sfx_app_queue, qctx->qid, sfx_nvmeq->msix_mask);
#endif
	return 0;
}

int sfx_bd_mq_resource_release(sfx_mul_drv *sfx_mdrv)
{
	sfx_destroy_spinlock(&sfx_mdrv->ftl_mq_ctx->mask_lock);
	sfx_destroy_spinlock(&sfx_mdrv->poll_lock);
	sfx_kfree(sfx_mdrv->cpu2wrqid_map);
	sfx_kfree(sfx_mdrv->cpu2rdqid_map);

	// Free I/O Latency allocated resource and Reset control flags
	if (1 == sfx_mdrv->ftl_mq_ctx->latency_mgt.lat_info_valid) {
		sfx_kfree(sfx_mdrv->ftl_mq_ctx->latency_mgt.latency_stats);
	}
	sfx_mdrv->ftl_mq_ctx->latency_mgt.latency_control = 0;

	return 0;
}

#ifdef SFX_LINUX
static int _sfx_if_shift_irq_affi(sfx_mul_drv *sfx_mdrv)
{
#ifdef SFX_LINUX
	xt_u32 shifted_irq_affi;
	if ((sfx_mdrv->ioq_config.num_stream == 1) &&
	    ((sfx_mdrv->ioq_config.rdq_per_unit + sfx_mdrv->ioq_config.wrq_per_stream) <
	     (TOT_QUEUE - NON_IO_QUEUE - QID_OFF_WR_BASE)) &&
	    (sfx_mdrv->numa_id != INVALID_32BIT) && (sfx_num_online_nodes() <= SFX_SHIFT_IRQ_AFFI_MAX_NODE) &&
	    (sfx_num_online_cpus() <= SFX_SHIFT_IRQ_AFFI_MAX_CPUS) &&
	    sfx_num_online_cpus() >= SFX_SHIFT_IRQ_AFFI_MIN_CPUS) {
		shifted_irq_affi = 1;
	} else {
		shifted_irq_affi = 0;
	}
	return shifted_irq_affi;
#else
	return 0;
#endif
}

static int _sfx_separete_cpus2numa(sfx_mul_drv *sfx_mdrv, xt_u32 **numa_array, xt_u32 *shift_off_affi)
{
#ifdef SFX_LINUX
	xt_u32 node_iter;
	xt_u32 num_cpu_node[SFX_SHIFT_IRQ_AFFI_MAX_NODE] = { 0 };
	xt_u32 *num_cpu, num_cpu_per_node;

	/* Initialize cpus for numa_array for each numa node */
	for (node_iter = 0; node_iter < sfx_num_online_nodes(); node_iter++) {
		struct cpumask *nodemask = (struct cpumask *)sfx_cpumask_of_node(node_iter);
		xt_u32 cpu_idx = 0, cpu = 0;

		if (node_iter == 0) {
			num_cpu = &num_cpu_node[node_iter];
		} else {
			num_cpu = &num_cpu_node[node_iter];
		}

		for_each_cpu (cpu, nodemask) {
			numa_array[node_iter][cpu_idx++] = cpu;
			(*num_cpu)++;
#if MQ_CONFIG_DEBUG
			sfx_print(-1, BLK_SYS, PL_INF,
				  "%s %d: node %u contains "
				  "cpu %u idx %u tot cpu %u\n",
				  __FUNCTION__, __LINE__, node_iter, cpu, cpu_idx, (*num_cpu));
#endif
		}
	}
#if MQ_CONFIG_DEBUG
	for (node_iter = 0; node_iter < sfx_num_online_nodes(); node_iter++) {
		xt_u32 cpu_iter = 0;
		num_cpu = &num_cpu_node[node_iter];
		sfx_print(-1, BLK_SYS, PL_INF, "%s %d: node %u has %u cpus\n", __FUNCTION__, __LINE__,
			  node_iter, *num_cpu);
		for (; cpu_iter < *num_cpu; cpu_iter++) {
			sfx_print(-1, BLK_SYS, PL_INF, "%s %d: node %u contains cpu %u\n", __FUNCTION__,
				  __LINE__, node_iter, numa_array[node_iter][cpu_iter]);
		}
	}
#endif
	/* Check and handle inbalance numa setting
       Currently only handle the case of cpu 0 is not included in numa 0
    */
	num_cpu_per_node = num_cpu_node[0];
	if (sfx_num_online_nodes() > 1) {
		for (node_iter = 0; node_iter < sfx_num_online_nodes() - 1; node_iter++) {
			if (num_cpu_per_node != num_cpu_node[node_iter + 1]) {
				if ((node_iter == 0) &&
				    (num_cpu_per_node = num_cpu_node[node_iter + 1] - 1)) {
					// cpu 0 is not included in numa 0
				} else {
					return 1; //cannot handle inbalance numa case
				}
			}
			num_cpu_per_node = num_cpu_node[node_iter + 1];
		}
	}

	/*Calculate the global shifted offset for irq affinity*/
	if (sfx_num_online_nodes() > 1) {
		if ((num_cpu_node[0] == num_cpu_node[1]) && !(num_cpu_node[0] % 4)) {
			*shift_off_affi = num_cpu_node[0] / 4;
		} else if ((num_cpu_node[0] == num_cpu_node[1] - 1) &&
			   !(num_cpu_node[1] % 4)) { // cpu 0 is not included in numa 0
			*shift_off_affi = num_cpu_node[1] / 4;
		} else {
			return 1;
		}
	} else {
		if (num_cpu_node[0] > 0 && !(num_cpu_node[0] % 4)) {
			*shift_off_affi = num_cpu_node[0] / 4;
		} else {
			return 1;
		}
	}
	return 0;
#else
	return 1;
#endif
}
#endif

#ifdef SFX_LINUX
static void set_nonio_q_irq_mask(xt_u32 dev_id, xt_u32 q_type, sfx_cpumask_var_t cpumask)
{
	if (g_cpu_map_mgm.cpu_pinning && g_cpu_map_mgm.proc_map->filled && g_cpu_map_mgm.core_map->filled) {
		struct sfx_phys_proc_map *phys_proc_map;
		xt_u16 proc_idx, proc_off;
		xt_u32 core_id;
		xt_u16 i;

		//get cgroup position for card number dev_id
		if (sfx_get_proc_pos(dev_id, &proc_idx, &proc_off)) {
			return;
		}
		phys_proc_map =
			(struct sfx_phys_proc_map *)((xt_u8 *)(&g_cpu_map_mgm.proc_map->phys_proc_map) +
						     g_cpu_map_mgm.proc_map->proc_map_size * proc_idx);
		sfx_cgroup_config(dev_id, cpumask);
		switch (q_type) {
		case SFX_MIXED_WRQ:
		case SFX_MIXED_RDQ:
			i = (q_type == SFX_MIXED_WRQ) ? GC_WR_THD : GC_RD_THD;
			core_id = phys_proc_map->cores[proc_off + i];
			sfx_cpumask_clear(cpumask);
			sfx_set_core_mask(core_id, cpumask);
			break;
		default:
			break;
		}
	}
}
#endif
static int sfx_nonioq_allocation(sfx_mul_drv *sfx_mdrv)
{
	struct sfx_driver_nvmeq_ctx init_ctx;
	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;
	xt_u16 qid_iter, qrsvd;
	void *nvmeq = NULL;
	sfx_cpumask_var_t mask;

	if (!sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
		return SFX_ERR_ENOMEM;
	}

	for (qid_iter = 0; qid_iter < NON_IO_QUEUE; qid_iter++) {
		sfx_memset(&init_ctx, 0, sizeof(struct sfx_driver_nvmeq_ctx));
		qrsvd = (qid_iter < SFX_DRIVER_PREALLOC_QUEUE);
		init_ctx.qid = qid_iter;
		init_ctx.cpumask = mask;
#ifdef SFX_LINUX
		sfx_cpumask_copy(mask, (struct cpumask *)sfx_cpu_online_mask);
#endif
		init_ctx.queue_type = sfx_get_queue_type(init_ctx.qid);
		if (init_ctx.queue_type == SFX_INVALIDQ) {
			sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device queue (id=%u) assignment failure!\n",
				  init_ctx.qid);
			return 1;
		}
		if (QID_MIX_WR == init_ctx.qid) {
			init_ctx.stream_id = STREAM_ID_MIX_WR;
		} else if (QID_WL == init_ctx.qid) {
			init_ctx.stream_id = STREAM_ID_WL;
		} else if (QID_CHEPT == init_ctx.qid) {
			init_ctx.stream_id = STREAM_ID_COLD_CHEPT;
		} else if (QID_MIX_RD == init_ctx.qid) {
			init_ctx.stream_id = MAX_STREAM_SUPPORT;
		}
#ifdef SFX_LINUX
		set_nonio_q_irq_mask(sfx_mdrv->devId, init_ctx.queue_type, init_ctx.cpumask);
#endif

		if (!qrsvd) {
			nvmeq = sfx_alloc_nvmeq(ftl_cntx->driver_handle, &init_ctx, ccs_cmpl_driver_cb);
			if (!nvmeq) {
				sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device failed to init nvmeq\n");
				return 1;
			}
		}

		ftl_cntx->drvg_ctx[qid_iter].blk_ftl_ctx = sfx_mdrv;
		ftl_cntx->drvg_ctx[qid_iter].driver_qp = nvmeq;
		ftl_cntx->drvg_ctx[qid_iter].cpumask = init_ctx.cpumask;
		ftl_cntx->drvg_ctx[qid_iter].stream_id = init_ctx.stream_id;
		ftl_cntx->drvg_ctx[qid_iter].queue_type = init_ctx.queue_type;
		if (sfx_alloc_nvmeioq(sfx_mdrv, &init_ctx)) {
			sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device failed to init io nvmeq\n");
			return 1;
		}
#if MQ_CONFIG_DEBUG
		sfx_print(-1, BLK_SYS, PL_INF,
			  "SFX block device allocates non-io qid=%u reserved=%s, "
			  "nvmeq=%p, q_type=%u, stream_id=%u\n",
			  qid_iter, qrsvd ? "Yes" : "No", ftl_cntx->drvg_ctx[qid_iter].driver_qp,
			  init_ctx.queue_type, init_ctx.stream_id);
#endif
	}

	sfx_free_cpumask_var(mask);
	ftl_cntx->next_available_qid = qid_iter;
	return 0;
}

static int sfx_hot_ioq_allocation(sfx_mul_drv *sfx_mdrv, xt_u16 qid_start)
{
	struct sfx_driver_nvmeq_ctx init_ctx;
	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;
	xt_u16 qid_iter = 0, stream_iter;
	xt_u16 num_wrq_stream, num_stream, num_queue_stream;
	xt_u16 qid_start_stream, qid_end_stream, rd_ioq, queue_type, qid_offset;
	sfx_cpumask_ptr *cpumask_per_stream;
	void *nvmeq;
#ifdef SFX_LINUX
	xt_u32 *numa_array[SFX_SHIFT_IRQ_AFFI_MAX_NODE];
	xt_u32 shifted_irq_affi = 0, shift_off_affi = 0;
	sfx_cpumask_var_t f_cpumask;
	if (!alloc_cpumask_var(&f_cpumask, SFX_GFP_NOIO)) {
		return 1;
	}
	sfx_cpumask_copy(f_cpumask, (struct cpumask *)sfx_cpu_online_mask);
#endif
	if (qid_start == HOT_RD_QID_BASE) {
		// allocate hot read queue
		rd_ioq = 1;
		num_stream = sfx_mdrv->ioq_config.isolation ? sfx_mdrv->ioq_config.num_stream : 1;
		num_queue_stream = sfx_mdrv->ioq_config.rdq_per_unit;
		cpumask_per_stream = ftl_cntx->rdq_cpumask_perunit;
		queue_type = SFX_HOT_RDQ;
#ifdef SFX_LINUX
		shifted_irq_affi = _sfx_if_shift_irq_affi(sfx_mdrv);
		if (shifted_irq_affi) {
			xt_u32 iter_node, tot_node;
			tot_node = sfx_num_online_nodes();
			for (iter_node = 0; iter_node < tot_node; iter_node++) {
				numa_array[iter_node] = sfx_malloc(sizeof(xt_u32) * 1024);
			}
			if (_sfx_separete_cpus2numa(sfx_mdrv, numa_array, &shift_off_affi)) {
				shifted_irq_affi = 0;
				for (iter_node = 0; iter_node < tot_node; iter_node++) {
					sfx_mfree(numa_array[iter_node]);
				}
			} else {
#if MQ_CONFIG_DEBUG
				xt_u32 sub_cpu_iter = 0, sub_node_iter;
				xt_u32 sub_num_cpu = sfx_num_online_cpus() / sfx_num_online_nodes();
				for (sub_node_iter = 0; sub_node_iter < sfx_num_online_nodes();
				     sub_node_iter++) {
					for (sub_cpu_iter = 0; sub_cpu_iter < sub_num_cpu; sub_cpu_iter++) {
						sfx_print(-1, BLK_SYS, PL_INF,
							  "%s %d: node %u contains cpu %u, shift off %u\n",
							  __FUNCTION__, __LINE__, sub_node_iter,
							  numa_array[sub_node_iter][sub_cpu_iter],
							  shift_off_affi);
					}
				}
#endif
			}
		}
#endif
	} else {
		rd_ioq = 0;
		num_stream = sfx_mdrv->ioq_config.num_stream;
		num_wrq_stream = sfx_mdrv->ioq_config.wrq_per_stream;
		num_queue_stream = QID_OFF_WR_BASE + num_wrq_stream;
		cpumask_per_stream = ftl_cntx->wrq_cpumask_perstream;
	}

#if MQ_CONFIG_DEBUG
	sfx_print(-1, BLK_SYS, PL_INF,
		  "DEBUG: SFX block device allocate %s hot-io queue num_stream=%u "
		  "num_queue_stream=%u\n",
		  rd_ioq ? "read" : "write", num_stream, num_queue_stream);
#endif

	qid_start_stream = qid_start;
	for (stream_iter = 0; stream_iter < num_stream; stream_iter++) {
		qid_offset = 0;
		qid_end_stream = qid_start_stream + num_queue_stream;

#if MQ_CONFIG_DEBUG
		sfx_print(-1, BLK_SYS, PL_INF, "DEBUG: stream_id=%u qid_start=%u qid_end=%u\n", stream_iter,
			  qid_start_stream, qid_end_stream);
#endif

		for (qid_iter = qid_start_stream; qid_iter < qid_end_stream; qid_iter++, qid_offset++) {
			sfx_memset(&init_ctx, 0, sizeof(struct sfx_driver_nvmeq_ctx));
			init_ctx.qid = qid_iter;

			if (rd_ioq) {
				xt_u32 cpumask_off;
				init_ctx.queue_type = queue_type;
#ifdef SFX_LINUX
				if (shifted_irq_affi) { //qid_offset in rdq is cpu_index
					xt_u32 node_idx = cpu_to_node(qid_offset);
					if (node_idx >= SFX_SHIFT_IRQ_AFFI_MAX_NODE) {
						cpumask_off = qid_offset;
#if MQ_CONFIG_DEBUG
						sfx_print(-1, BLK_SYS, PL_WRN,
							  "%s %d: Read qid_off %u "
							  "irq_affinity cpu %u, node_idx %u\n",
							  __FUNCTION__, __LINE__, qid_offset, cpumask_off,
							  node_idx);
#endif
					} else {
						xt_u32 cpu_offset_inside_numa = 0;
						for (cpu_offset_inside_numa = 0;
						     cpu_offset_inside_numa <
						     sfx_num_online_cpus() / sfx_num_online_nodes();
						     cpu_offset_inside_numa++) {
							if (numa_array[node_idx][cpu_offset_inside_numa] ==
							    qid_offset) {
								break;
							}
						}

						if (((qid_offset >= numa_array[node_idx][0]) &&
						     (qid_offset < numa_array[node_idx][shift_off_affi])) ||
						    ((qid_offset >=
						      numa_array[node_idx][shift_off_affi * 2]) &&
						     (qid_offset <
						      numa_array[node_idx][shift_off_affi *
									   3]))) { //first or third quarter

							if (cpu_offset_inside_numa >=
							    sfx_num_online_cpus() / sfx_num_online_nodes()) {
								cpumask_off = qid_offset;
							} else {
								cpumask_off =
									numa_array[node_idx]
										  [cpu_offset_inside_numa +
										   shift_off_affi];
							}
							if (cpumask_off >= sfx_num_online_cpus()) {
								cpumask_off = qid_offset;
								sfx_print(
									-1, BLK_SYS, PL_WRN,
									"%s %d: Read qid_off %u irq_affinity cpu %u "
									"node %u, shift_off %u, idx_in_numa_array %u, shift to %u\n",
									__FUNCTION__, __LINE__, qid_offset,
									cpumask_off, node_idx, shift_off_affi,
									cpu_offset_inside_numa, cpumask_off);
							}
#if MQ_CONFIG_DEBUG
							sfx_print(
								-1, BLK_SYS, PL_INF,
								"%s %d: Read qid_off %u irq_affinity cpu %u "
								"node %u, shift_off %u, idx_in_numa_array %u\n",
								__FUNCTION__, __LINE__, qid_offset,
								cpumask_off, node_idx, shift_off_affi,
								cpu_offset_inside_numa + shift_off_affi);
#endif
						} else if (((qid_offset >=
							     numa_array[node_idx][shift_off_affi]) &&
							    (qid_offset <
							     numa_array[node_idx][shift_off_affi * 2])) ||
							   ((qid_offset >=
							     numa_array[node_idx][shift_off_affi * 3]) &&
							    (qid_offset <=
							     numa_array[node_idx]
								       [shift_off_affi * 4 -
									1]))) { //second or last quarter

							if (cpu_offset_inside_numa >=
							    sfx_num_online_cpus() / sfx_num_online_nodes()) {
								cpumask_off = qid_offset;
							} else {
								if (cpu_offset_inside_numa >=
								    shift_off_affi) {
									cpumask_off = numa_array
										[node_idx]
										[cpu_offset_inside_numa -
										 shift_off_affi];
								} else {
									cpumask_off = qid_offset;
									sfx_print(
										-1, BLK_SYS, PL_WRN,
										"%s %d: Read qid_off %u irq_affinity cpu %u "
										"node %u, shift_off %u, idx_in_numa_array %u, shift to %u\n",
										__FUNCTION__, __LINE__,
										qid_offset, cpumask_off,
										node_idx, shift_off_affi,
										cpu_offset_inside_numa,
										cpumask_off);
								}
							}
#if MQ_CONFIG_DEBUG
							sfx_print(
								-1, BLK_SYS, PL_INF,
								"%s %d: Read qid_off %u irq_affinity cpu %u "
								"node %u, shift_off %u, idx_in_numa_array %u\n",
								__FUNCTION__, __LINE__, qid_offset,
								cpumask_off, node_idx, shift_off_affi,
								cpu_offset_inside_numa - shift_off_affi);
#endif
						} else {
							cpumask_off = qid_offset;
#if MQ_CONFIG_DEBUG
							sfx_print(
								-1, BLK_SYS, PL_INF,
								"%s %d: Read qid_off %u irq_affinity cpu %u "
								"first quarter %u, second quarter %u, third quarter %u, last quarter %u\n",
								__FUNCTION__, __LINE__, qid_offset,
								cpumask_off,
								numa_array[node_idx][shift_off_affi],
								numa_array[node_idx][shift_off_affi * 2],
								numa_array[node_idx][shift_off_affi * 3],
								numa_array[node_idx][shift_off_affi * 4 - 1]);
#endif
						}
					}
				} else {
					cpumask_off = qid_offset;
				}
				cpumask_off = qid_offset;
#else
				cpumask_off = qid_offset;
#endif
#if MQ_CONFIG_DEBUG
				sfx_print(-1, BLK_SYS, PL_INF, "%s %d: Read qid_off %u irq_affinity cpu %u\n",
					  __FUNCTION__, __LINE__, qid_offset, cpumask_off);
#endif

#ifdef SFX_LINUX
				{
					cpumask_clear(f_cpumask);
					sfx_cpumask_or(f_cpumask, cpumask_per_stream[cpumask_off],
						       cpumask_per_stream[qid_offset]);
					init_ctx.cpumask = cpumask_per_stream[cpumask_off];
				}
#else
				init_ctx.cpumask = cpumask_per_stream[cpumask_off];
#endif
				init_ctx.numa_node = ftl_cntx->rdq_numa_node[qid_offset];
			} else {
				if (qid_offset == QID_OFF_B2N) {
					init_ctx.queue_type = SFX_HOT_B2NQ;
#ifdef SFX_LINUX
					init_ctx.cpumask = f_cpumask;
					set_nonio_q_irq_mask(sfx_mdrv->devId, init_ctx.queue_type,
							     init_ctx.cpumask);
#endif
					init_ctx.numa_node = INVALID_32BIT;
				} else if (qid_offset == QID_OFF_META) {
					init_ctx.queue_type = SFX_HOT_METAQ;
#ifdef SFX_LINUX
					init_ctx.cpumask = f_cpumask;
					set_nonio_q_irq_mask(sfx_mdrv->devId, init_ctx.queue_type,
							     init_ctx.cpumask);
#endif
					init_ctx.numa_node = INVALID_32BIT;
				} else {
					init_ctx.queue_type = SFX_HOT_WRQ;
					init_ctx.cpumask = cpumask_per_stream[qid_offset - QID_OFF_WR_BASE];
					init_ctx.numa_node =
						ftl_cntx->wrq_numa_node[qid_offset - QID_OFF_WR_BASE];
				}
				/* don't terminate here, compression queues followed */
			}

			init_ctx.stream_id = stream_iter;
			if (!(nvmeq = sfx_alloc_nvmeq(ftl_cntx->driver_handle, &init_ctx,
						      ccs_cmpl_driver_cb))) {
				sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device failed to init nvmeq\n");
				return 1;
			}
			ftl_cntx->drvg_ctx[qid_iter].blk_ftl_ctx = sfx_mdrv;
			ftl_cntx->drvg_ctx[qid_iter].driver_qp = nvmeq;
			ftl_cntx->drvg_ctx[qid_iter].cpumask = init_ctx.cpumask;
			ftl_cntx->drvg_ctx[qid_iter].stream_id = init_ctx.stream_id;
			ftl_cntx->drvg_ctx[qid_iter].queue_type = init_ctx.queue_type;
			qid_offset = (qid_offset == (num_queue_stream - 1)) ? 0 : qid_offset;
			if (sfx_alloc_nvmeioq(sfx_mdrv, &init_ctx)) {
				sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device failed to init io nvmeq\n");
				return 1;
			}

#if MQ_CONFIG_DEBUG
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
			sfx_print(-1, BLK_SYS, PL_INF,
				  "DEBUG: BLK_FTL allocate %s nvmeq qid=%u streamid=%u qtype=%u "
				  "qidoff=%u cpu_mask=%*pb nvmeq=%p last flag=%u tot_activeq=%u, node=%u\n",
				  rd_ioq ? "read" : "write", init_ctx.qid, init_ctx.stream_id,
				  init_ctx.queue_type, qid_offset, sfx_cpumask_pr_args(init_ctx.cpumask),
				  ftl_cntx->drvg_ctx[qid_iter].driver_qp, init_ctx.flag_last,
				  sfx_mdrv->ioq_config.tot_active_queue, init_ctx.numa_node);
#endif
#endif
		}
		qid_start_stream = qid_iter;
	}
	ftl_cntx->next_available_qid = qid_iter;
#ifdef SFX_LINUX
	if ((qid_start == HOT_RD_QID_BASE) && shifted_irq_affi) {
		xt_u32 iter_node, tot_node;
		tot_node = sfx_num_online_nodes();
		for (iter_node = 0; iter_node < tot_node; iter_node++) {
			sfx_mfree(numa_array[iter_node]);
		}
	}
	free_cpumask_var(f_cpumask);
#endif
	return 0;
}

static int sfx_nvmq_allocation(sfx_mul_drv *sfx_mdrv, xt_u16 qid_start)
{
	struct sfx_driver_nvmeq_ctx init_ctx;
	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;
	void *nvmeq = NULL;
	int qend, qid_iter;

	/* one write queue for NVM write */
	qend = qid_start + 1;

	for (qid_iter = qid_start; qid_iter < qend; qid_iter++) {
		sfx_memset(&init_ctx, 0, sizeof(struct sfx_driver_nvmeq_ctx));
		init_ctx.qid = qid_iter;
		init_ctx.cpumask = (struct cpumask *)sfx_cpu_online_mask;
		init_ctx.queue_type = SFX_NVMQ;

		if (qid_iter == qend - 1) {
			init_ctx.flag_last = 1;
		}

		nvmeq = sfx_alloc_nvmeq(ftl_cntx->driver_handle, &init_ctx, ccs_cmpl_driver_cb);
		if (!nvmeq) {
			sfx_print(-1, BLK_SYS, PL_WRN, "%s, SFX block device failed to init nvmeq\n",
				  __FUNCTION__);
			return 1;
		}
		ftl_cntx->drvg_ctx[qid_iter].blk_ftl_ctx = sfx_mdrv;
		ftl_cntx->drvg_ctx[qid_iter].driver_qp = nvmeq;
		ftl_cntx->drvg_ctx[qid_iter].cpumask = init_ctx.cpumask;
		ftl_cntx->drvg_ctx[qid_iter].stream_id = init_ctx.stream_id;
		ftl_cntx->drvg_ctx[qid_iter].queue_type = init_ctx.queue_type;
		if (sfx_alloc_nvmeioq(sfx_mdrv, &init_ctx)) {
			sfx_print(-1, BLK_SYS, PL_WRN, "%s, SFX block device failed to init io nvmeq\n",
				  __FUNCTION__);
			return 1;
		}
#if MQ_CONFIG_DEBUG
		sfx_print(-1, BLK_SYS, PL_INF,
			  "SFX block device allocates nvm qid=%u "
			  "nvmeq=%p, q_type=%u, stream_id=%u\n",
			  qid_iter, ftl_cntx->drvg_ctx[qid_iter].driver_qp, init_ctx.queue_type,
			  init_ctx.stream_id);
#endif
	}

	ftl_cntx->next_available_qid = qid_iter;
	return 0;
}

int sfx_alloc_comp_nvmeioq(ftl_mq_ctx *ftl_cntx, struct sfx_driver_nvmeq_ctx *qctx)
{
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
	sfx_app_queue *sfx_appq;

	ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue = sfx_nvmeq =
		sfx_kzalloc_node0(sizeof(SFX_NVME_CMD_QUEUE_STRUCT), SFX_GFP_NOIO, qctx->numa_node);
	if (!sfx_nvmeq) {
		return 1;
	}
	ftl_cntx->drvg_ctx[qctx->qid].sfx_app_queue = sfx_appq =
		sfx_kzalloc_node0(sizeof(sfx_app_queue), SFX_GFP_NOIO, qctx->numa_node);
	if (!sfx_appq) {
		sfx_kfree(sfx_nvmeq);
		ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue = NULL;
		return 1;
	}
	ll_init(&sfx_nvmeq->nvme_ll, sfx_nvmeq->nvme_que, sfx_nvmeq->nvme_elem, HOT_IO_QD, 2);
	sfx_memset(sfx_nvmeq->meta_flag, 0, sizeof(xt_u32) * (HOT_META_FLAG_SIZE));
	sfx_nvmeq->curr_mid = INVALID_32BIT;
	ll_init(&sfx_appq->appq_ll, sfx_appq->appq_que, sfx_appq->appq_elem, HOT_IO_QD, 2);
	sfx_spin_lock_init(&sfx_nvmeq->q_lock);
	sfx_spin_lock_init(&sfx_nvmeq->nvme_submit_lock);
	sfx_spin_lock_init(&sfx_appq->q_lock);
	sfx_spin_lock_init(&ftl_cntx->drvg_ctx[qctx->qid].lock);
	sfx_nvmeq->nvme_pending_commands[PENDING_TAIL] = 0;
	sfx_nvmeq->msix_mask = MSIX_VECTOR_BIT_BASK_BASE + (qctx->qid << 4);
	sfx_appq->appq_pending_commands[PENDING_TAIL] = 0;
	sfx_atomic_set(&sfx_nvmeq->q_depth, 0);
	sfx_atomic64_set(&sfx_nvmeq->num_smt, 0);
	sfx_atomic64_set(&sfx_nvmeq->num_polled, 0);
#if MQ_CONFIG_DEBUG
	sfx_print(-1, BLK_SYS, PL_INF,
		  "SFX BLOCK DEV: Allocate sfx-nvme-cmdq=%p appq=%p for qid=%u with "
		  "msix vector mask %u\n",
		  ftl_cntx->drvg_ctx[qctx->qid].sfx_nvme_cmd_queue,
		  ftl_cntx->drvg_ctx[qctx->qid].sfx_app_queue, qctx->qid, sfx_nvmeq->msix_mask);
#endif
	return 0;
}

int sfx_computationq_allocation(void *parent, ftl_mq_ctx *ftl_cntx, xt_u32 reg, SFX_QUEUE_TYPE qtype,
				ftl_cmpl_cb cb, xt_u8 last)
{
	struct sfx_driver_nvmeq_ctx init_ctx;
	void *nvmeq = NULL;
	xt_u16 qid_start = ftl_cntx->next_available_qid;
	int qend, qid_iter;

	if (qtype == SFX_COMPRESSIONQ) { // compressionq | r2cq
		if (reg & 0x4) { // compression
			/* one write queue and one read queue per HW compression engine */
			qend = qid_start + MAX_NUM_COMP_ENG * 2;
		} else if (reg & 0x100) { // r2c
			qend = qid_start + R2C_MAX_SESSION * 2;
		} else {
			sfx_print(-1, BLK_SYS, PL_ERR,
				  "%s: Unsupported register value for COMPRESSIONQ, return\n", __FUNCTION__);
			return 1;
		}
	} else if (qtype == SFX_ECQ) { // ecq
		qend = qid_start + 2;
	} else {
		sfx_print(-1, BLK_SYS, PL_ERR, "%s: Unsupported SFX_QUEUE_TYPE, return\n", __FUNCTION__);
		return 1;
	}

	if (!qid_start && last) {
		qid_start++;
		qend++;
	}
	for (qid_iter = qid_start; qid_iter < qend; qid_iter++) {
		sfx_memset(&init_ctx, 0, sizeof(struct sfx_driver_nvmeq_ctx));
		init_ctx.qid = qid_iter;
		init_ctx.cpumask = (struct cpumask *)sfx_cpu_online_mask;
		init_ctx.queue_type = qtype;

		if (last && qtype == SFX_ECQ && qid_iter == qend - 1) {
			init_ctx.flag_last = 1;
		}

		nvmeq = sfx_alloc_nvmeq(ftl_cntx->driver_handle, &init_ctx, cb);
		if (!nvmeq) {
			sfx_print(-1, BLK_SYS, PL_ERR, "%s: failed to alloc nvmeq\n", __FUNCTION__);
			return 1;
		}
		ftl_cntx->drvg_ctx[qid_iter].blk_ftl_ctx = parent;
		ftl_cntx->drvg_ctx[qid_iter].driver_qp = nvmeq;
		ftl_cntx->drvg_ctx[qid_iter].cpumask = init_ctx.cpumask;
		ftl_cntx->drvg_ctx[qid_iter].stream_id = init_ctx.stream_id;
		ftl_cntx->drvg_ctx[qid_iter].queue_type = init_ctx.queue_type;
		if (sfx_alloc_comp_nvmeioq(ftl_cntx, &init_ctx)) {
			sfx_print(-1, BLK_SYS, PL_ERR, "%s: failed to alloc io nvmeioq\n", __FUNCTION__);
			return 1;
		}
#if MQ_CONFIG_DEBUG
		sfx_print(-1, BLK_SYS, PL_INF,
			  "%s: device allocates compression qid=%u nvmeq=%p, q_type=%u, stream_id=%u\n",
			  __FUNCTION__, qid_iter, ftl_cntx->drvg_ctx[qid_iter].driver_qp, init_ctx.queue_type,
			  init_ctx.stream_id);
#endif
		/* for compression, use HW throttle so that driver can blindly send NVME request */
	}

	switch (qtype) {
	case SFX_COMPRESSIONQ:
		if (reg & 0x4) {
			sfx_compressionq_throttle(ftl_cntx->driver_handle, qid_start, DCE_FIFO_SIZE);
			sfx_comp_readq_throttle(ftl_cntx->driver_handle, qid_start, READ_FIFO_DEFAULT);
		}
		break;
	case SFX_ECQ:
		sfx_ecq_throttle(ftl_cntx->driver_handle, qid_start, 6);
		break;
	default:
		break;
	}

	ftl_cntx->next_available_qid = qid_iter;

	return 0;
}

static int sfx_bd_mq_comp_allocate(sfx_mul_drv *sfx_mdrv)
{
	xt_32 ret = 0;
	xt_u32 feature_reg;
	union handle dev_handle;

	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;

	/* Read feature register to identify which queues to allocate */
	if ((ret = sfx_device_open(sfx_mdrv->dev_name, &dev_handle)) < 0) {
		sfx_print(-1, BLK_SYS, PL_ERR, "%s: Cannot open %s\n", __FUNCTION__, sfx_mdrv->dev_name);
		goto free;
	} else {
		sfx_print(-1, BLK_SYS, PL_INF, "%s: %s opened, refcnt %d\n", __FUNCTION__, sfx_mdrv->dev_name,
			  ret);
		ftl_cntx->dce_feature = feature_reg = sfx_reg_read(&dev_handle, REG_DCE_FEATURE);
		if ((ret = sfx_device_close(&dev_handle)) < 0) {
			sfx_print(-1, BLK_SYS, PL_ERR, "%s: Cannot close %s\n", __FUNCTION__,
				  sfx_mdrv->dev_name);
		} else {
			sfx_print(-1, BLK_SYS, PL_INF, "%s: %s closed, refcnt %d\n", __FUNCTION__,
				  sfx_mdrv->dev_name, ret);
			if (ret)
				sfx_dump_stack();
		}
	}
	sfx_print(-1, BLK_SYS, PL_INF, "%s: Feature register = 0x%x\n", __FUNCTION__, feature_reg);

	/* Allocate DCE queues from MSB to LSB in feature reg */
	/* Allocate R2C queues */
	ftl_cntx->r2c_base_qid = ftl_cntx->next_available_qid = SFX_DRIVER_PREALLOC_QUEUE;
	if (feature_reg & 0x100) {
		if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_COMPRESSIONQ,
						r2c_cmpl_driver_cb, 1)) {
			goto free;
		}
	}
	/* allocate compression queues */
	ftl_cntx->comp_base_qid = ftl_cntx->next_available_qid;
	if (feature_reg & 0x4) {
		if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_COMPRESSIONQ,
						comp_cmpl_driver_cb, 1)) {
			goto free;
		}
	}
	/* allocate ec queues */
	ftl_cntx->ec_base_qid = ftl_cntx->next_available_qid;
	if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_ECQ,
					ec_cmpl_driver_cb, 1)) {
		goto free;
	}
	return 0;
free:
	sfx_kfree(ftl_cntx->drvg_ctx);
	return 1;
}

static int sfx_bd_mq_resource_allocate(sfx_mul_drv *sfx_mdrv)
{
	xt_u32 qid, cpuid;
	xt_u32 feature_reg;
	union handle dev_handle;
	xt_u16 num_wrq_per_stream, num_rdq_per_unit, num_stream;
	xt_u16 start_qid_hot_write;
	unsigned int *cpu2wrq_map = NULL, *cpu2rdq_map = NULL;
	xt_32 ret = 0;

	unsigned long flags;
	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;

	num_wrq_per_stream = sfx_mdrv->ioq_config.wrq_per_stream;
	num_rdq_per_unit = sfx_mdrv->ioq_config.rdq_per_unit;
	num_stream = sfx_mdrv->ioq_config.num_stream;
	cpu2wrq_map = sfx_mdrv->cpu2wrqid_map;
	cpu2rdq_map = sfx_mdrv->cpu2rdqid_map;

	if (!cpu2wrq_map || !cpu2rdq_map) {
		return 1;
	}

	sfx_spin_lock_init(&ftl_cntx->mask_lock);
	ftl_cntx->drvg_ctx =
		sfx_kzalloc_node0((sizeof(struct sfx_drvq_ctx) * TOT_QUEUE), SFX_GFP_NOIO, sfx_mdrv->numa_id);
	if (!ftl_cntx->drvg_ctx) {
		return 1;
	}
	for (qid = 0; qid < TOT_QUEUE; qid++) {
		if (!sfx_zalloc_cpumask_ptr(&(ftl_cntx->wrq_cpumask_perstream[qid]), SFX_GFP_KERNEL) ||
		    !sfx_zalloc_cpumask_ptr(&(ftl_cntx->rdq_cpumask_perunit[qid]), SFX_GFP_KERNEL)) {
			sfx_print(-1, BLK_SYS, PL_WRN, "SFX block driver failed to allocate cpu mask\n");
			goto free_no_lock;
		}
	}
	sfx_spin_lock_irqsave(&ftl_cntx->mask_lock, flags);
	/* fill up cpu mask */
	sfx_for_each_online_cpu(cpuid)
	{
		qid = cpu2wrq_map[cpuid];
		sfx_cpumask_or(ftl_cntx->wrq_cpumask_perstream[qid], ftl_cntx->wrq_cpumask_perstream[qid],
			       sfx_cpumask_of(cpuid));
		ftl_cntx->wrq_numa_node[qid] = cpu_to_node(cpuid);

		qid = cpu2rdq_map[cpuid];
		sfx_cpumask_or(ftl_cntx->rdq_cpumask_perunit[qid], ftl_cntx->rdq_cpumask_perunit[qid],
			       sfx_cpumask_of(cpuid));
		ftl_cntx->rdq_numa_node[qid] = cpu_to_node(cpuid);
	}
	sfx_spin_unlock_irqrestore(&ftl_cntx->mask_lock, flags);
#if MQ_CONFIG_DEBUG
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	for (qid = 0; qid < sfx_mdrv->ioq_config.rdq_per_unit; qid++) {
		sfx_print(-1, BLK_SYS, PL_INF, "read queue id=%u cpumask=%*pb\n", qid,
			  sfx_cpumask_pr_args(ftl_cntx->rdq_cpumask_perunit[qid]));
	}
	for (qid = 0; qid < sfx_mdrv->ioq_config.wrq_per_stream; qid++) {
		sfx_print(-1, BLK_SYS, PL_INF, "write queue id=%u cpumask=%*pb\n", qid,
			  sfx_cpumask_pr_args(ftl_cntx->wrq_cpumask_perstream[qid]));
	}
#endif
#endif
	sfx_mutex_lock(&g_create_nvmeq_lock);
	/* allocate non-io queues*/
	if (sfx_nonioq_allocation(sfx_mdrv)) {
		sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
		goto free;
	}

	/* allocate hot read io-queues */
	if (sfx_hot_ioq_allocation(sfx_mdrv, HOT_RD_QID_BASE)) {
		sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
		goto free;
	}

	/* allocate hot write io-queues */
	start_qid_hot_write =
		HOT_RD_QID_BASE + ((sfx_mdrv->ioq_config.isolation ? sfx_mdrv->ioq_config.num_stream : 1) *
				   sfx_mdrv->ioq_config.rdq_per_unit);
	if (sfx_hot_ioq_allocation(sfx_mdrv, start_qid_hot_write)) {
		sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
		goto free;
	}
	ftl_cntx->ioq_config->tot_active_queue = ftl_cntx->next_available_qid - 1;
	/* get irq for each sfx-nvmeq */
	for (qid = 0; qid < ftl_cntx->ioq_config->tot_active_queue; qid++) {
		ftl_cntx->drvg_ctx[qid].irq = sfx_get_irq(ftl_cntx->driver_handle, qid);
#if MQ_CONFIG_DEBUG
		sfx_print(-1, BLK_SYS, PL_INF, "%s: QID=%u, related irq number=%u\n", __FUNCTION__, qid,
			  ftl_cntx->drvg_ctx[qid].irq);
#endif
	}

	/* Read feature register to identify which queues to allocate */
	if ((ret = sfx_device_open(sfx_mdrv->dev_name, &dev_handle)) < 0) {
		sfx_print(-1, BLK_SYS, PL_ERR, "%s: Cannot open %s\n", __FUNCTION__, sfx_mdrv->dev_name);
		goto free;
	} else {
		sfx_print(-1, BLK_SYS, PL_INF, "%s: %s opened, refcnt %d\n", __FUNCTION__, sfx_mdrv->dev_name,
			  ret);
		ftl_cntx->dce_feature = feature_reg = sfx_reg_read(&dev_handle, REG_DCE_FEATURE);
		if ((ret = sfx_device_close(&dev_handle)) < 0) {
			sfx_print(-1, BLK_SYS, PL_ERR, "%s: Cannot close %s\n", __FUNCTION__,
				  sfx_mdrv->dev_name);
		} else {
			sfx_print(-1, BLK_SYS, PL_INF, "%s: %s closed, refcnt %d\n", __FUNCTION__,
				  sfx_mdrv->dev_name, ret);
			if (ret)
				sfx_dump_stack();
		}
	}

#if MQ_CONFIG_DEBUG
	sfx_print(-1, BLK_SYS, PL_INF, "%s: Feature register = 0x%x\n", __FUNCTION__, feature_reg);
#endif

	/* Allocate DCE queues from MSB to LSB in feature reg */
	/* Allocate R2C queues */
	ftl_cntx->r2c_base_qid = ftl_cntx->next_available_qid;
	if (feature_reg & 0x100) {
		if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_COMPRESSIONQ,
						r2c_cmpl_driver_cb, 0)) {
			sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
			goto free;
		}
	}
	/* allocate compression queues */
	ftl_cntx->comp_base_qid = ftl_cntx->next_available_qid;
	if (feature_reg & 0x4) {
		if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_COMPRESSIONQ,
						comp_cmpl_driver_cb, 0)) {
			sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
			goto free;
		}
	}
	/* allocate ec queues */
	ftl_cntx->ec_base_qid = ftl_cntx->next_available_qid;
	if (sfx_computationq_allocation(sfx_mdrv, sfx_mdrv->ftl_mq_ctx, feature_reg, SFX_ECQ,
					ec_cmpl_driver_cb, 0)) {
		sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
		goto free;
	}
	/* allocate nvm queues */
	ftl_cntx->nvm_write_qid = ftl_cntx->next_available_qid;
	if (sfx_nvmq_allocation(sfx_mdrv, ftl_cntx->next_available_qid)) {
		sfx_print(-1, BLK_SYS, PL_INF, "%s:%d, exit!\n", __FUNCTION__, __LINE__);
		goto free;
	}

	sfx_mutex_unlock(&g_create_nvmeq_lock);

	return 0;
free:
	sfx_mutex_unlock(&g_create_nvmeq_lock);
free_no_lock:
	sfx_kfree(ftl_cntx->drvg_ctx);
	return 1;
}

int sfx_bd_mq_wq_init(sfx_mul_drv *sfx_mdrv)
{
	ftl_mq_ctx *ftl_mq_ctx = sfx_mdrv->ftl_mq_ctx;
	sfx_workqueue_struct wq;

	sfx_memset(ftl_mq_ctx->ftl_ctx.workq_name, 0, sizeof(ftl_mq_ctx->ftl_ctx.workq_name));
	sfx_snprintf(ftl_mq_ctx->ftl_ctx.workq_name, sizeof(ftl_mq_ctx->ftl_ctx.workq_name) - 1, "sfx_bd_wq");
	wq = sfx_bd_create_work_queue(ftl_mq_ctx->ftl_ctx.workq_name);
	if (!wq) {
		sfx_print(-1, BLK_SYS, PL_WRN, "Cannot create work queue!\n");
		return 1;
	}
	ftl_mq_ctx->ftl_ctx.workq = wq;
	return 0;
}

void sfx_bd_mq_wq_release(sfx_mul_drv *sfx_mdrv)
{
	ftl_mq_ctx *ftl_mq_ctx = sfx_mdrv->ftl_mq_ctx;
	if (ftl_mq_ctx->ftl_ctx.workq) {
		sfx_destroy_workqueue((sfx_workqueue_struct)ftl_mq_ctx->ftl_ctx.workq);
		ftl_mq_ctx->ftl_ctx.workq = NULL;
	}
}

#if ENABLE_VDEV
/* tagset in virtual driver now */
#else
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
static int sfx_mq_tagset(sfx_mul_drv *sfx_mdrv)
{
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "register mdrv to linux mq\n");

	sfx_mdrv_mq_tag_set(sfx_mdrv)->cmd_size = 4096; // sfx_request
	sfx_mdrv_mq_tag_set(sfx_mdrv)->ops = &sfx_mq_ops;
	sfx_mdrv_mq_tag_set(sfx_mdrv)->queue_depth = SFX_LINUX_MQ_DEPTH;
	sfx_mdrv_mq_tag_set(sfx_mdrv)->numa_node = sfx_mdrv->numa_id;
	sfx_mdrv_mq_tag_set(sfx_mdrv)->flags = BLK_MQ_F_SHOULD_MERGE;
	sfx_mdrv_mq_tag_set(sfx_mdrv)->driver_data = sfx_mdrv;
	if (sfx_mdrv->goldimg_dev) {
		sfx_mdrv_mq_tag_set(sfx_mdrv)->nr_hw_queues = 1;
	} else {
		sfx_mdrv_mq_tag_set(sfx_mdrv)->nr_hw_queues = sfx_num_online_cpus();
	}
	if (0 != blk_mq_alloc_tag_set(sfx_mdrv_mq_tag_set(sfx_mdrv))) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Failed to alloc tag set\n");
		return -1;
	}
	return 0;
}
#else
#define sfx_mq_tagset(sfx_mdrv) 0
#endif
#endif // ENABLE_VDEV

void register_ccs_thread(void *context, struct sfx_blk_ftl_thread **ccs_thread, void *ccp)
{
	sfx_mul_drv *sfx_mdrv = NULL;

	sfx_mdrv = container_of(context, sfx_mul_drv, devId);
	sfx_mdrv->devId = ccs_get_dev_id_by_ctrlr(ccp);
	set_ccs_private_data(sfx_mdrv->devId, sfx_mdrv, &sfx_mdrv->priv_thrds.assert_thread,
			     &sfx_mdrv->priv_thrds, &sfx_mdrv_state_machine);
}

static void sfx_blk_ftl_bg_check_thread_init(sfx_mul_drv *sfx_mdrv)
{
	sfx_thread_t priv_thread;

	xt_u32 idx_cpu;
#ifdef SFX_LINUX
	sfx_mdrv->disable_irq_time = sfx_alloc_percpu(xt_u64);
#else
	sfx_atomic64_set(&sfx_mdrv->disable_irq_time, 0);
#endif
	for (idx_cpu = 0; idx_cpu < sfx_num_online_cpus(); idx_cpu++) {
#ifdef SFX_LINUX
		*per_cpu_ptr(sfx_mdrv->disable_irq_time, idx_cpu) = 0;
#endif
		sfx_bd_init_work(sfx_mdrv->ftl_mq_ctx->ftl_ctx.bg_work, idx_cpu, blk_ftl_irq_bg_check);
	}
	sfx_smp_mb();

	sfx_init_waitqueue_head(&sfx_mdrv->priv_thrds.blk_ftl_bg_thread.wait);
	priv_thread = sfx_thread_create((sfx_thread_t *)(&(sfx_mdrv->priv_thrds.blk_ftl_bg_thread.thread)),
					blk_ftl_bg_check, (void *)sfx_mdrv, "sfx_bf_bg");
	sfx_mdrv->priv_thrds.blk_ftl_bg_thread.pid = sfx_thread_pid(priv_thread);
	blk_ftl_thread_init(sfx_mdrv, &sfx_mdrv->priv_thrds.blk_ftl_bg_thread,
			    SFX_PRIV_THREAD_SLOT_BLK_FTL_BG);
}

static void sfx_blk_ftl_bg_check_thread_exit(sfx_mul_drv *sfx_mdrv)
{
	/*sfx_print(-1, BLK_SYS, PL_LOG, "%s: sfx_mdrv->blk_ftl_bg_thread %p\n", __func__,
		  sfx_mdrv->priv_thrds.blk_ftl_bg_thread);*/
	sfx_kthread_stop(sfx_mdrv->priv_thrds.blk_ftl_bg_thread);
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
	sfx_free_percpu(sfx_mdrv->disable_irq_time);
#endif
#endif
}

static int sfx_defer_smt_init(sfx_mul_drv *sfx_mdrv)
{
	struct ftl_defer_smt_ctx *defer_ctx;
	sfx_thread_t defer_thread;

	defer_ctx = sfx_kzalloc_node0(sizeof(struct ftl_defer_smt_ctx), SFX_GFP_NOIO, sfx_mdrv->numa_id);
	if (!defer_ctx) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
			  "SFX_BLK_FTL: Fail to allocate memory for defer ctx\n");
		return 1;
	}
	sfx_atomic_set(&defer_ctx->defer_qd, 0);
	SFX_INIT_LIST_HEAD(&defer_ctx->defer_que);
	defer_ctx->defer_smt_thread = &sfx_mdrv->priv_thrds.defer_smt_thread;
	sfx_init_waitqueue_head(&(defer_ctx->defer_smt_thread->wait));
	sfx_spin_lock_init(&defer_ctx->defer_qlock);
	sfx_atomic_set(&sfx_mdrv->state_remove, 0);
	sfx_mdrv->ftl_mq_ctx->defer_smt = defer_ctx;

	sfx_smp_mb();
	defer_thread = sfx_thread_create_on_node((sfx_thread_t *)(&(defer_ctx->defer_smt_thread->thread)),
						 css_hotwr_smt, (void *)(sfx_mdrv->ftl_mq_ctx),
						 sfx_mdrv->numa_id, "sfx_defer_smt");
	defer_ctx->defer_smt_thread->pid = sfx_thread_pid(defer_thread);
	blk_ftl_thread_init(sfx_mdrv, defer_ctx->defer_smt_thread, SFX_PRIV_THREAD_SLOT_DEFER_SMT);
	return 0;
}

static void sfx_defer_smt_free(sfx_mul_drv *sfx_mdrv)
{
	struct ftl_defer_smt_ctx *defer_ctx = sfx_mdrv->ftl_mq_ctx->defer_smt;
	sfx_destroy_spinlock(&defer_ctx->defer_qlock);
	sfx_kfree(defer_ctx);
}

int update_drive_size(void *sfx_mdriv, OP_SETTING_E op_type)
{
	/*
     * OP % capacity = 100 * (Physical capacity - Drive size) / Drive size
     * Drive size = Physical capacity / (100 + (OP % capacity)) + 2% margin
     * Based on LBA-Count-for-Disk-Drives-Standard-LBA1-03.pdf
     * LBA counts = (97,696,368) + (1,953,504 * (Advertised Capacity in GBytes - 50))
     * Or
     * Advertised Capacity (GB) = [(LBA counts - 97,696,368)/1,953,504] + 50
     * Numbers 97,696,368, 1,953,504 and 50 are constants.
     */

	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_mdriv;
	sfx_board_nand_type card_info;
	map_t *gmap = (map_t *)sfx_mdrv->gmap;
	xt_u32 local_capacity = 0; //over provision percent from 0-100%
	xt_u32 max_capacity = 0;
	int status = 0;

	local_capacity = sfx_mdrv->card_info.card_capacity;
	max_capacity = local_capacity;

	if (op_type == OP_DEFAULT) {
		//use local_capacity as default
	} else if (op_type == OP_FACTORY_INIT) {
		if (capacity == 0xdeadbeef) {
			//use default local capacity
		} else if (capacity > max_capacity) {
			local_capacity = max_capacity;
		} else if (capacity < (local_capacity / 2)) {
			local_capacity = (local_capacity / 2);
		} else {
			local_capacity = capacity;
		}
		gmap->pmaster->capacity = local_capacity;
	} else if (op_type == OP_NORMAL) {
		local_capacity = gmap->pmaster->capacity;
	} else {
		sfx_ftl_assert(sfx_mdrv, 0);
		status = -EIO;

		goto out;
	}

	sfx_memset((void *)&card_info, 0, sizeof(card_info));
	sfx_get_card_feature(&sfx_mdrv->dev_handle, FEAT_OP_CARD_INFO, (xt_u32 *)&card_info,
			     sizeof(sfx_board_nand_type));
	if (!card_info.nand_type && sfx_mdrv->goldimg_dev) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: !nand_type and goldimage, assume 16TB\n",
			  __FUNCTION__);
		card_info.card_capacity = CAPACITY_16TB;
	}

	switch (card_info.card_capacity) {
	CASE_VARIANT_16TB:
		sfx_mdrv->blk_ft_cfg.physical_capacity_in_gigabyte = MAX_1_6TB_IN_GB;
		sfx_mdrv->blk_ft_cfg.real_drive_size =
			2ul * 1024ul * 1024ul * 1024ul * 1024ul / (1000ul * 1000ul * 1000ul);
		break;
	CASE_VARIANT_32TB:
		sfx_mdrv->blk_ft_cfg.physical_capacity_in_gigabyte = MAX_3_2TB_IN_GB;
		sfx_mdrv->blk_ft_cfg.real_drive_size =
			4ul * 1024ul * 1024ul * 1024ul * 1024ul / (1000ul * 1000ul * 1000ul);
		break;
	CASE_VARIANT_64TB:
		sfx_mdrv->blk_ft_cfg.physical_capacity_in_gigabyte = MAX_6_4TB_IN_GB;
		sfx_mdrv->blk_ft_cfg.real_drive_size =
			8ul * 1024ul * 1024ul * 1024ul * 1024ul / (1000ul * 1000ul * 1000ul);
		break;
	CASE_VARIANT_128TB:
	default:
		sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_WRN, "Wrong capacity %d\n", card_info.card_capacity);
		status = -5;
		break;
	}

	sfx_mdrv->blk_ft_cfg.default_mem_id_size_in_gigabyte =
		((sfx_mdrv->blk_ft_cfg.default_mem_id_size * 4096llu) + 1000llu * 1000llu * 1000llu / 2llu) /
		(1000llu * 1000llu * 1000llu); //round up

	if (local_capacity <= 100) {
		//use old format
		sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_WRN, "detect op_percent setting %d %d\n",
			  local_capacity, op_percent);
		sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte =
			((sfx_mdrv->blk_ft_cfg.physical_capacity_in_gigabyte * 100 +
			  (100 + local_capacity) / 2) /
			 (100 + local_capacity));
		//added 2 %
		sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte =
			(xt_u64)sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte * 102llu;
		sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte =
			((xt_u64)sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte) / 100llu;
	} else {
		sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte = local_capacity;
	}

	sfx_mdrv->blk_ft_cfg.drive_size_in_nsec =
		97696368llu + (1953504llu * ((xt_u64)sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte - 50llu));

	sfx_mdrv->blk_ft_cfg.map_size = ((sfx_mdrv->blk_ft_cfg.drive_size_in_nsec / 8) * 4) + 4096;

	sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_LOG,
		  "capacity ,%d, drive_size_in_nsec ,%lld,"
		  "drive size in bytes ,%lld, map size ,%lld, drive_size_in_gigabyte ,%d\n",
		  local_capacity, (long unsigned int)sfx_mdrv->blk_ft_cfg.drive_size_in_nsec,
		  ((long unsigned int)sfx_mdrv->blk_ft_cfg.drive_size_in_nsec * (long unsigned int)512),
		  (long unsigned int)sfx_mdrv->blk_ft_cfg.map_size,
		  sfx_mdrv->blk_ft_cfg.drive_size_in_gigabyte);

	sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_LOG,
		  "default_mem_id_size_in_gigabyte ,%d, "
		  "physical_capacity_in_gigabyte ,%d, real_drive_size ,%d, op_type "
		  ",%d, card_capacity ,%d\n",
		  sfx_mdrv->blk_ft_cfg.default_mem_id_size_in_gigabyte,
		  sfx_mdrv->blk_ft_cfg.physical_capacity_in_gigabyte, sfx_mdrv->blk_ft_cfg.real_drive_size,
		  op_type, card_info.card_capacity);

	if (op_type > OP_DEFAULT) {
		sfx_print(sfx_mdrv->devId, BLK_SCHD, PL_LOG, "capacity %d capacity ,%d\n",
			  card_info.card_capacity, gmap->pmaster->capacity);
	}

out:
	return status;
}

void print_debug_drive_size(void *sfx_mdriv)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_mdriv;
	xt_u32 i;
	map_t *gmap = (map_t *)sfx_mdrv->gmap;

	for (i = 0; i < 101; i++) {
		gmap->pmaster->capacity = i;
	}
}

int set_blk_ftl_config_params(void *sfx_mdriv)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_mdriv;

	sfx_memset((void *)&sfx_mdrv->card_info, 0, sizeof(sfx_mdrv->card_info));
	sfx_get_card_feature(&sfx_mdrv->dev_handle, FEAT_OP_CARD_INFO, (xt_u32 *)&sfx_mdrv->card_info,
			     sizeof(sfx_board_nand_type));
	if (!sfx_mdrv->card_info.nand_type && sfx_mdrv->goldimg_dev) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s: !nand_type and goldimage, assume 16TB\n",
			  __FUNCTION__);
		sfx_mdrv->card_info.card_capacity = CAPACITY_16TB;
	}

	if (sfx_mdrv->card_info.nand_type == MU_L06B) {
		switch (sfx_mdrv->card_info.card_capacity) {
		CASE_VARIANT_16TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 1015808; // around 4GB of mem_id
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 2;
			break;
		CASE_VARIANT_32TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 2031616; // around 8GB of mem_id
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 4;
			break;
		CASE_VARIANT_64TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 4063232; // around 16GB of mem_id
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 8;
			break;
		default:
			return -4;
		}
		sfx_mdrv->blk_ft_cfg.l2p_max_chan = 1;
	} else if (sfx_mdrv->card_info.nand_type == TSB_BICS) {
		switch (sfx_mdrv->card_info.card_capacity) {
		CASE_VARIANT_16TB:
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 2;
			break;
		CASE_VARIANT_32TB:
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 4;
			break;
		CASE_VARIANT_64TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size =
				sfx_mdrv->card_info.num_pg * sfx_mdrv->card_info.num_lun *
				sfx_mdrv->card_info.num_ce * sfx_mdrv->card_info.num_sw_gr *
				sfx_mdrv->card_info.num_sw_ch * sfx_mdrv->card_info.num_sw_pl *
				(1 << sfx_mdrv->card_info.sw_off_pl); //  around 3.2GB of mem_id
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 4;
			break;
		default:
			return -2;
		}
		sfx_mdrv->blk_ft_cfg.l2p_max_chan = 4;
	} else if (sfx_mdrv->card_info.nand_type == MU_B17A) {
		switch (sfx_mdrv->card_info.card_capacity) {
		CASE_VARIANT_16TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 9142272 / 8;
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 2;
			break;
		CASE_VARIANT_32TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 9142272 / 4;
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 4;
			break;
		CASE_VARIANT_64TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 9142272 / 2;
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 8;
			break;
		CASE_VARIANT_128TB:
			sfx_mdrv->blk_ft_cfg.default_mem_id_size = 9142272; // around 32GB of mem_id
			sfx_mdrv->blk_ft_cfg.gc_parity_buffers = 8;
			break;
		default:
			return -2;
		}
		sfx_mdrv->blk_ft_cfg.l2p_max_chan = 1; //fixme: don't know max chan
	} else {
		return -3;
	}
	sfx_mdrv->blk_ft_cfg.default_mem_id_size =
		(sfx_mdrv->card_info.num_pg * sfx_mdrv->card_info.num_lun * sfx_mdrv->card_info.num_ce *
		 sfx_mdrv->card_info.num_sw_gr * sfx_mdrv->card_info.num_sw_ch *
		 sfx_mdrv->card_info.num_sw_pl * (1 << sfx_mdrv->card_info.sw_off_pl) * (PARITY_RATIO - 1) /
		 PARITY_RATIO); //  around 3.2GB of mem_id
	sfx_mdrv->blk_ft_cfg.gc_parity_buffers =
		(sfx_mdrv->card_info.num_ce * sfx_mdrv->card_info.num_lun * sfx_mdrv->card_info.num_sw_gr *
		 sfx_mdrv->card_info.num_sw_ch / PARITY_RATIO);

	sfx_mdrv->blk_ft_cfg.pages_per_blk = sfx_mdrv->card_info.num_pg;
	sfx_mdrv->blk_ft_cfg.num_block = sfx_mdrv->card_info.num_blk;

	sfx_print(
		sfx_mdrv->devId, BLK_SYS, PL_INF,
		"%s: nand:%d card_capacity:%d drive_size:%lld default_mem_id_size:%d map_size: %llu gc_parity_buffers:%d page_bit_shift:%d\n",
		__FUNCTION__, sfx_mdrv->card_info.nand_type, sfx_mdrv->card_info.card_capacity,
		sfx_mdrv->blk_ft_cfg.drive_size_in_nsec, sfx_mdrv->blk_ft_cfg.default_mem_id_size,
		sfx_mdrv->blk_ft_cfg.map_size, sfx_mdrv->blk_ft_cfg.gc_parity_buffers,
		sfx_mdrv->card_info.sw_off_pg);
	return 0;
}

int sfx_blk_ftl_init(sfx_mul_drv *sfx_mdrv, ftl_global_ctx *ftl_gctx)
{
	int error = NO_ERROR, ret = 0;
	xt_u8 i;
	sfxError status;
	for (i = 0; i < MAX_STREAM_SUPPORT; i++) {
		sfx_atomic_set(&ftl_gctx->ftl_mq_ctx->flag_barrier_rebuild[i], 0);
	}

	sfx_mdrv->devId = MAX_NR_DRIVE; /* CCS_Open_ccs_dev() will set it to correct value. */
	if ((status = CCS_Open_ccs_dev(sfx_mdrv->dev_name, &sfx_mdrv->devId, sfx_mdrv->numa_id, ftl_gctx,
				       register_ccs_thread))) {
		sfx_print(-1, BLK_SYS, PL_ERR,
			  "%s: Init CCS failed with "
			  "return %d \n",
			  __FUNCTION__, status);
		if (CCS_IdentifyDevice(sfx_mdrv->devId) == ERROR_DEVICE_NOT_READY) {
			sfx_exit_all_threads(sfx_mdrv);
			sfx_bd_mq_wq_release(sfx_mdrv);
		}
		return -EPERM;
	}
	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
		if ((ret = sfx_device_open(sfx_mdrv->dev_name, &sfx_mdrv->dev_handle)) < 0) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "%s: Cannot open %s\n", __FUNCTION__,
				  sfx_mdrv->dev_name);
		} else {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: %s opened, refcnt %d\n",
				  __FUNCTION__, sfx_mdrv->dev_name, ret);
			if (!ret)
				sfx_dump_stack();
		}

		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s:%d\n", __FUNCTION__, __LINE__);
		error = set_blk_ftl_config_params(sfx_mdrv);
		if (error == NO_ERROR) {
			error = update_drive_size(sfx_mdrv, OP_DEFAULT);
		}
		if (0 > error) {
			return -ENOMEM;
		}
	} else {
		mim_mem_id_t *gpmem_id;
		map_t *gmap = NULL;

		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s:%d\n", __FUNCTION__, __LINE__);
		if ((ret = sfx_device_open(sfx_mdrv->dev_name, &sfx_mdrv->dev_handle)) < 0) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "%s: Cannot open %s\n", __FUNCTION__,
				  sfx_mdrv->dev_name);
		} else {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: %s opened, refcnt %d\n",
				  __FUNCTION__, sfx_mdrv->dev_name, ret);
			if (!ret)
				sfx_dump_stack();
		}

		sfx_mdrv->l2p_address = KERNEL_PHY_ADDR_FLAT_MAP_BEGIN + (sfx_mdrv->devId * OFFSET_4GB);

		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s:%d\n", __FUNCTION__, __LINE__);
		while (CCS_IdentifyDevice(sfx_mdrv->devId) != DEVICE_READY) {
			if (CCS_IdentifyDevice(sfx_mdrv->devId) == ERROR_DEVICE_NOT_READY) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "%s: device has errors and exit!!!\n", __FUNCTION__);
				sfx_exit_all_threads(sfx_mdrv);
				sfx_bd_mq_wq_release(sfx_mdrv);
				error = -EIO;

				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__,
					  __LINE__);
				return error;
			}
			sfx_usleep(1000);
		}
		error = set_blk_ftl_config_params(sfx_mdrv);
		if (error == NO_ERROR) {
			error = update_drive_size(sfx_mdrv, OP_DEFAULT);
		}
		if (0 > error) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
			return -ENOMEM;
		}
		if (sfx_defer_smt_init(sfx_mdrv)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
			return -ENOMEM;
		}
		sfx_check_ka_versions(sfx_mdrv);
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "start rebuild\n");
		sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->credit, BLK_FTL_THROTTLE_TARGET_SPEED *
								      BLK_FTL_THROTTLE_DEFAULT_SLEEP_TIME *
								      1024 * 2 / 10);
		if (blk_ftl_maplog_eh_init(sfx_mdrv) == ERROR_MALLOC) {
			error = -EIO;
			goto out;
		}
		sfx_init_gc_trigger(sfx_mdrv);
		if (fm_start_rebuild(sfx_mdrv)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Failed on fm start rebuild!\n");
			DestroyTable();
			error = -EIO;
		}
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

		if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
			sfx_blk_ftl_bg_check_thread_init(sfx_mdrv);
		}

		while (fm_get_current_state(sfx_mdrv) < FM_NORMAL) {
			if (sfx_atomic_read(
				    &sfx_mdrv->flag_dev_freeze)) { //when frezze, all private thread is either assert or park
				error = _quit_priv_thread(sfx_mdrv);
				return -EIO;
			}
			if (sfx_atomic_read(
				    &sfx_mdrv->surprising_remove)) { //when frezze, all private thread is either assert or park
				//error = _quit_priv_thread(sfx_mdrv);
				return ERROR_DEVICE_GONE;
			}
			sfx_schedule();
			sfx_mb();
		}
		sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->credit, 0);
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s: total free mem id %u, "
			  "active pu %u\n",
			  __FUNCTION__, gpmem_id->total_free_mem_id, gpmem_id->pu_res.active_pu);
		gmap = sfx_mdrv->gmap;
		while (gmap->is_rebuild_done == 0) {
			if (sfx_atomic_read(&sfx_mdrv->surprising_remove))
				break;
			sfx_schedule();
		}
		if (fm_get_current_state(sfx_mdrv) == FM_ASSERT_STATE) {
			error = -ENOMEM;
			goto out;
		}
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG,
			  "state after rebuild "
			  "done %d\n",
			  fm_get_current_state(sfx_mdrv));
		blk_ftl_cb_init(sfx_mdrv);
		blk_ftl_throttle_init(sfx_mdrv);
		if (blk_ftl_err_handle_init(sfx_mdrv) == ERROR_ASSERT) {
			error = -EIO;

			goto out;
		}
		blk_ftl_read_distb_init(sfx_mdrv);
		mdata_vfy_init(sfx_mdrv);
		if (NO_ERROR != init_pu_res_manager(sfx_mdrv)) {
			error = -ENOMEM;
			sfx_print(sfx_mdrv->devId, BLK_COH, PL_ERR, "Fail to init PU resource manager\n");
		}

		sfx_print(sfx_mdrv->devId, BLK_COH, PL_LOG, "%s %d: active pu %u\n", __FUNCTION__, __LINE__,
			  gpmem_id->pu_res.active_pu);
		sfx_pu_res_recover(sfx_mdrv);
		if (blk_ftl_coh_init(sfx_mdrv)) {
			error = -ENOMEM;
			sfx_print(sfx_mdrv->devId, BLK_COH, PL_ERR, "%s: Fail to init coh\n", __FUNCTION__);
		}
#ifdef SFX_LINUX
		if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO) {
			sfx_init_waitqueue_head(&sfx_mdrv->sq_full);
			sfx_init_waitqueue_entry(&sfx_mdrv->sq_cong_wait,
						 sfx_mdrv->priv_thrds.blk_ftl_bg_thread.thread);
			sfx_bio_list_init(&sfx_mdrv->sq_cong);
			sfx_spin_lock_init(&sfx_mdrv->sq_cong_lock);
		}
#endif
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
		  "%s: device is ready, numa id "
		  "%u, total pagelist entry %x\n",
		  __FUNCTION__, sfx_mdrv->numa_id, sfx_mdrv->tot_pglist_entry);

out:
	return error;
}

static void sfx_mdrv_init(sfx_mul_drv *sfx_mdrv)
{
	xt_u32 i;
	//nvme spec init, just for nvme cli
	sfx_mdrv->pci_vender_id = PCI_VENDOR_ID_SFX;
	sfx_mdrv->rab = 0;
	sfx_memset(&sfx_mdrv->feature.arb, 0, sizeof(struct sfx_nvme_feature));

	sfx_mdrv->tot_pglist_entry = sfx_get_pglist_entry_nr();
#ifdef CRASH_TRIGGER
	sfx_mdrv->crash_loc = 0xff;
#endif

	for (i = 0; i < SFX_PRIV_THREAD_SLOT_TOTAL; i++) {
		sfx_mdrv->priv_thrds.threads[i].thread_pid = 0;
		sfx_mdrv->priv_thrds.threads[i].assert_cmpl = NULL;
	}

	sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->state_remove, 0);
	sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->vir_surprise_remove, 0);
	sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->surprise_remove_done, 0);
	sfx_atomic_set(&sfx_mdrv->flag_dev_freeze, 0);
	sfx_atomic_set(&sfx_mdrv->assert_handle_action, SFX_DEVICE_NORMAL);
	sfx_atomic_set(&sfx_mdrv->assert_handled, 0);
	sfx_atomic_set(&sfx_mdrv->direct_cb, 0);
	sfx_atomic_set(&sfx_mdrv->queue_cb, 0);
	sfx_atomic_set(&sfx_mdrv->rd_num_req, 0);
	sfx_atomic_set(&sfx_mdrv->rd_cmpl_direc, 0);
	sfx_atomic_set(&sfx_mdrv->rd_cmpl_coh, 0);
	sfx_atomic_set(&sfx_mdrv->rd_cmpl_percpu, 0);

	sfx_atomic_set(&sfx_mdrv->bg_cmd_cmpl, 0);
	sfx_atomic_set(&sfx_mdrv->queue_stop, 0);
	sfx_atomic_set(&sfx_mdrv->active_bgworker, 0);
#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_atomic64_set(&sfx_mdrv->func_req_handle_lat, 0);
	sfx_atomic64_set(&sfx_mdrv->coh_process_time, 0);
	sfx_atomic64_set(&sfx_mdrv->coh_bio_init_time, 0);
	sfx_atomic64_set(&sfx_mdrv->coh_bio_proc_time, 0);
	sfx_atomic64_set(&sfx_mdrv->coh_thread_wake_time, 0);
	sfx_atomic64_set(&sfx_mdrv->req_init_time, 0);
	sfx_atomic64_set(&sfx_mdrv->hot_rd_req_intval, 0);
	sfx_atomic64_set(&sfx_mdrv->hot_wr_req_intval, 0);
	sfx_atomic64_set(&sfx_mdrv->last_req_time, 0);
	sfx_atomic64_set(&sfx_mdrv->req_interval_max, 0);
	sfx_atomic64_set(&sfx_mdrv->num_rd_req, 0);
	sfx_atomic64_set(&sfx_mdrv->num_wr_req, 0);
#endif
	sfx_atomic_set(&sfx_mdrv->outstanding_req, 0);
	sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->osd_req_num, 0);
	//init_per_cpu(sfx_mdrv->outstanding_size);
	sfx_atomic_set(&sfx_mdrv->outstanding_size, 0);
	sfx_atomic_set(&sfx_mdrv->tot_grown_bbd, 0);
	sfx_atomic_set(&sfx_mdrv->mdrv_removing, 0);
	sfx_atomic_set(&sfx_mdrv->ref_cnt_ioctl, 0);
	sfx_mdrv->rwr_me = 1;
#ifdef SFX_LINUX
	if (sfx_mdrv->en_sts) {
		xt_u32 idx;
		for (idx = 0; idx < IO_NUM_ENTRY; idx++) {
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].tot_num);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_2ms);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_8ms);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].tot_lat);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].tot_smt);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].tot_ccs);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_ccs_1ms);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_ccs_8ms);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_smt_1ms);
			init_per_cpu64(sfx_mdrv->rd_io_stat[idx].num_smt_8ms);
		}
		for (idx = 0; idx < IO_NUM_ENTRY; idx++) {
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].tot_num);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_2ms);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_8ms);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].tot_lat);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].tot_smt);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].tot_ccs);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_ccs_1ms);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_ccs_8ms);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_smt_1ms);
			init_per_cpu64(sfx_mdrv->wr_io_stat[idx].num_smt_8ms);
		}
	}
#endif
#if (HOT_READ_PERF || HOT_WRITE_PERF)
	sfx_atomic64_set(&sfx_mdrv->num_fresh_cmd, 0);
	sfx_atomic64_set(&sfx_mdrv->num_fresh_cmd_100, 0);
#endif

#if MEASURE_FUNC_TIME
	sfx_atomic64_set(&sfx_mdrv->nr_ccs_cb, 0);
	sfx_atomic64_set(&sfx_mdrv->nr_cb_enqueue, 0);
	sfx_atomic64_set(&sfx_mdrv->time_ccs_cb, 0);
	sfx_atomic64_set(&sfx_mdrv->time_cb_enqueue, 0);
#endif
#if PERFORMANCE
	sfx_atomic_set(&sfx_mdrv->active_host_rd_req, 0);
	sfx_atomic_set(&sfx_mdrv->active_host_wr_req, 0);
#endif
	sfx_mdrv->version = 0xFFFFFFFE;
	sfx_atomic_set(&sfx_mdrv->read_mode, 0);
	sfx_mdrv->ro_set_background = 0;
	sfx_atomic_set(&sfx_mdrv->nvme_fw_download, 1);
	sfx_atomic_set(&sfx_mdrv->nvme_reg_put, 1);
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(6, 5))
	sfx_spin_lock_init(&sfx_mdrv->io_acct_flag);
#endif
#endif
	sfx_memset(sfx_mdrv->nvme_elp, 0, sizeof(sfx_mdrv->nvme_elp));
	sfx_mdrv->nvme_elp_wptr = 0;

	sfx_spin_lock_init(&sfx_mdrv->nvme_elp_lock);
	sfx_spin_lock_init(&sfx_mdrv->grown_bbd_lock);
	sfx_spin_lock_init(&sfx_mdrv->mdrv_remove_lock);
	sfx_spin_lock_init(&sfx_mdrv->wl_gc_spin_lock);
	init_per_cpu64(sfx_mdrv->total_wr_cmds_sent_to_ccs_req);
	init_per_cpu64(sfx_mdrv->total_wr_cmds_rcvd_from_host_req);
	sfx_mdrv->blk_ftl_eh_exiting = 0;
	sfx_mdrv->enable_vu_flag = 0;
	sfx_mdrv->enable_vu_key = sfx_random();
}

static int sfx_mq_init(sfx_mul_drv *sfx_mdrv, ftl_mq_ctx *ftl_mq_ctx)
{
	unsigned int *rdmap = NULL, *wrmap = NULL;
	int error = NO_ERROR;
	sfx_thread_t assert_thread;
	xt_32 stream_num;
	io_latency_management_t *latency_mgt;
	io_latency_statistics_t *latency_stats;

#ifdef SFX_LINUX
	stream_num = (sfx_mdrv->multi_stream_mode == SINGLE_STREAM_MODE) ? SINGLE_STREAM : MULTI_STREAM;
#else
	stream_num = 1;
#endif
	rdmap = sfx_kzalloc_node0(sizeof(*rdmap) * sfx_num_possible_cpus(), SFX_GFP_NOIO, sfx_mdrv->numa_id);
	wrmap = sfx_kzalloc_node0(sizeof(*wrmap) * sfx_num_possible_cpus(), SFX_GFP_NOIO, sfx_mdrv->numa_id);

	if (!rdmap || !wrmap) {
		sfx_print(-1, BLK_SYS, PL_INF, "SFX block device allocate memory failed\n");
		error = -ENOMEM;

		goto ALLOC_ERR;
	}

	if (sfx_mq_get_cpu_queue_mapping(wrmap, rdmap, sfx_cpu_online_mask, &sfx_mdrv->ioq_config,
					 stream_num)) {
		sfx_print(-1, BLK_SYS, PL_INF, "SFX block device fail to allocate memory\n");
		error = -ENOMEM;

		goto ALLOC_ERR;
	}
	sfx_mdrv->cpu2wrqid_map = wrmap;
	sfx_mdrv->cpu2rdqid_map = rdmap;
	ftl_mq_ctx->cpu2wrqid_map = wrmap;
	ftl_mq_ctx->cpu2rdqid_map = rdmap;
	ftl_mq_ctx->ioq_config = &sfx_mdrv->ioq_config;
#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_atomic64_set(&ftl_mq_ctx->max_irq_time, 0);
	sfx_atomic64_set(&ftl_mq_ctx->num_irq, 0);
	sfx_atomic64_set(&ftl_mq_ctx->num_irq_100, 0);
#endif
#if MQ_CONFIG_DEBUG
	{
		unsigned int i;
		sfx_print(-1, BLK_SYS, PL_INF, "hot read cpu to qid mapping:\n");
		for_each_cpu (i, sfx_cpu_online_mask)
			sfx_print(-1, BLK_SYS, PL_INF, "    cpuid=%u, qid=%u\n", i,
				  sfx_mdrv->cpu2rdqid_map[i]);
		sfx_print(-1, BLK_SYS, PL_INF, "hot write cpu to qid mapping:\n");
		for_each_cpu (i, sfx_cpu_online_mask)
			sfx_print(-1, BLK_SYS, PL_INF, "    cpuid=%u, qid=%u\n", i,
				  sfx_mdrv->cpu2wrqid_map[i]);
	}
#endif

	sfx_spin_lock_init(&sfx_mdrv->poll_lock);
	sfx_mdrv->poll_ctx.thrd_direct_smt = 2;
	sfx_mdrv->num_stream = 1;
	sfx_mdrv->isolate = 0;
	sfx_mdrv->num_direct_cmpl = 128;
	if (sfx_bd_mq_resource_allocate(sfx_mdrv)) {
		error = -ENOMEM;
		goto ALLOC_ERR;
	}
	if (sfx_bd_mq_wq_init(sfx_mdrv)) {
		error = -ENOMEM;
		goto ALLOC_ERR;
	}
	sfx_init_waitqueue_head(&(sfx_mdrv->priv_thrds.assert_thread.wait));
#ifndef SFX_LINUX //ticket 2088
	sfx_atomic_set(&ftl_mq_ctx->hot_wr_pending, 0);
	sfx_atomic_set(&ftl_mq_ctx->hot_rd_pending, 0);
#endif
	sfx_atomic_set(&ftl_mq_ctx->ccs_init_done, 0);
	assert_thread = sfx_thread_create((sfx_thread_t *)(&(sfx_mdrv->priv_thrds.assert_thread.thread)),
					  sfx_assert_thread, (void *)sfx_mdrv, "sfx_assert_thrd");
	sfx_mdrv->priv_thrds.assert_thread.pid = sfx_thread_pid(assert_thread);
	blk_ftl_thread_init(sfx_mdrv, &sfx_mdrv->priv_thrds.assert_thread, SFX_PRIV_THREAD_SLOT_ASSERT);
	ftl_mq_ctx->ftl_ctx.blk_ftl_ctx = sfx_mdrv;
	/*sfx_print(-1, BLK_SYS, PL_LOG, "%s: Register sfx_mdrv %p [%p] to driver ftl ctx %p\n", __FUNCTION__,
		  sfx_mdrv, ftl_mq_ctx->ftl_ctx.blk_ftl_ctx, ftl_mq_ctx);*/

	// Allocate memory for IO Latency Statistics
	ftl_mq_ctx->latency_mgt.latency_stats =
		sfx_kzalloc_node0(sizeof(io_latency_statistics_t), SFX_GFP_NOIO, sfx_mdrv->numa_id);
	if (NULL == ftl_mq_ctx->latency_mgt.latency_stats) {
		sfx_print(-1, BLK_SYS, PL_INF,
			  "SFX block device allocates %dbytes "
			  "memory latency_stats failed\n",
			  sizeof(io_latency_statistics_t));
		error = -ENOMEM;

		goto ALLOC_ERR;
	}

	// Initialize IO Latency Statistics and
	// disable all flags as default
	latency_mgt = &ftl_mq_ctx->latency_mgt;
	latency_stats = latency_mgt->latency_stats;
	latency_mgt->latency_control = 0;

	// Reset version
	latency_mgt->version_major = 1;
	latency_mgt->version_minor = 0;

	// Reset each bucket in each group
	sfx_memset(latency_stats, 0, sizeof(io_latency_statistics_t));

	// Enable Read latency statistics process
	latency_mgt->lat_info_read = 1;
	latency_mgt->lat_info_write = 0;
	latency_mgt->lat_info_size = 0;
	latency_mgt->lat_info_valid = 1;

ALLOC_ERR:
	if (error) {
		sfx_destroy_spinlock(&sfx_mdrv->poll_lock);
		if (rdmap != NULL) {
			sfx_kfree(rdmap);
		}
		if (wrmap != NULL) {
			sfx_kfree(wrmap);
		}
	}
	return error;
}

static sfxError sfx_init_req_log(sfx_mul_drv *sfx_mdrv)
{
#ifdef SFX_LINUX
	if (sfx_mdrv->en_req_log) {
		blk_io_log_ctx *log_ctx = &sfx_mdrv->io_log_ctx;
		xt_u64 buf_iter = 0;
		void **buf;

		buf = sfx_alloc_pages_address(0);
		for (; buf_iter < (SFX_PAGE_SIZE / 8); buf_iter++) {
			((xt_u64 **)buf)[buf_iter] = (xt_u64 *)sfx_alloc_pages_address(0);
			if (((xt_u64 **)buf)[buf_iter] == (xt_u64 *)NULL) {
				sfx_print(-1, BLK_SYS, PL_WRN,
					  "Cannot allocate memory for "
					  "req_log, buf_idx=%u\n",
					  buf_iter);
				return ERROR_CODE;
			}
		}
		log_ctx->log_buf = buf;
		log_ctx->tot_cmd = 0;
		log_ctx->buf_idx = 0;
		log_ctx->inner_idx = 0;
	}
#endif
	return NO_ERROR;
}

static void sfx_release_req_log(sfx_mul_drv *sfx_mdrv)
{
#ifdef SFX_LINUX
	if (sfx_mdrv->en_req_log) {
		blk_io_log_ctx *log_ctx = &sfx_mdrv->io_log_ctx;
		void *page;
		xt_u32 buf_iter = 0;
		for (; buf_iter < NUM_LOG_BUF; buf_iter++) {
			page = (void *)((xt_u64 *)log_ctx->log_buf)[buf_iter];
			if (page) {
				sfx_free_pages_address(page, 0);
			}
		}
	}
#endif
}

#if HOT_RD_DATA_DEBUG
static void sfx_blk_rd_debug_init(sfx_mul_drv *sfx_mdrv)
{
	sfx_spin_lock_init(&sfx_mdrv->blk_rd_debug_lock);
	sfx_mdrv->blk_rd_debug_table =
		sfx_malloc(sizeof(blk_rd_debug_entry *) * HOT_RD_DEBUG_TABLE_ENTRY_NUM);
	for (sfx_mdrv->blk_rd_debug_idx = 0; sfx_mdrv->blk_rd_debug_idx < HOT_RD_DEBUG_TABLE_ENTRY_NUM;
	     sfx_mdrv->blk_rd_debug_idx++) {
		sfx_mdrv->blk_rd_debug_table[sfx_mdrv->blk_rd_debug_idx] =
			sfx_malloc(HOT_RD_DEBUG_BLK_ENTRY_SIZE);
		sfx_memset(sfx_mdrv->blk_rd_debug_table[sfx_mdrv->blk_rd_debug_idx], 0,
			   HOT_RD_DEBUG_BLK_ENTRY_SIZE);
	}
	sfx_mdrv->blk_rd_debug_idx = 0;
}

static void sfx_blk_rd_debug_release(sfx_mul_drv *sfx_mdrv)
{
	for (sfx_mdrv->blk_rd_debug_idx = 0; sfx_mdrv->blk_rd_debug_idx < HOT_RD_DEBUG_TABLE_ENTRY_NUM;
	     sfx_mdrv->blk_rd_debug_idx++) {
		sfx_mfree(sfx_mdrv->blk_rd_debug_table[sfx_mdrv->blk_rd_debug_idx]);
	}
	sfx_mfree(sfx_mdrv->blk_rd_debug_table);
}
#endif

extern int log_timer_thread(void *data);

#ifdef SFX_LINUX
void bd_mem_callback(sfv_mem *vmem)
{
	//sfx_print(-1, BLK_SYS, PL_INF, "%s(), vmem->sn %s \n", __FUNCTION__, vmem->sn);
	/* do whatever here */
}
#endif

static void sfx_mdrv_remove(sfx_mul_drv *sfx_mdrv);

int sfx_bd_probe(char *d_name, int nid, void *bd_param_in, void *ftl_cntx)
{
	int error = NO_ERROR;
	sfx_mul_drv *sfx_mdrv = NULL;
	ftl_global_ctx ftl_gctx;
	bd_param_t *bd_param = bd_param_in;

	if (!(sfx_mdrv = sfx_kzalloc_node0(sizeof(sfx_mul_drv), SFX_GFP_NOIO, nid))) {
		sfx_print(-1, BLK_SYS, PL_WRN, "SFX block device allocate memory failed\n");
		goto free;
	}

	/* process block device driver parameters passed from sfx_driver, if any */
	if (bd_param) {
		if (bd_param->intf_ver == 1) {
			sfx_mdrv->goldimg_dev = bd_param->goldimg;
			sfx_mdrv->comp_only = bd_param->comp_only;
			/*sfx_print(-1, BLK_SYS, PL_INF, "%s: gold image mode %u comp_only %u\n", __FUNCTION__,
				  sfx_mdrv->goldimg_dev, sfx_mdrv->comp_only);*/
			bd_param->dbg_lvl = change_dbg_lvl;
		} else {
			sfx_print(-1, BLK_SYS, PL_WRN,
				  "d_name %s, unsupported bd parameter interface version: %d\n", d_name,
				  bd_param->intf_ver);
		}
	} else {
		sfx_print(-1, BLK_SYS, PL_WRN, "OPN is not found in SFX device!\n");
		return -EPERM;
	}

	sfx_mdrv->heapid1 = bd_param->heapid1;
	sfx_mdrv->heapsz1 = bd_param->heapsz1;
	sfx_mdrv->heapid2 = bd_param->heapid2;
	sfx_mdrv->heapsz2 = bd_param->heapsz2;
	sfx_mdrv->dev_name = d_name;
	sfx_mdrv->numa_id = nid;
	sfx_mdrv->devId = bd_param->dev_id;
	sfx_mdrv->ftl_mq_ctx = ftl_cntx;
	sfx_mdrv->act_mode = 0;
#if (HOT_WRITE_PERF || HOT_READ_PERF)
	sfx_mdrv->en_sts = 1;
	sfx_mdrv->en_req_log = 1;
#else
	sfx_mdrv->en_sts = 0;
	sfx_mdrv->en_req_log = 1;
#endif
	sfx_mdrv->num_outlier = 0;
	sfx_mdrv->en_outlier_print = 0;
	sfx_mdrv->wr_outlier_thrd = 32; //in ms
	sfx_mdrv->rd_outlier_thrd = 32; //in ms

	/* Initialize as early as possible to handle probe phase exception. */
	SFX_INIT_LIST_HEAD(&sfx_mdrv->sfx_bd_list);

	if (ERROR_CODE == sfx_init_req_log(sfx_mdrv)) {
		goto free;
	}

#ifdef SFX_LINUX
	sfv_get_mem(bd_mem_callback, bd_param->sn);
#endif

#ifdef SFX_LINUX
	sfx_mdrv->multi_stream_mode = multi_stream;
	sfx_mdrv->discard_write_zeros = discard_write_zeros;
#else
	sfx_mdrv->multi_stream_mode = MULTI_STREAM_MODE;
	sfx_mdrv->discard_write_zeros = 0;
#endif
	sfx_memcpy(sfx_mdrv->opn, bd_param->opn, 32);
	sfx_memcpy(sfx_mdrv->sn, bd_param->sn, 32);
	sfx_memset(sfx_mdrv->firmware_rev, 0, sizeof(sfx_mdrv->firmware_rev));
	sfx_memcpy(sfx_mdrv->firmware_rev, bd_param->firmware_rev, sizeof(sfx_mdrv->firmware_rev) - 1);
	sfx_mdrv_init(sfx_mdrv);

	sfx_spin_lock(&g_sfx_probing_mul_drv_list_lock);
	sfx_list_add_tail(&sfx_mdrv->sfx_mdrv_list, &sfx_probing_mul_drv_list);
	sfx_spin_unlock(&g_sfx_probing_mul_drv_list_lock);

	sfx_mdrv_state_machine(sfx_mdrv, SFX_DEVICE_STATE_NOT_READY);

#if HOT_RD_DATA_DEBUG
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only))
		sfx_blk_rd_debug_init(sfx_mdrv);
#endif
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		error = sfx_mq_init(sfx_mdrv, ftl_cntx);
		if (error)
			goto free;

		sfx_mdrv->ftl_mq_ctx->debug_read = 0;
	} else { /* for sfx_mq_init_hctx */
		ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;

		if (sfx_mdrv->goldimg_dev) {
			ftl_cntx->drvg_ctx = sfx_kzalloc_node0((sizeof(struct sfx_drvq_ctx) * 1),
							       SFX_GFP_NOIO, sfx_mdrv->numa_id);
		} else if (sfx_mdrv->comp_only) {
			ftl_cntx->drvg_ctx = sfx_kzalloc_node0(
				(sizeof(struct sfx_drvq_ctx) * (MAX_R2C_QUEUE + MAX_EC_QUEUE)), SFX_GFP_NOIO,
				sfx_mdrv->numa_id);
		} else {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "Never reached\n");
		}
		if (!ftl_cntx->drvg_ctx) {
			error = -ENOMEM;
			goto free;
		}

		if (sfx_mdrv->comp_only) {
			if (sfx_bd_mq_comp_allocate(sfx_mdrv)) {
				error = -ENOMEM;
				goto free;
			}
		}
	}

	ftl_gctx.bd_param = bd_param;
#ifndef SFX_LINUX
	multi_stream = MULTI_STREAM_MODE;
#endif
	ftl_gctx.bd_param->multi_stream_mode = multi_stream;
	ftl_gctx.ftl_mq_ctx = ftl_cntx;
	ftl_gctx.bd_param->nor_dump = nor_dump;
	ftl_gctx.bd_param->debug_mode = debug_mode;
	ftl_gctx.bd_param->pe_preload = debug_mode ? pe_preload : 0;
	ftl_gctx.bd_param->hp_read = high_priority_read;
	ftl_gctx.bd_param->fast_cycle_mode = fast_cycle_mode;
	sfx_mdrv->fast_cycle_mode = fast_cycle_mode;

	error = sfx_blk_ftl_init(sfx_mdrv, &ftl_gctx);
	if (error == -EIO || error == -EPERM) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
		if (sfx_atomic_read(&sfx_mdrv->surprising_remove)) {
			sfx_mdrv_remove(sfx_mdrv);
			goto out_probe_free;
		}
		goto free;
	} else if (error == -ENOMEM) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
		goto out_probe_free;
	} else if (error == ERROR_DEVICE_GONE) {
		sfx_mdrv_remove(sfx_mdrv);
		goto out_probe_free;
	}

#if ENABLE_VDEV
#else
	error = sfx_mq_tagset(sfx_mdrv);
	if (error) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
		goto out_probe_free;
	}
#endif // ENABLE_VDEV

	error = sfx_bd_add_init(sfx_mdrv);
	if (error) {
		if (sfx_atomic_read(&sfx_mdrv->surprising_remove))
			sfx_mdrv_remove(sfx_mdrv);
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s:%d\n", __FUNCTION__, __LINE__);
		goto out_probe_free;
	}

	sfx_spin_lock(&g_sfx_probing_mul_drv_list_lock);
	sfx_list_del(&sfx_mdrv->sfx_mdrv_list);
	sfx_spin_unlock(&g_sfx_probing_mul_drv_list_lock);

	sfx_spin_lock(&g_sfx_mul_drv_list_lock);
	sfx_list_add_tail(&sfx_mdrv->sfx_mdrv_list, &sfx_mul_drv_list);
	sfx_spin_unlock(&g_sfx_mul_drv_list_lock);

	/*
     * Entry point to initialize ccs devices for DCE functionanlities.
     */
	if (!sfx_mdrv->goldimg_dev && bd_ccs_dev_init(d_name)) {
		/* Need to add error handling, print a message at least */
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s %d, bd_ccs_dev_init(%s) failed\n",
			  __FUNCTION__, __LINE__, d_name);
	}
	ftl_gctx.ftl_mq_ctx->ftl_ctx.device_ready = 1;

	sfx_mdrv->ttr_time = sfx_ktime_to_us(sfx_ktime_get());
	sfx_mdrv->ttr_time = sfx_mdrv->ttr_time - time_record;
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
		  "<=== %s Successfully probe "
		  "block FTL driver on CPU %u, BLK queue type %s\n",
		  __FUNCTION__, sfx_get_cpuid(),
		  ((SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ) ?
			   "multi-queue" :
			   ((SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ) ? "single-queue" : "bio")));

	/*
     * In case of error, the device_state has been set to other value.
     */
	if (sfx_atomic_read(&sfx_mdrv->device_state) == SFX_DEVICE_STATE_NOT_READY) {
		sfx_mdrv_state_machine(sfx_mdrv, SFX_DEVICE_STATE_RUNNING);
	}

	//readonly maybe set before bd_disk been register
	//which means the block ro status is not set successfully
	//need to set it ro again.
	if (sfx_atomic_read(&sfx_mdrv->read_mode)) {
		sfx_set_bd_ro_force(sfx_mdrv, 1);
	}

	if (sfx_mdrv->multi_stream_mode == SINGLE_STREAM_MODE) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "MAPLOG type is interleaved\n");
	} else {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "MAPLOG type is compact\n");
	}

	if (!sfx_mdrv->goldimg_dev) {
		record_multi_drv(sfx_mdrv->devId, sfx_mdrv);
		sfx_print(
			sfx_mdrv->devId, BLK_SYS, PL_LOG,
			"%s: Multi drive pointer %p recorded for devId = %d; pointer = %p after get pointer function called.\n",
			__FUNCTION__, sfx_mdrv, sfx_mdrv->devId, get_multi_drv(sfx_mdrv->devId));
		register_r2c_cb(sfx_mdrv->devId, handle_blk_ftl_r2c_read, handle_r2c_lba_pba);
	}

	ccs_set_blk_ftl_ready(sfx_mdrv->devId, 1);
	ccs_set_debug_level_all(sfx_mdrv->devId, 0);
	return error;

out_probe_free:
	if (sfx_mdrv) {
		ccs_set_blk_ftl_ready(sfx_mdrv->devId, 0);
		ccs_set_debug_level_all(sfx_mdrv->devId, 0);
	}
	if (!sfx_mdrv->goldimg_dev) {
		sfx_ftl_assert(sfx_mdrv, 0);
		sfx_exit_all_threads(sfx_mdrv);
		sfx_bd_mq_wq_release(sfx_mdrv);
	}
	return error;
free:
	if (sfx_mdrv) {
		ccs_set_blk_ftl_ready(sfx_mdrv->devId, 0);
		ccs_set_debug_level_all(sfx_mdrv->devId, 0);
		sfx_kfree(sfx_mdrv);
	}
	return error;
}

void get_host_bandwidth(sfx_mul_drv *sfx_mdrv, xt_u64 *host_write_bandwidth, xt_u64 *host_read_bandwidth,
			xt_u64 *output_time)
{
#if (MEASURE_TIME || ENABLE_FTL_MONITER)
	sfx_ktime_t time;
	xt_u64 time_ns;

	time = sfx_ktime_get();
	time_ns = (sfx_ktime_to_ns(time) - sfx_ktime_to_ns(sfx_mdrv->prev_time_linux_perf));
	*host_write_bandwidth = sfx_atomic64_read(&sfx_mdrv->total_write) * 4 * S_TO_NS / time_ns;
	*host_read_bandwidth = sfx_atomic64_read(&sfx_mdrv->total_read) * 4 * S_TO_NS / time_ns;
	*output_time = time_ns;

	sfx_atomic64_set(&sfx_mdrv->total_write, 0);
	sfx_atomic64_set(&sfx_mdrv->total_read, 0);
	sfx_mdrv->prev_time_linux_perf = time;
#endif
}

void blk_ftl_perf_linux_print(sfx_mul_drv *sfx_mdrv)
{
#if MEASURE_TIME
	if (sfx_mdrv->open_measure_time) {
		xt_u64 host_write_bandwidth;
		xt_u64 host_read_bandwidth;
		xt_u64 time_ns;

		get_host_bandwidth(sfx_mdrv, &host_write_bandwidth, &host_read_bandwidth, &time_ns);

		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Hot wr: %d KB/s, time_ns %d\n",
			  host_write_bandwidth, time_ns);
		sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Hot rd: %d KB/s, time_ns %d\n",
			  host_read_bandwidth, time_ns);
	}
#endif
}

void sfx_mdrv_ftl_perf_update(sfx_mul_drv *sfx_mdrv, ftl_moniter_t *ftl_moniter)
{
#if ENABLE_FTL_MONITER
	xt_u64 time_ns;

	get_host_bandwidth(sfx_mdrv, &(ftl_moniter->host_write_bandwidth),
			   &(ftl_moniter->host_read_bandwidth), &time_ns);

	gc_ftl_perf_update(sfx_mdrv, ftl_moniter);

	ftl_moniter->total_write_bandwidth = ftl_moniter->host_write_bandwidth +
					     ftl_moniter->gc_write_bandwidth +
					     ftl_moniter->wl_write_bandwidth;
	sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Hot wr: %d KB/s, time_ns %d\n",
		  ftl_moniter->host_write_bandwidth, time_ns);
	sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Hot rd: %d KB/s, time_ns %d\n",
		  ftl_moniter->host_read_bandwidth, time_ns);
	sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Cold wr: %d KB/s, time_ns %d\n",
		  ftl_moniter->gc_write_bandwidth, time_ns);
	sfx_print(sfx_mdrv->devId, BLK_PERF, PL_LOG, "Cold rd: %d KB/s, time_ns %d\n",
		  ftl_moniter->gc_read_bandwidth, time_ns);
#endif
}

bio_page_buf *alloc_bio_page_buf(sfx_mul_drv *sfx_mdrv, xt_u32 faker)
{
	bio_page_buf *page_buf;
	page_buf = kmem_malloc(sfx_mdrv->devId, sizeof(bio_page_buf));
	if (!page_buf) {
		return NULL;
	}

	if (!faker) {
#ifndef ALLOC_PAGE_INIT
#ifdef SFX_LINUX
		{
			sfx_page *page;
			page = kmem_valloc(sfx_mdrv->devId, SFX_PAGE_SIZE);
			if (!page) {
				kmem_free(page);
				return NULL;
			}
			page_buf->page_buf = page;
		}
#else
		page_buf->page_buf = kmem_valloc(sfx_mdrv->devId, SFX_PAGE_SIZE);
#endif
#endif

		if (!page_buf->page_buf) { // this may be allocated in constuctor of bio_buf_cache.
			free_bio_page_buf(page_buf);
			return NULL;
		}
		sfx_memset(page_buf->page_buf, 0x0, SFX_PAGE_SIZE);
	} else {
		page_buf->page_buf = NULL;
	}
	page_buf->len = 0;
	page_buf->off = 0;
	page_buf->data = 0;

	return page_buf;
}

void free_bio_page_buf(bio_page_buf *page_buf)
{
	if (!page_buf) {
		return;
	}

	if (page_buf->page_buf) {
		kmem_free(page_buf->page_buf);
		page_buf->page_buf = NULL;
	}
	kmem_mfree(page_buf);
	page_buf = NULL;
}

void blk_ftl_crash_trigger(sfx_mul_drv *sfx_mdrv, xt_u32 loc)
{
#ifdef CRASH_TRIGGER
	sfx_mdrv->crash_loc = loc;
	sfx_print(sfx_mdrv->devId, BLK_PF, PL_INF, "%s Set crash location %d\n", __FUNCTION__, loc);
#endif
}

#ifdef SFX_LINUX
static void fill_cpu_map(void)
{
	struct sfx_proc_map *proc_map;
	struct sfx_core_map *core_map;
	sfx_cpuinfo_x86 *c = &cpu_data(0);
	xt_u32 online_cpu_num = sfx_num_online_cpus();
	xt_u16 core_num_per_proc_valid = c->booted_cores;
	xt_u16 core_num_per_proc = c->booted_cores;
	xt_u16 proc_num = 0;
	xt_u16 sibling_num;
	xt_u16 core_num;
	xt_u16 max_core_id = 0;
	xt_u32 cpu_map_size;
	xt_u32 core_map_size;
	xt_u32 phys_proc_map_size;
	xt_u32 proc_map_size;
	xt_u32 i, j;
	g_cpu_map_mgm.cpu_pinning = 0;
	g_cpu_map_mgm.cgroup = 0;
	g_cpu_map_mgm.cgroup_step = 0;
	g_cpu_map_mgm.app_pin = 0;
	//get total processor package number. May have better way to get it.
	for (i = 0; i < online_cpu_num; i++) {
		c = &cpu_data(i);
		if (c->phys_proc_id > proc_num) {
			proc_num = c->phys_proc_id;
		}
		if (c->cpu_core_id > max_core_id) {
			//max_core_id may be bigger than core_num_per_proc
			//since some of the core_id may be skipped.
			max_core_id = c->cpu_core_id;
		}
	}
	proc_num++;
	core_num_per_proc = max_core_id + 1;
	core_num = core_num_per_proc * proc_num;
	sibling_num = online_cpu_num / (core_num_per_proc_valid * proc_num);

	cpu_map_size = sizeof(struct sfx_cpu_map) + sibling_num * sizeof(xt_u16);
	core_map_size = sizeof(struct sfx_core_map) + core_num * cpu_map_size;

	sfx_print(-1, BLK_SYS, PL_INF,
		  "core_num %d, valid core per proc %d, proc_num %d, sibling_num %d, "
		  "cpu_map_size %d, core_map_size %d\n",
		  core_num, core_num_per_proc_valid, proc_num, sibling_num, cpu_map_size, core_map_size);
	phys_proc_map_size = sizeof(struct sfx_phys_proc_map) + core_num_per_proc * sizeof(xt_u16);
	proc_map_size = sizeof(struct sfx_proc_map) + proc_num * phys_proc_map_size;

	proc_map = sfx_malloc(proc_map_size);
	sfx_memset(proc_map, 0, proc_map_size);
	core_map = sfx_malloc(core_map_size);
	sfx_memset(core_map, 0, core_map_size);
	g_cpu_map_mgm.proc_map = proc_map;
	g_cpu_map_mgm.core_map = core_map;

	proc_map->phys_proc_num = proc_num;
	proc_map->proc_map_size = phys_proc_map_size;
	core_map->core_num = core_num;
	core_map->valid_core_num = core_num_per_proc_valid * proc_num;
	core_map->cpu_map_size = cpu_map_size;

	for (i = 0; i < sfx_num_online_cpus(); i++) {
		struct sfx_phys_proc_map *phys_proc_map;
		struct sfx_cpu_map *cpu_map;
		xt_u16 proc_id, core_id;
		xt_u8 tmp;
		c = &cpu_data(i);
		proc_id = c->phys_proc_id;
		core_id = c->cpu_core_id + core_num_per_proc * proc_id;
		if (c->cpu_core_id >= core_num) {
			sfx_print(-1, BLK_SYS, PL_WRN,
				  "%s %d: CPU MAP populate failed! core_id %d, "
				  "core_num %d\n",
				  __FUNCTION__, __LINE__, c->cpu_core_id, core_num) goto out;
		}
		cpu_map = (struct sfx_cpu_map *)((xt_u8 *)(&core_map->cpu_map) +
						 core_map->cpu_map_size * core_id);
		sfx_print(-1, BLK_SYS, PL_INF, "cpu %d, core_id %d, cpu_map %p, sibling_num %d\n", i, core_id,
			  cpu_map, cpu_map->sibling_num);
		tmp = cpu_map->sibling_num;
		if (cpu_map->sibling_num >= sibling_num) {
			sfx_print(-1, BLK_SYS, PL_WRN,
				  "%s %d: CPU MAP populate failed! core_id %d,"
				  " proc_id %d, sibling_num %d\n",
				  __FUNCTION__, __LINE__, core_id, proc_id, cpu_map->sibling_num);
			goto out;
		}
		cpu_map->sibling_id[cpu_map->sibling_num++] = i;
		phys_proc_map = (struct sfx_phys_proc_map *)((xt_u8 *)(&proc_map->phys_proc_map) +
							     proc_map->proc_map_size * proc_id);
		if (!tmp) {
			if (phys_proc_map->core_num >= core_num_per_proc) {
				sfx_print(-1, BLK_SYS, PL_WRN,
					  "%s %d: CPU MAP populate failed!"
					  " core_id %d,"
					  " proc_id %d, core_num %d\n",
					  __FUNCTION__, __LINE__, core_id, proc_id, phys_proc_map->core_num);
				goto out;
			}
			phys_proc_map->cores[phys_proc_map->core_num++] = core_id;
		}
	}
	//print out final results
	for (i = 0; i < proc_num; i++) {
		struct sfx_phys_proc_map *phys_proc_map;
		phys_proc_map = (struct sfx_phys_proc_map *)((xt_u8 *)(&proc_map->phys_proc_map) +
							     proc_map->proc_map_size * i);
		sfx_print(-1, BLK_SYS, PL_INF, "Package %d: ", i);
		for (j = 0; j < phys_proc_map->core_num; j++) {
			sfx_print(-1, BLK_SYS, PL_INF, "%d ", phys_proc_map->cores[j]);
		}
		sfx_print(-1, BLK_SYS, PL_INF, "\n");
	}

	for (i = 0; i < core_num; i++) {
		struct sfx_cpu_map *cpu_map;
		cpu_map = (struct sfx_cpu_map *)((xt_u8 *)(&core_map->cpu_map) + core_map->cpu_map_size * i);
		sfx_print(-1, BLK_SYS, PL_INF, "core %d: ", i);
		for (j = 0; j < cpu_map->sibling_num; j++) {
			sfx_print(-1, BLK_SYS, PL_INF, "%d ", cpu_map->sibling_id[j]);
		}
		sfx_print(-1, BLK_SYS, PL_INF, "\n");
	}

	proc_map->filled = 1;
	core_map->filled = 1;
	g_cpu_map_mgm.cpu_pinning = sfx_cpu_pinning;
	g_cpu_map_mgm.cgroup = sfx_cgroup;
	g_cpu_map_mgm.cgroup_step = sfx_cgroup_step;
	g_cpu_map_mgm.app_pin = sfx_app_pin;

out:
	return;
}
#endif
int sfx_bd_init(void)
{
	int error = NO_ERROR;
#ifdef SFX_LINUX
	fill_cpu_map();
#endif
#if ENABLE_VDEV
#else
	sfx_bd_dev_major = register_blkdev(sfx_bd_dev_major, "nvme");
	if (((int)sfx_bd_dev_major) < 0) {
		return -EIO;
	}
#endif

	time_record = sfx_ktime_to_us(sfx_ktime_get());

	SFX_INIT_LIST_HEAD(&sfx_bd_driver.probe_pre_list);
	SFX_INIT_LIST_HEAD(&sfx_bd_driver.probe_ing_list);
	SFX_INIT_LIST_HEAD(&sfx_bd_driver.probe_done_list);
	SFX_INIT_LIST_HEAD(&sfx_bd_driver.probe_fail_list);
	sfx_spin_lock_init(&sfx_bd_driver.probe_list_lock);
	sfx_mutex_init(&g_create_nvmeq_lock);
	sfx_spin_lock_init(&g_sfx_mul_drv_list_lock);
	sfx_spin_lock_init(&g_sfx_probing_mul_drv_list_lock);
	if (sfx_register_driver(&sfx_bd_driver)) {
		sfx_print(-1, BLK_SYS, PL_WRN, "SFX driver(%s) register failed.\n", sfx_bd_driver.name);
	} else {
		sfx_print(-1, BLK_SYS, PL_INF, "SFX driver(%s) is registered.\n", sfx_bd_driver.name);
	}
	return error;
}
EXPORT_SYMBOL(sfx_bd_init);

static void sfx_mdrv_remove(sfx_mul_drv *sfx_mdrv)
{
	sfx_atomic_set(&sfx_mdrv->ftl_mq_ctx->state_remove, 1);
	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
		sfx_list_del(&sfx_mdrv->sfx_mdrv_list);
		if (sfx_mdrv->comp_only) {
			bd_ccs_per_dev_exit(sfx_mdrv->dev_name);
		}
		CCS_DestroyTable(sfx_mdrv->devId);
		if (sfx_mdrv->ftl_mq_ctx->drvg_ctx)
			sfx_kfree(sfx_mdrv->ftl_mq_ctx->drvg_ctx);
		return;
	}

	ccs_erase_point_config(sfx_mdrv->devId, 0, 64, 1);
	sfx_exit_all_threads(sfx_mdrv);
	sfx_blk_ftl_bg_check_thread_exit(sfx_mdrv);
	sfx_bd_mq_wq_release(sfx_mdrv);
#if HOT_RD_DATA_DEBUG
	sfx_blk_rd_debug_release(sfx_mdrv);
#endif
	sfx_list_del(&sfx_mdrv->sfx_mdrv_list);
	/* Remove ccs dev one by one */
	bd_ccs_per_dev_exit(sfx_mdrv->dev_name);
	CCS_DestroyTable(sfx_mdrv->devId);
	sfx_kthread_stop(sfx_mdrv->priv_thrds.assert_thread);
	sfx_defer_smt_free(sfx_mdrv);
	sfx_bd_mq_resource_release(sfx_mdrv);
}

void remove_one_mdrv(sfx_mul_drv *sfx_mdrv, int keep_disk)
{
	xt_32 ret = 0;
	sfx_bd_device *sfx_bd, *next;
	unsigned long flag = 0;

	if (!sfx_atomic_read(&sfx_mdrv->mdrv_removing)) {
		sfx_spin_lock_irqsave(&sfx_mdrv->mdrv_remove_lock, flag);
		if (!sfx_atomic_read(&sfx_mdrv->mdrv_removing)) {
			sfx_atomic_set(&sfx_mdrv->mdrv_removing, 1);
			sfx_spin_unlock_irqrestore(&sfx_mdrv->mdrv_remove_lock, flag);
		} else {
			sfx_spin_unlock_irqrestore(&sfx_mdrv->mdrv_remove_lock, flag);
			return;
		}
	} else {
		return;
	}

	if (!sfx_atomic_read(&sfx_mdrv->surprising_remove) &&
	    !(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		map_log_flush_ctx *ml_ctx;
		unsigned long flags;
		ml_ctx = &sfx_mdrv->ftl_mq_ctx->ml_flush_ctx[SFX_STREAM_ID];
		if (sfx_atomic_read(&ml_ctx->ml_ready)) {
			xt_u32 mem_id = mim_peek_open_fifo(sfx_mdrv, MIM_HOT_STREAM0, &flags);
			sfx_wake_up_interruptible(&(sfx_mdrv->ftl_mq_ctx->defer_smt->defer_smt_thread->wait));
			if (sfx_mdrv->multi_stream_mode != SINGLE_STREAM_MODE)
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s %d:wrong multi str mod %x\n",
					  __FUNCTION__, __LINE__, sfx_mdrv->multi_stream_mode);
			fm_flush_dummy_user_data_with_maplog(sfx_mdrv, mem_id, 1, 0);
		}
	}

	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s %d: active pu %u\n", __FUNCTION__, __LINE__,
			  ((mim_mem_id_t *)sfx_mdrv->gpmem_id)->pu_res.active_pu);
	} else {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s %d: goldimg_dev %u comp_only %u\n",
			  __FUNCTION__, __LINE__, sfx_mdrv->goldimg_dev, sfx_mdrv->comp_only);
	}

	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
#if ENABLE_VDEV
		if (!sfx_atomic_read(&sfx_mdrv->surprising_remove) && sfx_bd) {
			sfv_device *vdev = (sfv_device *)sfx_bd->sfx_bd_queue->queuedata;

			if (!sfx_atomic_test_and_set(&vdev->queue_stopped, 1)) {
				sfx_bd_stop_queue(sfx_bd->sfx_bd_queue);
				sfx_print(-1, BLK_SYS, PL_INF, "%s: queue stopped\n", __func__);
				msleep_interruptible(100); /* give block driver some time to digest */
			}
		}
#else // ENABLE_VDEV
		if (sfx_bd && !sfx_atomic_read(&sfx_mdrv->surprising_remove)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG, "%s: stop sfx_bd %p\n", __FUNCTION__,
				  sfx_bd);
			sfx_bd_stop_queue(sfx_bd->sfx_bd_queue);
		}
#endif // ENABLE_VDEV
	}

	sfx_mdrv_remove(sfx_mdrv);

	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
		if (!sfx_bd) {
			sfx_print(-1, BLK_SYS, PL_WRN, "%s: sfx_bd null pointer\n", __func__);
			continue;
		}
		//sfx_print(-1, BLK_SYS, PL_INF, "%s: sfx_bd %p removed\n", __func__, sfx_bd);
#if ENABLE_VDEV
		if (!sfx_atomic_read(&sfx_mdrv->surprising_remove) && keep_disk) {
			sfx_disconnect_disk(sfx_bd, 1);
		} else {
			volatile uintptr_t iptr = sfx_mdrv->devId;
			//it is surpring remove. has to set queue dying
			//to prevent futher traffic from kernel
#ifdef SFX_LINUX
			sfx_bd_set_queue_dying(sfx_bd->sfx_bd_queue);
#endif
			/*gendisk might not be freed as mount or fio, need clear private_data pointer before del_gendisk*/
			/*
			 * Use a hack way to saving ida_instance of sfx_dev to gendisk->private_data field so that we
			 * can release the ida_instance in .release() cb func when disk is finally free to system
			 * */
			SFX_INFO("del_gendisk, saving ida instance %d to private_data\n", (int)iptr);
			sfx_bd->sfx_bd_disk->private_data = (void *)iptr;
			sfx_disconnect_disk(sfx_bd, 0);
		}
#endif // ENABLE_VDEV
		sfx_bd_free(sfx_bd);
	}

#if ENABLE_VDEV
#else
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	blk_mq_free_tag_set(sfx_mdrv_mq_tag_set(sfx_mdrv));
#endif
#endif // ENABLE_VDEV
	if ((ret = sfx_device_close(&sfx_mdrv->dev_handle)) < 0) {
		sfx_print(-1, BLK_SYS, PL_ERR, "%s: Cannot close %s\n", __func__, sfx_mdrv->dev_name);
	} else {
		sfx_print(-1, BLK_SYS, PL_INF, "%s: %s closed, refcnt %d\n", __func__, sfx_mdrv->dev_name,
			  ret);
		/* ret should be 0 */
		if (ret) {
			sfx_dump_stack();
			BUG();
		}
	}
#ifdef SFX_LINUX
	if (sfx_mdrv->en_sts) {
		xt_u32 idx;
		for (idx = 0; idx < IO_NUM_ENTRY; idx++) {
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].tot_num);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_2ms);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_8ms);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].tot_lat);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].tot_smt);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].tot_ccs);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_ccs_1ms);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_ccs_8ms);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_smt_1ms);
			sfx_free_percpu(sfx_mdrv->rd_io_stat[idx].num_smt_8ms);
		}
		for (idx = 0; idx < IO_NUM_ENTRY; idx++) {
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].tot_num);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_2ms);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_8ms);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].tot_lat);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].tot_smt);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].tot_ccs);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_ccs_1ms);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_ccs_8ms);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_smt_1ms);
			sfx_free_percpu(sfx_mdrv->wr_io_stat[idx].num_smt_8ms);
		}
	}
#endif
	sfx_destroy_spinlock(&sfx_mdrv->nvme_elp_lock);
	sfx_destroy_spinlock(&sfx_mdrv->mdrv_remove_lock);
	sfx_destroy_spinlock(&sfx_mdrv->grown_bbd_lock);
	sfx_destroy_spinlock(&sfx_mdrv->wl_gc_spin_lock);
	sfx_release_req_log(sfx_mdrv);
	sfx_kfree(sfx_mdrv);
}

void sfx_mdrv_check_osd_req(ftl_mq_ctx *ftl_mq_ctx)
{
	sfx_mul_drv *sfx_mdrv, *next;

	sfx_spin_lock(&g_sfx_mul_drv_list_lock);
	sfx_list_for_each_entry_safe(sfx_mdrv, next, &sfx_mul_drv_list, sfx_mdrv_list)
	{
		if (sfx_mdrv->ftl_mq_ctx == ftl_mq_ctx)
			blk_ftl_finish_reqs_in_freeze(sfx_mdrv);
	}
	sfx_spin_unlock(&g_sfx_mul_drv_list_lock);
}

xt_32 sfx_mdrv_single_remove(ftl_mq_ctx *ftl_mq_ctx, int keep_disk)
{
	sfx_mul_drv *sfx_mdrv, *next;

	sfx_spin_lock(&g_sfx_mul_drv_list_lock);
	sfx_list_for_each_entry_safe(sfx_mdrv, next, &sfx_mul_drv_list, sfx_mdrv_list)
	{
		ccs_set_debug_level_all(sfx_mdrv->devId, 1);
		if (sfx_mdrv->ftl_mq_ctx == ftl_mq_ctx) {
			//TODO: Do we need to filter out jitter
			/*
			 * nvme reset support
			 * Do not do sfx_mdrv->outstanding_req check to let driver not going surprise_remove state
			 * so that vdev can suspending the request
			 */
			xt_u32 surprising_remove = ((sfx_get_pci_bar_csts(&sfx_mdrv->dev_handle) == -1) ||
						    sfx_atomic_read(&ftl_mq_ctx->vir_surprise_remove));
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
				  "Going to remove %s, surprising_remove %d\n", sfx_mdrv->dev_name,
				  surprising_remove);
			if (surprising_remove) {
				ccs_set_surprising_remove(sfx_mdrv->devId);
				while (ccs_get_inflight_cb_cnt(sfx_mdrv->devId))
					sfx_usleep(10);
				sfx_atomic_set(&sfx_mdrv->surprising_remove, 1);
			}

			/*wait until format finish*/
			while (sfx_atomic_read(&(sfx_mdrv->se_in_progress)) != 0) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
					  "%s: ses erase is in progress, wait\n", sfx_mdrv->dev_name);
				sfx_msleep(500);
			}
			remove_one_mdrv(sfx_mdrv, keep_disk);
			break;
		}
	}
	sfx_spin_unlock(&g_sfx_mul_drv_list_lock);

	return 0;
}

int sfx_mdrv_single_dev_gone(char *d_name)
{
	sfx_mul_drv *sfx_mdrv, *next;

	sfx_print(-1, BLK_SYS, PL_INF, "SFX block device gone\n");
	sfx_spin_lock(&g_sfx_mul_drv_list_lock);
	sfx_list_for_each_entry_safe(sfx_mdrv, next, &sfx_mul_drv_list, sfx_mdrv_list)
	{
		if (!sfx_strcmp(sfx_mdrv->dev_name, d_name)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s is marked as gone\n",
				  sfx_mdrv->dev_name);
			ccs_set_surprising_remove(sfx_mdrv->devId);
			sfx_atomic_set(&sfx_mdrv->surprising_remove, 1);
			break;
		}
	}
	sfx_spin_unlock(&g_sfx_mul_drv_list_lock);

	sfx_spin_lock(&g_sfx_probing_mul_drv_list_lock);
	sfx_list_for_each_entry_safe(sfx_mdrv, next, &sfx_probing_mul_drv_list, sfx_mdrv_list)
	{
		if (!sfx_strcmp(sfx_mdrv->dev_name, d_name)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s is marked as gone\n",
				  sfx_mdrv->dev_name);
			ccs_set_surprising_remove(sfx_mdrv->devId);
			sfx_atomic_set(&sfx_mdrv->surprising_remove, 1);
			break;
		}
	}
	sfx_spin_unlock(&g_sfx_probing_mul_drv_list_lock);
	return 0;
}

void sfx_bd_exit(void)
{
#ifdef SFX_LINUX // for vmware compiling
#if ENABLE_VDEV
	sfxError error;
#endif
#endif
	//sfx_print(-1, BLK_SYS, PL_INF, "%s\n", __FUNCTION__);
#ifdef SFX_LINUX // for vmware compiling
#if ENABLE_VDEV
	sfx_wait_probe_finish(&sfx_bd_driver);

	/* notify virtual device driver to decouple us from exported disk(s) */
	error = sfv_unregister();
	if (error != NO_ERROR) {
		sfx_print(-1, BLK_SYS, PL_WRN, "%s failed error code %d\n", __FUNCTION__, error);
		return;
	}
#endif // ENABLE_VDEV
#endif

	if (sfx_unregister_driver(&sfx_bd_driver))
		sfx_print(-1, BLK_SYS, PL_WRN, " SFX driver (%s) unregister failed.\n", sfx_bd_driver.name);
	sfx_destroy_spinlock(&sfx_bd_driver.probe_list_lock);
	bd_ccs_dev_exit();
	//sfx_print(-1, BLK_SYS, PL_INF, "SFX block device is removed\n");

#if ENABLE_VDEV
#else
	unregister_blkdev(sfx_bd_dev_major, "nvme");
#endif
	sfx_mutex_destroy(&g_create_nvmeq_lock);
	sfx_destroy_spinlock(&g_sfx_mul_drv_list_lock);
	sfx_print(-1, BLK_SYS, PL_INF, "SFX block device exit\n");
}
EXPORT_SYMBOL(sfx_bd_exit);

xt_u32 get_atomic_wr_from_host(void)
{
	return atomic_wr;
}

xt_u32 get_multi_stream(void)
{
	return multi_stream;
}

sfx_bool sfx_set_and_fetch_bd_ro(sfx_mul_drv *sfx_mdrv, xt_8 read_only_mode)
{
	sfx_bd_device *sfx_bd, *next;
	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
		sfx_set_device_ro(sfx_bd->sfx_bd_disk, read_only_mode);
		if (sfx_bdev_read_only(sfx_bd->sfx_bd_disk) != read_only_mode)
			return FALSE;
	}
	return TRUE;
}

static void sfx_set_bd_ro_force(sfx_mul_drv *sfx_mdrv, xt_8 read_only_mode)
{
	sfx_bd_device *sfx_bd, *next;
	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
		xt_u32 loop = 0;
		sfx_set_device_ro(sfx_bd->sfx_bd_disk, read_only_mode);
		while (sfx_bdev_read_only(sfx_bd->sfx_bd_disk) != read_only_mode) {
			sfx_set_device_ro(sfx_bd->sfx_bd_disk, read_only_mode);
			sfx_usleep(100);
			loop++;
			if (loop > 50000) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "%s: block device [%s] ro set fail,"
					  " timeout more thant 5s\n",
					  __FUNCTION__, sfx_mdrv->dev_name);
				break;
			}
		}
		if (loop > 50000) {
			sfx_mdrv->ro_set_background = 1;
			break;
		}
	}
}

static void sfx_mdrv_state_machine_readonly(sfx_mul_drv *sfx_mdrv, xt_8 read_only_mode)
{
	sfx_bd_device *sfx_bd, *next;

	/* block device RO mode */
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: block device [%s] read only mode is set to %d.\n",
		  __FUNCTION__, sfx_mdrv->dev_name, read_only_mode);
	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
		sfx_set_device_ro(sfx_bd->sfx_bd_disk, read_only_mode);
	}

	/* blk_ftl readonly mode */
	sfx_atomic_set(&sfx_mdrv->read_mode, read_only_mode);
}

void sfx_mdrv_state_machine(void *mdrv, sfx_device_state state)
{
	sfx_mul_drv *sfx_mdrv = mdrv;

	switch (state) {
	case SFX_DEVICE_STATE_NOT_READY:
		break;

	case SFX_DEVICE_STATE_RUNNING:
		if (sfx_atomic_read(&sfx_mdrv->device_state) == SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS ||
		    sfx_atomic_read(&sfx_mdrv->device_state) == SFX_DEVICE_STATE_READONLY_BY_DATALOSS) {
			ccs_reset_data_loss_mode(sfx_mdrv->devId);
		}
		sfx_mdrv_state_machine_readonly(sfx_mdrv, 0);
		break;

	case SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS:
	case SFX_DEVICE_STATE_READONLY_BY_DATALOSS:
		ccs_set_data_loss_mode(sfx_mdrv->devId);
		/* fall through */
	case SFX_DEVICE_STATE_READONLY:
		sfx_mdrv_state_machine_readonly(sfx_mdrv, 1);
		break;

	case SFX_DEVICE_STATE_FREEZE: /* TODO */
	case SFX_DEVICE_STATE_REMOVE: /* TODO */
	default:
		sfx_ftl_assert(sfx_mdrv, 0);
		break;
	}

	sfx_atomic_set(&sfx_mdrv->device_state, state);
	/*sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: %s device_state set to %d (%s).\n", __FUNCTION__,
		  sfx_mdrv->dev_name, sfx_atomic_read(&sfx_mdrv->device_state),
		  sfx_device_state_get(sfx_atomic_read(&sfx_mdrv->device_state)));*/
}

//restore from freeze or read only
int sfx_mdrv_restore_state(void *mdrv)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)mdrv;
	sfx_device_state state = sfx_atomic_read(&sfx_mdrv->device_state);

	if (ccs_is_nonassert_readonly(sfx_mdrv->devId)) {
		ccs_clear_read_only_signal(sfx_mdrv->devId);
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: current state.%d\n", __FUNCTION__, state);
	/* Sanity Check: input. */
	if (state != SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS && state != SFX_DEVICE_STATE_READONLY_BY_DATALOSS &&
	    state != SFX_DEVICE_STATE_READONLY) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: not in abormal state\n", __FUNCTION__);
		return 1;
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: clear read only state\n", __FUNCTION__);
	sfx_atomic_set(&sfx_mdrv->device_state, SFX_DEVICE_STATE_RUNNING);
	sfx_mdrv_state_machine_readonly(sfx_mdrv, 0);
	return 0;
}

module_init(sfx_bd_init);
module_exit(sfx_bd_exit);
MODULE_LICENSE("Proprietary");
MODULE_AUTHOR("software engineers@scaleflux");
MODULE_DESCRIPTION("SFX_BD_DEV");
/* SFX_SW_VERSION is dynamically defined in version_tmp.h */
MODULE_VERSION(SFX_SW_VERSION);
