// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : gc.h
//
// ---------------------------------------------------------------------------

#ifndef __GC_H__
#define __GC_H__

#include "sfx_os_headers.h"
#include "ccs_api.h"
#include "mem_id_mgr.h"

#define GC_DEBUG
#define GC_DUMMY_LBA                        0xDEADBAAD
#define GC_EARLY_SEALED_FIFO_SIZE           (GC_TOTAL_DONE_FIFO_ALLOC)

#define GC_TOTAL_DONE_FIFO                  (MIM_TOTAL_USER_MEM_ID)
#define GC_TOTAL_DONE_FIFO_ALLOC            (MIM_TOTAL_MEM_ID_ALLOCATE)     // alloc more space than needed
#define GC_TOTAL_LBA_READ_PENDING           (SYSTEM_UNIT / FOUR_KB_PER_MAPPING_UNIT)
#define FREE_SPACE_CONST                    1024

#define NUMBER_OF_MAX_MULTI_STREAM               (3)
#define MAX_NUMBER_OF_CANDIDATES_IN_A_STREAM     (20)

///////////////////////////////////////////////////////////////////////////////
//extra +2 for unalign and separate entry for flush maplog and footer
#define GC_MAX_WRITE_BUFFER_PER_MEM_ID_MAX  (9218)  //9218 for 6.4T B17A card     //(8194)      // max value for 6.4TB
#define GC_MAX_WRITE_BUFFER_PER_MEM_ID      (MIM_MEM_ID_DEFAULT_SIZE / SYSTEM_UNIT + 2)

#define GC_TOTAL_CANDIDATE_FIFO             (16)
#define GC_START_TRIGGER                    (sfx_mdrv->fast_cycle_mode ? 5 :(sfx_mdrv->card_info.free_block_fifo_size + sfx_mdrv->card_info.free_block_fifo_size + 6))
#define GC_STOP_TRIGGER                     (GC_START_TRIGGER + (sfx_mdrv->fast_cycle_mode ? 2 : 6))
#define GC_THROTTLE_WRITE                   (GC_START_TRIGGER - (sfx_mdrv->fast_cycle_mode ? 3 : 8))
#define GC_START_TRIGGER_ACT_MODE           (GC_START_TRIGGER + (sfx_mdrv->fast_cycle_mode ? 2 : 4))
#define GC_STOP_TRIGGER_ACT_MODE            (GC_STOP_TRIGGER + (sfx_mdrv->fast_cycle_mode ? 2 : 4))
#define WL_STOP_TRIGGER                     (GC_STOP_TRIGGER)
#define WL_START_TRIGGER                    (GC_START_TRIGGER)
#define WL_FREE_SPACE_RATIO_THRD            (128)
#define WL_LESS_VALID_THRD                  (7)
///////////////////////////////////////////////////////////////////////////////

#define GC_LBA_PER_BUFFER                   (SYSTEM_UNIT / FOUR_KB_PER_MAPPING_UNIT)
#define GC_LBA_PER_BUFFER_ALLOCATE                  (SYSTEM_UNIT_ALLOCATE / FOUR_KB_PER_MAPPING_UNIT)
#define GC_PREAD_SIZE                       ((GC_LBA_PER_BUFFER + EXTRA_PREAD_WRITE) * 3)
#define GC_MAX_GATHER_PENDING               4//(gc->gc_max_gather_pending)      // 8MB
#define GC_READ_1MB                         16//(gc->gc_read_size)
#define GC_MAX_DEALLOC_PENDING_MEM_ID       2
#define GC_CREDIT_INCREASE                  (3000)

#define CONTEXT_SIZE                        (sizeof(void *))

#define TOTAL_GC_BUFFER                     137     // 137 * 512Kb = 68.5MB
#define GC_MAX_PARITY_BUFFER_MAX            (8)
#define GC_MAX_PARITY_BUFFER                (sfx_mdrv->blk_ft_cfg.gc_parity_buffers)

#define TOTAL_MAP_LOG_READ_AHEAD            64

typedef enum
{
    GC_0_INIT,
    GC_1_IDLE,
    GC_2_SELECT_MEM_ID_ALGORITHM,
    GC_5_GATHER_COLD_DATA,
    GC_6_MOVE_DATA,
    GC_7_EXIT_BACKGROUND_LOOP,
    GC_99_EXIT_START,
    GC_99_EXIT_DONE,
} GC_STATE_E;

typedef enum
{
    WL_0_INIT,
    WL_1_IDLE,
    WL_2_SELECT_MEM_ID_ALGORITHM,
    WL_3_GC_HOT_DATA,
    WL_4_GC_COLD_DATA,
    WL_5_EXIT_START,
    WL_6_EXIT_DONE,
} WL_STATE_E;

enum
{
    WL_COLD_HAS_LESS_DATA = 0,
    WL_COLD_HAS_MORE_DATA,
};
typedef enum
{
    WL_0_HOT,
    WL_1_COLD,
} WL_TYPE;

typedef struct gc_map_log_s
{
    //read is issued to ccs layer, waiting for maplog data read done come back
    xt_u8 is_read_pending;
    //finished read, map log data is valid
    xt_u8 is_read_done;
    //map log read is done in ccs thread, can copy the maplog to map_original
    xt_u8 need_copy_original;
    xt_u8 unused;
    map_log_t *pmap_log;
    map_log_t *pmap_log_original;   //use for lba to map conversion
} gc_map_log_t;

typedef struct gc_lba_info_s
{
    flat_map_t new_map;
    flat_map_t candidate_map;
    xt_u32 type;
} gc_lba_info_t;


typedef struct map_log_sort_grp_s
{
    xt_u32  free_space;
    xt_u32  log_index;
} map_log_sort_grp_t;

typedef struct gc_write_s
{
    //forced write this gc_write_t entry even if buffer is not fill up full
    xt_u32 forced_write;
    //this buffer is the last buffer, we will do some clean up
    xt_u32 start_sealing;

    //gc open mem_id for this gc buffer
    xt_u16 mem_id;
    //counter for number of 4k pending read in to this gc buffer
    xt_u16 gather_pending_count;
    //counter for number of 4k done reading in to this gc buffer
    xt_u16 gather_done_count;  // this is incremented in the read/copy callback, max is 496
    //the latest offset to read more data in to this buffer until buffer is full
    xt_u32 wr_offset;  //this is for gather data in to pwr_buff
    //use to store the static buffer index we used for this
    //write buffer. will free this index after write is
    //done
    xt_u32 fifo_buff_index[SYSTEM_UNIT_ALLOCATE / SYSTEM_WRITE_UNIT + ((SYSTEM_UNIT_ALLOCATE % SYSTEM_WRITE_UNIT != 0) ? 1 : 0)];
    //buff that holds 1 super page about 2Mb data
    //it is break down to 512Kb granularity
    //we need to write the entire 2Mb at one time or the system will hang
    xt_u8 *pwr_buff[SYSTEM_UNIT_ALLOCATE / SYSTEM_WRITE_UNIT + ((SYSTEM_UNIT_ALLOCATE % SYSTEM_WRITE_UNIT != 0) ? 1 : 0)];
    //store all the lba in this gc buffer that we will write
    gc_lba_info_t param[GC_LBA_PER_BUFFER_ALLOCATE];  //per write buffer param
    //index in to pcandidate_mem_id, these 2 contains all the candidate
    //mem_id that we gather data in to this gc buffer
    xt_u32 candidate_mem_id_index;
    xt_u32 *pcandidate_mem_id;
    sfx_lba_list lba_list;
    xt_u32 system_unit;  //varied based on bad block and parity.
} gc_write_t;

typedef struct gc_param_s
{
    //current active log index that we try to gather data to gc buffer
    //is is valid only if this mem_id is the gc candidate
    volatile xt_u32 log_index;
    //store map log info that we are gathering.
    gc_map_log_t log[MAP_LOGS_PER_MEM_ID_MAX];
    map_log_sort_grp_t log_grp[MAP_LOGS_PER_MEM_ID_MAX];
    xt_u32 map_log_size;   //accumulate map log size during remapping
    xt_u32 map_log_entry_index;  //keep track so we don't add the size multiple times

    //mem_id candidate status that need to be deallocate when all move done
    xt_u32 move_pending;    //number of write entries, update in gather
    xt_u32 move_done;       //number of write entries, update in move data callback
    xt_u32 select_candi_count;   //how many times we select this mem_id as candidate
    //last written location mem_id and offset. should not deallocate if not
    //written to this address yet
    flat_map_t dealloc;
    xt_u32 last_gather_index;   //last gather index belong the the candidate
    xt_u8 direct_dealloc; //when we find some memid with all invalid data,
                          //will directly deallocate
} gc_param_t;

typedef struct gc_hot_data_s
{
    lba_t lba;      //hot data lba that need to write to gc open mem_id
    void *pbuffer;  //buffer contains lba data
    void *context;  //for callback when done gc append
    xt_u8 is_buffer_valid;
} gc_hot_data_t;

typedef struct gc_read_entry_s
{
    xt_u32 mim_mem_id;
    xt_u32 mem_id;
    xt_u32 offset;
    xt_u32 length;  // maximum value it can have is SYSTEM_UNIT
    xt_u32 gc_gather_index;
    xt_u32 is_last_map_log;
    void *pmap;
    xt_u32 skip_gc;
    xt_u32 flush_required;
    lba_t start_lba;
} gc_read_entry_t;

typedef struct gc_read_s
{
    xt_32 index;
    gc_read_entry_t *entry;
} gc_read_t;

typedef struct gc_s
{
    GC_STATE_E wr_thrd_state;   //gc write thread state
    GC_STATE_E rd_thrd_state;   //gc read thread state
    GC_STATE_E wl_thrd_state;   //gc wear level thread state
    //gc state machine need to stop gracefully because of upper layer
    sfx_atomic_t is_stop_triggered;
    //gc thread is sleep != 0, 0 = awake
    sfx_atomic_t is_wr_thrd_sleeping;
    sfx_atomic_t is_rd_thrd_sleeping;
    //if gc read fail, halt gc process
    sfx_atomic_t is_read_fail;
    xt_u32 is_gc_init_done;
    //try to slowly stop gc because is_stop_triggered is on
    xt_u32 block_gather_cold_data;
    //other thread wake up gc for various reasons
    //sfx_atomic_t gc_need_wake_up;
    sfx_atomic_t gc_wr_need_wake_up;
    sfx_atomic_t gc_rd_need_wake_up;
    xt_u32 is_read_ahead_done;  //flag to trigger move data when read is done
    //gather index is used for reading data in to gc buffer, it is index in to the
    //*pwr super page buffer
    xt_u32 gather_index;
    //wr index is used for writing the gc buffer pwr in to gc open mem_id.
    xt_u32 wr_index;
    //pwr contains information about 1 super page buffer inside the open gc mem_id.
    //pwr pointer arrays covers current gc open mem_id and seal pending gc mem_id.
    //However, only some entries are valid, the rest is invalid because
    //of memory limitation.
    gc_write_t *pwr[GC_MAX_WRITE_BUFFER_PER_MEM_ID_MAX];

    // wait q head declarations
#ifdef __SFX_KERNEL__
    sfx_wait_queue_head_t gc_thread_wait;
#endif

    // Mutex declarations
    sfx_spinlock_t gather_done_spin_lock;
    sfx_spinlock_t gc_buffer_spin_lock;
    sfx_spinlock_t gc_static_buffer_spin_lock;
    sfx_spinlock_t gc_early_seal_fifo_spin_lock;
    sfx_mutex_t gc_insert_candidate_mutex;

#ifndef __SFX_KERNEL__
    sfx_mutex_t gc_sleep_mutex;
#endif
    //contains parameter for all gc candidate mem_id, this is used for gc
    //gather data.  only the latest gc candidate will be valid.
    //all other will be for debug log purpose only.
    gc_param_t * param[MIM_TOTAL_MEM_ID_ALLOCATE];

    //stores mem_id where program error happened, waiting to be early sealed.
    FIFO early_sealed_fifo;
    FIFO_TYPE early_sealed_fifo_array[GC_EARLY_SEALED_FIFO_SIZE];

    //stores mem_id gc candidate from mem_id picking algorithm
    FIFO candidate_fifo;
    FIFO_TYPE candidate_fifo_array[GC_TOTAL_CANDIDATE_FIFO];

    //done gc, waiting for background gc to deallocate these
    FIFO deallocate_pending_fifo;
    FIFO_TYPE deallocate_pending_fifo_array[GC_TOTAL_DONE_FIFO_ALLOC];
    //buffer used for gc gather and write, size of each buffer is 512Kb
    xt_u8 *pbuff[TOTAL_GC_BUFFER];
    //used for get available pbuff and free the used pbuff above
    FIFO buffer_index_fifo;
    FIFO_TYPE buffer_index_fifo_array[TOTAL_GC_BUFFER];
    xt_u32 map_log_current_index;   //index in to map_log_index
    xt_u32 map_log_footer_index[TOTAL_MAP_LOG_READ_AHEAD];  //index in to footer map log summary
    FIFO map_log_fifo;
    FIFO_TYPE map_log_fifo_array[TOTAL_MAP_LOG_READ_AHEAD];
    map_log_t *pmap_log[TOTAL_MAP_LOG_READ_AHEAD];
    map_log_t *pmap_log_original[TOTAL_MAP_LOG_READ_AHEAD];

    gc_read_t *pread;

    // calculate number of invalid pages. it is incremented during gc gathering
    // and it is reset to 0 in after every 100 ms by throttling thread
    // it is used for performance calculations.
    sfx_atomic_t invalid_pages;
    sfx_atomic_t first_enter;
#ifdef __SFX_KERNEL__
    sfx_page **gc_1mb_read;
#endif
    xt_u32 gc_read_size;
    xt_u32 gc_max_gather_pending;
    xt_u32 gc_1mb_read_index;  // indicates the position inside 1MB
    xt_u32 gc_1mb_gather_index;
    xt_u32 gc_1mb_mem_id;
    xt_u32 gc_1mb_offset;
    xt_u32 gc_1mb_start_reading;
    xt_u32 gc_1mb_valid_lba_count;
    void *prd_buff;
    xt_u32 invalid_pages_per_map_log;
    xt_u32 valid_pages_per_map_log;
    sfx_atomic_t tot_ipage_bgt_cnt;
    sfx_atomic64_t tot_ipage_bgt;

    sfx_atomic_t bg;
    sfx_atomic_t stop_bg;
#if (MEASURE_TIME || ENABLE_FTL_MONITER)
    struct {
#ifdef __SFX_KERNEL__
        sfx_ktime_t prev_time_perf;
#else
        struct timespec prev_time_perf;
#endif
        sfx_atomic_t   map_log_num;
        sfx_atomic_t   map_log_time;
        sfx_atomic64_t total_read_lba;
        sfx_atomic64_t total_write_lba;
        xt_u64         last_total_read_lba;
        xt_u64         last_total_write_lba;
    };
#endif
    //the gc->pwr[x] buffer is varied based on bad block
    //each mem_id will have different buffer size based on bad block and parity
    //will only be valid when at least one 4k is written to the open mem_id
    xt_u32 is_buffer_valid;     //need to get new buffer size when writing to a new mem_id
    xt_u32 buffer_index;
    xt_u32 buffer_size[GC_MAX_PARITY_BUFFER_MAX];
    xt_u32 adjusted_buff_alignment_size;
    xt_u32 adjusted_buffer_index;
    xt_u32 is_seal_early;
    xt_u32 is_forced_write;
    xt_u32 idle_gc_threshold;
    sfx_atomic_t wl_program_erase_high_candidate_mem_id;
#if ENABLE_SEAL_EARLY_TEST
    xt_u32 seal_early_index;
#endif

    xt_u32 gc_candidate_stream[NUMBER_OF_MAX_MULTI_STREAM][MAX_NUMBER_OF_CANDIDATES_IN_A_STREAM];
    xt_u32 gc_stream_chosen;
    sfx_atomic_t vu_is_gc_triggered;
    sfx_atomic_t vu_is_gc_picked_mid;
} gc_t;

typedef struct wl_s
{
    gc_t *gc;
    xt_u32 wl_hot_candidate_mem_id;
    xt_u32 wl_cold_candidate_mem_id;
    xt_u32 copy_wl_cold_candidate;
    sfx_atomic_t wl_cold_has_more_data;
    xt_u32 last_is_max_free;
    sfx_atomic_t state;
    xt_u32 *pel_candidate;
    xt_u32 is_wl_pending_seal;
    //the following two elements only be used by vu
    sfx_atomic_t vu_is_wl_triggered;
    sfx_atomic_t vu_disable_wl_fifosize_check;
} wl_t;

int gc_is_sleep(sfx_mul_drv *sfx_mdrv);
void gc_start(sfx_mul_drv *sfx_mdrv);
gc_t * gc_get_table(sfx_mul_drv *sfx_mdrv);
sfxError gc_start_sealing(sfx_mul_drv *sfx_mdrv, gc_t *gc, void *map, xt_u32 open_mem_id, xt_u32 move_fifo);
void gc_lock_buffer(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 debug_loc, unsigned long *pflags);
void gc_unlock_buffer(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 debug_loc, unsigned long *pflags);
void gc_thread_wake_up(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 debug_loc);
void gc_stop_gc_thread(sfx_mul_drv *sfx_mdrv);
xt_u32 gc_clean_up_max_free_mem_id(sfx_mul_drv *sfx_mdrv);
void gc_write_t_print(sfx_mul_drv *sfx_mdrv, gc_write_t *pwr);
void gc_param_print(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
sfxError gc_init_wr_entry(sfx_mul_drv *sfx_mdrv, gc_t *gc);
xt_u8 *gc_calc_buffer(sfx_mul_drv *sfx_mdrv, gc_write_t *pgc_wr, xt_u32 offset);
void gc_snapshot_section(sfx_mul_drv *sfx_mdrv);
void gc_verify_map_log_after_seal(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
sfxError gc_read_map_log(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 mem_id, gc_map_log_t *plog, xt_u32 index, xt_u32 map_log_index);
void gc_multi_drive_init(sfx_mul_drv *sfx_mdrv);
xt_u8 *gc_get_static_buffer(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 *pindex, xt_u32 debug_loc);
sfxError fm_gc_map_log_update(sfx_mul_drv *sfx_mdrv, flat_map_t current_map, gc_t *gc);
void gc_force_write_utility(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 insert);
xt_u32 gc_get_offset(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 gather_index);
xt_u32 wl_pick_candidate(sfx_mul_drv *sfx_mdrv);
void wl_multi_drive_init(sfx_mul_drv *sfx_mdrv);
void wl_start(sfx_mul_drv *sfx_mdrv);
void wl_stop(sfx_mul_drv *sfx_mdrv);
sfxError blk_ftl_trim_set_bit_map(sfx_mul_drv *sfx_mdrv, xt_u32 lba, xt_u8 *buff);
xt_u8 is_wl_triggered(sfx_mul_drv *sfx_mdrv);
sfxError gc_rebuild_mem_id_picking(sfx_mul_drv *sfx_mdrv);
void gc_free_static_buffer(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 index, xt_u32 debug_loc);
void gc_print_map_log(sfx_mul_drv *sfx_mdrv, map_log_t *pmap_log);
int wgc_is_sleep(sfx_mul_drv *sfx_mdrv);
void gc_update_buffer_size(sfx_mul_drv *sfx_mdrv, gc_t *gc, xt_u32 mem_id, xt_u32 is_wait_done);
void gc_verify_l2p(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 offset);
void gc_update_idle_gc_threshold(sfx_mul_drv *sfx_mdrv);
xt_u32 gc_is_early_seal_fifo_empty(sfx_mul_drv *sfx_mdrv, unsigned long *pflags);
void gc_push_mid_to_early_sealed_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 mim_mem_id);
xt_u32 gc_pull_mid_from_early_sealed_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 mim_mem_id, xt_u32 sblock, xt_u8 is_clear);
xt_u32 gc_peek_mid_from_early_sealed_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 check_build_done);
xt_u32 gc_check_mid_in_early_sealed_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 mim_mem_id);
xt_u32 gc_check_background_gc(sfx_mul_drv *sfx_mdrv, gc_t *gc);


void gc_credit_control_print(sfx_mul_drv *sfx_mdrv);
sfxError gc_move_open_fifo_to_seal_pending_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 stream);
sfxError gc_update_free_space(sfx_mul_drv *sfx_mdrv, flat_map_t old_map, xt_u32 do_not_update_sorting_free_space);
xt_u32 get_blk_ftl_wl_stage(sfx_mul_drv *sfx_mdrv);
GC_STATE_E get_blk_ftl_gc_write_stage(sfx_mul_drv *sfx_mdrv);
GC_STATE_E get_blk_ftl_gc_read_stage(sfx_mul_drv *sfx_mdrv);

#endif // __GC_H__
