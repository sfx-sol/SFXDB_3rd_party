// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_coh.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_COH_H__
#define __BLK_FTL_COH_H__

#include "blk_ftl_callback.h"
#include "mem_id_mgr.h"

struct sfx_mul_drv_s;

#define COH_TBL_SIZE                    (16 * 1024)
#define COH_HASH(addr)                  ((addr) & 0x3FFF)

#undef TRIM_DEBUG
#define SINGLE_JOB_THRESHOLD		(3000)
#define SINGLE_JOB_NOISE		(300)

/*
 * @brief definition of coherence table entry state
 */
typedef enum
{
    COH_BLOCK = 0,
    COH_ACTIVE,
    COH_INIT,
    COH_TOTAL,
    COH_ASSERT
} COH_ENTRY_STATE;

typedef enum
{
    COH_DLOCK = 0,
    COH_DUNLOCK
} COH_LOCK_TYPE;

typedef enum
{
    COH_UNBLOCK = 0,
    COH_BLOCK_LBA,
    COH_BLOCK_TRIM,
    COH_BLOCK_BOTH
} COH_BLOCK_TYPE;
enum
{
    NO_PAGE_RMW = 0,
    FIRST_PAGE_RMW = 1,
    LAST_PAGE_RMW,
    BOTH_PAGE_RMW
};

enum
{
    RMW_READ = 1,
    RMW_WRITE,
    RMW_CMPL
};

struct blk_ftl_coh_bio_t;

/**
 * @brief definition of coherence table entry.
 *  This is based on the definition presented in Fig.7 of the blk_ftl document.
 */
typedef struct
{
    struct sfx_list_head list_vertical;
    struct sfx_list_head list_horizontal;
    sfx_spinlock_t entry_mutex;
    struct blk_ftl_coh_bio_t *bio;
    xt_u64 lba;
    xt_u32 index;
    COH_ENTRY_STATE cur_state;
    xt_u16 rw;                  // read or write
    xt_u8 cleared;              // only used in freeze state
    xt_u8 block_type;
} blk_ftl_coh_entry CACHELINE_ALIGNED;

typedef struct
{
    xt_u64 sect_start_lba;      // start lba in sector unit
    xt_u64 sect_end_lba;        // end lba in sector unit
    xt_u64 map_start_lba;       // start lba in mapping unit
    xt_u64 map_end_lba;         // end lba in mapping unit
    xt_u64 page_start_lba;      // start lba in page unit
    xt_u64 page_end_lba;        // end lba in page unit
    xt_u64 trim_end_lba;        // trim end lba in coh table
} lba_info CACHELINE_ALIGNED;

typedef struct
{
    void *page_buf;
    xt_u32 off;                 // offset of data in this page buf
    xt_u32 len;                 // valid length of data in this page buf
    xt_u32 data;                // if data in this page buf is valid
} bio_page_buf;

/**
 * @brief Our wrapped bio containing bio and bitmap.
 * As bio private can not be used.
 */
typedef struct blk_ftl_coh_bio_t
{
    sfx_bio                *bio;
    struct sfx_list_head    readylist;          /* used to connect ready list */
    sfx_page              **bio_pages;          /* for bvec_offset not 0 case */
    sfx_page               *signle_bio_page;    /* for 4k request to
                                                   avoid memory allocation */
    bio_page_buf          **bio_buf_list;       /* for unaligned case */
    blk_ftl_coh_entry       bvec_list;          /* used to connect
                                                   blk_ftl_coh_entry horizontally */
    blk_ftl_coh_entry       bvec_list_first;    /* Optimization for 4K request to
                                                   avoid extra memory allocation*/
    blk_ftl_callback_elem   cb_elem;            /* Optimization for 4K request*/
    ccs_callback_t          cb;                 /* callback function associated */
    struct sfx_request     *cb_para;            /* callback context, sfx_req */
    lba_info                coh_bio_lba;
    sfx_atomic_t            finished_cnt;
    xt_u32                  is_trim;
    sfx_atomic_t            trim_region_cnt;
    xt_u32                  trim_send_region_cnt;
    sfx_atomic_t            trim_cplt_region_cnt;
    xt_u32                  coh_bio_pnr;        /* page buf number */
    xt_u32                  rmw_page_idx;       /* 0: no page; 1: the first page;
                                                   2: the last page; 3: both*/
    sfx_atomic_t            outstanding_len;
    xt_u32                  bvec_cnt;
    xt_u32                  qid;
    sfx_lba_list_hot        lba_list_hot;
    sfx_atomic_t            rmw_remain_act_num;
    sfx_atomic_t            rmw_state;
    xt_u32                  direct_handle;
    sfx_bd_device          *sfx_bd;
    COH_ENTRY_STATE         state;              /* current blk_ftl_coh_bio state*/
    xt_u32                  signle_lba;
    xt_u32                  unaligned;
    xt_u32                  mem_unaligned;
    xt_u32                  nvm;
    xt_u8                   pread[512];
    xt_u8                   pwrite[1024];
    xt_u8                   pre_read_rmw;
#ifdef COH_DEBUG
    xt_u32 tot_len;
    xt_u32 ost_len_to_act;
    xt_u32 ost_len_to_gc_buf;
    sfx_atomic_t rev_len_from_act;
    sfx_atomic_t rev_len_from_ccs;
    xt_u32 rev_len_from_gc;
    xt_u32 org_bio_size;
    xt_u32 org_bio_sector;
    xt_u32 offset_blk;
    xt_u32 rmw;
    xt_u32 start;
    xt_u32 end;
    xt_u32 bio_pages_range;
    xt_u32 bio_pages_loc;
#endif
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    struct {
        sfx_ktime_t coh_init_time;
        sfx_ktime_t coh_start_handle_time;
        sfx_ktime_t coh_handle_time;
        sfx_ktime_t coh_proc_wr_time;
        sfx_ktime_t coh_cmpl_time;
    };
#endif
#if MEASURE_TIME
    struct {
        sfx_ktime_t receive_time;
        sfx_ktime_t finish_coh_time;
        sfx_ktime_t schedule_begin_time;
        sfx_ktime_t schedule_end_time;
        sfx_ktime_t cb_begin_time;
        sfx_ktime_t cb_end_time;
        sfx_ktime_t finish_time;
        sfx_ktime_t process_time;
        sfx_ktime_t finish_process_time;
    };
#endif
} blk_ftl_coh_bio;

/**
 * Initialize the blk ftl conherence table
 * @param: None.
 * @retv : State indicating initialize is done or not
 */
sfxError blk_ftl_coh_init(struct sfx_mul_drv_s *sfx_mdrv);

/**
 * Free the blk ftl conherence table
 * @param: None
 * @retv : None
 */
void blk_ftl_coh_free(struct sfx_mul_drv_s *sfx_mdrv);

/**
 * Insert a bio into the coherence table
 *
 * @para: sfx_bio  -- bio data structure
 * @para:  cb         -- callback function
 * @para:  cb_para    -- callback context
 *
 * @retv : None.
 */
sfxError blk_ftl_coh_lock(sfx_bd_device *sfx_bd, sfx_bio *bio,
        ccs_callback_t cb, void *cb_para);

/**
 * Delete a bio from the coherence table
 * @param:  coh_bio
 * @retv:   None
 */
sfxError blk_ftl_coh_unlock(struct sfx_mul_drv_s *sfx_mdrv,
        blk_ftl_coh_bio *coh_bio);

xt_u32 get_coh_thd_num(sfx_mul_drv *sfx_mdrv);
void blk_ftl_finish_reqs_in_freeze(struct sfx_mul_drv_s *sfx_mdrv);
void blk_ftl_set_read_mode(struct sfx_mul_drv_s *sfx_mdrv);
void blk_ftl_schedule_print(struct sfx_mul_drv_s *sfx_mdrv);

// The following functions are exported from sfx_bd_pagelist.c
bio_page_buf *alloc_bio_page_buf(sfx_mul_drv *sfx_mdrv, xt_u32 faker);
void free_bio_page_buf(bio_page_buf *page_buf);
int blk_ftl_init_bio_page_buf(sfx_bio *bio,
        blk_ftl_coh_bio *coh_bio, xt_u32 size);
void blk_ftl_coh_bio_init_bio_pages(blk_ftl_coh_bio *coh_bio, sfx_bio *bio);
void blk_ftl_copy_coh_buffer_to_bio_pages(blk_ftl_coh_bio *coh_bio,
        sfx_page **pages, xt_u32 len);
xt_u32 sfx_bd_create_token_range_from_bio(struct sfx_mul_drv_s *sfx_mdrv,
        union handle *bhand,blk_ftl_coh_bio *coh_bio, void **token, xt_u32 start,
        xt_u32 end, read_entry_t *prd_entry);
xt_u32 sfx_bd_create_token_range_from_pages(struct sfx_mul_drv_s *sfx_mdrv,
        union handle *bhand, sfx_page**list, void **token, xt_u32 coh_start_lba,
        xt_u32 start, xt_u32 end, blk_ftl_coh_bio *coh_bio, read_entry_t *prd_entry);
xt_u32 sfx_bd_create_token_range(union handle *bhand,
        blk_ftl_coh_bio *coh_bio, void **token, xt_u32 start, xt_u32 end);
void blk_ftl_rmw_copy_bvec_to_coh_buf(blk_ftl_coh_bio *coh_bio);
xt_u32 print_coh(struct sfx_mul_drv_s *sfx_mdrv);
xt_u8 sfx_single_thread_detection(struct sfx_mul_drv_s *sfx_mdrv);

xt_u32 sfx_bd_create_r2c_seq_off(struct sfx_mul_drv_s *sfx_mdrv, union handle *bhand,
        xt_u32 start, xt_u32 end, blk_ftl_coh_bio *coh_bio, read_entry_t *prd_entry);
#endif // __BLK_FTL_COH_H__
