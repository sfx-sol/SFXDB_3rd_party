// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_vu.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_VU_H__
#define __BLK_FTL_VU_H__

int sfx_dispatch_vu_command(sfx_mul_drv *sfx_mdrv, void *arg);

#endif // __BLK_FTL_VU_H__
