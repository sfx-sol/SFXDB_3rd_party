// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_ops.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_OPS_H__
#define __BLK_FTL_OPS_H__

#include "sfx_types.h"
#include "flat_map.h"

//#define TURN_ON_RC_OPS

struct sfx_mul_drv_s;
struct blk_ftl_coh_bio_t;

#define REGION_TO_PAGE_SHIFT            (15)
#define LBA_COUNT_PER_REGION            (1 << REGION_TO_PAGE_SHIFT)
#define REGION_TO_PAGE_MASK             ((1 << REGION_TO_PAGE_SHIFT) - 1)
#define MERGE_READ

sfxError handle_blk_ftl_read(struct sfx_mul_drv_s *sfx_mdrv, struct blk_ftl_coh_bio_t *coh_bio);
sfxError handle_blk_ftl_write(struct sfx_mul_drv_s *sfx_mdrv, struct blk_ftl_coh_bio_t *coh_bio);
sfxError handle_blk_ftl_trim(struct sfx_mul_drv_s *sfx_mdrv, struct blk_ftl_coh_bio_t *coh_bio);
sfxError handle_blk_ftl_rmw_merge_and_write(struct sfx_mul_drv_s *sfx_mdrv, struct blk_ftl_coh_bio_t *coh_bio);
sfxError ccs_blk_write_callback(sfxError cmpl_status, void *context);
sfxError handle_blk_ftl_r2c_read(void *multi_drv, void *context);
sfxError handle_r2c_lba_pba(void *multi_drv, void *context);
sfxError blk_ftl_r2c_cb_callback(sfxError cmpl_status, void *callback_p);
void fm_trim_record_update(struct sfx_mul_drv_s *sfx_mdrv, lba_t start_lba,
                                    lba_t end_lba, xt_u32 is_valid_flag);
#endif // __BLK_FTL_OPS_H__
