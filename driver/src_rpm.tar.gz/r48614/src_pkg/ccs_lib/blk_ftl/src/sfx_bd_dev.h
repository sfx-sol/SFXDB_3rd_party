// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_bd_dev.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_BD_DEV_H__
#define __SFX_BD_DEV_H__

#include "blk_ftl_multidrive.h"

#undef HK_DEBUG

#define MAX_REQ_SIZE_LOG2                   (9)
#define MAX_REQ_SIZE                        (1<<MAX_REQ_SIZE_LOG2)       // Max request size, in sector granularity
#define SFX_WAKEUP_TIME                     1000000     // in ns

#define MAX_DSM_4K_NUM                      (0xFFFFFFFF >> 12) //bio_size is 32bit
#define MAX_DSM_SEC_NUM                     (MAX_DSM_4K_NUM << 3)

/* KV IOCTL cmds flags */
#define SFX_IOCTL_REQ_OP_KV_IN              34
#define SFX_IOCTL_REQ_OP_KV_OUT             35

struct read_s;
struct write_s;

typedef enum
{
    SFX_BD_INIT = 0,
    SFX_BD_RUNNING,
    SFX_BD_STOPPED,
    SFX_BD_RESUME,
    SFX_BD_TOTAL
} SFX_BD_STATE;

enum
{
    DISABLE_NUMA_SWITCH = 0,
    ENABLE_NUMA_SWITCH,
    CHECK_TO_NUMA_SWITCH
};

struct sfx_bd_smart
{
    xt_u64 bg_gc_timer_range_l;
    xt_u64 bg_gc_timer_range_h;
    xt_u64 bg_gc_timer;
    xt_u64 read_scrub_range_l;
    xt_u64 read_scrub_range_h;
    xt_u64 read_scrub;
    xt_u8 bg_gc_threshold_range;
    xt_u8 bg_gc_threshold;
    xt_u8 wear_leveling;
};
struct sfx_kobj
{
    struct sfx_kobject      kobject;
    struct sfx_completion   complete;
};

typedef struct sfx_smp_ctx
{
    sfx_mul_drv             *sfx_mdrv;
    struct sfx_request      *req;
    xt_u32                  end_req;
    xt_u32                  free_res;
    xt_u32                  smt_cpu;
    xt_u32                  rsvd;
} sfx_smp_ctx;
/*
 * Representation an SFX_BD device.
 */
typedef struct sfx_bd_device_s
{
    sfx_request_queue       *sfx_bd_queue;
    sfx_gendisk             *sfx_bd_disk;
    sfx_mul_drv             *sfx_mdrv;
    void                    *sfx_ctrlr;
    struct sfx_bd_smart     smart;
    struct sfx_kobj         smart_kobj;
    struct sfx_kobj         debug_kobj;
    struct sfx_kobj         debug_level_kobj;
    struct sfx_list_head    sfx_bd_list;
    sfx_mutex_t             req_mutex;
    sfx_spinlock_t          sfx_bd_lock;

    xt_u32                  sfx_bd_id;		/* ns id */
    xt_u64                  sfx_bd_lba_cnt;	/* ns lba cnt */
    xt_u64                  sfx_bd_cap;		/* ns lba cnt */
    xt_u64                  sfx_bd_lba_shift;
    xt_u64                  sfx_bd_lba_edirty;
    xt_u32                  sfx_bd_nvm;
    xt_u32                  sfx_bd_nvm_cnt;
} sfx_bd_device;

typedef struct sfx_nvm_recover_s
{
    xt_u8   nvm[4096];
    xt_u64  nvm_cnt;
} sfx_nvm_recover;

enum
{
    SFX_BD_RQ  = 0,
    SFX_BD_MQ  = 1,
    SFX_BD_BIO = 2,
};

struct blk_ftl_coh_bio_t;
/*WARNING: Please explicitly zero the member
 *during sfx_alloc_sfx_request() if it is required
 *to be zero. We do not memset the whole sfx_request
 *to zero during initialization for performance reason.
 * */
struct sfx_request
{
    sfx_bio_request *req;
    sfx_bd_device *sfx_dev;
    xt_u32 size;
    xt_u32 bvec_tot_len;
    xt_u32 req_type; /* 0: read; 1: write; 2: discard */
    sfx_atomic_t bvec_remain_count;
    sfx_atomic_t finish_tag;
    sfx_atomic_t cmpl_flag;
    sfx_atomic_t osd_bio_count; // outstanding bio counter
    xt_u64 start; //specially for iostat in bio mode
    xt_u32 is_unalign;
    xt_u32 kv_flag;
    sfx_ktime_t init_time;
    //all the above variables can be fit
    //into one cacheline (64B).
    xt_u64 direct_smt;
#ifndef SFX_LINUX //ticket 2088
    xt_u32 pre_read_rmw;
    xt_u32 pre_rw_cnt;
#endif
    xt_u32 error;
    xt_u32 is_coh_block;
    sfx_ktime_t coh_init_time;
    sfx_ktime_t coh_active_time;
    sfx_ktime_t coh_release_time;
    sfx_ktime_t sub_time;
    sfx_ktime_t rtn_time;
    sfx_ktime_t finish_time;
    struct sfx_list_head list; //obselete, going to remove it
    xt_u32 coh_bio[0] CACHELINE_ALIGNED;
};

typedef struct
{
    sfx_page** pages;
    sfx_page** bio_pages;
    xt_u16  cur_index;
    xt_u16  len;
    xt_u32  bio_start_4k_lba;
    xt_u32  bio_end_4k_lba;
} bio_extra_pages;

struct bio_cb_cxt
{
    bio_extra_pages         *extra;
    sfx_bio                 *bio;                   /* needed for unlock bio */
    xt_u32                  remain_count;
};

struct ccs_callback_context
{
    write_callback_context_t wr_cb;
    sfx_mul_drv             *sfx_mdrv;
    void                    *coh_bio;             /* used to free coh table*/
    struct read_s           *pread;               /* used to free read_t */
    struct write_s          *pwrite;              /* used to free write_t  */
    xt_u32                  *token;               /* used to free token */
    xt_u32                  len;                  /* 4k based */
    xt_u16                  error;                /* indicate whether this is error case or not */
    xt_u16                  rmw_rd;
    sfx_atomic_t            cmt_len;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    struct {
        sfx_ktime_t         smt_time;
        sfx_ktime_t         rtn_time;
        sfx_ktime_t         cmpl_time;
    };
#endif
};

struct blk_ftl_rmw_callback
{
    void                    *coh_bio;
    sfx_page                **pages;
    struct blk_ftl_rmw_each_act_context *act;
    struct read_s           *pread;
    sfx_mul_drv             *sfx_mdrv;
    sfx_atomic_t            remain_act_num;      /* total bvec_num to finish for read*/
};

/**
 * @breif: each rmw act cmd context
 */
struct blk_ftl_rmw_each_act_context
{
    struct blk_ftl_rmw_callback          *rmw_cxt;   /* pointer to the whole rmw cb cxt */
    xt_u32                               *token;     /* used to free token */
};

struct sfx_id_ns
{
    xt_u64 nsze;
    xt_u64 ncap;
    xt_u64 flbas;
    xt_u64 dps;
    xt_u64 nmic;
};

static inline int get_first_sibling(unsigned int cpu)
{
    unsigned int ret = sfx_cpumask_first(sfx_topology_thread_cpumask(cpu));
    if (ret < sfx_nr_cpu_ids()) {
        return ret;
    }
    return cpu;
}

static inline int cpu_to_queue_index(unsigned int nr_cpus, unsigned int nr_queues, const int cpu)
{
    return (cpu % nr_queues);
}

#ifdef SFX_LINUX
extern xt_u32 sfx_bd_dev_major;
int sfx_req_generic_handler(void *sfx_bd, void *sfxrq, xt_u32 flag);
void sfx_start_io_acct(sfx_mul_drv *sfx_mdrv, sfx_bio *bio);
void sfx_end_io_acct(sfx_mul_drv *sfx_mdrv, sfx_bio *bio, xt_u64 start_time);
void linux_req2bv(sfx_bio_request *req, xt_u32 *nr_bvec_page, xt_u32 *nr_bvec_not_trim, xt_u64 *size);
xt_u32 sfx_get_dsm_pages(sfx_bio_request *req);
void sfx_get_bvec_cnt(struct blk_ftl_coh_bio_t *coh_bio, sfx_bio *bio);
#endif

int sfx_ioctl(sfx_block_device *dev, unsigned cmd, void *arg);
void sfx_nvme_update_err_log(sfx_mul_drv *sfx_mdrv, xt_u32 status, xt_u64 *lba);
xt_32 sfx_get_cpu_brand(void);

void sfx_mdrv_check_osd_req(ftl_mq_ctx *ftl_mq_ctx);

int sfx_handle_ioctl_trim(sfx_bd_device *sfx_bd, void *range);

int sfx_mdrv_single_remove(ftl_mq_ctx *mq_ctx, int keep_disk);
int sfx_mdrv_single_dev_gone(char *d_name);
int sfx_bd_probe (char *d_name, int nid, void *bd_param, void *ftl_mq_ctx);

sfxError bio_end_requestall_callback(sfxError cmpl_status, void *context);
void sfx_zero_set_bio_range(sfx_bio *bio, xt_u32 lba, xt_u32 start_lba, xt_u32 end_lba);
void sfx_bio_end_request_free_req(sfx_mul_drv *sfx_mdrv, struct sfx_request *sfx_req, xt_u32 end_req, xt_u32 free_res);
void sfx_blk_ftl_try_smt_remote_cmpl(sfx_mul_drv *sfx_mdrv, struct sfx_request *req, xt_u32 is_unaligned);
void sfx_align_nodemask_to_numa_id(sfx_mul_drv *sfx_mdrv);

xt_u32 sfx_op_is_write(struct bio *bio);
xt_u32 sfx_op_is_discard(sfx_bio *bio);
xt_u32 sfx_op_is_readahead(struct bio *bio);
xt_u32 sfx_is_discard_request(sfx_bio_request *req);
xt_u32 sfx_is_write_request(sfx_bio_request *req);
void *sfx_get_qdata_from_sfx_req(struct sfx_request *sfx_req);
sfx_request_queue *sfx_get_req_q_from_sfx_req(struct sfx_request *sfx_req);
unsigned int sfx_get_cmd_flags_from_request(sfx_bio_request *req);

void sfx_bd_stop_queue(sfx_request_queue *q);
void sfx_bd_set_queue_dying(sfx_request_queue *q);
void sfx_bd_start_queue(sfx_request_queue *q);
void sfx_bd_start_queue_conditional(sfx_mul_drv *sfx_mdrv, struct sfx_request *req);
struct sfx_request *sfx_alloc_sfx_request(sfx_bd_device *sfx_bd, sfx_bio_request *req, xt_u32 flag);
void sfx_bd_softirq_done_fn(sfx_bio_request *rq, xt_u16 error);
void sfx_resubmit_bios(sfx_bd_device *sfx_bd);
void blk_ftl_free_buffer(void *buffer, xt_u32 size);
void blk_ftl_copy_gc_buffer_to_bio_page(struct blk_ftl_coh_bio_t *coh_bio, xt_u32 start, xt_u32 end, void **ppbuff);
void blk_ftl_cleanup_priv_thrd(sfx_mul_drv *sfx_mdrv);
void blk_ftl_wakeup_priv_thrd(sfx_mul_drv *sfx_mdrv);
xt_32 sfx_mq_get_cpu_queue_mapping(xt_u32 *wr_map, xt_u32 *rd_map, const struct cpumask *online_mask,
        struct sfx_ioq_config *ioq_config, xt_u32 stream_num);
int blk_ftl_bg_check(void *data);
void sfx_blk_ftl_complete_and_free_req(sfx_mul_drv *sfx_mdrv, sfx_bio_request *req);
void blk_ftl_req_handler(sfx_bd_device *sfx_bd, sfx_bio_request *req, xt_u32 flag);
void sfx_blk_ftl_complete_request(sfx_mul_drv *sfx_mdrv, sfx_bio_request *req, int err, xt_u64 start);
void blk_ftl_irq_bg_check(struct sfx_work_struct *work);
void blk_ftl_mq_cmpl_req(sfx_mul_drv *sfx_mdrv, xt_u32 cpuid, xt_u32 is_bg);
xt_u32 blk_ftl_cmpl_cmds(sfx_mul_drv *sfx_mdrv, xt_u32 cpuid, xt_u8 poll_type, int poll_num);
void sfx_polling_worker(struct sfx_work_struct *work);
xt_u8 sfx_num_app_thread_detection(sfx_mul_drv *sfx_mdrv, xt_u16 *qd);
int sfx_bd_add_one(sfx_bd_device *sfx_bd);
sfx_bd_device* sfx_bd_ns_alloc(sfx_mul_drv *sfx_mdrv, int nsid, void *arg);
sfx_bd_device *sfx_get_bd_by_ns(sfx_mul_drv *sfx_mdrv, xt_u8 nsid);
void sfx_update_ns_map(sfx_bd_device *sfx_bd);
void sfx_bd_attr_config_sec_size(sfx_bd_device *sfx_bd, int sector_sz);
void sfx_bd_free(sfx_bd_device *sfx_bd);
void bio_page_buf_init_once_linux(void *buf);
int bio_page_buf_init_once_esx(void *buf, int size, void *arg, int flags);

int sfx_bd_init(void);
void sfx_bd_exit(void);
void sfx_disconnect_disk(sfx_bd_device *sfx_bd, int keep_disk);

// for ESX
#ifdef VMKERNEL
int sfx_esx_bd_add(sfx_mul_drv *sfx_mdrv);
void blk_ftl_gc_print_esx(void);
void blk_ftl_schedule_print_esx(void);
void blk_ftl_perf_print_esx(void);
void blk_ftl_gc_iops_print_esx(void);
void blk_ftl_perf_enable_print_esx(void);
void blk_ftl_perf_linux_print_esx(void);
void blk_ftl_coherency_print_esx(void);
void blk_ftl_mim_print_esx(void);
void ccs_stats_print_esx(void);
void ccs_snapshot_print_esx(void);
void ccs_app_q_print_esx(void);
void ccs_nvme_q_print_esx(void);
void ccs_map_print_esx(void);
void ccs_sblock_print_esx(void);
void ccs_nvme_print_esx(void);
void ccs_perf_debug_print_esx(void);
void blk_ftl_mdata_vfy_scan_l2p_table_esx(void);
void blk_ftl_mdata_vfy_scan_valid_mem_ids_esx(void);
#endif

// for Linux
#ifdef SFX_LINUX
int sfx_linux_bd_add(sfx_mul_drv *sfx_mdrv);
struct hot_rd_s *sfx_get_cpu_ptr_to_hot_rd(struct hot_rd_s * phr);
struct hot_rd_s *sfx_per_cpu_ptr_to_hot_rd(struct hot_rd_s * phr, xt_32 cpu_iter);
xt_u32 linux_get_total_outstanding_size(sfx_mul_drv *sfx_mdrv);
sfx_bio *sfx_get_req_bio(sfx_bio_request *req);
sfx_bio *sfx_get_bio_bi_next(sfx_bio *bio);
sfx_bd_device *sfx_get_bd_device_from_gendisk(sfx_block_device *dev);
sector_t sfx_get_gendisk_capacity(sfx_block_device *dev);
void sfx_check_ka_versions(sfx_mul_drv *sfx_mdrv);
#else
#define sfx_check_ka_versions(...)
#endif

int sfx_is_remote_cmpl_supported(void);
#if SFX_USE_REMOTE_CMPL
void sfx_blk_ftl_smt_remote_cmpl(sfx_mul_drv *sfx_mdrv, struct sfx_request *req);
#else
#define sfx_blk_ftl_smt_remote_cmpl(...)
#endif

// from blk_ftl_error_handling.h
sfxError blk_ftl_err_handle_init(sfx_mul_drv *sfx_mdrv);

// from blk_ftl_read_disturb.h
void blk_ftl_read_distb_init(sfx_mul_drv *sfx_mdrv);
void blk_ftl_read_distb_exit(sfx_mul_drv *sfx_mdrv);

// from flat_map.h
int sfx_get_euid_size(sfx_mul_drv *sfx_mdrv, void *arg);
int sfx_get_euid(sfx_mul_drv *sfx_mdrv, void *arg);

// from gc.c
void sfx_init_gc_trigger(sfx_mul_drv *sfx_mdrv);

// from iops_test.c
void iops_read_test(void);
void iops_read_test(void);
void set_test_qd(xt_u32 qd);
void set_test_wbs(xt_u32 bs);
void set_test_rbs(xt_u32 bs);
void set_data_length(xt_u32 len);

// from meta_data_verify.h
void mdata_vfy_init(sfx_mul_drv *sfx_mdrv);

// from sfx_assert.c
int sfx_assert_thread(void *data);
void sfx_exit_all_threads(sfx_mul_drv *sfx_mdrv);

// all functions below are called by sfx_sysfs.c
void gc_perf_debug(sfx_mul_drv *sfx_mdrv);
void blk_ftl_throttle_debug(sfx_mul_drv *sfx_mdrv);
void req_handle_perf_debug_enable(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void interleave_max_read_slot(sfx_mul_drv *sfx_mdrv, xt_u8 val);
void enable_gc_distribution_check(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void req_handle_perf_debug(sfx_mul_drv *sfx_mdrv);
void gc_perf_iops(sfx_mul_drv *sfx_mdrv);
void gc_ftl_perf_update(sfx_mul_drv *sfx_mdrv, ftl_moniter_t *ftl_moniter);
void blk_ftl_perf_linux_print(sfx_mul_drv *sfx_mdrv);
void sfx_mdrv_ftl_perf_update(sfx_mul_drv *sfx_mdrv, ftl_moniter_t *ftl_moniter);
void blk_ftl_crash_trigger(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void l2p_table_dump(sfx_mul_drv *sfx_mdrv);
sfxError secure_erase(sfx_mul_drv *sfx_mdrv, xt_u32 choice);
void mdata_vfy_scan_l2p_table(sfx_mul_drv *sfx_mdrv);
void mdata_vfy_scan_all_valid_mem_ids(sfx_mul_drv *sfx_mdrv);
void blk_ftl_no_bg_gc(sfx_mul_drv *sfx_mdrv, xt_u32 val);
xt_u32 set_stream_gc_threshold(sfx_mul_drv *sfx_mdrv, xt_u32 stream, xt_u64 val, xt_u64 nsectors);
void mdata_get_reverse_lba_from_mem_id_offset(sfx_mul_drv *sfx_mdrv, const xt_u8 *str);
xt_u32 get_atomic_wr_from_host(void);
xt_u32 get_multi_stream(void);
sfx_bool sfx_set_and_fetch_bd_ro(sfx_mul_drv *sfx_mdrv, xt_8 read_only_mode);
extern int comp_flush_time;

#endif // __SFX_BD_DEV_H__
