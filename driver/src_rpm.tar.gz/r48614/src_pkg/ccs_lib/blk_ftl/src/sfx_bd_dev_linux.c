/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_bd_dev_linux.c
 *
 * API for the ScaleFlux SFX_BD_DEV Linux device driver
 * ---------------------------------------------------------------------------
 */

#include "sfx_bd_dev.h"
#include "blk_ftl_coh.h"
#include "flat_map.h"
#include "blk_ftl_req_handler.h"
#include "sfx_sysfs.h"
#include "sfx_driver_api.h"
#include "blk_ftl_vu.h"
#include "nvme310_327.h"
#include "sfx_vdev.h"

#if ENABLE_VDEV
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
#ifdef CENTOS7X_4_14_0_49_PATCH
blk_status_t sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#else
#ifdef RHEL_RELEASE_CODE
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
blk_status_t sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, struct request *rq, bool not_used_here);
#else
int sfx_mq_queue_rq(struct blk_mq_hw_ctx *hctx, struct request *rq);
#endif
#endif
#endif // CENTOS7X_4_14_0_49_PATCH
#if ((LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0)))
int sfxdriver_blk_mq_map_queues(struct blk_mq_tag_set *set);
#endif
int sfx_mq_init_hctx(struct blk_mq_hw_ctx *hctx, void *data, unsigned int hctx_idx);
void sfx_mq_complete_rq(sfx_bio_request *req);
#endif
#endif // ENABLE_VDEV

#define DEFAULT_SECTOR_SIZE 512
static int sector_size = DEFAULT_SECTOR_SIZE;
module_param(sector_size, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(sector_size, "sector_size");

#define SFX_BD_MINORS (256)
#define SFX_MDRV_MINORS (SFX_BD_MINORS * 3)

//#define ALLOC_PAGE_INIT
void bio_page_buf_init_once_linux(void *buf)
{
#ifdef ALLOC_PAGE_INIT
	bio_page_buf *page_buf = (bio_page_buf *)buf;
	sfx_page *page = NULL;
	page_buf->page_buf = NULL;
	page = sfx_alloc_pages_handle(0);
	if (page) {
		page_buf->page_buf = sfx_page_address(page);
	}
#endif
}

void sfx_update_ns_map(sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	sfx_bd_device *sfx_bd0 = (sfx_bd_device *)sfx_mdrv->sfx_bd0;
	map_t *pgmap = fm_get_gmap(sfx_mdrv);
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry, *ns_entry0;
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "remove sfd%dn%d update ns map\n", sfx_mdrv->devId,
		  sfx_bd->sfx_bd_id);

	sfx_mdrv->sfx_bd_bmap &= ~(1 << sfx_bd->sfx_bd_id);
	sfx_mdrv->sfx_bd_cnt--;

	gpmem_id->ns_recover.ns_bmap &= ~(1 << sfx_bd->sfx_bd_id);
	gpmem_id->ns_recover.ns_cnt--;
	gpmem_id->ns_recover.ns_bmap &= ~(1 << sfx_bd->sfx_bd_id);
	ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
	ns_entry->ns_id = 0;
	ns_entry->ns_lba_cnt = 0;
	ns_entry->ns_lba_cap = 0;
	ns_entry->ns_lba_shift = 0;

	ns_entry0 = &gpmem_id->ns_recover.ns_entry[0];

	if (--sfx_bd->sfx_bd_lba_shift == sfx_bd0->sfx_bd_lba_cnt) {
		sfx_bd0->sfx_bd_lba_cnt += sfx_bd->sfx_bd_lba_cnt;
		ns_entry0->ns_lba_cnt = sfx_bd0->sfx_bd_lba_cnt;
		set_capacity(sfx_bd0->sfx_bd_disk, sfx_bd0->sfx_bd_lba_cnt);
	}
	if (sfx_mdrv->sfx_bd_cnt == 1) {
		xt_u64 nsec = (xt_u64)pgmap->pmaster->lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB;
		if (sfx_bd0->sfx_bd_lba_cnt != nsec) {
			sfx_bd0->sfx_bd_lba_cnt = nsec;
			ns_entry0->ns_lba_cnt = sfx_bd0->sfx_bd_lba_cnt;
			set_capacity(sfx_bd0->sfx_bd_disk, sfx_bd0->sfx_bd_lba_cnt);
		}
	}
}

void sfx_bd_attr_config_sec_size(sfx_bd_device *sfx_bd, int sector_sz)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = NULL;
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		if (sector_sz != 4096 && sector_sz != 512) {
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF,
				  "invalid sector size, set it to default\n", sector_sz);
			sector_sz = DEFAULT_SECTOR_SIZE;
		}
		gpmem_id->sector_size = sector_sz;
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "set blk_queue_logical_block_size to %d\n",
			  gpmem_id->sector_size);
		blk_queue_logical_block_size(sfx_bd->sfx_bd_queue, sector_sz);
	} else {
		blk_queue_logical_block_size(sfx_bd->sfx_bd_queue, DEFAULT_SECTOR_SIZE);
	}
}

void sfx_bd_attr_config(sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u32 pb_size;
	/* general property*/
	sfx_bd->sfx_bd_queue->queuedata = sfx_bd;
#if (DEREF_BACKING_DEV_INFO_OF_STRUCT_REQUEST_QUEUE != 0)
	sfx_bd->sfx_bd_queue->backing_dev_info->ra_pages = BLKFTL_RARAGE;
#else
	sfx_bd->sfx_bd_queue->backing_dev_info.ra_pages = BLKFTL_RARAGE;
#endif
	blk_queue_alignment_offset(sfx_bd->sfx_bd_queue, 0);
	if (gpmem_id->sector_size != 4096 && gpmem_id->sector_size != 512) {
		gpmem_id->sector_size = DEFAULT_SECTOR_SIZE;
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "update master sector size first time to %d\n",
			  gpmem_id->sector_size);
	}
	sfx_bd_attr_config_sec_size(sfx_bd, gpmem_id->sector_size);

	blk_queue_io_opt(sfx_bd->sfx_bd_queue, FOUR_KB_PER_MAPPING_UNIT * BLKFTL_4K);
	blk_limits_io_min(&sfx_bd->sfx_bd_queue->limits, FOUR_KB_PER_MAPPING_UNIT * BLKFTL_4K);
	blk_queue_max_hw_sectors(sfx_bd->sfx_bd_queue, BLKFTL_MAXB_PERREQ / KERNEL_SECTOR_SIZE);
	blk_queue_physical_block_size(sfx_bd->sfx_bd_queue, FOUR_KB_PER_MAPPING_UNIT * BLKFTL_4K);
	sfx_bd->sfx_bd_queue->limits.max_sectors = MAX_REQ_SIZE;
	/* discard property */
	pb_size = queue_physical_block_size(sfx_bd->sfx_bd_queue);
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 12, 0)
	sfx_bd->sfx_bd_queue->limits.discard_zeroes_data = sfx_mdrv->discard_write_zeros;
#endif
	sfx_bd->sfx_bd_queue->limits.discard_alignment = pb_size;
	sfx_bd->sfx_bd_queue->limits.discard_granularity = pb_size;

#ifdef CONFIG_PREEMPT_COUNT
	sfx_bd->sfx_bd_queue->limits.max_discard_sectors = 1024;
#else
	sfx_bd->sfx_bd_queue->limits.max_discard_sectors = 0x400000;
#endif
	sfx_queue_flag_set_unlocked(QUEUE_FLAG_DISCARD, sfx_bd->sfx_bd_queue);
	sfx_queue_flag_set(QUEUE_FLAG_NONROT, sfx_bd->sfx_bd_queue);
	sfx_queue_flag_clear_unlocked(QUEUE_FLAG_ADD_RANDOM, sfx_bd->sfx_bd_queue);
	sfx_queue_flag_set_unlocked(QUEUE_FLAG_NOMERGES, sfx_bd->sfx_bd_queue);
}

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)

static int sfx_bd_bio_submit(sfx_request_queue *q, sfx_bio *bio)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(q);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	struct request *req;
	xt_u32 cpuid = sfx_get_cpuid();
	int is_rdq = 0;

	req = kmem_malloc(sfx_mdrv->devId, sizeof(sfx_bio_request));
	sfx_memset(req, 0, sizeof(sfx_bio_request));
	req->bio = bio;
	bio->bi_next = NULL;
	if (sfx_op_is_write(bio)) {
		req->cmd_flags |= SFX_REQ_WRITE;
	} else {
		is_rdq = 1;
	}

	if (sfx_op_is_discard(bio)) {
		req->cmd_flags |= SFX_REQ_DISCARD;
	}
	req->q = q;
	if (!sfx_irqs_disabled()) {
		sfx_local_irq_disable();
	}
	blk_ftl_req_handler(sfx_bd, req, 0);
	if (!sfx_single_thread_detection(sfx_mdrv) ||
	    (sfx_atomic_read(&sfx_mdrv->outstanding_req) >= SFX_BLK_MAX_REQ)) {
		if (!sfx_is_discard_request(req)) {
			if (is_rdq) {
				blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_READ, -1);
			} else {
				blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_WRITE, -1);
			}
		}
	}
	if (sfx_irqs_disabled()) {
		sfx_local_irq_enable();
	}
	return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 10, 0)
#define bio_end_sector(bio) ((bio)->bi_sector + bio_sectors((bio)))
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
static blk_qc_t sfx_bd_make_request(sfx_request_queue *q, sfx_bio *bio)
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 2, 0)
static int sfx_bd_make_request(sfx_request_queue *q, sfx_bio *bio)
#else
static void sfx_bd_make_request(sfx_request_queue *q, sfx_bio *bio)
#endif
#endif
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(q);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 14, 0)
	sfx_block_device *bdev = bio->bi_bdev;
#endif
#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_ktime_t start_time, end_time;
	start_time = sfx_ktime_get();
#endif
	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only || sfx_atomic_read(&sfx_mdrv->flag_dev_freeze) ||
	    (sfx_op_is_write(bio) && sfx_atomic_read(&sfx_mdrv->read_mode))
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 14, 0)
	    || (bio_end_sector(bio) > get_capacity(bdev->bd_disk))
#else
	    || (bio_end_sector(bio) > get_capacity(bio->bi_disk))
#endif
	    || sfx_blk_queue_stopped(q) || sfx_atomic_read(&sfx_mdrv->queue_stop)) {
		goto err_case;
	}

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	sfx_start_io_acct(sfx_mdrv, bio);
#endif
	sfx_bd_bio_submit(q, bio);

#if HOT_READ_PERF || HOT_WRITE_PERF
	end_time = sfx_ktime_get();
	sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd);
	if (sfx_ktime_to_ns(end_time) - sfx_ktime_to_ns(start_time) > 100000) {
		sfx_atomic64_inc(&sfx_mdrv->num_fresh_cmd_100);
	}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
	return 0;
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 2, 0)
	return 0;
#else
	return;
#endif
#endif

err_case:
	bio_io_error(bio);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 4, 0)
	return 0;
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 2, 0)
	return 0;
#else
	return;
#endif
#endif
}

#endif // SFX_BLK_SQ_BIO

void sfx_resubmit_bios(sfx_bd_device *sfx_bd)
{
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	unsigned long flag = 0;
	while (bio_list_peek(&sfx_mdrv->sq_cong)) {
		xt_u32 do_submit = 0;
		sfx_bio *bio = NULL;
		sfx_spin_lock_irqsave(&sfx_mdrv->sq_cong_lock, flag);
		if (bio_list_peek(&sfx_mdrv->sq_cong)) {
			bio = bio_list_pop(&sfx_mdrv->sq_cong);
			do_submit = 1;
		}

		if (bio_list_empty(&sfx_mdrv->sq_cong)) {
			remove_wait_queue(&sfx_mdrv->sq_full, &sfx_mdrv->sq_cong_wait);
		}
		sfx_spin_unlock_irqrestore(&sfx_mdrv->sq_cong_lock, flag);
		if (do_submit) {
			if (sfx_bd_bio_submit(sfx_bd->sfx_bd_queue, bio)) {
				break;
			}
		}
	}
#endif
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 0, 0))
static void sfx_bd_request(sfx_request_queue *q)
{
	sfx_bio_request *req;
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_QUEUE(q);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
#if MEASURE_TIME
	static sfx_ktime_t req_prev; /* use global variable to track last update for multi-card case */
	sfx_ktime_t prev_time, cur_time;

	xt_u64 time_delta0 = 0;
	xt_u64 time_delta1 = 0;
	if (sfx_mdrv->open_measure_time) {
		cur_time = sfx_ktime_get();
		if (sfx_ktime_to_ns(req_prev)) {
			if (sfx_ktime_to_ns(cur_time) - sfx_ktime_to_ns(req_prev)) {
				time_delta0 = sfx_ktime_to_ns(cur_time) - sfx_ktime_to_ns(req_prev);
				sfx_atomic_add(time_delta0, &sfx_mdrv->req_time);
			}
		}
		sfx_atomic_inc(&sfx_mdrv->req_call_num);
	}
#endif
	while ((req = blk_fetch_request(q)) != NULL) {
		spin_unlock_irq(q->queue_lock);
#if MEASURE_TIME
		prev_time = sfx_ktime_get(); /* always initialize "prev_time" to make compiler happy */
#endif
		if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
			sfx_blk_ftl_complete_request(sfx_mdrv, req, 0, 0);
		} else {
			int is_rdq = (!sfx_is_write_request(req));
			xt_u32 cpuid = sfx_get_cpuid();
			if (!sfx_irqs_disabled()) {
				sfx_local_irq_disable();
			}
			blk_ftl_req_handler(sfx_bd, req, 0);
			if (!sfx_is_discard_request(req)) {
				if (is_rdq) {
					blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_READ, -1);
				} else {
					blk_ftl_cmpl_cmds(sfx_mdrv, cpuid, POLLED_WRITE, -1);
				}
			}
			if (sfx_irqs_disabled()) {
				sfx_local_irq_enable();
			}
		}
#if MEASURE_TIME
		if (sfx_mdrv->open_measure_time) {
			cur_time = sfx_ktime_get();
			if (sfx_ktime_to_ns(prev_time)) {
				if (sfx_ktime_to_ns(cur_time) > sfx_ktime_to_ns(prev_time)) {
					sfx_atomic64_inc(&sfx_mdrv->req_num);
					time_delta1 = sfx_ktime_to_ns(cur_time) - sfx_ktime_to_ns(req_prev);
					sfx_atomic_add(time_delta1, &sfx_mdrv->req_handle_time);
				}
			}
			sfx_atomic_set(&sfx_mdrv->req_time_max,
				       (time_delta0 > sfx_atomic_read(&sfx_mdrv->req_time_max)) ?
					       time_delta0 :
					       sfx_atomic_read(&sfx_mdrv->req_time_max));
			sfx_atomic_set(&sfx_mdrv->req_handle_time_max,
				       (time_delta1 > sfx_atomic_read(&sfx_mdrv->req_handle_time_max)) ?
					       time_delta1 :
					       sfx_atomic_read(&sfx_mdrv->req_handle_time_max));
		}
#endif
		spin_lock_irq(q->queue_lock);
	}
#if MEASURE_TIME
	if (sfx_mdrv->open_measure_time) {
		req_prev = sfx_ktime_get();
	}
#endif
	return;
}
#endif // (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))

int sfx_bd_revalidate(sfx_gendisk *gd)
{
	sfx_gendisk *disk = gd;
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(disk);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	loff_t disk_nr_sects;

	// pr_inf("%s\n", __FUNCTION__);
	disk_nr_sects = (loff_t)get_capacity(disk);
	if (disk_nr_sects != sfx_bd->sfx_bd_lba_cnt) {
		set_capacity(disk, sfx_bd->sfx_bd_lba_cnt);
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
			  "%s: !!!!!! size of disk %s "
			  "is %llu sectors\n",
			  __FUNCTION__, disk->disk_name, sfx_bd->sfx_bd_lba_cnt);
		dump_stack();
	}
	return NO_ERROR;
}

void sfx_bd_invalidate(unsigned long ldev)
{
	// empty body
}

static int sfx_ioctl_blkroset(sfx_block_device *bdev, void *arg)
{
	unsigned int ro;

	if (sfx_copy_from_user(&ro, arg, sizeof(unsigned int))) {
		return -EFAULT;
	}
	set_device_ro(bdev, ro);
	return 0;
}

int sfx_ioctl_alloc_pu(sfx_mul_drv *sfx_mdrv, void *arg)
{
	sfx_pu_res pu_res = { 0 };
	if (sfx_copy_from_user(&pu_res, arg, sizeof(sfx_pu_res))) {
		return -EFAULT;
	}

	if (-1 == alloc_pu_internal(sfx_mdrv, 1, &pu_res)) {
		return -EPERM;
	}
	if (sfx_copy_to_user(arg, &pu_res, sizeof(sfx_pu_res))) {
		return -EFAULT;
	}
	return 0;
}

int sfx_ioctl_dealloc_pu(sfx_mul_drv *sfx_mdrv, void *arg)
{
	unsigned long pu_id;
	if (sfx_copy_from_user(&pu_id, arg, sizeof(unsigned long))) {
		return -EFAULT;
	}
	dealloc_pu_internal(sfx_mdrv, (int)pu_id);
	return 0;
}

int sfx_get_open_euid(sfx_mul_drv *sfx_mdrv, void *arg)
{
	xt_u64 open_euid;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	unsigned long pflags = 0;

	sfx_spin_lock_irqsave(&gpmem_id->non_psafe.open_fifo_lock, pflags);
	if (FifoIsEmpty(&gpmem_id->open_fifo[MIM_HOT_STREAM0]) != 0) {
		sfx_spin_unlock_irqrestore(&gpmem_id->non_psafe.open_fifo_lock, pflags);
		return -EFAULT;
	}
	open_euid = FifoPeek(&gpmem_id->open_fifo[MIM_HOT_STREAM0]);
	sfx_spin_unlock_irqrestore(&gpmem_id->non_psafe.open_fifo_lock, pflags);

	if (sfx_copy_to_user(arg, &open_euid, sizeof(unsigned long))) {
		return -EFAULT;
	}
	return 0;
}

int sfx_get_ns_recover(sfx_mul_drv *sfx_mdrv, void *arg)
{
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry;
	struct nvme_admin_cmd cmd;
	xt_u32 nsid;

	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s, enter\n", __FUNCTION__);

	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "link block copy from failed\n");
		return -EFAULT;
	}
	nsid = cmd.cdw2;
	ns_entry = &gpmem_id->ns_recover.ns_entry[nsid];

	if (sfx_copy_to_user((void *)cmd.addr, ns_entry, sizeof(ns_entry_t))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: Failed to copy recover info to user\n",
			  __FUNCTION__);
		return -1;
	}
	return 0;
}

int sfx_handle_vu_command(sfx_mul_drv *sfx_mdrv, void *arg)
{
	vu_param_t vu_param;
	sfxError errno;

	if (sfx_copy_from_user(&vu_param, arg, sizeof(vu_param))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "!! VU copy arg memory failed!\n");
		return -EFAULT;
	}

	errno = sfx_dispatch_vu_command(sfx_mdrv, &vu_param);
	if (errno) {
		// following line ensure that the vu_param.result can copy to user
		sfx_copy_to_user(arg, &vu_param, sizeof(vu_param));
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "!! VU Command Exec Error:0x%x!\n", errno);
		return -EFAULT;
	}

	// copy the result to user space
	if (sfx_copy_to_user(arg, &vu_param, sizeof(vu_param))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "!! VU copy arg memory failed!\n");
		return -EFAULT;
	}

	return 0;
}

int sfx_get_bb_table(sfx_mul_drv *sfx_mdrv, void *arg)
{
	xt_u64 *data_buf;

	data_buf = (xt_u64 *)sfx_valloc(256 * FOUR_KB);
	sfx_memset((xt_u8 *)data_buf, 256 * FOUR_KB, 0xFF);
	get_bb_table(sfx_mdrv->devId, data_buf, 0);

	if (sfx_copy_to_user((void *)arg, (xt_u8 *)data_buf, 256 * FOUR_KB)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: Failed to copy bb info to user\n",
			  __FUNCTION__);
		sfx_free(data_buf);
		return -EFAULT;
	}

	sfx_free(data_buf);
	return 0;
}

/**
 * @brief  get current sfx_bd_dev.ko module loading params
 *
 * @param sfx_mdrv
 * @param arg
 *
 * @return
 */
int sfx_get_mod_param(sfx_mul_drv *sfx_mdrv, void *arg)
{
	bd_mod_param_t param = { 0 };
	param.sector_size = sector_size;
	param.atomic_wr = get_atomic_wr_from_host();
	;
	param.multi_stream = get_multi_stream();

	if (sfx_copy_to_user(arg, &param, sizeof(param))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: Failed to mod params info to user\n",
			  __FUNCTION__);
		return -1;
	}
	return 0;
}

int sfx_get_recover(sfx_mul_drv *sfx_mdrv, void *arg)
{
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_map_t *ns_recover = &gpmem_id->ns_recover;

	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s, enter\n", __FUNCTION__);

	if (sfx_copy_to_user(arg, &ns_recover->ns_cnt, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: Failed to copy recover info to user\n",
			  __FUNCTION__);
		return -1;
	}
	return 0;
}

int sfx_set_kv(sfx_mul_drv *sfx_mdrv, void *arg)
{
	xt_u32 nsid;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry;

	if (sfx_copy_from_user(&nsid, arg, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "set kv copy failed\n");
		return -EFAULT;
	}
	ns_entry = &gpmem_id->ns_recover.ns_entry[nsid];
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "set kv\n", __FUNCTION__);
	ns_entry->ns_kv = 1;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	return 0;
}

int sfx_get_block_size(sfx_mul_drv *sfx_mdrv, void *arg)
{
	xt_u32 open_euid;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	mim_param_t *memid_param;
	mim_param_not_power_safe_t *memid_param_nps;

	if (sfx_copy_from_user(&open_euid, arg, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "get block sz copy from failed\n");
		return -EFAULT;
	}
	memid_param = &gpmem_id->param[open_euid];
	memid_param_nps = &gpmem_id->param_nps[open_euid];
	if (sfx_copy_to_user(arg, &memid_param_nps->size, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "get block sz copy to failed\n");
		return -EFAULT;
	}
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s: get memid %d size %d\n", __FUNCTION__, open_euid,
		  memid_param_nps->size);
	return 0;
}

int sfx_link_block(sfx_mul_drv *sfx_mdrv, void *arg)
{
	struct nvme_admin_cmd cmd;
	xt_u32 nsid, stream, block_id, ap, blocks, ms_mode;
	xt_u64 open_euid;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns;
	mim_param_t *memid_param;
	mim_param_not_power_safe_t *memid_param_nps;
	unsigned long flags = 0;

	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "link block copy from failed\n");
		return -EFAULT;
	}
	stream = cmd.nsid;
	block_id = cmd.cdw2;
	ms_mode = cmd.cdw3;
	nsid = (ms_mode == 1) ? stream : 0;

	ns = &gpmem_id->ns_recover.ns_entry[nsid];
	open_euid = mim_peek_open_fifo(sfx_mdrv, stream, &flags);
	memid_param = &gpmem_id->param[open_euid];
	memid_param_nps = &gpmem_id->param_nps[open_euid];
	blocks = sfx_atomic_read(&memid_param_nps->size);
	/* Mark this block as valid in master map */
	ns->ns_block_map[block_id].block_memid = (xt_u16)open_euid;
	ns->ns_block_map[block_id].block_memid |= stream << 14;

	ns->ns_blocks++;
	if (ms_mode == 1)
		ns->ns_cur_bid = block_id;
	else
		ns->ns_stream[stream].sc_bid = block_id;

	ap = sfx_atomic_read(&gpmem_id->param_nps[open_euid].append_point);
	if (ap != 17) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "append_point %d, correct the size(- %d).\n", ap,
			  ap - 17);
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN, "THIS IS RARE !!!!!!!!!!!!!!!!!!!!!\n");
		blocks -= ap - 17;
		ns->ns_block_map[block_id].preserve |= (ap - 17) << 4 & 0xF0;
	}
	if (sfx_copy_to_user((void *)cmd.addr, &blocks, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "link block copy to failed\n");
		return -EFAULT;
	}
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF,
		  "%s: block_id %d <---> mem_id %lu, blocks %d, size %d, block sz %d, ap %d\n", __FUNCTION__,
		  block_id, open_euid, ns->ns_blocks, memid_param_nps->size, blocks, ap);
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	return 0;
}

int sfx_unlink_block(sfx_mul_drv *sfx_mdrv, void *arg)
{
	struct nvme_admin_cmd cmd;
	xt_u32 nsid, stream, block_id, ms_mode;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns;

	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN, "unlink block copy from failed\n");
		return -EFAULT;
	}
	stream = cmd.nsid;
	block_id = cmd.cdw2;
	ms_mode = cmd.cdw3;
	nsid = (ms_mode == 1) ? stream : 0;

	ns = &gpmem_id->ns_recover.ns_entry[nsid];

	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s, unlink block, nsid %d, stream %d, block_id %d\n",
		  __FUNCTION__, nsid, stream, block_id);
	ns->ns_block_map[block_id].block_memid = 0;
	ns->ns_block_map[block_id].llsid = 0;
	ns->ns_block_map[block_id].preserve = 0;
	ns->ns_blocks--;

	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	return 0;
}

int sfx_set_llsid(sfx_bd_device *sfx_bd, void *arg)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	struct nvme_admin_cmd cmd;
	xt_u16 bid;
	xt_u32 llsid, saved, ms_mode, stream;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];

	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "set llsid copy from failed\n");
		return -EFAULT;
	}
	llsid = cmd.cdw10;
	saved = cmd.cdw11;
	ms_mode = cmd.cdw12;
	stream = cmd.cdw13;

	bid = (ms_mode == 1) ? ns_entry->ns_cur_bid : ns_entry->ns_stream[stream].sc_bid;
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s, set llsid, ms_mode %d, bid %d\n", __FUNCTION__,
		  ms_mode, bid);
	if (saved) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "set saved bit\n");
		ns_entry->ns_block_map[bid].preserve |= 8;
	} else {
		ns_entry->ns_block_map[bid].llsid = llsid;
		ns_entry->ns_block_map[bid].preserve++;
	}
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	return 0;
}

int sfx_get_lba(sfx_mul_drv *sfx_mdrv, void *arg)
{
	struct nvme_admin_cmd cmd;
	sfxError status = NO_ERROR;

	memset(&cmd, 0, sizeof(struct nvme_admin_cmd));
	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "set llsid copy from failed\n");
		return -EFAULT;
	}
	status = fm_get_lba(sfx_mdrv, &cmd);
	if (status == ERROR_ASSERT) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "get lba failed\n");
		return -EFAULT;
	}
	if (sfx_copy_to_user((void *)cmd.addr, &sfx_mdrv->kv_get_lba, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "get lba copy to failed\n");
		return -EFAULT;
	}

	return 0;
}

int sfx_record_stream(sfx_mul_drv *sfx_mdrv, void *arg)
{
	xt_u32 stream;
	struct nvme_admin_cmd cmd;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry;

	memset(&cmd, 0, sizeof(struct nvme_admin_cmd));
	if (sfx_copy_from_user(&cmd, arg, sizeof(xt_u32))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "record stream copy from failed\n");
		return -EFAULT;
	}
	stream = cmd.cdw2;
	ns_entry = &gpmem_id->ns_recover.ns_entry[0];
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s, record stream %d\n", __FUNCTION__, stream);
	ns_entry->ns_stream_cnt++;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	return 0;
}

static int sfx_clean_meta(sfx_bd_device *sfx_bd, void *arg)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	ns_entry_t *ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];

	memset(ns_entry->ns_block_map, 0, sizeof(block_map_t) * 512);
	memset(ns_entry->ns_stream, 0, sizeof(ns_stream) * 4);
	ns_entry->ns_blocks = 0;
	ns_entry->ns_cur_bid = 0;
	ns_entry->ns_kv = 0;
	ns_entry->ns_nvm = 0;
	ns_entry->ns_nvm_cnt = 0;
	return 0;
}

static sfx_bio *sfx_build_bio(sfx_mul_drv *sfx_mdrv, xt_u32 off, xt_u32 count, struct page **pages,
			      xt_u32 len)
{
	sfx_bio *bio;
	struct bio_vec *bvec;
	xt_u32 idx_bvec = 0;
	xt_u32 page_len = 4096, sum = 0;
	int i;

	bio = kmem_malloc(sfx_mdrv->devId, sizeof(struct bio) + count * sizeof(struct bio_vec));

	if (bio == NULL) {
		sfx_print(-1, BLK_REQ, PL_ERR, "%s: ERROR, failed to allocate bio\n", __FUNCTION__);
		return bio;
	} else {
		bio->bi_io_vec = bio->bi_inline_vecs;
		bio->bi_max_vecs = count;
	}

	if (bio->bi_vcnt >= bio->bi_max_vecs) {
		sfx_print(-1, BLK_REQ, PL_INF, "%s: bio->bi_vcnt %d, bio->bi_max_vecs %d\n", __FUNCTION__,
			  bio->bi_vcnt, bio->bi_max_vecs);
		return bio;
	}

	/* First bvec has offset */
	bvec = sfx_get_bvec(bio, &idx_bvec);
	bvec->bv_page = pages[0];
	bvec->bv_offset = off;
	bvec->bv_len = min(page_len - bvec->bv_offset, len);
	sum += bvec->bv_len;
	bio->bi_vcnt++;

#if KV_DEBUG
	sfx_print(-1, BLK_REQ, PL_INF, "pages[%d] 0x%p, bv_page 0x%p, bv_len %d, bv_off %d\n", 0, pages[0],
		  bvec->bv_page, bvec->bv_len, bvec->bv_offset)
#endif

		/* Left bvecs except the last one are full pages */
		for (i = 1; i < count - 1; i++)
	{
		bvec = sfx_get_bvec(bio, &idx_bvec);
		bvec->bv_page = pages[i];
		bvec->bv_offset = 0;
		bvec->bv_len = page_len;
		sum += page_len;
		bio->bi_vcnt++;

#if KV_DEBUG
		sfx_print(-1, BLK_REQ, PL_INF, "pages[%d] 0x%p, bv_page 0x%p, bv_len %d, bv_off %d\n", i,
			  pages[i], bvec->bv_page, bvec->bv_len, bvec->bv_offset)
#endif
	}

	/* Last bvec has no offset but is not full */
	if (count > 1) {
		bvec = sfx_get_bvec(bio, &idx_bvec);
		bvec->bv_page = pages[count - 1];
		bvec->bv_offset = 0;
		bvec->bv_len = len - sum;
		bio->bi_vcnt++;
	}

#if KV_DEBUG
	sfx_print(-1, BLK_REQ, PL_INF, "pages[%d] 0x%p, bv_page 0x%p, bv_len %d, bv_off %d\n", count - 1,
		  pages[count - 1], bvec->bv_page, bvec->bv_len, bvec->bv_offset)
#endif

		return bio;
}

static int sfx_kv_request_init(sfx_bio_request **sfxrq, sfx_bio *sfxbio, sfx_bd_device *sfx_bd,
			       xt_u8 is_write, xt_u8 need_malloc)
{
	/*
     * Refer to sfx_mq_tagset():
     * where sfx_mdrv->sfx_mq_tag_set.cmd_size = 4096.
     */
	sfx_bio_request *r = NULL;
	if (need_malloc) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		r = kmem_malloc(sfx_bd->sfx_mdrv->devId, sizeof(sfx_bio_request) + SFX_PAGE_SIZE);
#else
		r = kmem_malloc(sfx_bd->sfx_mdrv->devId, sizeof(sfx_bio_request));
#endif
	} else {
		r = *sfxrq;
	}
	if (r == NULL) {
		return -ENOMEM;
	}

	sfx_memset(r, 0, sizeof(sfx_bio_request));
	r->bio = sfxbio;
	r->q = sfx_bd->sfx_bd_queue;
	if (is_write) {
		r->cmd_flags = SFX_IOCTL_REQ_OP_KV_OUT;
	} else {
		r->cmd_flags = SFX_IOCTL_REQ_OP_KV_IN;
	}
	*sfxrq = r;

	return 0;
}

static inline sfx_bool sfx_kv_check_rq(sfx_bio_request *sfxrq)
{
	return (sfxrq->cmd_flags == SFX_IOCTL_REQ_OP_KV_IN || (sfxrq->cmd_flags == SFX_IOCTL_REQ_OP_KV_OUT));
}

int sfx_handle_ioctl_trim(sfx_bd_device *sfx_bd, void *arg)
{
	struct nvme_dsm_range *range = (struct nvme_dsm_range *)arg;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	int err = NO_ERROR, counter;
	sfx_bio *sfxbio = NULL;
	sfx_bio_request *sfxrq = NULL;
	xt_u32 remained_len = 0, req_sec_num = 0;
	sfx__le64 start_slba = 0, start_bio_lba = 0;
	xt_u8 lba_shift, need_malloc = 1;
	mim_mem_id_t *gpmem_id = NULL;
	xt_u32 sector_sz, max_dsm_lba_num;
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	xt_u8 req_need_free = 0;
#else
	xt_u8 req_need_free = 1;
#endif
	if (sfx_atomic_read(&sfx_mdrv->surprising_remove))
		return -1;
	if (range->slba + (xt_u64)range->nlb >
	    (xt_u64)((xt_u64)sfx_mdrv->lba_per_drv * (xt_u64)MIM_SECTORS_PER_FOUR_KB)) {
		sfx_print(-1, BLK_REQ, PL_INF,
			  "%s: ERROR, slba %lxh nlb %xh %lx lba_per_drive %xh (in 4K) %lx\n", __FUNCTION__,
			  range->slba, range->nlb, range->slba + (xt_u64)range->nlb, sfx_mdrv->lba_per_drv,
			  (xt_u64)((xt_u64)sfx_mdrv->lba_per_drv * (xt_u64)MIM_SECTORS_PER_FOUR_KB));
		return NVME_SC_LBA_RANGE;
	}
	sfxbio = kmem_malloc(sfx_mdrv->devId, sizeof(struct bio));

	if (sfxbio == NULL) {
		sfx_print(-1, BLK_REQ, PL_ERR, "%s: ERROR, failed to allocate bio\n", __FUNCTION__);
		return -1;
	}
	if (sfx_mdrv->gpmem_id != NULL) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		sector_sz = gpmem_id->sector_size;
		if (sector_sz != 512 && sector_sz != 4096) {
			sfx_print(-1, BLK_REQ, PL_WRN, "%s: wrong sector size %d\n", __FUNCTION__, sector_sz);
			return -1;
		}
	} else {
		sfx_print(-1, BLK_REQ, PL_WRN, "%s: warning, gpmem_id is NULL\n", __FUNCTION__);
		return -1;
	}

	remained_len = range->nlb;
	start_slba = range->slba;
	//we only support sector_sz=512 or 4096
	lba_shift = (sector_sz == DEFAULT_SECTOR_SIZE) ? 0 : 3;
	max_dsm_lba_num = MAX_DSM_SEC_NUM >> lba_shift;
	while (remained_len) {
		if (sfx_atomic_read(&sfx_mdrv->surprising_remove)) {
			err = -1;
			goto out;
		}
		sfx_memset(sfxbio, 0, sizeof(sfx_bio));
		req_sec_num = (remained_len > max_dsm_lba_num) ? max_dsm_lba_num : remained_len;

#if KV_DEBUG
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s: nlb %d slba %lx\n", __FUNCTION__, range->nlb,
			  range->slba);
#endif
		start_bio_lba = (start_slba << lba_shift);
		sfx_set_bsec(sfxbio, start_bio_lba);
		sfx_inc_bsz(sfxbio, req_sec_num * (sector_sz));
		sfxbio->bi_vcnt = DIV_ROUND_UP(start_bio_lba, 8);
		sfx_brw(sfxbio) |= SFX_REQ_WRITE;

#if KV_DEBUG
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF, "%s: sfx_bsz %xh, sfx_bsec %xh, vcnt %xh\n",
			  __FUNCTION__, sfx_bsz(sfxbio), sfx_bsec(sfxbio), sfxbio->bi_vcnt);
#endif
		err = sfx_kv_request_init(&sfxrq, sfxbio, sfx_bd, 1, need_malloc);
		if (err != 0) {
			err = -EFAULT;
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s, init sfx_request failed\n",
				  __FUNCTION__);
			if (sfxrq) {
				kmem_mfree(sfxrq);
				sfxrq = NULL;
			}
			goto out;
		}
		//sfx_set_discard_request(sfxrq);
		sfx_kv_set_rq_start(sfxrq);
		err = sfx_req_generic_handler((void *)sfx_bd, (void *)sfxrq, SFX_DSM_DISCARD);
#if KV_DEBUG
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_LOG,
			  "%s: doing I/O, sfxrq->atomic_flags 0x%x, sfxrq->cmd_flags 0x%x"
			  ", returned from blk_ftl, waiting for completion ....\n",
			  __FUNCTION__, sfxrq->atomic_flags, sfxrq->cmd_flags);
#endif

		counter = 100000000;
		do {
			sfx_usleep(1);
			counter--;
		} while (!sfx_kv_check_rq_done(sfxrq) && counter > 0);

		/* Check if sfxrq is completed. */
		if (!sfx_kv_check_rq_done(sfxrq)) {
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s: lost completion for request 0x%p\n",
				  __FUNCTION__, sfxrq);
			err = sfx_ftl_assert(sfx_mdrv, 0);
		}
		need_malloc = !req_need_free;
		start_slba += req_sec_num;
		remained_len -= req_sec_num;
	}

out:
	if (sfxbio) {
		kmem_mfree(sfxbio);
		sfxbio = NULL;
	}
	if (req_need_free && sfxrq) {
		kmem_mfree(sfxrq);
		sfxrq = NULL;
	}
	return err;
}

static int sfx_handle_ioctl_write(sfx_bd_device *sfx_bd, void *arg)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	struct nvme_admin_cmd cmd;
	xt_u64 addr, offset;
	xt_u32 len, off, count, stream, nvm_cnt, kv_flag = 0;
	struct page **pages;
	int err, i, counter, nvm;
	xt_u8 is_write = 1;
	sfx_bio *sfxbio = NULL;
	sfx_bio_request *sfxrq = NULL;

	memset(&cmd, 0, sizeof(struct nvme_admin_cmd));
	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "handle unaligned copy from failed\n");
		return -EFAULT;
	}
	addr = cmd.addr;
	len = cmd.cdw2;
	stream = cmd.cdw3;
	is_write = cmd.cdw10;
	offset = ((xt_u64)cmd.cdw11 << 32) | cmd.cdw12;
	nvm = cmd.cdw13;
	nvm_cnt = cmd.cdw14;

	sfx_bd->sfx_bd_nvm_cnt = nvm_cnt;
#if KV_DEBUG
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF,
		  "%s, addr %lx, len %d, stream %d, rw %d, 11 %x, 12 %x offset %lx %lx, nvm %d\n",
		  __FUNCTION__, addr, len, stream, is_write, cmd.cdw11, cmd.cdw12, offset, offset, nvm);
#endif

	off = offset_in_page(addr);
	count = DIV_ROUND_UP(off + len, PAGE_SIZE);
	pages = kmem_malloc(sfx_mdrv->devId, sizeof(*pages) * count);
	if (!pages) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s, no mem\n", __FUNCTION__);
		return -ENOMEM;
	}

	err = sfxdriver_get_user_pages_fast(addr, count, is_write, pages);
	if (err != count) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s, expect %d, got %d, addr %lu\n", __FUNCTION__,
			  count, err, addr);
		count = err;
		err = -EFAULT;
		goto put_pages;
	}

	sfxbio = sfx_build_bio(sfx_mdrv, off, count, pages, len);
	if (!sfxbio) {
		err = -EFAULT;
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s, build bio failed\n", __FUNCTION__);
		goto put_pages;
	}
	sfx_inc_bsz(sfxbio, len);
	sfx_brw(sfxbio) |= is_write;
	sfx_set_bsec(sfxbio, offset / 512);
	if (nvm) {
		kv_flag |= 1 << KV_NVM_ENABLE_OFF;
		kv_flag |= sfx_bd->sfx_bd_nvm << KV_NVM_INDEX_OFF;
	}
	kv_flag |= stream << KV_STREAM_OFF;
#if KV_DEBUG
	sfx_print(-1, BLK_REQ, PL_LOG, "bi_vcnt %d, rw 0x%x, bsec 0x%x, bsz %d, kv_flag 0x%x\n",
		  sfxbio->bi_vcnt, sfxbio->bi_rw, sfx_bsec(sfxbio), sfx_bsz(sfxbio), kv_flag);
#endif

	err = sfx_kv_request_init(&sfxrq, sfxbio, sfx_bd, is_write, 1);
	if (err != 0) {
		err = -EFAULT;
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "%s, init sfx_request failed\n", __FUNCTION__);
		goto put_pages;
	}
	sfx_kv_set_rq_start(sfxrq);
	err = sfx_req_generic_handler((void *)sfx_bd, (void *)sfxrq, kv_flag);
#if KV_DEBUG
	sfx_print(sfx_mdrv->devId, BLK_REQ, PL_LOG,
		  "%s: doing I/O, sfxrq->atomic_flags 0x%x, sfxrq->cmd_flags 0x%x"
		  ", returned from blk_ftl, waiting for completion ....\n",
		  __FUNCTION__, sfxrq->atomic_flags, sfxrq->cmd_flags);
#endif

	counter = 100000000;
	do {
		sfx_usleep(1);
		counter--;
	} while (!sfx_kv_check_rq_done(sfxrq) && counter > 0);

	/* Check if sfxrq is completed. */
	if (!sfx_kv_check_rq_done(sfxrq)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_LOG, "%s: lost completion for request 0x%p\n",
			  __FUNCTION__, sfxrq);
		BUG_ON(1);
	}

put_pages:
	for (i = 0; i < count; i++) {
		kmem_mfree(pages[i]);
	}
	kmem_mfree(pages);
	if (sfxbio) {
		kmem_mfree(sfxbio);
		sfxbio = NULL;
	}
	if (sfxrq) {
		kmem_mfree(sfxrq);
		sfxrq = NULL;
	}
	return err;
}

static int sfx_get_nvm(sfx_bd_device *sfx_bd, sfx_nvm_recover *nvm, xt_u32 nvm_id, xt_u32 lba)
{
	//  xt_u8     pba[];
	//  xt_u64    nvm_cnt;

	/* get NVM data from CCS */

	/* Pick the correct NVM pair with sfx_bd_id */

	/*
     * Pick the correct NVM with nvm_id
     * 1. PF
     *  When we do recover from PF, nvm_id is not reliable.
     *  Compare the LBA read from NVM headers with the last committed LBA.
     *  Only the LBA-HEADER which is 1 bigger than LBA might be valid.
     * 2. KVSDK Exit + GSD
     *  During GSD, blk_ftl will flash the nvm_id and nvm_cnt to master table. So if those variables
     *  are valid, we can retrieve the NVM data according to the info in master table. Clear the bits
     *  in master table after data retrieving.
     * 3. KVSDK Exit + KVSDK Reload
     *  System is alive so nvm_id and nvm_cnt in sfx_bd_device is valid. Retrieve the NVM data with those
     *  variables.
     */

	/* copy picked NVM to KVSDK NVM buffer */
	//    memcpy(nvm->nvm, pba, 4096);

	/* set KVSDK nvm_cnt */
	//    nvm->nvm_cnt = nvm_cnt;

	return 0;
}

static int sfx_recover_nvm(sfx_bd_device *sfx_bd, void *arg)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	struct nvme_admin_cmd cmd;
	sfx_nvm_recover *nvm;
	xt_u32 nvm_id, lba;

	nvm = sfx_malloc(sizeof(sfx_nvm_recover));
	memset(&cmd, 0, sizeof(struct nvme_admin_cmd));
	memset(nvm, 0, sizeof(sfx_nvm_recover));
	if (sfx_copy_from_user(&cmd, arg, sizeof(struct nvme_admin_cmd))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "recover nvm copy from failed\n");
		return -EFAULT;
	}

	nvm_id = cmd.cdw2;
	lba = cmd.cdw3;

	sfx_get_nvm(sfx_bd, nvm, nvm_id, lba);

	if (sfx_copy_to_user((void *)cmd.addr, nvm, sizeof(sfx_nvm_recover))) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR, "recover nvm copy to failed\n");
		return -EFAULT;
	}
	sfx_mfree(nvm);
	return 0;
}

sfx_bd_device *sfx_get_bd_device_from_gendisk(sfx_block_device *dev)
{
	return GET_SFX_BD_FROM_DISK(dev->bd_disk);
}

sector_t sfx_get_gendisk_capacity(sfx_block_device *dev)
{
	return get_capacity(dev->bd_disk);
}

int sfx_bd_ioctl(sfx_block_device *bdev, fmode_t mode, unsigned cmd, unsigned long arg)
{
	sfx_gendisk *disk = bdev->bd_disk;
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(disk);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;

	// In some case, sfx_mdrv will be NULL, we need use original linux printk print some information to catch the bug
	/*printk("%s, disk:0x%llx, sfx_bd:0x%llx, sfx_mdrv:0x%llx\n\n\n", __FUNCTION__, (xt_u64)disk,
	       (xt_u64)sfx_bd, (xt_u64)sfx_mdrv);*/
	if (!disk || !sfx_bd || !sfx_mdrv) {
		printk("%s, the disk or sfx_bd or sfx_mdrv is invalid!\n", __FUNCTION__);
		return -ENOTTY;
	}

	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
		if (cmd == SFX_NVME_IOCTL_ADMIN_CMD || cmd == NVME_IOCTL_ID) {
			return sfx_ioctl(bdev, cmd, (void __user *)arg);
		} else {
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN,
				  "%s: goldimg %u comp_only %u, no support for cmd 0x%x, return -ENOTTY\n",
				  __FUNCTION__, sfx_mdrv->goldimg_dev, sfx_mdrv->comp_only, cmd);
			return -ENOTTY;
		}
	}
	if (sfx_atomic_read(&sfx_mdrv->surprising_remove)) {
		sfx_print(sfx_mdrv->devId, BLK_REQ, PL_WRN, "device gone in sfx_bd_ioctl!, return -ENOTTY\n");
		return -ENOTTY;
	}
	switch (cmd) {
	case SFX_BLKFLSBUF:
		break;

	case SFX_BLKROSET:
		return sfx_ioctl_blkroset(bdev, (void __user *)arg);

	case SFX_NVME_IOCTL_ADMIN_CMD:
	case SFX_NVME_IOCTL_IO_CMD:
	case NVME_IOCTL_ID:
	case NVME_IOCTL_SUBMIT_IO:
		return sfx_ioctl(bdev, cmd, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_EUID:
		return sfx_get_euid(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_EUID_SIZE:
		return sfx_get_euid_size(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_OPEN_EUID:
		return sfx_get_open_euid(sfx_mdrv, (void __user *)arg);
	case SFX_PU_ALLOCATION:
		return sfx_ioctl_alloc_pu(sfx_mdrv, (void __user *)arg);
	case SFX_PU_DEALLOCATION:
		return sfx_ioctl_dealloc_pu(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_RECOVER:
		return sfx_get_recover(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_SET_KV:
		return sfx_set_kv(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_LINK_BLOCK:
		return sfx_link_block(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_UNLINK_BLOCK:
		return sfx_unlink_block(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_SET_LLSID:
		return sfx_set_llsid(sfx_bd, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_BLOCK_SIZE:
		return sfx_get_block_size(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_LBA:
		return sfx_get_lba(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_RECORD_STREAM:
		return sfx_record_stream(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_CLEAN_META:
		return sfx_clean_meta(sfx_bd, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_WRITE:
		return sfx_handle_ioctl_write(sfx_bd, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_NVM_RECOVER:
		return sfx_recover_nvm(sfx_bd, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_NS_RECOVER:
		return sfx_get_ns_recover(sfx_mdrv, (void __user *)arg);
		// case SG_IO:
		// return sfx_scsi((void *)sfx_bd, (void __user *)arg);

	case SFX_BLK_FTL_VU_CMD:
		return sfx_handle_vu_command(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_MOD_PARAM:
		return sfx_get_mod_param(sfx_mdrv, (void __user *)arg);
	case SFX_BLK_FTL_IOCTL_GET_BB_TABLE:
		return sfx_get_bb_table(sfx_mdrv, (void __user *)arg);

	default:
		break;
	}
	return -ENOTTY;
}

int sfx_bd_getgeo(sfx_block_device *bdev, struct hd_geometry *geo)
{
	sfx_gendisk *disk = bdev->bd_disk;
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(disk);
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	xt_u64 size = 0;
	map_t *pgmap;
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		pgmap = fm_get_gmap(sfx_mdrv);
		if (fm_get_current_state(sfx_mdrv) < FM_NORMAL) {
			return -EIO;
		}
		size = sfx_bd->sfx_bd_lba_cnt * 512;
	}
	geo->heads = BLKFTL_IOCTL_DIE_NR;
	geo->sectors = BLKFTL_IOCTL_PHY_PAGE_SIZE / KERNEL_SECTOR_SIZE;
	geo->cylinders = size / (geo->heads * geo->sectors);
	geo->start = 0;
	return 0;
}

#if ENABLE_VDEV
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
/* adapted from sfx_mq_tagset() */
static int sfx_vdev_tagset(void *bd, struct blk_mq_tag_set *set)
{
	sfx_bd_device *sfx_bd = bd;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;

	set->cmd_size = 4096; // sfx_request
	set->queue_depth = SFX_LINUX_MQ_DEPTH;
	set->numa_node = sfx_mdrv->numa_id;
	set->flags = BLK_MQ_F_SHOULD_MERGE;
	if (sfx_mdrv->goldimg_dev) {
		set->nr_hw_queues = 1;
	} else {
		set->nr_hw_queues = sfx_num_online_cpus();
	}
	if (0 != blk_mq_alloc_tag_set(set)) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Failed to alloc tag set\n");
		return -1;
	}
	return 0;
}
#endif
static int sfx_bd_open(sfx_block_device *bdev, fmode_t mode)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(bdev->bd_disk);
	if (!sfx_bd) {
		sfx_print(-1, BLK_SYS, PL_ERR, "%s, sfx_bd is NULL return -1\n", __FUNCTION__);
		return -ENOMEM;
	}
	if (sfx_bd->sfx_mdrv)
		sfx_inc_blk_ref_cnt_api(sfx_bd->sfx_mdrv->dev_handle.fdk);
	return NO_ERROR;
}
extern void sfx_release_instance(xt_32 instance);
static void sfx_bd_release_instance(xt_32 instance)
{
	sfx_release_instance(instance);
}
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
static int sfx_bd_release(sfx_gendisk *disk, fmode_t mode)
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
static void sfx_bd_release(sfx_gendisk *disk, fmode_t mode)
#endif
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(disk);
	if (sfx_bd)
		sfx_dec_blk_ref_cnt_api(sfx_bd->sfx_mdrv->dev_handle.fdk);
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
	return 0;
#endif
}

/**
 * @brief get the opened counter of disk
 *
 * @param disk
 *
 * @return
 */
static int get_blk_ref_cnt(struct gendisk *disk)
{
	int blk_cnt = 0;
	struct block_device *bdev = bdget_disk(disk, 0);
	if (bdev) {
		blk_cnt = bdev->bd_openers;
	}
	/** printk(KERN_ERR "%s: blk_ref %d\n", disk->disk_name, blk_cnt); */
	return blk_cnt;
}

static void restore_blk_ref(sfx_bd_device *sfx_bd)
{
	int sum = get_blk_ref_cnt(sfx_bd->sfx_bd_disk);
	int i;
	for (i = 0; i < sum; i++) {
		sfx_inc_blk_ref_cnt_api(sfx_bd->sfx_mdrv->dev_handle.fdk);
	}
	sfx_print(sfx_bd->sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: blk_ref_cnt+ %d\n", __func__, sum);
}

/* initialize some missing info for sfx_mdrv/sfx_bd/sysfs */
void reconnect_disk(sfv_device *vdev)
{
	sfx_bd_device *sfx_bd = vdev->sfx_bd;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = NULL;
	ns_entry_t *ns_entry;

	sfx_bd->sfx_bd_disk = vdev->sfv_disk;
	sfx_bd->sfx_bd_queue = vdev->sfv_queue;

	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

		if (sfx_bd->sfx_bd_id == 1) {
			sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		} else if (gpmem_id->ns_recover.ns_bmap & (1 << sfx_bd->sfx_bd_id)) {
			/* retrieve */
			ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
			sfx_bd->sfx_bd_lba_shift = ns_entry->ns_lba_shift;
		} else {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR,
				  "%s: something wrong with sfx_bd_id: %d\n", __FUNCTION__,
				  sfx_bd->sfx_bd_id);
			return;
		}
		sfx_mdrv->num_blks_ns[sfx_mdrv->sfx_bd_cnt - 1] =
			(xt_u32)((sfx_bd->sfx_bd_lba_cnt / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
				 sfx_mdrv->blk_ft_cfg.default_mem_id_size);
	} else {
		xt_u64 lba_per_drive =
			((xt_u64)DRIVE_SIZE / (xt_u64)MIM_SECTORS_PER_FOUR_KB) / FOUR_KB_PER_MAPPING_UNIT;
		xt_u64 nsectors = (xt_u64)((xt_u64)lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB);
		sfx_bd->sfx_bd_lba_cnt = nsectors;
		sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s: size of disk %s "
			  "is %llu sectors, lba per drive %d\n",
			  __FUNCTION__, vdev->sfv_disk->disk_name, sfx_bd->sfx_bd_lba_cnt, lba_per_drive);
	}
	sfx_mdrv->sfx_bd_bmap |= (1 << sfx_bd->sfx_bd_id);

	/* add symbolic link under pcie device because some customer needs it */
	if (sfxdriver_sysfs_create_link((struct kobject *)(sfx_mdrv->ftl_mq_ctx->pdev1),
					&((disk_to_dev(sfx_bd->sfx_bd_disk))->kobj),
					sfx_bd->sfx_bd_disk->disk_name)) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s, Failed to create link under pci device\n",
			  __FUNCTION__);
	}

	sfx_prepare_dev_info();

	/*
	 * when reconnect the gendisk, need restore the sfx_dev->blk_ref by opened
	 * counter of connected gendisk
	 * */
	restore_blk_ref(sfx_bd);
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
		  "%s: size of disk %s "
		  "is %llu sectors, bd_lba_shift %d\n",
		  __FUNCTION__, vdev->sfv_disk->disk_name, sfx_bd->sfx_bd_lba_cnt, sfx_bd->sfx_bd_lba_shift);
}

int sfx_add_disk(sfv_device *vdev)
{
	sfx_bd_device *sfx_bd = vdev->sfx_bd;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	sfx_gendisk *disk;
	xt_u64 nsectors = 0;
	map_t *pgmap;
	mim_mem_id_t *gpmem_id = NULL;
	ns_entry_t *ns_entry;
	xt_u32 new_ns = 0;
	CRASH_LOCATION_T state;

	sfx_spin_lock_init(&vdev->sfv_lock);

	switch (SFX_BLK_QUEUE_TYPE) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	case SFX_BLK_SQ_BIO:
		vdev->sfv_queue = blk_alloc_queue(SFX_GFP_KERNEL);
		if (!vdev->sfv_queue) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "%s, Fail blk_alloc_queue()\n",
				  __FUNCTION__);
			goto out_add_disk;
		}
		vdev->sfv_queue->queue_flags = QUEUE_FLAG_DEFAULT;
		blk_queue_make_request(vdev->sfv_queue, vdev->sfv_make_request);
		break;
#endif // SFX_BLK_SQ_BIO
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	case SFX_BLK_MQ:
		vdev->sfv_queue = blk_mq_init_queue(&vdev->mq_tag_set);
		// Use the kernel macro IS_ERR() to check for error return code.
		if (IS_ERR(vdev->sfv_queue)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "%s, Fail blk_mq_init_queue()\n",
				  __FUNCTION__);
			goto out_add_disk;
		}
		break;
#endif
	default:
		/* fall into.. */
	case SFX_BLK_SQ:
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 0, 0))
		vdev->sfv_queue = blk_init_queue(vdev->sfv_request, &vdev->sfv_lock);
		if (vdev->sfv_queue == NULL) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "%s, Fail blk_init_queue()\n",
				  __FUNCTION__);
			goto out_add_disk;
		}
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 7, 0)
		if (IS_ERR_VALUE(elevator_change(vdev->sfv_queue, "noop")))
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 12, 0)
		if (IS_ERR_VALUE((unsigned long)elevator_change(vdev->sfv_queue, "noop")))
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 18, 0)
		if (IS_ERR_VALUE((unsigned long)elevator_init(vdev->sfv_queue, "noop")))
#else
		if (0)
#endif
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
				  "%s, Switch elevator failed, using default\n", __FUNCTION__);
#else
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "Fail to init sfx_mq\n");
		goto out_add_disk;
#endif // (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))
		break;
	}

	/* need to use persistent vdev settings when creating disk */
	disk = sfx_bd->sfx_bd_disk = vdev->sfv_disk = alloc_disk_node(SFX_BD_MINORS, sfx_mdrv->numa_id);
	if (!disk)
		goto sfv_free_queue;

	sfx_bd->sfx_bd_queue = vdev->sfv_queue;
	sfx_bd_attr_config(sfx_bd);
	sfx_bd->sfx_bd_queue->queuedata = vdev;

	disk->major = vdev->vdev_major;
	disk->first_minor = (sfx_mdrv->devId * SFX_MDRV_MINORS) + (sfx_bd->sfx_bd_id - 1) * SFX_BD_MINORS;
	disk->fops = vdev->fops;
	disk->private_data = vdev;
	disk->queue = vdev->sfv_queue;

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	disk->driverfs_dev = NULL; /* sysfs attributes will show up under /sys/devices/virtual */
#endif

	sprintf(disk->disk_name, "sfd%dn%d", sfx_mdrv->devId, sfx_bd->sfx_bd_id);
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		state = fm_get_current_state(sfx_mdrv);
		if (state < FM_7_REBUILD_DONE) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "error fm state = %x\n", state);
			goto sfv_free_disk;
		}
		pgmap = fm_get_gmap(sfx_mdrv);
		nsectors = (xt_u64)((xt_u64)pgmap->pmaster->lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB);
		if (sfx_bd->sfx_bd_id == 1) {
			if (sfx_bd->sfx_bd_lba_cnt == 0) {
				/* default ns fresh boot */
				sfx_bd->sfx_bd_lba_cnt = nsectors;
				new_ns = 1;
			}
			sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		} else if (gpmem_id->ns_recover.ns_bmap & (1 << sfx_bd->sfx_bd_id)) {
			/* retrieve */
			ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
			sfx_bd->sfx_bd_lba_shift = ns_entry->ns_lba_shift;
		} else {
			/* create new ns */
			sfx_bd_device *sfx_bd0 = (sfx_bd_device *)sfx_mdrv->sfx_bd0;
			xt_u64 lba_remain;
			new_ns = 1;
			lba_remain = sfx_bd0->sfx_bd_lba_cnt - sfx_bd0->sfx_bd_lba_edirty;
			if (lba_remain < sfx_bd->sfx_bd_lba_cnt) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "No enough space left on sfd0n1\n");
				goto sfv_free_queue;
			} else {
				sfx_bd->sfx_bd_lba_shift = sfx_bd0->sfx_bd_lba_cnt - sfx_bd->sfx_bd_lba_cnt;
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
					  "calculate lba shift, sfd0 %llu, sfd %llu, shift %llu\n",
					  sfx_bd0->sfx_bd_lba_cnt, sfx_bd->sfx_bd_lba_cnt,
					  sfx_bd->sfx_bd_lba_shift);
				sfx_bd0->sfx_bd_lba_cnt -= sfx_bd->sfx_bd_lba_cnt;
				/* Update ns_entry for sfx_bd0 */
				ns_entry = &gpmem_id->ns_recover.ns_entry[0];
				ns_entry->ns_lba_cnt = sfx_bd0->sfx_bd_lba_cnt;
				set_capacity(sfx_bd0->sfx_bd_disk, sfx_bd0->sfx_bd_lba_cnt);
				sfx_mdrv->num_blks_ns[0] =
					(xt_u32)((sfx_bd0->sfx_bd_lba_cnt / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
						 sfx_mdrv->blk_ft_cfg.default_mem_id_size);
			}
		}
	} else {
		xt_u64 lba_per_drive =
			((xt_u64)DRIVE_SIZE / (xt_u64)MIM_SECTORS_PER_FOUR_KB) / FOUR_KB_PER_MAPPING_UNIT;
		nsectors = (xt_u64)((xt_u64)lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB);
		sfx_bd->sfx_bd_lba_cnt = nsectors;
		sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s: size of disk %s "
			  "is %llu sectors, lba per drive %d\n",
			  __FUNCTION__, disk->disk_name, sfx_bd->sfx_bd_lba_cnt, lba_per_drive);
	}

	set_capacity(disk, sfx_bd->sfx_bd_lba_cnt);
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		sfx_mdrv->num_blks_ns[sfx_mdrv->sfx_bd_cnt - 1] =
			(xt_u32)((sfx_bd->sfx_bd_lba_cnt / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
				 sfx_mdrv->blk_ft_cfg.default_mem_id_size);
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s, disk %p, vdev %p, sfx_bd %p\n", __FUNCTION__, disk,
		  vdev, vdev->sfx_bd);

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	add_disk(disk);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 20, 0)
	device_add_disk(NULL, disk);
#else
	device_add_disk(NULL, disk, NULL);
#endif
	sfx_prepare_dev_info();

	sfx_mdrv->sfx_bd_bmap |= (1 << sfx_bd->sfx_bd_id);
	/* add new ns info to master map for persistence sfx_bd_id should be less than 9 */
	if (new_ns) {
		gpmem_id->ns_recover.ns_bmap |= (1 << sfx_bd->sfx_bd_id);
		gpmem_id->ns_recover.ns_cnt++;
		ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
		ns_entry->ns_id = sfx_bd->sfx_bd_id;
		ns_entry->ns_lba_cnt = sfx_bd->sfx_bd_lba_cnt;
		ns_entry->ns_lba_cap = sfx_bd->sfx_bd_cap;
		ns_entry->ns_lba_shift = sfx_bd->sfx_bd_lba_shift;
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s, new ns %d lba cnt %lu, shift %lu, added to gpmemid, totoal %d\n", __FUNCTION__,
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_id,
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_lba_cnt,
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_lba_shift,
			  gpmem_id->ns_recover.ns_cnt);
	}
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s, sfx_bd_bmap 0x%x, bd cnt 0x%x\n", __FUNCTION__,
		  sfx_mdrv->sfx_bd_bmap, sfx_mdrv->sfx_bd_cnt);

	/* add symbolic link under pcie device because some customer needs it */
	if (sfxdriver_sysfs_create_link((struct kobject *)(sfx_mdrv->ftl_mq_ctx->pdev1),
					&((disk_to_dev(disk))->kobj), disk->disk_name)) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s, Failed to create link under pci device\n",
			  __FUNCTION__);
	}

	return 0;

sfv_free_disk:
	put_disk(vdev->sfv_disk);

sfv_free_queue:
	sfx_blk_cleanup_queue(vdev->sfv_queue);

out_add_disk:
	sfx_kfree(sfx_bd);
	return -EIO;
}

sfxError sfx_wait_idle(sfv_device *vdev)
{
	sfx_bd_device *sfx_bd = vdev->sfx_bd;
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	xt_u32 count = 0;
	while (sfx_mdrv_empty_query(sfx_mdrv) == 0) {
		msleep_interruptible(5);
		if (count == 2000) {
			//Timeout 20s
			sfx_print(-1, BLK_SYS, PL_ERR, "%s Timeout Outstanding request %d\n", __FUNCTION__,
				  sfx_atomic_read(&sfx_mdrv->outstanding_req));
			return ERROR_TIMEOUT;
		}
		count++;
	}
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s, vdev %p, sfx_bd %p, sfx_mdrv %p, system is idle!\n",
		  __FUNCTION__, vdev, sfx_bd, sfx_mdrv);
	return NO_ERROR;
}

/* for passing callbacks and sysfs stuff */
static struct vdev_register vdev_params = {
	.sfx_bd_open = sfx_bd_open,
	.sfx_bd_release = sfx_bd_release,
	.sfx_bd_release_instance = sfx_bd_release_instance,
	.sfx_bd_revalidate = sfx_bd_revalidate,
	.sfx_bd_ioctl = sfx_bd_ioctl,
	.sfx_bd_getgeo = sfx_bd_getgeo,
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 0, 0))
	.sfx_bd_request = sfx_bd_request,
#endif
	.sfx_bd_stop_queue = sfx_bd_stop_queue,
	.sfx_bd_start_queue = sfx_bd_start_queue,
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	.sfx_vdev_tagset = sfx_vdev_tagset,
	.sfx_mq_queue_rq = sfx_mq_queue_rq,
#if ((LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0)))
	.sfxdriver_blk_mq_map_queues = sfxdriver_blk_mq_map_queues,
#endif
	.sfx_mq_init_hctx = sfx_mq_init_hctx,
	.sfx_mq_complete_rq = sfx_mq_complete_rq,
#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	.sfx_bd_make_request = sfx_bd_make_request,
#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	.sfx_add_disk = sfx_add_disk,
	.reconnect_disk = reconnect_disk,
	.sfx_wait_idle = sfx_wait_idle,
	.dev_info = dev_info,
	.smart_feature_attrs = smart_feature_attrs,
	.debug_attrs = debug_attrs,
	.debug_level_attrs = debug_level_attrs,
	.bd_module = THIS_MODULE,
};

int sfx_bd_add_one(sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	int rc;

	sfv_lock(); /* we have only one copy of vdev_params(above) */
	vdev_params.sfx_bd = sfx_bd;
	vdev_params.nid = sfx_mdrv->numa_id;
	sfx_snprintf(vdev_params.wwid, WWID_MAX, "%04x-%s-%s-%04x", PCI_VENDOR_ID_SFX, sfx_mdrv->sn,
		     sfx_mdrv->opn, sfx_bd->sfx_bd_id);

	rc = sfv_register(&vdev_params); /* register with virtual device driver */
	sfv_unlock();

	return rc;
}

/* ask virtual block driver to forget us */
void sfx_disconnect_disk(sfx_bd_device *sfx_bd, int keep_disk)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;

	sfv_lock();

	sfx_snprintf(vdev_params.wwid, WWID_MAX, "%04x-%s-%s-%04x", PCI_VENDOR_ID_SFX, sfx_mdrv->sn,
		     sfx_mdrv->opn, sfx_bd->sfx_bd_id);
	sfv_disconnect_disk(vdev_params.wwid, keep_disk);

	sfv_unlock();
}

#else // ENABLE_VDEV

xt_u8 is_valid_mdrv(void *mdrv)
{
	xt_u8 is_valid = 0;
	sfx_mul_drv *sfx_mdrv;
	sfx_mul_drv *sfx_mdrv_input = mdrv;

	sfx_spin_lock(&g_sfx_mul_drv_list_lock);
	sfx_list_for_each_entry(sfx_mdrv, &sfx_mul_drv_list, sfx_mdrv_list)
	{
		if (sfx_mdrv == sfx_mdrv_input) {
			is_valid = 1;
			break;
		} else {
			sfx_print(-1, BLK_SYS, PL_WRN, "%s, sfx_mdrv:0x%p is invalid\n", __FUNCTION__,
				  sfx_mdrv_input);
		}
	}
	sfx_spin_unlock(&g_sfx_mul_drv_list_lock);
	return is_valid;
}

static int sfx_bd_open(sfx_block_device *bdev, fmode_t mode)
{
	sfx_bd_device *sfx_bd = GET_SFX_BD_FROM_DISK(bdev->bd_disk);

	sfx_mul_drv *sfx_mdrv;
	if (!sfx_bd) {
		sfx_print(-1, BLK_SYS, PL_WRN, "%s, sfx_bd is NULL return -1\n", __FUNCTION__);
		return -ENOMEM;
	}
	sfx_mdrv = sfx_bd->sfx_mdrv;

	if (!is_valid_mdrv(sfx_mdrv)) {
		sfx_print(-1, BLK_SYS, PL_WRN, "%s, invalid sfx_mdrv;0x%p, return -1\n", __FUNCTION__,
			  sfx_mdrv);
		return -ENOMEM;
	}
	return NO_ERROR;
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
static int sfx_bd_release(sfx_gendisk *disk, fmode_t mode)
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
static void sfx_bd_release(sfx_gendisk *disk, fmode_t mode)
#endif
{
	// pr_inf("%s\n", __FUNCTION__);
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
	return 0;
#endif
}

static int sfx_bd_media_changed(sfx_gendisk *gd)
{
	// pr_inf("%s\n", __FUNCTION__);
	return NO_ERROR;
}

static const struct block_device_operations sfx_bd_fops = { .owner = THIS_MODULE,
							    .open = sfx_bd_open,
							    .release = sfx_bd_release,
							    .media_changed = sfx_bd_media_changed,
							    .revalidate_disk = sfx_bd_revalidate,
							    .ioctl = sfx_bd_ioctl,
							    .getgeo = sfx_bd_getgeo };

int sfx_bd_add_one(sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	sfx_gendisk *disk;
	sfx_device *dev;
	xt_u64 nsectors = 0;
	map_t *pgmap;
	mim_mem_id_t *gpmem_id = NULL;
	ns_entry_t *ns_entry;
	xt_u32 new_ns = 0;
	CRASH_LOCATION_T state;

	sfx_spin_lock_init(&sfx_bd->sfx_bd_lock);
	sfx_mutex_init(&sfx_bd->req_mutex);
	switch (SFX_BLK_QUEUE_TYPE) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
	case SFX_BLK_SQ_BIO:
		sfx_bd->sfx_bd_queue = blk_alloc_queue(SFX_GFP_KERNEL);
		if (!sfx_bd->sfx_bd_queue)
			goto out_free_dev;
		sfx_bd->sfx_bd_queue->queue_flags = QUEUE_FLAG_DEFAULT;
		blk_queue_make_request(sfx_bd->sfx_bd_queue, sfx_bd_make_request);
		break;
#endif // SFX_BLK_SQ_BIO
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	case SFX_BLK_MQ:
		sfx_bd->sfx_bd_queue = blk_mq_init_queue(sfx_mdrv_mq_tag_set(sfx_mdrv));
		// Use the kernel macro IS_ERR() to check for error return code.
		if (IS_ERR(sfx_bd->sfx_bd_queue)) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Fail to init sfx_mq\n");
			goto out_free_dev;
		}
		break;
#endif // SFX_BLK_MQ
	default:
		/* fall into.. */
	case SFX_BLK_SQ:
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 0, 0))
		sfx_bd->sfx_bd_queue = blk_init_queue(sfx_bd_request, &sfx_bd->sfx_bd_lock);
		if (sfx_bd->sfx_bd_queue == NULL)
			goto out_free_dev;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 7, 0)
		if (IS_ERR_VALUE(elevator_change(sfx_bd->sfx_bd_queue, "noop")))
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 12, 0)
		if (IS_ERR_VALUE((unsigned long)elevator_change(sfx_bd->sfx_bd_queue, "noop")))
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 18, 0)
		if (IS_ERR_VALUE((unsigned long)elevator_init(sfx_bd->sfx_bd_queue, "noop")))
#else
		if (0)
#endif
			printk(KERN_WARNING "Switch elevator failed, using default\n");
#else
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Fail to init sfx_mq\n");
		goto out_free_dev;
#endif // (LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0))
		break;
	}

	disk = sfx_bd->sfx_bd_disk = alloc_disk_node(SFX_BD_MINORS, sfx_mdrv->numa_id);
	if (!disk)
		goto out_free_queue;
	sfx_bd_attr_config(sfx_bd);

	disk->major = sfx_bd_dev_major;
	disk->first_minor = (sfx_mdrv->devId * SFX_MDRV_MINORS) + (sfx_bd->sfx_bd_id - 1) * SFX_BD_MINORS;
	disk->fops = &sfx_bd_fops;
	disk->private_data = sfx_bd;
	disk->queue = sfx_bd->sfx_bd_queue;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	disk->driverfs_dev = sfx_mdrv->ftl_mq_ctx->pdev;
#endif
	/* use %d for drive name as standard nvme driver */
	sprintf(disk->disk_name, "sfd%dn%d", sfx_mdrv->devId, sfx_bd->sfx_bd_id);
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		state = fm_get_current_state(sfx_mdrv);
		if (state < FM_7_REBUILD_DONE) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "error fm state = %x\n", state);
			goto out_free_disk;
		}
		pgmap = fm_get_gmap(sfx_mdrv);
		nsectors = (xt_u64)((xt_u64)pgmap->pmaster->lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB);
		if (sfx_bd->sfx_bd_id == 1) {
			if (sfx_bd->sfx_bd_lba_cnt == 0) {
				/* default ns fresh boot */
				sfx_bd->sfx_bd_lba_cnt = nsectors;
				new_ns = 1;
			}
			sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		} else if (gpmem_id->ns_recover.ns_bmap & (1 << sfx_bd->sfx_bd_id)) {
			/* retrieve */
			ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
			sfx_bd->sfx_bd_lba_shift = ns_entry->ns_lba_shift;
		} else {
			/* create new ns */
			sfx_bd_device *sfx_bd0 = (sfx_bd_device *)sfx_mdrv->sfx_bd0;
			xt_u64 lba_remain;
			new_ns = 1;
			lba_remain = sfx_bd0->sfx_bd_lba_cnt - sfx_bd0->sfx_bd_lba_edirty;
			if (lba_remain < sfx_bd->sfx_bd_lba_cnt) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "No enough space left on sfd0n1\n");
				goto out_free_queue;
			} else {
				sfx_bd->sfx_bd_lba_shift = sfx_bd0->sfx_bd_lba_cnt - sfx_bd->sfx_bd_lba_cnt;
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
					  "calculate lba shift, sfd0 %llu, sfd %llu, shift %llu\n",
					  sfx_bd0->sfx_bd_lba_cnt, sfx_bd->sfx_bd_lba_cnt,
					  sfx_bd->sfx_bd_lba_shift);
				sfx_bd0->sfx_bd_lba_cnt -= sfx_bd->sfx_bd_lba_cnt;
				/* Update ns_entry for sfx_bd0 */
				ns_entry = &gpmem_id->ns_recover.ns_entry[0];
				ns_entry->ns_lba_cnt = sfx_bd0->sfx_bd_lba_cnt;
				//blk_queue_chunk_sectors(sfx_bd0->sfx_bd_queue, sfx_bd0->sfx_bd_lba_cnt);
				set_capacity(sfx_bd0->sfx_bd_disk, sfx_bd0->sfx_bd_lba_cnt);
				sfx_mdrv->num_blks_ns[0] =
					(xt_u32)((sfx_bd0->sfx_bd_lba_cnt / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
						 sfx_mdrv->blk_ft_cfg.default_mem_id_size);
			}
		}
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s: size of disk %s "
			  "is %llu lba per drive %d state %d\n",
			  __FUNCTION__, disk->disk_name, sfx_bd->sfx_bd_lba_cnt,
			  pgmap->pmaster->lba_per_drive, state);
	} else {
		xt_u64 lba_per_drive =
			((xt_u64)DRIVE_SIZE / (xt_u64)MIM_SECTORS_PER_FOUR_KB) / FOUR_KB_PER_MAPPING_UNIT;
		nsectors = (xt_u64)((xt_u64)lba_per_drive * (xt_u64)MIM_SECTORS_PER_FOUR_KB);
		sfx_bd->sfx_bd_lba_cnt = nsectors;
		sfx_mdrv->sfx_bd0 = (void *)sfx_bd;
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "%s: size of disk %s "
			  "is %llu sectors, lba per drive %d\n",
			  __FUNCTION__, disk->disk_name, sfx_bd->sfx_bd_lba_cnt, lba_per_drive);
	}

	set_capacity(disk, sfx_bd->sfx_bd_lba_cnt);
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		sfx_mdrv->num_blks_ns[sfx_mdrv->sfx_bd_cnt - 1] =
			(xt_u32)((sfx_bd->sfx_bd_lba_cnt / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
				 sfx_mdrv->blk_ft_cfg.default_mem_id_size);
	}
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	add_disk(disk);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 20, 0)
	device_add_disk(sfx_mdrv->ftl_mq_ctx->pdev, disk);
#else
	device_add_disk(sfx_mdrv->ftl_mq_ctx->pdev, disk, NULL);
#endif
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s, blk ftl add disk %d\n", __FUNCTION__,
		  sfx_bd->sfx_bd_id);

	/* XXX error handling TBD here. */
	dev = disk_to_dev(disk);

	if (sfx_add_dev_info(&dev->kobj)) {
		goto out_free_disk;
	}
	if (sfx_init_sysfs(&sfx_bd->smart_kobj, kobject_get(&dev->kobj), &smart_feature_ktype,
			   "sfx_smart_features")) {
		goto out_free_disk;
	}

	if (sfx_init_sysfs(&sfx_bd->debug_kobj, kobject_get(&dev->kobj), &debug_ktype, "sfx_debug")) {
		goto out_free_disk;
	}

	if (sfx_init_sysfs(&sfx_bd->debug_level_kobj, &sfx_bd->debug_kobj.kobject, &debug_level_ktype,
			   "debug_level")) {
		goto out_free_disk;
	}
	sfx_mdrv->sfx_bd_bmap |= (1 << sfx_bd->sfx_bd_id);
	/* add new ns info to master map for persistence sfx_bd_id should be less than 9 */
	if (new_ns) {
		gpmem_id->ns_recover.ns_bmap |= (1 << sfx_bd->sfx_bd_id);
		gpmem_id->ns_recover.ns_cnt++;
		ns_entry = &gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1];
		ns_entry->ns_id = sfx_bd->sfx_bd_id;
		ns_entry->ns_lba_cnt = sfx_bd->sfx_bd_lba_cnt;
		ns_entry->ns_lba_cap = sfx_bd->sfx_bd_cap;
		ns_entry->ns_lba_shift = sfx_bd->sfx_bd_lba_shift;
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
			  "new ns %d lba cnt %lu, shift %lu, added to gpmemid, totoal %d\n",
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_id,
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_lba_cnt,
			  gpmem_id->ns_recover.ns_entry[sfx_bd->sfx_bd_id - 1].ns_lba_shift,
			  gpmem_id->ns_recover.ns_cnt);
	}
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	}

	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "sfx_bd_bmap 0x%x, bd cnt 0x%x\n", sfx_mdrv->sfx_bd_bmap,
		  sfx_mdrv->sfx_bd_cnt);

	return 0;

out_free_disk:
	put_disk(sfx_bd->sfx_bd_disk);
out_free_queue:
	sfx_blk_cleanup_queue(sfx_bd->sfx_bd_queue);
out_free_dev:
	sfx_kfree(sfx_bd);
	return -EIO;
}
#endif // ENABLE_VDEV

int sfx_bd_add(sfx_mul_drv *sfx_mdrv)
{
	sfx_bd_device *sfx_bd, *next;
	int error = 0;

	/* XXX verify ns number here? */
	sfx_list_for_each_entry_safe(sfx_bd, next, &sfx_mdrv->sfx_bd_list, sfx_bd_list)
	{
		error = sfx_bd_add_one(sfx_bd);
	}
#if ENABLE_VDEV
	/* do nothing, tag set belongs to vdev */
#else
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	if (error) {
		blk_mq_free_tag_set(sfx_mdrv_mq_tag_set(sfx_mdrv));
	}
#endif
#endif // ENABLE_VDEV
	return error;
}

sfx_bd_device *sfx_bd_ns_alloc(sfx_mul_drv *sfx_mdrv, int nsid, void *arg)
{
	sfx_bd_device *sfx_bd;
	struct sfx_id_ns *ns;
	ns_entry_t *ns_entry;
	mim_mem_id_t *gpmem_id = NULL;

	sfx_bd = sfx_kzalloc_node0(sizeof(sfx_bd_device), SFX_GFP_KERNEL, sfx_mdrv->numa_id);
	if (!sfx_bd)
		return NULL;

	sfx_bd->sfx_mdrv = sfx_mdrv;
	sfx_bd->sfx_bd_id = nsid; /* XXX check nsid exist? */
	if (!(sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only)) {
		gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		if (arg) {
			/* create ns from nvme_cli */
			xt_u64 nsize, ncap;
			sfx_bd_device *sfx_bd0 = (sfx_bd_device *)sfx_mdrv->sfx_bd0;
			ns = (struct sfx_id_ns *)arg;
			if (gpmem_id->sector_size == 512) {
				nsize = ns->nsze;
				ncap = ns->ncap;
			} else if (gpmem_id->sector_size == 4096) {
				nsize = ns->nsze * 8;
				ncap = ns->ncap * 8;
			} else {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "sector_size %d is wrong\n");
				return NULL;
			}
			if ((sfx_bd0->sfx_bd_lba_cnt - sfx_bd0->sfx_bd_lba_edirty) < nsize) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "No enough space left on this drive\n");
				return NULL;
			}
			sfx_bd->sfx_bd_lba_cnt = nsize;
			sfx_bd->sfx_bd_cap = ncap;
			sfx_mdrv->sfx_bd_cnt++;

		} else {
			/* retrieve ns info from master map */
			ns_entry = &gpmem_id->ns_recover.ns_entry[nsid - 1];
			sfx_bd->sfx_bd_lba_cnt = ns_entry->ns_lba_cnt;
			sfx_bd->sfx_bd_cap = ns_entry->ns_lba_cap;
			sfx_bd->sfx_bd_lba_shift = ns_entry->ns_lba_shift;
		}
	}

	sfx_mdrv->sfx_bd_checker[nsid] = (xt_u64)sfx_bd;
	sfx_list_add_tail(&sfx_bd->sfx_bd_list, &sfx_mdrv->sfx_bd_list);
	return sfx_bd;
}

sfx_bd_device *sfx_get_bd_by_ns(sfx_mul_drv *sfx_mdrv, xt_u8 nsid)
{
	sfx_bd_device *sfx_bd = NULL;
	if (sfx_mdrv->sfx_bd_bmap & (1 << nsid))
		sfx_bd = (sfx_bd_device *)sfx_mdrv->sfx_bd_checker[nsid];

	return sfx_bd;
}

int sfx_bd_mns_alloc(sfx_mul_drv *sfx_mdrv)
{
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u32 ns_cnt, i = 1;

	if (sfx_mdrv->goldimg_dev || sfx_mdrv->comp_only) {
		ns_cnt = 1;
	} else {
		ns_cnt = gpmem_id->ns_recover.ns_cnt;
	}
	if (ns_cnt < 2) {
		/* one ns */
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%d one ns to be added\n", ns_cnt);
		sfx_mdrv->sfx_bd_cnt = 1;
		ns_cnt = 1;
		if (sfx_bd_ns_alloc(sfx_mdrv, 1, NULL) == NULL) {
			return -ENOMEM;
		}
	} else {
		/* multiple ns stored, recover */
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%d multi-ns to be added, bmap 0x%x\n", ns_cnt,
			  gpmem_id->ns_recover.ns_bmap);
		sfx_mdrv->sfx_bd_cnt = ns_cnt;
		while ((gpmem_id->ns_recover.ns_bmap & (1 << i)) && (i < 9)) {
			/* validate nsid */
			if (gpmem_id->ns_recover.ns_entry[i - 1].ns_id != i) {
				sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
					  "Namespace recover map CORRUPTED!!!\n");
				/* what to do here? */
				return -ENOMEM;
			}
			if (sfx_bd_ns_alloc(sfx_mdrv, i, NULL) == NULL)
				return -ENOMEM;
			if (--ns_cnt == 0)
				break;
			i++;
		}
	}
	return 0;
}

int sfx_linux_bd_add(sfx_mul_drv *sfx_mdrv)
{
	int error;
	error = sfx_bd_mns_alloc(sfx_mdrv);
	if (error) {
		return error;
	}
	error = sfx_bd_add(sfx_mdrv);
	if (error) {
		return error;
	}
	return 0;
}

void sfx_bd_free_linux(sfx_bd_device *sfx_bd)
{
#if ENABLE_VDEV
	/* free symbolic link under pci device */
	sfxdriver_sysfs_remove_link((struct kobject *)(sfx_bd->sfx_mdrv->ftl_mq_ctx->pdev1),
				    sfx_bd->sfx_bd_disk->disk_name);
#else
	del_gendisk(sfx_bd->sfx_bd_disk);
	sfx_exit_sysfs(&sfx_bd->smart_kobj);
	sfx_exit_sysfs(&sfx_bd->debug_level_kobj); /* release before debug_kobj */
	sfx_exit_sysfs(&sfx_bd->debug_kobj);

	put_disk(sfx_bd->sfx_bd_disk);
	sfx_blk_cleanup_queue(sfx_bd->sfx_bd_queue);
#endif // ENABLE_VDEV
	sfx_list_del(&sfx_bd->sfx_bd_list);
	sfx_kfree(sfx_bd);
}

// #define get_cpu_ptr(var) ({ preempt_disable(); this_cpu_ptr(var); })
// #define put_cpu_ptr(var) do { (void)(var); preempt_enable(); } while (0)
// <linux/percpu-defs.h>
sfx_hot_rd_t *sfx_get_cpu_ptr_to_hot_rd(sfx_hot_rd_t *phr)
{
	return get_cpu_ptr(phr);
}
sfx_hot_rd_t *sfx_per_cpu_ptr_to_hot_rd(sfx_hot_rd_t *phr, xt_32 cpu_iter)
{
	return per_cpu_ptr(phr, cpu_iter);
}

void sfx_blk_ftl_complete_request(sfx_mul_drv *sfx_mdrv, sfx_bio_request *req, int err, xt_u64 start)
{
	/* Command came from IOCTL */
	if (sfx_kv_check_rq(req)) {
#if KV_DEBUG
		sfx_print(-1, BLK_REQ, PL_INF,
			  "%s: request is from scsi I/O, req 0x%p, req->cmd_flags 0x%llx (%llu)\n",
			  __FUNCTION__, req, req->cmd_flags, req->cmd_flags);
#endif
		sfx_kv_set_rq_done(req);
		return;
	}
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ)

	// SQ
	sfx_blk_end_request_all(req, err);

#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)

	// SQ_BIO
	sfx_end_io_acct(sfx_mdrv, req->bio, start);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 3, 0)
	if (err) {
		// this kernel call will set the bio error and end the bio request
		bio_io_error(req->bio);
	} else {
		bio_endio(req->bio);
	}
#else
	bio_endio(req->bio, err);
#endif

#elif (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

// MQ
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 12, 0))
	blk_mq_end_request(req, err);
	//blk_mq_complete_request(req);
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 3, 0))
// kernel version >= 4.3.0
#ifdef RHEL_RELEASE_CODE
// Redhat OS
#if (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7, 2))
	blk_mq_complete_request(req, err);
#else
	req->errors = err;
	blk_mq_complete_request(req);
#endif
#elif defined(CENTOS_OS) || defined(UBUNTU_OS)
	// Centos or Ubuntu
	blk_mq_complete_request(req, err);
#else
	// Place-holder for other Linux Distro - please correct if this does not fit.
	blk_mq_complete_request(req, err);
#endif // UBUNTU_OS
#else
// kernel version < 4.3.0
#ifdef RHEL_RELEASE_CODE
// Redhat OS
#if (RHEL_RELEASE_CODE > RHEL_RELEASE_VERSION(7, 2))
	blk_mq_complete_request(req, err);
#else
	req->errors = err;
	blk_mq_complete_request(req);
#endif
#elif defined(CENTOS_OS) || defined(UBUNTU_OS)
	// Centos or Ubuntu
	req->errors = err;
	blk_mq_complete_request(req);
#else
	// Place-holder for other Linux Distro - please correct if this does not fit.
	req->errors = err;
	blk_mq_complete_request(req);
#endif

#endif // KERNEL >= 4.3.0

#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
}

void sfx_get_bvec_cnt(blk_ftl_coh_bio *coh_bio, sfx_bio *bio)
{
	if (coh_bio->is_trim) {
		coh_bio->bvec_cnt = bio->bi_vcnt;
	} else {
		sfx_bio_vec tmp_bvec;
		sfx_bvec_iter tmp_iter;
		coh_bio->bvec_cnt = 0;
		sfx_bio_for_each_segment(tmp_bvec, bio, tmp_iter)
		{
			coh_bio->bvec_cnt++;
		}
	}
}

xt_u32 linux_get_dsm_pages(sfx_bio_request *req)
{
	return req->bio->bi_vcnt;
}

void linux_req2bv(sfx_bio_request *req, xt_u32 *nr_bvec_page, xt_u32 *nr_bvec_not_trim, xt_u64 *size)
{
	sfx_bio *bio;
	__rq_for_each_bio (bio, req) {
		if (sfx_is_discard_request(req)) {
			(*nr_bvec_page) += bio->bi_vcnt;
			break;
		} else {
			sfx_bio_vec bvec;
			sfx_bvec_iter iter;
			bio_for_each_segment (bvec, bio, iter) {
				(*nr_bvec_page)++;
				(*nr_bvec_not_trim)++;
			}
			(*size) += sfx_bsz(bio);
		}
	}
}

// 2.6.32 struct request {
// ...
//		sector_t __sector;			/* sector cursor */
//		unsigned int __data_len;	/* total data len */
//		struct bio *bio;
//
// 4.13.0 struct request {
// ...
//		int tag;
//		sector_t __sector;	/* sector cursor */
//		struct bio *bio;
//
// <linux/blkdev.h>
sfx_bio *sfx_get_req_bio(sfx_bio_request *req)
{
	// the bio member (pointer to struct bio) is at diff offset amongst diff linux versions.
	return req->bio;
}

sfx_bio *sfx_get_bio_bi_next(sfx_bio *bio)
{
	return bio->bi_next;
}

xt_u32 linux_get_total_outstanding_size(sfx_mul_drv *sfx_mdrv)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 11)
	/*
    xt_u32 tot_outstanding_size = 0;
    xt_u32 cpu_iter = 0;
    sfx_for_each_online_cpu(cpu_iter) {
        tot_outstanding_size += *sfx_per_cpu_ptr_to_xt_32(sfx_mdrv->outstanding_size, cpu_iter);
    }
    return tot_outstanding_size;
    */
	return sfx_atomic_read(&sfx_mdrv->outstanding_size);
#else
	return sfx_atomic_read(&sfx_mdrv->outstanding_size);
#endif
}

xt_u64 linux_get_bio_bi_sector(struct bio *bio)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
	return bio->bi_sector;
#else
	return bio->bi_iter.bi_sector;
#endif
}
void linux_set_bio_bi_sector(struct bio *bio, xt_u64 lba)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
	bio->bi_sector = lba;
#else
	bio->bi_iter.bi_sector = lba;
#endif
}

xt_u32 linux_get_bio_bi_size(struct bio *bio)
{
	return (bio_sectors(bio) << SECTOR_SHIFT);
}
void linux_inc_bio_bi_size(struct bio *bio, xt_u32 inc)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
	bio->bi_size += inc;
#else
	bio->bi_iter.bi_size += inc;
#endif
}

xt_u32 linux_get_bio_bi_vcnt(struct bio *bio)
{
	return bio->bi_vcnt;
}
xt_u32 linux_get_bio_bi_flags(struct bio *bio)
{
	return bio->bi_flags;
}

struct bio_vec *linux_get_bio_bio_vec(struct bio *bio)
{
	return bio->bi_io_vec;
}
xt_u32 linux_get_bio_biovec_bv_offset(struct bio *bio)
{
	return bio->bi_io_vec->bv_offset;
}
xt_u32 linux_get_bio_biovec_bv_len(struct bio *bio)
{
	return bio->bi_io_vec->bv_len;
}

struct bio_vec *linux_get_bio_iovec_idx_postinc(struct bio *bio, xt_u32 *idx)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
	return bio_iovec_idx(bio, ((*idx)++));
#else
	return &(bio->bi_io_vec[(*idx)++]);
#endif
}

struct bio_vec *linux_get_advance_iter_iovec(struct bio *bio, xt_u32 *idx_bvec, sfx_bvec_iter *bvec_iter,
					     struct bio_vec *bvec)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)
	// first bvec
	if (!((*idx_bvec)++))
		return bvec;
	sfx_bio_advance_iter(bio, bvec_iter, bvec->bv_len);
	*bvec = sfx_bio_iter_iovec(bio, *bvec_iter);
#endif
	return bvec;
}

xt_u32 linux_get_bio_offset(struct bio *bio)
{
	return bio_offset(bio);
}

xt_u32 linux_is_unaligned_bio(struct bio *bio)
{
	xt_u32 idx = 0;
	sfx_bio_vec bvec;
	sfx_bvec_iter iter;
	sfx_bio_for_each_segment(bvec, bio, iter)
	{
		if (!idx) {
			if (sfx_bvecoff(bvec) + sfx_bveclen(bvec) != PAGE_SIZE)
				return 1;
		} else if (idx == bio->bi_vcnt - 1) {
			if (sfx_bvecoff(bvec))
				return 1;
		} else {
			if (sfx_bveclen(bvec) != PAGE_SIZE)
				return 1;
		}
		idx++;
	}
	return ((bio_sectors(bio) % PAGE_SECTORS) || sfx_bsec(bio) % (1 << (PAGE_SHIFT - SECTOR_SHIFT)));
}

/*
 * Init bvec iter
 */
void sfx_init_bvec_iter(sfx_bio *bio, sfx_bvec_iter *bvec_iter, struct bio_vec *bvec)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
	*bvec_iter = (bio)->bi_idx;
#else
	*bvec_iter = bio->bi_iter;
	*bvec = sfx_bio_iter_iovec(bio, *bvec_iter);
#endif
}

int linux_get_rq_data_dir_from_request(struct request *req)
{
	return (int)rq_data_dir(req);
}

#if SFX_USE_REMOTE_CMPL
static void _sfx_blk_ftl_complete_request_remote(void *data)
{
	sfx_smp_ctx *ctx = data;
	sfx_bio_end_request_free_req(ctx->sfx_mdrv, ctx->req, 1, 1);
}

void sfx_blk_ftl_smt_remote_cmpl(sfx_mul_drv *sfx_mdrv, struct sfx_request *req)
{
	xt_u32 single_thread = sfx_single_thread_detection(sfx_mdrv);
	if ((req->smp_ctx.smt_cpu != sfx_get_cpuid()) && (sfx_atomic_read(&sfx_mdrv->outstanding_req) > 1) &&
	    ((single_thread && req->bvec_tot_len > 2) || (!single_thread)) &&
	    (req->req_type == SFX_READ_REQ)) {
		req->smp_ctx.sfx_mdrv = sfx_mdrv;
		req->smp_ctx.req = req;
		req->smp_ctx.end_req = 1;
		req->smp_ctx.free_res = 1;
		req->req->csd.func = _sfx_blk_ftl_complete_request_remote;
		req->req->csd.info = &req->smp_ctx;
		req->req->csd.flags = 0;
		sfxdriver_smp_call_function_single_async(req->smp_ctx.smt_cpu, &req->req->csd);
	} else {
		sfx_bio_end_request_free_req(sfx_mdrv, req, 1, 1);
	}
}
#endif

void sfx_check_and_pin_cpu(void *drv)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)drv;
	struct task_struct *p = sfx_get_current();
	if (g_cpu_map_mgm.cpu_pinning && g_cpu_map_mgm.app_pin && g_cpu_map_mgm.proc_map->filled &&
	    g_cpu_map_mgm.core_map->filled && !sfx_mdrv->single_job_pin) {
		sfx_cpumask_var_t mask;
		if (sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
			sfx_cgroup_config(sfx_mdrv->devId, mask);
			if (sfx_cpumask_full(&p->cpus_allowed) || sfx_cpumask_equal(&p->cpus_allowed, mask)) {
				if (!sfx_set_thd_cpu_mask(sfx_mdrv->devId, APP_THD)) {
					sfx_mdrv->single_job_pin = 1;
					sfx_mdrv->single_job_task = p;
				}
			}
			sfx_free_cpumask_var(mask);
		}
	}
}

void sfx_set_core_mask(xt_u16 core_id, sfx_cpumask_var_t mask)
{
	struct sfx_cpu_map *cpu_map;
	xt_u32 i;
	cpu_map = (struct sfx_cpu_map *)((xt_u8 *)(&g_cpu_map_mgm.core_map->cpu_map) +
					 g_cpu_map_mgm.core_map->cpu_map_size * core_id);
	for (i = 0; i < cpu_map->sibling_num; i++) {
		sfx_cpumask_set_cpu(cpu_map->sibling_id[i], mask);
	}
}

xt_u32 sfx_get_proc_pos(xt_u32 dev_id, xt_u16 *proc_idx, xt_u16 *proc_off)
{
	xt_u16 valid_core_num = g_cpu_map_mgm.core_map->valid_core_num;
	xt_u16 phys_proc_num = g_cpu_map_mgm.proc_map->phys_proc_num;
	xt_u16 core_per_proc = valid_core_num / phys_proc_num;
	xt_u16 num_dev_per_proc;

	num_dev_per_proc = core_per_proc / g_cpu_map_mgm.cgroup_step;
	if (num_dev_per_proc == 0) {
		//the total cores on one processor is not even enough
		//for a cgroup step, there is no meaning to pin CPU anymore
		sfx_print(-1, BLK_SYS, PL_INF, "core_per_proc %d\n", core_per_proc);
		return 1;
	}
	*proc_idx = (dev_id / num_dev_per_proc) % phys_proc_num;
	*proc_off = (dev_id % num_dev_per_proc) * g_cpu_map_mgm.cgroup_step;

	return 0;
}

xt_u32 sfx_cgroup_config(xt_u32 dev_id, sfx_cpumask_var_t mask)
{
	struct sfx_phys_proc_map *phys_proc_map;
	xt_u16 proc_idx;
	xt_u16 proc_off;
	xt_u16 i;

	if (g_cpu_map_mgm.cgroup_step < 2) {
		//If cgroup_step is too small, it is meanling to pin CPU
		//since multiple internal heave threads are going to share
		//one CPU.
		return 1;
	}

	if (sfx_get_proc_pos(dev_id, &proc_idx, &proc_off)) {
		return 1;
	}

	phys_proc_map = (struct sfx_phys_proc_map *)((xt_u8 *)(&g_cpu_map_mgm.proc_map->phys_proc_map) +
						     g_cpu_map_mgm.proc_map->proc_map_size * proc_idx);

	sfx_print(-1, BLK_SYS, PL_LOG, "proc_idx %d, dev_id %d, proc_off %d\n", proc_idx, dev_id, proc_off);
	sfx_cpumask_clear(mask);
	for (i = 0; i < g_cpu_map_mgm.cgroup_step; i++) {
		struct sfx_cpu_map *cpu_map;
		xt_u16 core_id;
		xt_u16 j;
		core_id = phys_proc_map->cores[proc_off + i];

		sfx_print(-1, BLK_SYS, PL_LOG, "core_id %d\n", core_id);
		cpu_map = (struct sfx_cpu_map *)((xt_u8 *)(&g_cpu_map_mgm.core_map->cpu_map) +
						 g_cpu_map_mgm.core_map->cpu_map_size * core_id);
		for (j = 0; j < cpu_map->sibling_num; j++) {
			xt_u16 sid = cpu_map->sibling_id[j];
			sfx_cpumask_set_cpu(sid, mask);
			sfx_print(-1, BLK_SYS, PL_LOG, "sid %d\n", sid);
		}
	}

	return 0;
}

void sfx_get_node_cpumask(xt_u32 node_id, sfx_cpumask_var_t mask)
{
	struct sfx_phys_proc_map *phys_proc_map;
	struct sfx_proc_map *proc_map;
	xt_u32 i;

	proc_map = g_cpu_map_mgm.proc_map;
	phys_proc_map = (struct sfx_phys_proc_map *)((xt_u8 *)(&proc_map->phys_proc_map) +
						     proc_map->proc_map_size * node_id);
	for (i = 0; i < phys_proc_map->core_num; i++) {
		xt_u32 core_id = phys_proc_map->cores[i];
		sfx_set_core_mask(core_id, mask);
	}
}

xt_32 sfx_set_cpus_node(xt_u32 node_id)
{
	sfx_cpumask_var_t mask;
	if (!sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
		return SFX_ERR_ENOMEM;
	}
	sfx_cpumask_clear(mask);
	sfx_get_node_cpumask(node_id, mask);
	sfx_set_cpus_allowed_ptr(sfx_get_current(), mask);
	sfx_free_cpumask_var(mask);
	return NO_ERROR;
}

xt_32 sfx_set_thd_cpu_mask(xt_u32 dev_id, xt_u32 thd_idx)
{
	sfx_cpumask_var_t mask;
	if (!sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
		return SFX_ERR_ENOMEM;
	}

	if (!sfx_cgroup_config(dev_id, mask)) {
		if (g_cpu_map_mgm.cgroup) {
			//if cgroup is set, all internal heavy
			//lifting threads are bound to same CPU
			//group
			sfx_set_cpus_allowed_ptr(sfx_get_current(), mask);

		} else {
			//if cpu_pinning is set but not cgroup,
			//all internal heavy lifting threads are
			//bound to a specific CPU inside a cgroup

			//get the first cpu in a cgroup
			//first CPU is for gc_write_process
			//second CPU is for gc_read_process
			//third CPU is for blk_ftl_coh
			struct sfx_phys_proc_map *phys_proc_map;
			xt_u32 core_id;
			xt_u16 proc_idx = 0, proc_off = 0;
			sfx_get_proc_pos(dev_id, &proc_idx, &proc_off);
			phys_proc_map = (struct sfx_phys_proc_map
						 *)((xt_u8 *)(&g_cpu_map_mgm.proc_map->phys_proc_map) +
						    g_cpu_map_mgm.proc_map->proc_map_size * proc_idx);
			core_id = phys_proc_map->cores[proc_off + (thd_idx % g_cpu_map_mgm.cgroup_step)];

			sfx_print(-1, BLK_SYS, PL_LOG, "Pin thread idx %d of card %d to core_id %d\n",
				  thd_idx, dev_id, core_id);
			sfx_cpumask_clear(mask);
			//set CPU mask for all the siblings in a core
			sfx_set_core_mask(core_id, mask);
			sfx_set_cpus_allowed_ptr(sfx_get_current(), mask);
		}
	}
	sfx_free_cpumask_var(mask);
	return NO_ERROR;
}
