// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_throttle.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_THROTTLE_H__
#define __BLK_FTL_THROTTLE_H__

#include "osal.h"

#define BLK_FTL_THROTTLE_TARGET_SPEED          (2)          // 2G per second for write
#define BLK_FTL_THROTTLE_DEFAULT_SLEEP_TIME    (4000)       // default sleep time: 4ms
#define INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME  (sfx_mdrv->fast_cycle_mode?24000:(240000 * 4 * 32UL))     //(5000000)    // default sleep time to check invalid_page count: 5 seconds
#define GC_BG_CHECK_DEFAULT_SLEEP_TIME         (sfx_mdrv->fast_cycle_mode?24000:(240000 * 4UL))     // default sleep time to check if no incoming requests from block layer 1 seconds
#define HOT_THROTTLE_SPEED_REFRESH_TIME        (INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME / BLK_FTL_THROTTLE_DEFAULT_SLEEP_TIME)// dafault refresh time hot_throttle_speed is 5s
#define BORROW_CREDIT                          (77)         // roughly comes out as 300MBpS

#define MIN_CREDIT_ACT_MODE                    (80 * INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME / 1000)  //320MB
#define MIN_CREDIT_HIGH_ACT_MODE               (80 * INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME / 1000)

#define MIN_CREDIT                             (20 * INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME / 1000)  //80MB
#define MIN_CREDIT_HIGH                        (20 * INVALID_PAGE_CHECK_DEFAULT_SLEEP_TIME / 1000)

#define GC_CREDIT_REFRESH_TIME                 (8000 / BLK_FTL_THROTTLE_DEFAULT_SLEEP_TIME)         // 4 ms
#define GC_CREDIT_ADJUST_TIME                  ((8000 * 40) / BLK_FTL_THROTTLE_DEFAULT_SLEEP_TIME)   // 16ms

#define FREE_SPACE_THRESHOLD                   (0xe5000)

#define MIN_INVALID_PAGE_BUDGET                (8) //has to be bigger or equal than GC_CCS_WR_UNIT

#define LOWEST_CARRY_ONS_3                       (-200L)
#define LOWEST_CARRY_ONS_2                       (-50L)
#define LOWEST_CARRY_ONS_1                       (-10L)
#define LOWEST_CARRY_ONS                       (0L)
#define CARRY_ONS_1                            (15L)
#define CARRY_ONS_2                            (200L)
#define CARRY_ONS_3                            (400L)
#define CARRY_ONS_4                            (1000L)

#define C_CARRY_ONS_0                            (1000L)
#define C_CARRY_ONS_1                            (1000L)
#define C_CARRY_ONS_2                            (3000L)
#define C_CARRY_ONS_3                            (8000L)
#define C_CARRY_ONS_4                            (15000L)
#define C_CARRY_ONS_5                            (160000L)

#define DECREMENT_INVALID_PGAE_BUDGET_1        (2)
#define DECREMENT_INVALID_PGAE_BUDGET_2        (5)
#define DECREMENT_INVALID_PGAE_BUDGET_3        (10)

#define INCREMENT_INVALID_PGAE_BUDGET_1          (2)
#define INCREMENT_INVALID_PGAE_BUDGET_2          (3)
#define INCREMENT_INVALID_PGAE_BUDGET_3          (3)
#define INCREMENT_INVALID_PGAE_BUDGET_4         (20)
#define CNT_INV_PG_HIS_WINDOW                  (32)
#define C_DECREMENT_INVALID_PGAE_BUDGET_1        (0)
#define C_DECREMENT_INVALID_PGAE_BUDGET_2        (0)
#define C_DECREMENT_INVALID_PGAE_BUDGET_3        (0)
#define C_DECREMENT_INVALID_PGAE_BUDGET_4        (0)
#define C_DECREMENT_INVALID_PGAE_BUDGET_5        (0)
#define C_INCREMENT_INVALID_PGAE_BUDGET        (0)
/**
 * @brief: data structure containing important information about throttling
 */
typedef struct blk_ftl_throttle_s
{
    xt_u32   sleep_us;                 /* micro second to determine the credit */
    xt_u32   full_speed;               /* full speed to do writes per sleep_us */
    xt_64   hot_throttle_speed;
    xt_u32   resi_pages_5s;
    xt_u32   err_credit;
    xt_u32   prev_invalid_pages;
    xt_u32   his_cnt_inv_pg[CNT_INV_PG_HIS_WINDOW];
    xt_64    counter_invalid_page;
    xt_64    avg_cnt_inv_pg;
    xt_u64   avg_cnt;
    xt_u64   carry_on_factor;
    xt_u64   prev_gc_credit;
    xt_u64   prev_invalid_page_budget;
    xt_u64   curr_invalid_page_budget;
    sfx_atomic64_t tot_ipage_bgt;
    sfx_atomic_t tot_ipage_bgt_cnt;
    xt_u64   check_240ms;
    xt_u64   check_1s;
    xt_u64   check_120ms;
    xt_64    carry_on_120_ms;
    xt_u32   inv_delta;
    xt_u32   tot_read_bio;
    xt_u32   tot_write_bio;
    xt_u8   r2_die;
    xt_u8   no_irq_coal;
    xt_u8   hp_rd_off;
    xt_u32 gc_speed_from_hot;
    xt_u32 hot_speed;
    xt_64    borrow_credit;
    xt_64    ipage_tot;
    xt_64   ipage_cnt;
    sfx_bool flag_borrow_credit;
} blk_ftl_throttle_t;

/**
 * @brief: 1. Initialize the blk_ftl_throttle_t structure.
 *         2. Create throttle thread. Create blk_ftl_end_req thread.
 */
void blk_ftl_throttle_init(struct sfx_mul_drv_s *sfx_mdrv);

/**
 *@brief:  exit function for blk_ftl_throttle
 */
void blk_ftl_throttle_exit(struct sfx_mul_drv_s *sfx_mdrv);

#endif // __BLK_FTL_THROTTLE_H__
