// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_maplog_eh.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_MAPLOG_EH_H__
#define __BLK_FTL_MAPLOG_EH_H__

#include "mem_id_mgr.h"
#include "flat_map.h"
#include "sfx_bd_dev.h"

///
///\pagetitle Map Log Error Handling
///
///This section we introduce how to handle map log error, normally when data has error
///if RAID rebuild failed, then we lost the data, but for map log, if we lost it, we can rebuild
///map log from host data, this is just the princple of how to handle map log error
///
///First let's see some maplog data structure.
///
///\subtitle MapLog EH data structure
///
///First is the The ``MAPLOG_EH_ELEMENT_POOL_SIZE``, it is the max size that we can handle map log error
///
///::
///
///    #define MAPLOG_EH_ELEMENT_POOL_SIZE                (1024)//(2048)
///
#define MAPLOG_EH_ELEMENT_POOL_SIZE                (1024)//(2048)

///
///And the ``blk_ftl_maplog_eh_state`` is all the state that used in handle map log error
///
typedef enum
{
    MAPLOG_EH_0_IDLE,
    MAPLOG_EH_1_READ_REVERSE_HEADER,
    MAPLOG_EH_2_THREAD_EXIT,
} blk_ftl_maplog_eh_state;

///
///``blk_ftl_maplog_eh_element_t`` is the map log eh entry, it records all the info needed
///to do a map log error handle, such as the memid used, map log index in this memid, and
///the offset of map log
///
///::
///
///    typedef struct blk_ftl_maplog_eh_queue_s
///    {
///        // maplog eh queue head
///        struct sfx_list_head            next;
///
///        // the dirve context
///        sfx_mul_drv                 *sfx_mdrv;
///
///        // the memid of this map log belongs
///        xt_u32                           mem_id;
///
///        // the map log index in this memid
///        xt_u32                          maplog_index;
///
///        // the offset within this memid
///        flat_map_t                      offset;
///
///        // the maplog used to store recovered data
///        map_log_t                       *pmap_log;
///    }blk_ftl_maplog_eh_element_t;
///
typedef struct blk_ftl_maplog_eh_queue_s
{
    // maplog eh queue head
    struct sfx_list_head            eh_list;

    // index
    xt_u32                          index;

    // the dirve context
    sfx_mul_drv                    *sfx_mdrv;

    // the memid of this map log belongs
    xt_u32                          mem_id;

    // the map log index in this memid
    xt_u32                          maplog_index;

    // the offset within this memid
    xt_u32                          offset;

    // the maplog used to store recovered data
    map_log_t                      *pmap_log;

    //maplog eh callback function
    ccs_callback_t                 cb;

    //callback parameter
    void                           *cbctxt;
} blk_ftl_maplog_eh_element_t;

///
///``blk_ftl_maplog_eh_ctxt_t`` is the core management structure of maplog eh, it is the map log eh control
///structure, it contains all the info need to handle map log error. eh element queues
///
typedef struct blk_ftl_maplog_eh_s
{
    sfx_mul_drv                     *sfx_mdrv;
    blk_ftl_maplog_eh_state         eh_state;
    // map log error handle queue head
    struct sfx_list_head            maplog_eh_list_head;
    // the fifo and element array
    FIFO                            eh_element_fifo;
    FIFO_TYPE                       eh_element_fifo_array[MAPLOG_EH_ELEMENT_POOL_SIZE];
    blk_ftl_maplog_eh_element_t     eh_pool[MAPLOG_EH_ELEMENT_POOL_SIZE];
    xt_u32                          rd_send_cnt;
    xt_u32                          rd_recv_cnt;
    xt_u32                          exit_flag;
} blk_ftl_maplog_eh_ctxt_t;

// map log eh init function
sfxError blk_ftl_maplog_eh_init(sfx_mul_drv *sfx_mdrv);

// map log eh thread exit function
void blk_ftl_maplog_eh_exit(sfx_mul_drv *sfx_mdrv);

sfxError blk_ftl_maplog_eh_insert_req(sfx_mul_drv *sfx_mdrv, xt_u32  mem_id, xt_u32 index,
                                      map_log_t *pmap_log, ccs_callback_t cb, void *context);

// get first host data offset in a maplog
sfxError maplog_get_first_data_offset(sfx_mul_drv *sfx_mdrv, xt_u32 memid, xt_u32 maplog_index, flat_map_t *map, xt_u32 *in_maplog_window);

// rebuild maplog from host data
sfxError maplog_rebuild(sfx_mul_drv *sfx_mdrv, xt_u32 memid, xt_u32 maplog_index, map_log_t *pmaplog);

#endif // __BLK_FTL_MAPLOG_EH_H__
