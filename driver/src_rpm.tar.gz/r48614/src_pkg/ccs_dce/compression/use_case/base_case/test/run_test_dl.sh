#!/usr/bin/env bash
set -e

if test $# -lt 1; then
echo -e "usage: ./run_test_dl.sh input_file"
exit 1
fi

if [[ ! -c /dev/sfx0 ]]; then
    echo "No SFX Device found! Please install SFX RPM package first!"
    exit 1
fi

perms==$(stat /dev/sfx0 | sed -n '/^Access: (/{s/Access: (\([0-9]\+\).*$/\1/;p}')
if [[ $perms != 666 ]]; then
    chmod 666 /dev/sfx0
fi
 
make clean 1>/dev/null 2>&1 && make 1>/dev/null 2>&1
./utils/csszlib_test_dl $1
./utils/zlib_test_dl $1
