/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_init.c
 * ---------------------------------------------------------------------------
 */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "osal.h"
#include "osutil.h"
#include "sfx_ioctl.h"
#include "sfx_driver.h"
#include "sfx_hw_regs.h"
#include "sfxdriver_spi_common.h"

#define STA_MODE_BIT 0x2
#define SWITCH_CAL_PERIOD 100 // in us
#define SWITCH_CAL_TOTAL 10000 // multiple of SWITCH_CAL_PERIOD
#define I2C_READ_MASK 0x2
// these offsets are used to caculate the address form
// the end of the total nor
#define NOR_IDENTITY_OPN_OFFSET 0xFFE0
#define NOR_IDENTITY_SN_OFFSET 0x10000
#define NOR_IDENTITY_HW_OFFSET 0x20000
#define NOR_IDENTITY_SW_OFFSET 0x30000
#define TP_MASK 0x30 // for triphora+ and panther board
#define MAX_RETRY 7
#define MSK_CAP_IO_POS 15
#define CLR_CAP_IO_POS 15
#define ALARM_CAP_IO_POS 15
#define I2C_SLVA_INTR_POS 12
#define CHIP_INTR_STATUS 0x100040
#define CHIP_INTR_MASK 0x100044
#define CHIP_INTR_RC 0x100048
#define MAX_RETRY_NUM 0x6
#define VSHUNT 0x00000000
#define VOLTAGE_FACTOR 221
#define VOLTAGE_DIVIDER 100000
#define CURRENT_FACTOR 1983
#define CURRENT_DIVIDER 1000
#define RS_FACTOR 7
#define POWER_DIVIDER 1000

extern xt_u32 post_prog_sequence[][2];
extern xt_u32 post_b17a_sequence[][2];
extern xt_u32 post_b17a_hdp_sequence[][2];
extern xt_u32 async_sequence[][2];
extern xt_u32 ddr_sequence[][2];
extern xt_u32 ddr3_sequence[][2];
extern xt_u32 ddr_b17a_hdp_sequence[][2];
extern xt_u32 post_tsb_sequence[][2];
extern xt_u32 tsb_sequence[][2];
extern xt_u32 b17a_MLC_prog_ctrl[][2];
extern xt_u32 b17a_ddr2_enh_set_feat[][2];
extern xt_u32 scr_seed_lut[1024][3];
extern char *sfx_cc;

xt_u32 vref_tab_l06b[32][2] = {
	// A3A2A1A0    A7A6A5A4
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00F6F1EC, 0x00000000 }, //  1
	{ 0xF6F1E7E7, 0x000000F6 }, //  2
	{ 0x00FbF6F6, 0x00000000 }, //  3
	{ 0xF6ECECE7, 0x000000F6 }, //  4
	{ 0x0A0A0A0A, 0x00000000 }, //  5
	{ 0xECECE2DD, 0x000000EC }, //  6
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00F6F1EC, 0x00000000 }, //  1
	{ 0xF6F6F1E7, 0x000000F6 }, //  7
	{ 0x00232323, 0x00000000 }, //  8
	{ 0x00fbfbfb, 0x00000000 }, //  9
	{ 0x00f6f6f6, 0x00000000 }, // 10
	{ 0x00f1f1f1, 0x00000000 }, // 11
	{ 0x00ececec, 0x00000000 }, // 12
	{ 0x00e7e7e7, 0x00000000 }, // 13
	{ 0x00e2e2e2, 0x00000000 }, // 14
	{ 0x00dddddd, 0x00000000 }, // 15
	{ 0x05000000, 0x00000005 }, // 16
	{ 0x0a000000, 0x0000000a }, // 17
	{ 0x0f000000, 0x0000000f }, // 18
	{ 0x14000000, 0x00000014 }, // 19
	{ 0x19000000, 0x00000019 }, // 20
	{ 0x1e000000, 0x0000001e }, // 21
	{ 0x19000000, 0x00000019 }, // 22
	{ 0xfb000000, 0x000000fb }, // 23
	{ 0xf6000000, 0x000000f6 }, // 24
	{ 0xf1000000, 0x000000f1 }, // 25
	{ 0xec000000, 0x000000ec }, // 26
	{ 0xe7000000, 0x000000e7 }, // 27
	{ 0xe2000000, 0x000000e2 }, // 28
};
xt_u32 vref_tab_b17a[32][2] = {
	// A3A2A1A0    A7A6A5A4
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00000000, 0x00000000 }, //  1
	{ 0x00000000, 0xF0F0F200 }, //  2
	{ 0xF0ECECEC, 0x00000000 }, //  3
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00000000, 0x00000000 }, //  1
	{ 0x00F0F3F5, 0xF7FBFCF0 }, //  4,c2,M retry1
	{ 0xFBFBFBF9, 0x00000000 }, //  5,c2,M retry1
	{ 0x00EBEDF0, 0xF0F5F4DF }, //  6,c3,M retry2
	{ 0xFBF5F4F4, 0x00000000 }, //  7,c3,M retry2
	{ 0x00DFDFDF, 0xFAF9F3F1 }, //  8,C4,M RETRY3
	{ 0xF3F6F9FA, 0x00000000 }, //  9,C4,M RETRY3
	{ 0x00D1D1D1, 0xE0E5E6B6 }, // 10,C5,M RETRY4
	{ 0xE2E0DADD, 0x00000000 }, // 11,C5,M RETRY4
	{ 0x00EDF700, 0xF6FA001B }, // 12,C6,M RETRY6
	{ 0x0DF4F7F9, 0x00000000 }, // 13,C6,M RETRY6
	{ 0x00000000, 0x00000000 }, //  0
	{ 0x00000000, 0x00000000 }, //  1
	{ 0x00000000, 0xF0F0F200 }, //  2
	{ 0xF0ECECEC, 0x00000000 }, //  3
	{ 0x00F2F308, 0xEFF70828 }, // 14,C7,M RETRY7
	{ 0xF6F1F3F2, 0x00000000 }, // 15,C7,M RETRY7
	{ 0x00000000, 0x00000000 }, // 16
	{ 0x00000000, 0x00000000 }, // 17
	{ 0x00000000, 0x00000000 }, // 18
	{ 0x00000000, 0x00000000 }, // 19
	{ 0x00000000, 0x00000000 }, // 20
	{ 0x00000000, 0x00000000 }, // 21
	{ 0x00000000, 0x00000000 }, // 22
	{ 0x00000000, 0x00000000 }, // 23
	{ 0x00000000, 0x00000000 }, // 24
	{ 0x00000000, 0x00000000 }, // 25
};
// cTLC Table
xt_u32 vref_tab_tsb_c[32][2] = {
	// G E C A     F D B
	{ 0xF8FCFCFC, 0x00F9FC00 }, //  0, 512Gb, TSB moderate28
	{ 0x00000000, 0x00000000 }, //  1, 512Gb, TSB vt0
	{ 0xF8020200, 0x00FE0004 }, //  2, 512Gb, TSB vt6
	{ 0xF6F7F8EC, 0x00F6F4F8 }, //  3, 512Gb, TSB vt1
	{ 0xF4F6FC00, 0x00F8F600 }, //  4, 512Gb, TSB vt7
	{ 0xE804FA08, 0x00FE0002 }, //  5, 512Gb, TSB vt4
	{ 0xE4F0F6FC, 0x00E8F0FC }, //  6, 512Gb, TSB vt8
	{ 0xEEF2FB00, 0x00F2F200 }, //  7, 512Gb, TSB vt13
	{ 0x00000000, 0x00000000 }, //  1, 512Gb, TSB vt0
	{ 0xF8FCFCFC, 0x00F9FC00 }, //  0, 512Gb, TSB moderate28
	{ 0xECF4FE04, 0x00F0F604 }, //  8, 512Gb, TSB vt25
	{ 0xE8FC0204, 0x00F40006 }, //  9, 512Gb, TSB vt10
	{ 0xE2F80104, 0x00EFFC06 }, //  10, 512Gb, TSB vt16
	{ 0xDEEBF5FC, 0x00E3ECFC }, //  11, 512Gb, TSB vt14
	{ 0xDCE6EEF4, 0x00E0E6F4 }, //  12, 512Gb, TSB vt20
	{ 0x080A0606, 0x000A0404 }, //  13, 512Gb, TSB vt2
	{ 0xF407FF00, 0x00F9FC00 }, //  14, 512Gb, TSB vt3
	{ 0x00F40408, 0x00040406 }, //  15, 512Gb, TSB vt5
	{ 0xF4F6020A, 0x00FA0002 }, //  16, 512Gb, TSB vt9
	{ 0xF800FFF0, 0x00E8F4FC }, //  17, 512Gb, TSB vt11
	{ 0xFC0C0804, 0x00020406 }, //  18, 512Gb, TSB vt12
	{ 0xEEFD0100, 0x00F4FC02 }, //  19, 512Gb, TSB vt15
	{ 0xF8FCFCFC, 0x00FCFAFE }, //  20, 512Gb, TSB vt17
	{ 0xF0FAF8F8, 0x00F6F8FC }, //  21, 512Gb, TSB vt18
	{ 0xECEEF4F8, 0x00F0EEF8 }, //  22, 512Gb, TSB vt19
	{ 0xE0F4FAFC, 0x00ECF6FE }, //  23, 512Gb, TSB vt21
	{ 0x080C0C0C, 0x000C0C0E }, //  24, 512Gb, TSB vt22
	{ 0x02080A08, 0x0006080C }, //  25, 512Gb, TSB vt23
	{ 0xFCFE0408, 0x0000FE08 }, //  26, 512Gb, TSB vt24
	{ 0xFC06FC0C, 0x00100808 }, //  27, 512Gb, TSB vt26
	{ 0xD4DEECEC, 0x00D8E0F0 }, //  28, 512Gb, TSB vt27
	{ 0x05050505, 0x00050505 }, //  29, 512Gb, soft-rd29
};

// eTLC Retry Table
xt_u32 vref_tab_tsb_e[32][2] = {
	// G E C A      F D B
	{ 0xF4FA0002, 0x00FA0000 }, //  0,  256Gb, TSB // moderate
	{ 0x00000000, 0x00000000 }, //  1,  256Gb, TSB // 0x00
	{ 0xF5030100, 0x00FD0104 }, //  2,  256Gb, TSB // 2
	{ 0x0b070914, 0x000b0912 }, //  3,  256Gb, TSB // Modi-1
	{ 0xF1FFFDFC, 0x00F7FD04 }, //  4,  256Gb, TSB // 4
	{ 0x06040006, 0x000402FE }, //  5,  256Gb, TSB // 30
	{ 0xE5EFEFF4, 0x00EDF1F4 }, //  6,  256Gb, TSB // 25
	{ 0x0107090C, 0x0001090A }, //  7,  256Gb, TSB // 28
	{ 0xFD010300, 0x00FF0404 }, //  8,  256Gb, TSB // 13
	{ 0xE9FBFDFC, 0x00F1FF02 }, //  9,  256Gb, TSB // 8
	{ 0x07090915, 0x00070A0f }, //  10, 256Gb, TSB // Modi-2
	{ 0xF6F7F8EC, 0x00F6F4F8 }, //  11, 512Gb, cTSB// vt1
	{ 0x07FB0913, 0x00080B10 }, //  12, 256Gb, TSB // Modi-3
	{ 0x00000000, 0x00000000 }, //  1,  256Gb, TSB // 0x00
	{ 0xF4FA0002, 0x00FA0000 }, //  0,  256Gb, TSB // moderate
	{ 0x0b070914, 0x000b0912 }, //  13, 256Gb, TSB // 26
	{ 0xE5F3FB04, 0x00EDF900 }, //  14, 256Gb, TSB // 21
	{ 0xFD0305FC, 0x00FD0304 }, //  15, 256Gb, TSB // 15
	{ 0xE5F70300, 0x00ED0102 }, //  16, 256Gb, TSB // 12
	{ 0xF90305FE, 0x00FF0502 }, //  17, 256Gb, TSB // 16
	{ 0xEDFF0104, 0x00F50106 }, //  18, 256Gb, TSB // 6
	{ 0xF5F3F900, 0x00F5FDFE }, //  19, 256Gb, TSB // 23
	{ 0xE9FB0504, 0x00F30306 }, //  20, 256Gb, TSB // 10
	{ 0xF5FDFFFE, 0x00F9FF02 }, //  21, 256Gb, TSB // 31
	{ 0xF1FF0100, 0x00F90104 }, //  22, 256Gb, TSB // 3
	{ 0xFB0101FE, 0x00FD0302 }, //  23, 256Gb, TSB // 14
	{ 0xF5030504, 0x00FD0506 }, //  24, 256Gb, TSB // 1
	{ 0xEFF9FBFE, 0x00F7FDFE }, //  25, 256Gb, TSB // 24
	{ 0xE7F7FF0C, 0x00EDFD07 }, //  26, 256Gb, TSB // 34
	{ 0x050B0D0E, 0x00090F0E }, //  27, 256Gb, TSB // 27
	{ 0xF1FF0104, 0x00F9050A }, //  28, 256Gb, TSB // 5
	{ 0x05050505, 0x00050505 }, //  29, 512Gb, soft-rd29
};
// sfx_init_db:
// each entry: revid, length, reg_0, val_0, reg_1, val_1, ....
extern xt_u32 sfx_init_db[][INIT_DB_ENTRY_SIZE];

//count bit when v=1 output = 1;
static xt_u32 find_cont_bits_c(xt_u32 v)
{
	if (1 == v) {
		return 1; // modify bug.
	} else {
		return find_cont_bits(v);
	}
}

int skip_init = 0;
sfx_module_param(skip_init, int, 0);

int skip_nand_cfg = 0;
sfx_module_param(skip_nand_cfg, int, 0);

void sfx_load_sequence(struct sfx_dev *dev, xt_u32 (*seq)[2])
{
	while ((*seq)[0] != 0) {
		fis_indirect_write32(dev, dev->bar, (*seq)[0], (*seq)[1]);
		seq++;
	}
}

void sfx_set_sta_mode(struct sfx_dev *dev, int mode)
{
	xt_u32 reg_val;
	reg_val = fis_indirect_read32(dev, dev->bar, SFX_P1_CTRL);
	if (mode) {
		reg_val |= STA_MODE_BIT;
	} else {
		reg_val &= ~STA_MODE_BIT;
	}
	fis_indirect_write32(dev, dev->bar, SFX_P1_CTRL, reg_val);
	reg_val = fis_indirect_read32(dev, dev->bar,
				      SFX_P1_CTRL); // to flush write
}

int hard_hang = 0;

xt_u32 sfx_set_get_feature_generic(struct sfx_dev *dev, int isSet, xt_u32 values[2], xt_u32 msg)
{
	int fatal_err = 0;
	xt_u32 total = 0, res = 0, i;
	xt_u32 firstMsg;

	if (isSet) {
		firstMsg = 0x00030b00;
	} else {
		firstMsg = 0x00030c00;
	}

	/* swtich to sta mode */
	sfx_set_sta_mode(dev, 1);

	/* set feature cmd */
	fis_indirect_write32(dev, dev->bar, CMD_MESSAGE, firstMsg | (msg << 24));

	for (i = 0; i < 2; i++) {
		fis_indirect_write32(dev, dev->bar, CMD_MESSAGE, values[i]);
	}

	sfx_usleep(100);

	/* drain results */
	total = fis_indirect_read32(dev, dev->bar, STAS_MSG_COUNT);
	while (total != 3) {
		sfx_pr_info("WARNING: %s, total:%d", dev->name, total);
		fatal_err++;
		sfx_usleep(100);
		total = fis_indirect_read32(dev, dev->bar, STAS_MSG_COUNT);
		if (fatal_err > 500 || hard_hang == 1) {
			hard_hang = 1;
			sfx_pr_info("WARNING: %s, total:%d hard_hang.\n", dev->name, total);
			return 0;
		}
		if (fatal_err > 500 || hard_hang == 1) {
			hard_hang = 1;
			sfx_pr_info("WARNING: %s, total:%d hard_hang.\n", dev->name, total);
			return 0;
		}
	}
	for (i = 0; i < total; i++) {
		if (dev->device_gone)
			return 0;
		res = fis_indirect_read32(dev, dev->bar, STAS_MESSAGE);
#ifdef INIT_DEBUG
		sfx_printk(" 0x%08x", res);
#endif
	}
#ifdef INIT_DEBUG
	sfx_printk("\n");
#endif
	/* disable sta mode */
	sfx_set_sta_mode(dev, 0);

	return res;
}

xt_u32 sfx_set_feature(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce, xt_u32 lun, xt_u32 addr, xt_u32 val,
		       xt_u32 msg, xt_u32 nand_type)
{
	xt_u32 vals[2];
	xt_u32 P2;
	if (nand_type == MU_L06B) {
		P2 = (ch << 4) | (ce << 1) | lun;
	} else {
		// TSB BiCS
		P2 = (ch << 4) | (ce << 2) | lun;
	}
	vals[0] = val << 8;
	vals[1] = (addr << 24) | (P2 << 16) | (val >> 24);

	return sfx_set_get_feature_generic(dev, 1, vals, msg);
}

xt_u32 sfx_get_feature(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce, xt_u32 lun, xt_u32 addr, xt_u32 msg,
		       xt_u32 nand_type)
{
	xt_u32 vals[2];
	xt_u32 P2;

	if (nand_type == MU_L06B) {
		P2 = ((ch << 4) | (ce << 1)) | lun;
	} else {
		// TSB BiCS
		P2 = ((ch << 4) | (ce << 2)) | lun;
	}
	vals[0] = 0;
	vals[1] = (addr << 24) | (P2 << 16);

	return sfx_set_get_feature_generic(dev, 0, vals, msg);
}

int do_set_feature_all_ce(struct sfx_dev *dev, xt_u32 addr, xt_u32 val, sfx_bool printw)
{
	int ch = 0, ce = 0;
	sfx_board_nand_type *card_info = &dev->card_info;
	xt_u32 msg_id, msg_dw;
	xt_u32 cmd_cnt = 0,
	       sta_cnt = 0; //card_info->num_ce * card_info->num_ch;
	xt_u32 res = 0, total, timer;

	int init_set_feat_index; // set_feature sequence: 1: drive strength; 2: enable differential mode
		//                       3: switch to ddr2; 0: other set features
	if ((addr & 0xFF) == 0x10) {
		init_set_feat_index = 1;
	} else if ((addr & 0xFF) == 0x02) {
		init_set_feat_index = 2;
	} else if ((addr & 0xFF) == 0x01) {
		init_set_feat_index = 3;
	} else {
		init_set_feat_index = 0;
	}

	/* swtich to sta mode */
	sfx_set_sta_mode(dev, 1);

	while (1) {
		if (dev->device_gone) {
			return -ENODEV;
		}
		// send command in when cmd_fifo is not full
		total = fis_indirect_read32(dev, dev->bar, CMD_MSG_COUNT);
		if ((sta_cnt == cmd_cnt) && (total != 0)) {
			sfx_pr_info("ERROR: %s, HW abnormal!\n", dev->name);
			return -ETIME;
		}

		while (total < 6) {
			if (dev->device_gone) {
				return -ENODEV;
			}
			if (card_info->nand_type == MU_L06B) {
				msg_id = (ch << 4) | (ce << 1);
			} else {
				msg_id = (ch << 4) | (ce << 2);
			}
			// dw0
			msg_dw = 0x00030b00 | (msg_id << 24);
			fis_indirect_write32(dev, dev->bar, CMD_MESSAGE, msg_dw);
			// dw1
			msg_dw = val << 8;
			fis_indirect_write32(dev, dev->bar, CMD_MESSAGE, msg_dw);
			//dw 3
			msg_dw = (addr << 24) | (msg_id << 16) | (val >> 24);
			fis_indirect_write32(dev, dev->bar, CMD_MESSAGE, msg_dw);
			cmd_cnt = cmd_cnt + 1;
			if (cmd_cnt == card_info->num_ce * card_info->num_ch) {
				break;
			}
			if (ce == card_info->num_ce - 1) {
				ce = 0;
				ch = ch + 1;
			} else {
				ce = ce + 1;
			}
			total = fis_indirect_read32(dev, dev->bar, CMD_MSG_COUNT);
#ifdef INIT_DEBUG
			sfx_pr_info("CH %d, CE %d: msg_id = 0x%02x, total=%d\n", ch, ce, msg_id, total);
#endif
		}

		// drain status
		while (sta_cnt < cmd_cnt) {
			if (dev->device_gone) {
				return -ENODEV;
			}
			total = fis_indirect_read32(dev, dev->bar, STAS_MSG_COUNT);
			total = total & 0xf;
			timer = 0;
			while (total < 3) {
				if (dev->device_gone) {
					return -ENODEV;
				}
				total = fis_indirect_read32(dev, dev->bar, STAS_MSG_COUNT);
				timer++;
				if (timer > 100) {
					sfx_pr_info("ERROR: %s, set_feature status read time out\n",
						    dev->name);
					return -ETIME;
				}
			}
			while (total >= 3) {
				if (dev->device_gone) {
					return -ENODEV;
				}
				res = fis_indirect_read32(dev, dev->bar, STAS_MESSAGE);
				msg_id = (res >> 24) & 0xff;
				ch = msg_id >> 4;
				if (card_info->nand_type == MU_L06B) {
					ce = (msg_id >> 1) & 0x7;
				} else {
					ce = (msg_id >> 2) & 0x3;
				}

				res = fis_indirect_read32(dev, dev->bar, STAS_MESSAGE);
				res = fis_indirect_read32(dev, dev->bar, STAS_MESSAGE);
#ifdef INIT_DEBUG
				sfx_pr_info("CH%d, CE%d: 0x%08x,", ch, ce, res);
				if ((res & 0xFF) != 0xe0) {
					dev->init_err++;
				}
#else
				if (dev->init_msg_store & (init_set_feat_index != 0)) {
					if (init_set_feat_index == 1) {
						dev->fail_drive_strength_store[(ch * card_info->num_ce + ce) *
									       3] = ch & 0x0F;
						dev->fail_drive_strength_store[(ch * card_info->num_ce + ce) *
										       3 +
									       1] = ce & 0x0F;
						dev->fail_drive_strength_store[(ch * card_info->num_ce + ce) *
										       3 +
									       2] = res & 0xFF;
					} else if (init_set_feat_index == 2) {
						dev->fail_en_diffmode_store[(ch * card_info->num_ce + ce) * 3] =
							ch & 0x0F;
						dev->fail_en_diffmode_store[(ch * card_info->num_ce + ce) * 3 +
									    1] = ce & 0x0F;
						dev->fail_en_diffmode_store[(ch * card_info->num_ce + ce) * 3 +
									    2] = res & 0xFF;
					} else if (init_set_feat_index == 3) {
						dev->fail_switch_ddr_store[(ch * card_info->num_ce + ce) * 3] =
							ch & 0x0F;
						dev->fail_switch_ddr_store[(ch * card_info->num_ce + ce) * 3 +
									   1] = ce & 0x0F;
						dev->fail_switch_ddr_store[(ch * card_info->num_ce + ce) * 3 +
									   2] = res & 0xFF;
					}
				}
				if (((res & 0xFF) != 0xe0)) {
					if (printw) {
						sfx_pr_info("WARNING: %s, CH%d, CE%d: 0x%08x\n", dev->name,
							    ch, ce, res);
					}
					dev->init_err++;
				}
#endif
				total = total - 3;
				sta_cnt = sta_cnt + 1;
			}
		}
		// operation finishes
		if (cmd_cnt == card_info->num_ce * card_info->num_ch) {
			break;
		}
	}
	/* disable sta mode */
	sfx_set_sta_mode(dev, 0);
	return 0;
}

xt_u32 sfx_nand_set_drive_strength(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce)
{
	return sfx_set_feature(dev, ch, ce, 0, 0x10, 0x03, 0x0, MU_L06B);
}

xt_u32 sfx_nand_switch_to_ddr_sub(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce, int diff_mode_en)
{
	xt_u32 res;
	if (diff_mode_en == 1) {
		res = sfx_set_feature(dev, ch, ce, 0, 0x2, 0x06, 0x11, MU_L06B);
	}
	res = sfx_set_feature(dev, ch, ce, 0, 0x1, 0x66, 0x11, MU_L06B);
	return res;
}

/* Analog of do_reset_all in python code */
int sfx_do_reset(struct sfx_dev *dev, int nand_type, sfx_bool printw)
{
	int ret = 0;
	xt_u32 ce;
	xt_u64 ch;
	xt_u32 res = 0;
	xt_u64 pba_addr;
	sfx_board_nand_type *card_info = &dev->card_info;
	for (ch = 0; ch < card_info->num_ch; ch++) {
		for (ce = 0; ce < card_info->num_ce; ce++) {
			pba_addr = (((xt_u64)ch << card_info->hw_off_ch) + (ce << card_info->hw_off_ce)) &
				   0xFFFFFFFFFF;
			if (!(ret = sfx_nand_pba_reset(dev, pba_addr, &res))) {
				if (dev->init_msg_store) {
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3] = ch & 0x0F;
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3 + 1] = ce &
												       0x0F;
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3 + 2] = res &
												       0xFF;
				}
				if (((res & 0xFF) != 0xe0)) {
					if (printw)
						sfx_pr_info("WARNING: %s, RESET ch%ld:ce%d 0x%08x\n",
							    dev->name, ch, ce, res);
					dev->init_err++;
				}
#ifdef INIT_DEBUG
				else {
					sfx_pr_info("OK:RESET %d:%d 0x%08x\n", ch, ce, res);
				}
#endif
			} else {
				if (dev->init_msg_store) {
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3] = ch & 0x0F;
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3 + 1] = ce &
												       0x0F;
					dev->fail_reset_store[(ch * card_info->num_ce + ce) * 3 + 2] = 0x00;
				}
				sfx_pr_err("%s: %s, RESET failed %d returned, ch%d:ce%d 0x%08x\n",
					   __FUNCTION__, dev->name, ret, ch, ce, res);
				return ret;
			}
		}
	}
	return ret;
}

void do_switch_rdmz(struct sfx_dev *dev, int on, sfx_bool print_warning)
{
	do_set_feature_all_ce(dev, 0x92, on, print_warning); // Jinjin
}

void do_switch_diff_mode(struct sfx_dev *dev, xt_u32 nand_type, sfx_bool printw)
{
	int ch, ce;
	sfx_board_nand_type *card_info = &dev->card_info;
	for (ch = 0; ch < card_info->num_ch; ch++) {
#ifdef INIT_DEBUG
		sfx_pr_info("CH %d\n", ch);
#endif
		for (ce = 0; ce < card_info->num_ce; ce++) {
			xt_u32 res;
			res = sfx_set_feature(dev, ch, ce, 0, 0x2, 0x06, 0x11, card_info->nand_type);
			if (((res & 0xFF) != 0xe0) && printw) {
				sfx_pr_info("WARNING: %s, Switch %d:%d 0x%08x\n", dev->name, ch, ce, res);
			}
		}
	}
}

void do_set_feature_all(struct sfx_dev *dev, xt_u32 addr, xt_u32 val, xt_u32 nand_type)
{
	int ch, ce, lun;
	sfx_board_nand_type *card_info = &dev->card_info;
	for (ch = 0; ch < card_info->num_ch; ch++) {
#ifdef INIT_DEBUG
		sfx_pr_info("CH %d\n", ch);
#endif
		for (ce = 0; ce < card_info->num_ce; ce++) {
			for (lun = 0; lun < card_info->num_lun; lun++) {
				sfx_set_feature(dev, ch, ce, lun, addr, val, 0x0, card_info->nand_type);
			}
		}
	}
}

/* Analog of switch_to_ddr2 in xscope.py */
void sfx_switch_to_ddr2(struct sfx_dev *dev, xt_u32 rev, sfx_bool print_warning)
{
	sfx_board_nand_type *card_info = &dev->card_info;

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: Set drive strength\n", __FUNCTION__);
#endif
	do_set_feature_all_ce(dev, 0x10, 0x03, print_warning);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: Enable differential dqs\n", __FUNCTION__);
#endif
	do_set_feature_all_ce(dev, 0x02, 0x06, print_warning);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: Switch to DDR2 mode\n", __FUNCTION__);
#endif

	if (card_info->board_type == PCB_PANTHER_A) {
		do_set_feature_all_ce(dev, 0x01, 0x67, print_warning);
	} else {
		do_set_feature_all_ce(dev, 0x01, 0x66, print_warning);
	}

	if (card_info->nand_type == MU_B17A && card_info->num_lun == 4) {
		sfx_load_sequence(dev, ddr_b17a_hdp_sequence);
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: Load B17A HDP sequence \n", __FUNCTION__);
#endif
	} else {
		sfx_load_sequence(dev, ddr_sequence);
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: Load Micron DDR sequence \n", __FUNCTION__);
#endif
	}
}

void do_check_feat_all(struct sfx_dev *dev, unsigned int feat)
{
	int ch, ce, lun;
	sfx_board_nand_type *card_info = &dev->card_info;
	for (ch = 0; ch < card_info->num_ch; ch++) {
		for (ce = 0; ce < card_info->num_ce; ce++) {
			for (lun = 0; lun < card_info->num_lun; lun++) {
				sfx_get_feature(dev, ch, ce, lun, feat, 0, card_info->nand_type);
			}
		}
	}
}

void do_init_vref_tab(struct sfx_dev *dev, xt_u32 (*tab)[2])
{
	xt_u32 vref_ind;

	for (vref_ind = 0; vref_ind < 32; vref_ind++) {
		fis_indirect_write32(dev, dev->bar, VREF_TAB_INDEX, vref_ind);
		fis_indirect_write32(dev, dev->bar, VREF_VAL_L, tab[vref_ind][0]);
		fis_indirect_write32(dev, dev->bar, VREF_VAL_H, tab[vref_ind][1]);
	}
}

void do_init_scr_seed_tab(struct sfx_dev *dev)
{
	xt_u16 index;
	for (index = 0; index < 1024; index++) {
		fis_indirect_write32(dev, dev->bar, SCR_SEED_LUT_DIN_L, scr_seed_lut[index][1]);
		fis_indirect_write32(dev, dev->bar, SCR_SEED_LUT_DIN_H, scr_seed_lut[index][0]);
		fis_indirect_write32(dev, dev->bar, SCR_SEED_LUT_DIN_P, scr_seed_lut[index][2]);
		fis_indirect_write32(dev, dev->bar, SCR_SEED_LUT_DIN_WADDR, index);
	}
}

static int switch_cal_mode(struct sfx_dev *dev, xt_u32 mode)
{
	int i;

	fis_indirect_write32(dev, dev->bar, NDPHY_CONTROL_0, mode);
	for (i = 0; i <= SWITCH_CAL_TOTAL; i++) {
		if (1 & fis_indirect_read32(dev, dev->bar, FCE_STATUS_0)) {
			return 0; /* NDPHY is ready */
		}
		sfx_usleep(SWITCH_CAL_PERIOD);
	}

	sfx_pr_err("%s: %s, NDPHY timed out after %ims\n", __FUNCTION__, dev->name, SWITCH_CAL_TOTAL);
	dev->init_fatal_err++;
	return -ETIME;
}

void reg_set_bit(struct sfx_dev *dev, xt_u32 reg, int bit)
{
	xt_u32 reg_val;
	reg_val = fis_indirect_read32(dev, dev->bar, reg);
	fis_indirect_write32(dev, dev->bar, reg, (1 << bit) | reg_val);
}

void reg_unset_bit(struct sfx_dev *dev, xt_u32 reg, int bit)
{
	xt_u32 reg_val;
	reg_val = fis_indirect_read32(dev, dev->bar, reg);
	fis_indirect_write32(dev, dev->bar, reg, ~(1 << bit) & reg_val);
}

void sfx_set_legacy_mode(struct sfx_dev *dev)
{
	reg_set_bit(dev, FCE_CONTROL_0, 2);
	reg_set_bit(dev, FCE_CONTROL_0, 3);
	reg_set_bit(dev, FCE_CONTROL_0, 13);
}

int micron_nand_init(struct sfx_dev *dev, xt_u32 rev, sfx_bool print_warning)
{
	int ret;
	sfx_board_nand_type *card_info = &dev->card_info;
	if (skip_nand_cfg == 0) {
		if ((ret = switch_cal_mode(dev, 0))) {
			return ret;
		}
		// set timer for mirroring feature
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL0, 0x1fffffff);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL1, 0x080001ff);
		sfx_set_legacy_mode(dev);
		sfx_load_sequence(dev, async_sequence);
		if ((ret = sfx_do_reset(dev, MU_L06B, print_warning))) {
			return ret;
		}

		if ((card_info->board_type == PCB_LEOPARD)) {
			// switch controller to DDR2 mode
			reg_unset_bit(dev, FCE_CONTROL_0, 2);
			reg_unset_bit(dev, FCE_CONTROL_0, 3);
			reg_set_bit(dev, FCE_CONTROL_0, 13);
			sfx_load_sequence(dev, ddr3_sequence);
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: Load Micron DDR3 sequence \n", __FUNCTION__);
#endif
			do_set_feature_all_ce(dev, 0x10, 0x03, print_warning);
			do_set_feature_all_ce(dev, 0x2, 0x07, print_warning);
			do_set_feature_all_ce(dev, 0x1, 0x067, print_warning);

		} else {
			if ((card_info->board_type == PCB_PUMA_C) && (card_info->nand_type == MU_B17A)) {
				// Adding ODT for PUMA_C MU_B17A only
				do_set_feature_all_ce(dev, 0xE2, 0x01, print_warning);
			}

			sfx_switch_to_ddr2(dev, rev, print_warning);
			// switch controller to DDR2 mode
			reg_unset_bit(dev, FCE_CONTROL_0, 2);
			reg_unset_bit(dev, FCE_CONTROL_0, 3);
			reg_set_bit(dev, FCE_CONTROL_0, 13);
		}
	} else {
		sfx_pr_info("%s: %s, Skip NAND RESET and DDR mode setting\n", __FUNCTION__, dev->name);
	}

	// multi-plane polling setting
	if ((rev & 0xfffff) <= 1530) {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: Disable multi-plane polling by default\n", __FUNCTION__);
#endif
		reg_unset_bit(dev, FCE_CONTROL_0, 16);
	} else {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: Enable multi-plane polling by default\n", __FUNCTION__);
#endif
		reg_set_bit(dev, FCE_CONTROL_0, 16);
	}

	if ((ret = switch_cal_mode(dev, 1))) {
		return ret;
	}

	if (card_info->nand_type == MU_L06B) {
		if (skip_nand_cfg == 0) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: Disable NAND randomizer\n", __FUNCTION__);
#endif
			do_switch_rdmz(dev, 0, print_warning);
#ifdef SFXDRIVER_BASE_DEBUG
		} else {
			sfx_pr_info("%s: Skip NAND randomizer setting\n", __FUNCTION__);
#endif
		}
	}

	// set re_delay[1:0] to 2'b01 to delay DQS 1 cycle //
	reg_unset_bit(dev, FCE_CONTROL_1, 22);
	reg_set_bit(dev, FCE_CONTROL_1, 21);

	if (card_info->nand_type == MU_L06B) {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: load vref_table for l06b device\n", __FUNCTION__);
#endif
		do_init_vref_tab(dev, vref_tab_l06b);
	} else if (card_info->nand_type == MU_B17A) {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: load vref_table for b17a device\n", __FUNCTION__);
#endif
		do_init_vref_tab(dev, vref_tab_b17a);
	}

	fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL0, 0x1fff3fff);

	if (card_info->nand_type == MU_B17A) {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: REV %d, the image supports snap read\n", __FUNCTION__, (rev & 0xfffff));
#endif
		reg_set_bit(dev, SFX_P1_CTRL, 29);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL0, 0x1fff1f3f);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL1, 0x800090);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL3, 0x100010);
		if (card_info->num_lun == 4) {
			sfx_load_sequence(dev, post_b17a_hdp_sequence);
			sfx_pr_info("%s: %s, Load B17A HDP sequence \n", __FUNCTION__, dev->name);
		} else {
			sfx_load_sequence(dev, post_b17a_sequence);
			sfx_pr_info("%s: %s, Load B17A post sequence \n", __FUNCTION__, dev->name);
		}
	} else {
		// enable snap read if rev_id>='h851('d2129) //
		if ((rev & 0xfffff) >= 2129) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: REV %d, the image supports snap read. Enable NAND snap read mode\n",
				    __FUNCTION__, (rev & 0xfffff));
#endif
			do_set_feature_all_ce(dev, 0xF5, 0x245006, print_warning);
			reg_set_bit(dev, SFX_P1_CTRL, 29);
			fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL1, 0x6c0150);
			fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL3, 0x0d0010);
		} else {
			sfx_pr_info("%s: %s, REV %d, the image does NOT support snap read\n", __FUNCTION__,
				    dev->name, (rev & 0xfffff));
			do_set_feature_all_ce(dev, 0xF5, 0, print_warning);
			reg_unset_bit(dev, SFX_P1_CTRL, 29);
			fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL1, 0x8001ff);
			fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL3, 0x100010);
		}
		sfx_load_sequence(dev, post_prog_sequence);
	}

	return 0;
}

int tsb_nand_init(struct sfx_dev *dev, xt_u32 rev, sfx_bool print_warning, xt_u32 t_type)
{
	int ret;

	sfx_set_legacy_mode(dev);
	if ((ret = switch_cal_mode(dev, 0))) {
		return ret;
	}

	reg_set_bit(dev, FCE_CONTROL_0, 8);

	sfx_load_sequence(dev, tsb_sequence);
	if ((ret = sfx_do_reset(dev, TSB_BICS, print_warning))) {
		return ret;
	}
	reg_set_bit(dev, FCE_CONTROL_0, 13);
	reg_unset_bit(dev, FCE_CONTROL_0, 2);
	reg_unset_bit(dev, FCE_CONTROL_0, 3);
	if ((ret = switch_cal_mode(dev, 1))) {
		return ret;
	}

	/* set differential mode */
	if ((rev & 0xfffff) >= 2954) {
		//sfx_pr_info("%s: %s, Set differential mode\n", __FUNCTION__, dev->name);
		do_set_feature_all_ce(dev, 0x2, 0x06, print_warning);
	}
	sfx_load_sequence(dev, post_tsb_sequence);

	/* set re_delay[1:0] to 2'b01 to delay DQS 1 cycle */
	reg_unset_bit(dev, FCE_CONTROL_1, 22);
	reg_set_bit(dev, FCE_CONTROL_1, 21);

	if (hard_hang) {
		sfx_pr_info("%s: %s, hard_hang not execute init.\n", __FUNCTION__, dev->name);
		return 0;
	}

	/* pogram vref table*/
	// cTLC type
	if ((t_type == 0)) {
		do_init_vref_tab(dev, vref_tab_tsb_c); // cTLC
	} else {
		do_init_vref_tab(dev, vref_tab_tsb_e); // eTLC
	}

	return 0;
}

// set i2c to direct mode
void i2c_direct_mode(struct sfx_dev *dev)
{
	xt_u32 reg_data = 0x0;
	fis_indirect_write32(dev, dev->bar, CHIP_I2C_MODE, reg_data);
}

//   set i2c to indirect mode
void i2c_indirect_mode(struct sfx_dev *dev)
{
	xt_u32 reg_data = 0x1;
	fis_indirect_write32(dev, dev->bar, CHIP_I2C_MODE, reg_data);
}

xt_u32 i2c_direct_init(struct sfx_dev *dev)
{
	xt_u32 ret = 0;
	xt_u32 reg_data;
	int counter = 0;
	int timer = 0;
	int cnt_max = 10; // Maximum looping 10 times

	i2c_direct_mode(dev);

	for (counter = 0; counter < cnt_max; counter++) {
		// step 1 Reset IIC core
		reg_data = 0x200;
		fis_indirect_write32(dev, dev->bar, CHIP_RST_CTL, reg_data);
		reg_data = 0x0;
		fis_indirect_write32(dev, dev->bar, CHIP_RST_CTL, reg_data);

		// step 2 enable IIC core
		reg_data = 0x00000001;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_CR, reg_data);

		// step 3 soft reset
		reg_data = 0x0000000A;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_SOFTR, reg_data);

		// step 4 enable global interrupt
		reg_data = 0x80000000;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_GIE, reg_data);

		// step 5 enable all interrupt in ISR
		reg_data = 0x000000FF;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_IER, reg_data);

		// step 6 program RX_FIFO_PIRQ
		reg_data = 0x0000000F;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_RX_FIFO_PIRQ, reg_data);

		// step 7 reset tx_fifo
		reg_data = 0x00000002;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_CR, reg_data);

		// step 8 enable IIC core
		reg_data = 0x00000001;
		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_CR, reg_data);

		// step 9 check IIC core status
		timer = 0;
		do {
			reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);
			timer += 1;
		} while (((reg_data & 0x000000c4) != 0x000000c0) && timer <= 0x200);

		if (reg_data == 0x000000c0)
			counter = cnt_max;
		else
			counter += 1;
	}

	if ((reg_data != 0x000000c0) && (counter == cnt_max)) {
		sfx_pr_err("%s: %s, i2c_dir_init failed\n", __FUNCTION__, dev->name);
		ret = 1;
	} else {
#ifdef I2C_INIT_DEBUG
		sfx_pr_info("[I2C_DEBUG]I2c_direct_init: --> completed\n");
#endif
	}
	return ret;
}

void i2c_reg_write(struct sfx_dev *dev, xt_u32 reg_addr, xt_u32 value)
{
	fis_indirect_write32(dev, dev->bar, reg_addr, value);
}

xt_u32 i2c_reg_read(struct sfx_dev *dev, xt_u32 reg_addr)
{
	xt_u32 data = fis_indirect_read32(dev, dev->bar, reg_addr);
	return data;
}

xt_u32 i2c_write(struct sfx_dev *dev, xt_u32 slv_addr, xt_u32 reg_addr, xt_32 len, xt_32 wdata)
{
	int loop_cnt;
	xt_u32 cmd_mask = 0;
	xt_u32 status;

	if (len < 0) {
		sfx_pr_info("%s: %s, I2C WRITE Length is wrong!", __FUNCTION__, dev->name);
		return -1;
	} else if (len > 0) {
		len = len - 1; // HW is using 0 based number
		cmd_mask = 0x9;
	} else {
		// length 0
		cmd_mask = 0x1;
		wdata = reg_addr; // data content is register address when length is zero
		reg_addr = 0x0; // set register address to 0 when len is zero
	}

	i2c_reg_write(dev, CHIP_I2C_IND_WDATA, wdata);
	i2c_reg_write(dev, CHIP_I2C_IND_ADDR, (reg_addr << 8) + slv_addr);
	i2c_reg_write(dev, CHIP_I2C_IND_CR, (len << 4) + cmd_mask);

	loop_cnt = 0;
	while (1) {
		sfx_usleep(100);
		status = i2c_reg_read(dev, CHIP_I2C_IND_SR);
		if (status & 0x1) {
			if (status & 0x100) {
				sfx_pr_info("%s: %s, I2C controller WRITE failed: Slave does NOT response!",
					    __FUNCTION__, dev->name);
				return -1;
			} else {
				//sfx_pr_info("%s: %s, I2C write 0x%x to slave 0x%x at address 0x%x",
				//	    __FUNCTION__, dev->name, wdata, slv_addr, reg_addr);
				return 0;
			}
		} else if (status & 0x10) {
			sfx_pr_info("%s: %s, I2C controller FATAL error!", __FUNCTION__, dev->name);
			return -1;
		}
		if (loop_cnt == 100) {
			sfx_pr_info("%s: %s, I2C controller WRITE hang!", __FUNCTION__, dev->name);
			return -1;
		}
		loop_cnt++;
	}
}

xt_u32 i2c_direct_write(struct sfx_dev *dev, xt_u32 slv_addr, xt_u32 reg_addr, xt_32 len, xt_32 wdata,
			int inter_vld)
{
	xt_u32 reg_data;
	xt_u32 counter = 0x0;
	int arb_lost = 0;
	int ret = 0;
	int write_cnt = 0;
	int write_retry = 0;

#ifdef SFX_LINUX
	spin_lock(&dev->i2c_lock);
#endif
	i2c_direct_mode(dev);
	// clear all interrupt
	reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_ISR);
	fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_ISR, reg_data);

	// Get CMD i2c write at slave addr
	do {
		counter = 0x0;
		do {
			arb_lost = 0;
			// Check FIFO and BUS status
			reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);
			counter = counter + 1;
		} while (((reg_data & 0x000000c4) != 0x000000c0) && (counter < 0x00000040));

		if ((counter >= 0x00000040 || write_retry)) {
			// IIC FIFO not empty,  run initialization flows
			i2c_direct_init(dev);
		}
		counter = 0x0;
		// i2c write start with addr.  write slave address with WRITE FLAG
		reg_data = (((slv_addr & 0x0000007F) << 1) & 0x000000FE) | 0x00000100;

		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);

		if (inter_vld) {
			// write internal register address
			if (len == 0) {
				reg_data = (reg_addr & 0x000000FF) | 0x00000200;
			} else {
				reg_data = (reg_addr & 0x000000FF);
			}
			fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);
		}

		// write bytes out
		if (len != 0) {
			for (write_cnt = 0; write_cnt < len; write_cnt++) {
				if (write_cnt == len - 1) {
					reg_data = ((wdata >> (write_cnt * 8)) & 0x000000FF) | 0x00000200;
				} else {
					reg_data = (wdata >> (write_cnt * 8)) & 0x000000FF;
				}
				fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);
			}
		}

		do {
			// Check Bus Status
			reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);
			counter = counter + 1;
		} while (((reg_data & 0x000000c4) != 0x000000c0) && (counter <= 0x200));

		if ((!arb_lost) && (counter > 0x200)) {
			if (write_retry >= MAX_RETRY_NUM) {
				sfx_pr_err("%s: %s, i2c_direct_write failed\n", __FUNCTION__, dev->name);
				ret = 1;
#ifdef SFX_LINUX
				spin_unlock(&dev->i2c_lock);
#endif
				return ret;
			} else {
				write_retry += 1;
				arb_lost = 1;
				break;
			}
		}

	} while (arb_lost != 0);

	if (write_retry >= MAX_RETRY_NUM) {
		ret = 1;
#ifdef SFX_LINUX
		spin_unlock(&dev->i2c_lock);
#endif
		return ret;
	}
#ifdef I2C_DEBUG
	reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);
	sfx_pr_info("[I2C_DEBUG]i2c_direct_write completed with status of:  %x\n", reg_data);
#endif

#ifdef SFX_LINUX
	spin_unlock(&dev->i2c_lock);
#endif
	return ret;
}

xt_u32 i2c_read(struct sfx_dev *dev, xt_u32 slv_addr, xt_u32 reg_addr, xt_u32 len)
{
	int loop_cnt;
	xt_u32 status;
	xt_u32 rdata;

	if (len <= 0) {
		sfx_pr_info("%s: %s, I2C READ Length is wrong!", __FUNCTION__, dev->name);
		return -1;
	} else {
		len = len - 1; // HW is using 0 based number
		i2c_reg_write(dev, CHIP_I2C_IND_ADDR, (reg_addr << 8) + slv_addr);
		i2c_reg_write(dev, CHIP_I2C_IND_CR, (len << 4) + 0xb);
	}

	loop_cnt = 0;
	while (1) {
		sfx_usleep(100);
		status = i2c_reg_read(dev, CHIP_I2C_IND_SR);

		if (status & 0x1) {
			if (status & 0x100) {
				sfx_pr_info("%s: %s, I2C controller READ FAILED!", __FUNCTION__, dev->name);
				return -1;
			} else {
				rdata = i2c_reg_read(dev, CHIP_I2C_IND_RDATA);
				return rdata;
			}
			break;
		} else if (status & 0x10) {
			sfx_pr_info("%s: %s, I2C controller FATAL error!", __FUNCTION__, dev->name);
			return -1;
		}

		if (loop_cnt == 100) {
			sfx_pr_info("%s: %s, I2C controller READ hang!", __FUNCTION__, dev->name);
			break;
		}
		loop_cnt++;
	}
	return -1;
}

xt_u32 i2c_direct_read(struct sfx_dev *dev, xt_u32 slv_addr, xt_u32 reg_addr, xt_u32 len, int inter_vld)
{
	xt_u32 reg_data;
	xt_u32 recv_data_bytes = 0x0;
	xt_u32 counter = 0x0;
	int arb_lost = 0;
	int read_retry = 0;
	int read_cnt = 0;

#ifdef SFX_LINUX
	spin_lock(&dev->i2c_lock);
#endif
	i2c_direct_mode(dev);
	// clear interrupt
	reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_ISR);
	fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_ISR, reg_data);

	//Get CMD
	do {
		arb_lost = 0;
		counter = 0x0;
		// run initialization flow
		i2c_direct_init(dev);

		// i2c read start with i2c valid addr
		if (inter_vld) {
			// write slave address
			reg_data = (((slv_addr & 0x0000007F) << 1) & 0x000000FE) | 0x00000100;

			fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);
			reg_data = (reg_addr & 0x000000FF);

			fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);
		}

		reg_data = (((slv_addr & 0x0000007F) << 1) & 0x000000FE) | 0x00000101;

		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);
		// write read length
		reg_data = (len & 0x000000FF) | 0x00000200;

		fis_indirect_write32(dev, dev->bar, CHIP_I2C_DIR_TX_FIFO, reg_data);

		for (read_cnt = 0; read_cnt < len; read_cnt++) {
			reg_data = 0xFF;
			counter = 0x0;
			while (((reg_data & 0x00000040) != 0x0) && (counter < 0x200)) {
				reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);
				counter = counter + 1;
			}

			if (counter >= 0x200) {
				if (read_retry >= MAX_RETRY_NUM) {
					sfx_pr_err("%s: %s, i2c_direct_read failed\n", __FUNCTION__,
						   dev->name);
#ifdef SFX_LINUX
					spin_unlock(&dev->i2c_lock);
#endif
					return -1;
				} else {
					// Read Timeout!! Re-send read command
#ifdef I2C_INIT_DEBUG
					sfx_pr_info(
						"[I2C_DEBUG]i2c_direct_read: Read Timeout!! Re-send read command\n");
#endif
					read_retry += 1;
					arb_lost = 1;
				}
				break;
			}

			if (arb_lost) {
				break;
			}
			reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_RX_FIFO);
			recv_data_bytes = recv_data_bytes |
					  (((reg_data & 0xFF) << (read_cnt * 8)) & 0xFFFFFFFF);
		}

	} while (arb_lost != 0);

	reg_data = fis_indirect_read32(dev, dev->bar, CHIP_I2C_DIR_SR);

	// I2C read done
	if (read_retry < MAX_RETRY_NUM) {
#ifdef SFX_LINUX
		spin_unlock(&dev->i2c_lock);
#endif
#ifdef I2C_INIT_DEBUG
		sfx_pr_info("[I2C_DEBUG]i2c_direct_read completed\n");
#endif
		return recv_data_bytes;
	} else {
#ifdef I2C_INIT_DEBUG
		sfx_pr_err("%s: %s, i2c_direct_read failed\n", __FUNCTION__, dev->name);
#endif
#ifdef SFX_LINUX
		spin_unlock(&dev->i2c_lock);
#endif
		return -1;
	}
}

void i2c_fsm_reset(struct sfx_dev *dev)
{
	// i2c FSM is hanging, reset bit[9] in rst_ctl
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x0200);
	sfx_mdelay(10);
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x0000);
	sfx_pr_info("%s: %s, Reset I2C FSM ...\n", __FUNCTION__, dev->name);
}

xt_u32 sfx_read_power(struct sfx_dev *dev)
{
	xt_u64 power = 0;
	xt_u64 reg_data_v = 0;
	xt_u64 reg_data_i = 0;

	// Voltage measurement
	reg_data_v = i2c_direct_read(dev, 0x09, 0x25, 2, 1);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: %s, Voltage reg_data is   %d!\n", __FUNCTION__, dev->name, reg_data_v);
#endif

	// Current measurement
	reg_data_i = i2c_direct_read(dev, 0x09, 0x28, 2, 1);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: %s, Current reg_data is   %d\n", __FUNCTION__, dev->name, reg_data_i);
#endif

	// Power calculation
	power = reg_data_v * VOLTAGE_FACTOR / VOLTAGE_DIVIDER * reg_data_i / CURRENT_DIVIDER *
		CURRENT_FACTOR / RS_FACTOR / POWER_DIVIDER;

	if ((power <= 0) || (power > 50)) {
		sfx_pr_err("%s: %s Invalid Power Consumption\n", __FUNCTION__, dev->name);
		return -1;
	} else if (power > 25) {
		// Limit power consumption
		power = 25;
	}

	sfx_pr_info("%s: %s, Power consumption is %d W!\n", __FUNCTION__, dev->name, power);

#ifdef I2C_INIT_DEBUG
	sfx_pr_info("[I2C_DEBUG]power consumption completed\n");
#endif
	return power;
}

xt_u32 i2c_axi_direct_reset(struct sfx_dev *dev)
{
	xt_u32 status;
	int ret = 0;

#ifdef I2C_INIT_DEBUG
	sfx_pr_info("[I2C_DEBUG]i2c_axi_direct_reset\n");
#endif

	i2c_direct_mode(dev);
	ret = i2c_direct_init(dev);

	if (ret != 0) {
		sfx_pr_info("[sfxdriver_I2C]ERROR: i2c_direct_init failed!\n");
		return ret;
	}

	status = i2c_reg_read(dev, REG_MISC_CONTROL);
	status |= 0x1;
	i2c_reg_write(dev, REG_MISC_CONTROL, status); // Enable i3887 access

	return ret;
}

#define I2C_READ_MASK 0x2
void puma_i2c_init(struct sfx_dev *dev)
{
	int i;
	xt_u32 status;
	xt_u32 misc_control;

	misc_control = fis_indirect_read32(dev, dev->bar, REG_MISC_CONTROL);
	fis_indirect_write32(dev, dev->bar, REG_MISC_CONTROL, 1);
	/* Pre-scale Low: 100MHz/5*100KHz-1='d199=0xc7 */
	i2c_reg_write(dev, I2C_CSR, 0xc7);
	/* Pre-scale High */
	i2c_reg_write(dev, I2C_CSR_HIGH, 0x0);
	/* {I2C enable, Intr eable, RSVD[5:0]} */
	i2c_reg_write(dev, I2C_ENABLE, 0x80);

	/* Send addr for write */
	/* {addr (0x09), w/r (0)} */
	i2c_reg_write(dev, I2C_ADDR_FOR_WRITE, 0x12);
	/* {STA, STO, RD, WR, ACK, RSVD[2:1], IACK} */
	i2c_reg_write(dev, I2C_ADDR_WRITE, 0x90);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: 1st read start\n", __FUNCTION__);
#endif
	do {
		if (dev->device_gone) {
			return;
		}
		/* {RxACK, Busy, AL, RSVD[4:2], TIP, IF} # should keep pulling till [1] = 0 */
		status = i2c_reg_read(dev, I2C_ADDR_WRITE);
	} while (status & I2C_READ_MASK);

	/* Send data */
	/* Data for slave internal addr */
	i2c_reg_write(dev, I2C_ADDR_FOR_WRITE, 0x06);
	/* {STA, STO, RD, WR, ACK, RSVD[2:1], IACK} */
	i2c_reg_write(dev, I2C_ADDR_WRITE, 0x10);
	do {
		if (dev->device_gone) {
			return;
		}
		status = i2c_reg_read(dev, I2C_ADDR_WRITE);
	} while (status & I2C_READ_MASK);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: 2nd read end\n", __FUNCTION__);
#endif

	for (i = 0; i < 2; i++) {
		/* Data send to register */
		i2c_reg_write(dev, I2C_ADDR_FOR_WRITE, 0x00);
		i2c_reg_write(dev, I2C_ADDR_WRITE, 0x10);
		do {
			if (dev->device_gone) {
				return;
			}
			status = i2c_reg_read(dev, I2C_ADDR_WRITE);
		} while (status & I2C_READ_MASK);
#ifdef I2C_INIT_DEBUG
		sfx_pr_info("%s: 3rd read end\n", __FUNCTION__);
#endif
	}
	/* Stop/IAck */
	i2c_reg_write(dev, I2C_ADDR_WRITE, 0x44);
	/* Clear Intr */
	i2c_reg_write(dev, I2C_ADDR_WRITE, 0x01);
	do {
		if (dev->device_gone) {
			return;
		}
		status = i2c_reg_read(dev, I2C_ADDR_WRITE);
	} while (status & I2C_READ_MASK);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: 4th read end\n", __FUNCTION__);
#endif
	/* Disable */
	i2c_reg_write(dev, I2C_ENABLE, 0x00);
#ifdef I2C_INIT_DEBUG
	sfx_pr_info("%s: exit\n", __FUNCTION__);
#endif
	fis_indirect_write32(dev, dev->bar, REG_MISC_CONTROL, misc_control);
}

static xt_u32 sfx_read_nor_did(struct sfx_dev *dev, xt_u32 *nor_did_info)
{
	xt_u32 ret = 0;

	if ((ret = sfxdriver_spi_init_read_only(dev))) {
		sfx_pr_err("%s: sfxdriver_spi_init_read_only failed %u returned\n", __FUNCTION__, ret);
		return ret;
	}
	if ((ret = sfxdriver_spi_read_nor_did(dev, 12, nor_did_info))) {
		sfx_pr_err("%s: sfxdriver_spi_read_nor_did failed %u returned\n", __FUNCTION__, ret);
		return ret;
	}
	return ret;
}

void print_card_info(sfx_board_nand_type *c)
{
	sfx_pr_info(
		"%s  FEAT_OP_CARD_INFO num_blk:%d num_pg:%d num_lun:%d num_ce:%d num_ch:%d\n num_hw_pl:%d num_sw_gr:%d num_hw_pt:%d num_of:%d\n",
		__FUNCTION__, c->num_blk, c->num_pg, c->num_lun, c->num_ce, c->num_ch, c->num_hw_pl,
		c->num_sw_gr, c->num_hw_pt, c->num_of);
	sfx_pr_info("sw_off_blk:%d sw_off_pg:%d sw_off_lu:%d sw_off_ce:%d sw_off_gr:%d sw_off_ch:%d\n"
		    "sw_off_pl:%d sw_mask_blk:0x%x sw_mask_pg:0x%x sw_mask_lu:0x%x sw_mask_ce:0x%x\n"
		    "sw_mask_gr:0x%x sw_mask_ch:0x%x sw_mask_pl:0x%x\n",
		    c->sw_off_blk, c->sw_off_pg, c->sw_off_lu, c->sw_off_ce, c->sw_off_gr, c->sw_off_ch,
		    c->sw_off_pl, c->sw_mask_blk, c->sw_mask_pg, c->sw_mask_lu, c->sw_mask_ce, c->sw_mask_gr,
		    c->sw_mask_ch, c->sw_mask_pl);
	sfx_pr_info(
		"hw_off_blk:%d hw_off_blkh:%d hw_off_pg:%d hw_off_lu:%d hw_off_ce:%d hw_off_ch:%d\n"
		"hw_off_pt:%d hw_off_pl:%d hw_mask_blk:0x%x hw_mask_pg:0x%x hw_mask_lu:0x%x\n"
		"hw_mask_ce:0x%x hw_mask_ch:0x%x hw_mask_lp:0x%x hw_mask_pt:0x%x hw_mask_pl:0x%x hw_mask_of:0x%x\n",
		c->hw_off_blk, c->hw_off_blkh, c->hw_off_pg, c->hw_off_lu, c->hw_off_ce, c->hw_off_ch,
		c->hw_off_pt, c->hw_off_pl, c->hw_mask_blk, c->hw_mask_pg, c->hw_mask_lu, c->hw_mask_ce,
		c->hw_mask_ch, c->hw_mask_lp, c->hw_mask_pt, c->hw_mask_pl, c->hw_mask_of);
	sfx_pr_info("nand_type:%d board_type:%d capacity:%d\n", c->nand_type, c->board_type,
		    c->card_capacity);
}

void nand_init_fail_print(struct sfx_dev *dev)
{
	int print_job_itr, print_die_itr;
	sfx_board_nand_type *card_info = &dev->card_info;

	sfx_pr_err("%s: First round NAND INITIALIZATION MESSAGE PRINT:\n", __FUNCTION__);
	if (card_info->nand_type != TSB_BICS) {
		for (print_job_itr = 0; print_job_itr < 4; print_job_itr++) {
			if (print_job_itr == 0) {
				sfx_pr_info("NAND Flash Reset: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_reset_store[print_die_itr * 3 + 2] & 0xFF) != 0xe0) {
						sfx_pr_err("FAIL: ch%d ce%d, return:%02x\n",
							   dev->fail_reset_store[print_die_itr * 3],
							   dev->fail_reset_store[print_die_itr * 3 + 1],
							   dev->fail_reset_store[print_die_itr * 3 + 2] &
								   0xFF);
					} else {
						sfx_pr_info("PASS: ch%d ce%d, return:%02x\n",
							    dev->fail_reset_store[print_die_itr * 3],
							    dev->fail_reset_store[print_die_itr * 3 + 1],
							    dev->fail_reset_store[print_die_itr * 3 + 2] &
								    0xFF);
					}
				}
			}
			if (print_job_itr == 1) {
				sfx_pr_info("Set Drive Strength: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_drive_strength_store[print_die_itr * 3 + 2] & 0xFF) !=
					    0xe0) {
						sfx_pr_err(
							"FAIL: ch%d ce%d, return:%02x\n",
							dev->fail_drive_strength_store[print_die_itr * 3],
							dev->fail_drive_strength_store[print_die_itr * 3 + 1],
							dev->fail_drive_strength_store[print_die_itr * 3 + 2] &
								0xFF);
					} else {
						sfx_pr_info(
							"PASS: ch%d ce%d, return:%02x\n",
							dev->fail_drive_strength_store[print_die_itr * 3],
							dev->fail_drive_strength_store[print_die_itr * 3 + 1],
							dev->fail_drive_strength_store[print_die_itr * 3 + 2] &
								0xFF);
					}
				}
			}
			if (print_job_itr == 2) {
				sfx_pr_info("Set Differential Mode: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_en_diffmode_store[print_die_itr * 3 + 2] & 0xFF) !=
					    0xe0) {
						sfx_pr_err(
							"FAIL: ch%d ce%d, return:%02x\n",
							dev->fail_en_diffmode_store[print_die_itr * 3],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 1],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 2] &
								0xFF);
					} else {
						sfx_pr_info(
							"PASS: ch%d ce%d, return:%02x\n",
							dev->fail_en_diffmode_store[print_die_itr * 3],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 1],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 2] &
								0xFF);
					}
				}
			}
			if (print_job_itr == 3) {
				sfx_pr_info("Switch to DDR2 Mode: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_switch_ddr_store[print_die_itr * 3 + 2] & 0xFF) !=
					    0xe0) {
						sfx_pr_err("FAIL: ch%d ce%d, return:%02x\n",
							   dev->fail_switch_ddr_store[print_die_itr * 3],
							   dev->fail_switch_ddr_store[print_die_itr * 3 + 1],
							   dev->fail_switch_ddr_store[print_die_itr * 3 + 2] &
								   0xFF);
					} else {
						sfx_pr_info(
							"PASS: ch%d ce%d, return:%02x\n",
							dev->fail_switch_ddr_store[print_die_itr * 3],
							dev->fail_switch_ddr_store[print_die_itr * 3 + 1],
							dev->fail_switch_ddr_store[print_die_itr * 3 + 2] &
								0xFF);
					}
				}
			}
		}
	} else {
		for (print_job_itr = 0; print_job_itr < 2; print_job_itr++) {
			if (print_job_itr == 0) {
				sfx_pr_info("NAND Flash Reset: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_reset_store[print_die_itr * 3 + 2] & 0xFF) != 0xe0) {
						sfx_pr_err("FAIL: ch%d ce%d, return:%02x\n",
							   dev->fail_reset_store[print_die_itr * 3],
							   dev->fail_reset_store[print_die_itr * 3 + 1],
							   dev->fail_reset_store[print_die_itr * 3 + 2] &
								   0xFF);
					} else {
						sfx_pr_info("PASS: ch%d ce%d, return:%02x\n",
							    dev->fail_reset_store[print_die_itr * 3],
							    dev->fail_reset_store[print_die_itr * 3 + 1],
							    dev->fail_reset_store[print_die_itr * 3 + 2] &
								    0xFF);
					}
				}
			}
			if (print_job_itr == 1) {
				sfx_pr_info("Set Differential Mode: \n");
				for (print_die_itr = 0; print_die_itr < card_info->num_ch * card_info->num_ce;
				     print_die_itr++) {
					if ((dev->fail_en_diffmode_store[print_die_itr * 3 + 2] & 0xFF) !=
					    0xe0) {
						sfx_pr_err(
							"FAIL: ch%d ce%d, return:%02x\n",
							dev->fail_en_diffmode_store[print_die_itr * 3],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 1],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 2] &
								0xFF);
					} else {
						sfx_pr_info(
							"PASS: ch%d ce%d, return:%02x\n",
							dev->fail_en_diffmode_store[print_die_itr * 3],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 1],
							dev->fail_en_diffmode_store[print_die_itr * 3 + 2] &
								0xFF);
					}
				}
			}
		}
	}
}

int sfx_opn_parser(struct sfx_dev *dev)
{
	opn_info *card_opn = (opn_info *)dev->opn;
	char *str, strc[4];
	int offset;
	sfx_board_nand_type *card_info = &dev->card_info;
	xt_u8 cc;

	sfx_memset(card_info, 0, sizeof(sfx_board_nand_type));

	if ((strncmp((char *)card_opn->family, "CSS", sizeof(card_opn->family))) &&
	    (strncmp((char *)card_opn->family, "CSD", sizeof(card_opn->family)))) {
		goto invalid_opn;
	}
	if (strncmp((char *)card_opn->board_type, "P2", sizeof(card_opn->board_type)) == 0) {
		if (strncmp((char *)card_opn->revision, "A0", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_PUMA_AB;
		} else {
			card_info->board_type = PCB_PUMA_C;
		}
	} else if (strncmp((char *)card_opn->board_type, "U2", sizeof(card_opn->board_type)) == 0) {
		if (strncmp((char *)card_opn->revision, "A0", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_LYNX_A;
		} else {
			card_info->board_type = PCB_LYNX_B;
		}
	} else if (strncmp((char *)card_opn->board_type, "P3", sizeof(card_opn->board_type)) == 0) {
		if (strncmp((char *)card_opn->revision, "A0", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_PANTHER_A;
		} else if (strncmp((char *)card_opn->revision, "A1", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_PANTHER_A;
		}
	} else if (strncmp((char *)card_opn->board_type, "U3", sizeof(card_opn->board_type)) == 0) {
		if (strncmp((char *)card_opn->revision, "A0", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_LEOPARD;
			card_info->board_rev = BOARD_REV_A;
		} else if (strncmp((char *)card_opn->revision, "A1", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_LEOPARD;
			card_info->board_rev = BOARD_REV_A;
		} else if (strncmp((char *)card_opn->revision, "B0", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_LEOPARD;
			card_info->board_rev = BOARD_REV_B;
		} else if (strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) == 0) {
			card_info->board_type = PCB_LEOPARD;
			card_info->board_rev = BOARD_REV_B;
		}
	} else {
		goto invalid_opn;
	}

	str = (char *)card_opn->flash_type;
	if ((strncmp(str, "B", sizeof(card_opn->flash_type)) == 0) ||
	    (strncmp(str, "C", sizeof(card_opn->flash_type)) == 0)) {
		// Micron L06B MLC 3K
		card_info->nand_type = MU_L06B;
	} else if (strncmp(str, "E", sizeof(card_opn->flash_type)) == 0) {
		// Micron B17A TLC 10K
		card_info->nand_type = MU_B17A;
	} else if (strncmp(str, "F", sizeof(card_opn->flash_type)) == 0) {
		// Micron B17A TLC 10K
		card_info->nand_type = MU_B17A;
	} else if (!strncmp(str, "K", sizeof(card_opn->flash_type)) ||
		   !strncmp(str, "L", sizeof(card_opn->flash_type))) {
		card_info->nand_type = TSB_BICS;
	} else if (strncmp(str, "Z", sizeof(card_opn->flash_type)) == 0) {
		// card_info->board_type = PCB_PUMA_C;  /* set above */
		card_info->nand_type = MU_L06B;
		card_info->card_capacity = CAPACITY_16TB; /* assuming a small size to get blk device */
		sfx_pr_info("%s: %s, Compression only card\n", __FUNCTION__, dev->name);
		dev->comp_only = 1;
		return sfx_true;
	} else {
		goto invalid_opn;
	}
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: Based on OPN: nand_type %d \n", __FUNCTION__, card_info->nand_type);
#endif

	// init die_remap to 0
	card_info->die_remap = 0;

	str = (char *)card_opn->capacity;
	sfx_memset(strc, 0, 4);
	sfx_memcpy(strc, str, 3);
	if (kstrtou8(strc, 10, &cc)) {
		goto invalid_opn;
	} else {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: strc %s card_capacity %u\n", __FUNCTION__, strc, cc);
#endif
		switch (cc) {
		case 16:
			card_info->card_capacity = CAPACITY_16TB;
			break;
		case 19:
			card_info->card_capacity = CAPACITY_19TB;
			break;
		case 20:
			if (!strncmp((char *)card_opn->family, "CSD", sizeof(card_opn->family))) {
				card_info->card_capacity = CAPACITY_16TB;
			} else {
				card_info->card_capacity = CAPACITY_20TB;
			}
			break;
		case 32:
			card_info->card_capacity = CAPACITY_32TB;
			break;
		case 38:
			card_info->card_capacity = CAPACITY_38TB;
			break;
		case 40:
			if (!strncmp((char *)card_opn->family, "CSD", sizeof(card_opn->family))) {
				card_info->card_capacity = CAPACITY_32TB;
			} else {
				card_info->card_capacity = CAPACITY_40TB;
			}
			break;
		case 64:
			card_info->card_capacity = CAPACITY_64TB;
			break;
		case 77:
			card_info->card_capacity = CAPACITY_77TB;
			break;
		case 80:
			if (!strncmp((char *)card_opn->family, "CSD", sizeof(card_opn->family))) {
				card_info->card_capacity = CAPACITY_64TB;
			} else {
				card_info->card_capacity = CAPACITY_80TB;
			}
			break;
		case 128:
			card_info->card_capacity = CAPACITY_128TB;
			break;
		case 154:
			card_info->card_capacity = CAPACITY_154TB;
			break;
		default:
			sfx_pr_err("%s: %s, invalid card_capacity\n", __FUNCTION__, dev->name);
			goto invalid_opn;
		}
	}
	if (card_info->nand_type == MU_L06B) {
		card_info->free_block_fifo_size = 6; // nodes of fifo used by gc
		switch (card_info->card_capacity) {
		CASE_VARIANT_16TB:
			card_info->num_lun = 1;
			card_info->num_ce = 4;
			if (strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) == 0) {
				card_info->die_remap = 1;
			}
			break;
		CASE_VARIANT_32TB:
			card_info->num_lun = 2;
			card_info->num_ce = 4;
			if (strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) == 0) {
				card_info->die_remap = 2;
			}
			break;
		CASE_VARIANT_64TB:
			card_info->num_lun = 2;
			card_info->num_ce = 8;
			break;
		default:
			goto invalid_opn;
		}
		// all micro NAND have same hardware address format, but not same software address format
		card_info->num_hw_pt = 1;
		card_info->num_hw_pl = 4;
		card_info->num_of = 4;
		card_info->num_sw_gr = 4;
		card_info->num_sw_ch = 4;
		card_info->num_sw_pl = 4;
		card_info->num_blk = 548;
		card_info->num_pg = 1024;
		card_info->num_ch = 16;
		card_info->hw_off_blk = 14;
		card_info->hw_off_blkh = 32;
		card_info->hw_off_pg = 4;
		card_info->hw_off_lu = 24;
		card_info->hw_off_ce = 25;
		card_info->hw_off_ch = 28;
		card_info->hw_off_pt = 4;
		card_info->hw_off_pl = 2;
	} else if (card_info->nand_type == MU_B17A) {
		card_info->free_block_fifo_size = 6; // nodes of fifo used by gc
		card_info->b17_logic_page_num = 1536;
		switch (card_info->card_capacity) {
		CASE_VARIANT_16TB:
			card_info->num_lun = 1;
			card_info->num_ce = 2;
			if ((strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) == 0) ||
			    (strncmp((char *)card_opn->revision, "B0", sizeof(card_opn->revision)) == 0) ||
			    (strncmp((char *)card_opn->revision, "A1", sizeof(card_opn->revision)) == 0)) {
				card_info->die_remap = 2;
			}
			break;
		CASE_VARIANT_32TB:
			card_info->num_lun = 1;
			card_info->num_ce = 4;
			if ((strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) == 0) ||
			    (strncmp((char *)card_opn->revision, "A1", sizeof(card_opn->revision)) == 0)) {
				card_info->die_remap = 1;
			}
			break;
		CASE_VARIANT_64TB:
			card_info->num_lun = 2;
			card_info->num_ce = 4;
			break;
		CASE_VARIANT_128TB:
			card_info->num_lun = 4;
			card_info->num_ce = 4;
			break;
		default:
			goto invalid_opn;
		}
		card_info->num_hw_pt = 1;
		card_info->num_hw_pl = 4;
		card_info->num_of = 4;
		card_info->num_sw_gr = 4;
		card_info->num_sw_ch = 4;
		card_info->num_sw_pl = 4;
		card_info->num_blk = 504;
		card_info->num_pg = 2304;
		card_info->num_ch = 16;
		card_info->hw_off_blk = 16;
		card_info->hw_off_blkh = 32;
		card_info->hw_off_pg = 4;
		card_info->hw_off_lu = 28;
		card_info->hw_off_ce = 30;
		card_info->hw_off_ch = 32;
		card_info->hw_off_pt = 4;
		card_info->hw_off_pl = 2;
	} else if (card_info->nand_type == TSB_BICS) {
		// BiCS3 TLC 256Gb
		if (strncmp((char *)card_opn->flash_type, "K", sizeof(card_opn->flash_type)) == 0) {
			card_info->free_block_fifo_size = 20; //12; // nodes of fifo used by gc
			card_info->num_blk = 1478;
			card_info->num_pg = 256;
			reg_unset_bit(dev, FCE_CONTROL_0, 26); // TSB TLC 256GB
			switch (card_info->card_capacity) {
			CASE_VARIANT_16TB:
				card_info->num_ce = 4;
				card_info->num_ch = 16;
				card_info->num_lun = 1;
				if (strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) ==
				    0) {
					card_info->die_remap = 1;
				}
				break;
			CASE_VARIANT_32TB:
				card_info->num_ce = 4;
				card_info->num_ch = 16;
				card_info->num_lun = 2;
				break;
			default:
				goto invalid_opn;
			}
		} else if (strncmp((char *)card_opn->flash_type, "L", sizeof(card_opn->flash_type)) == 0) {
			// BiCS3 TLC 512Gb
			card_info->free_block_fifo_size = 20; // nodes of fifo used by gc
			card_info->num_blk = 2958;
			card_info->num_pg = 256;
			reg_set_bit(dev, FCE_CONTROL_0, 26); // TSB TLC 512GB
			switch (card_info->card_capacity) {
			CASE_VARIANT_32TB:
				card_info->num_ce = 4;
				card_info->num_ch = 16;
				card_info->num_lun = 1;
				card_info->die_remap = 0;

				if ((strncmp((char *)card_opn->revision, "B1", sizeof(card_opn->revision)) ==
				     0)) {
					card_info->die_remap = 1;
				}
				break;
			CASE_VARIANT_64TB:
				card_info->num_ce = 4;
				card_info->num_ch = 16;
				card_info->num_lun = 2;
				card_info->die_remap = 0;
				break;
			default:
				goto invalid_opn;
			}
		} else {
			goto invalid_opn;
		}
		//Toshiba Nand have same address format
		card_info->num_hw_pt = 3;
		card_info->num_hw_pl = 2;
		card_info->num_of = 4;
		card_info->num_sw_gr = 4;
		card_info->num_sw_ch = 4;
		card_info->num_sw_pl = 6;
		card_info->hw_off_blk = 13;
		card_info->hw_off_blkh = 32;
		card_info->hw_off_pg = 5;
		card_info->hw_off_lu = 24;
		card_info->hw_off_ce = 26;
		card_info->hw_off_ch = 28;
		card_info->hw_off_pt = 3;
		card_info->hw_off_pl = 2;
	}

	offset = find_cont_bits(card_info->num_of);
	card_info->sw_off_pl = offset;
	offset += find_cont_bits(card_info->num_sw_pl);
	card_info->sw_off_ch = offset;
	offset += find_cont_bits(card_info->num_sw_ch);
	card_info->sw_off_gr = offset;
	offset += find_cont_bits(card_info->num_sw_gr);
	card_info->sw_off_ce = offset;
	offset += find_cont_bits(card_info->num_ce);
	card_info->sw_off_lu = offset;
	offset += find_cont_bits(card_info->num_lun);
	card_info->sw_off_pg = offset;
	offset += find_cont_bits(card_info->num_pg);
	card_info->sw_off_blk = offset;

	// all mask are calculate by its bits, so it is common code
	card_info->sw_mask_blk = (1 << find_cont_bits(card_info->num_blk)) - 1;
	card_info->sw_mask_pg = (1 << find_cont_bits(card_info->num_pg)) - 1;
	card_info->sw_mask_lu = (1 << find_cont_bits(card_info->num_lun)) - 1;
	card_info->sw_mask_ce = (1 << find_cont_bits(card_info->num_ce)) - 1;
	card_info->sw_mask_gr = (1 << find_cont_bits(card_info->num_sw_gr)) - 1;
	card_info->sw_mask_ch = (1 << find_cont_bits(card_info->num_sw_ch)) - 1;
	card_info->sw_mask_pl = (1 << find_cont_bits(card_info->num_sw_pl)) - 1;
	card_info->hw_mask_blk = (1 << (card_info->hw_off_lu - card_info->hw_off_blk)) - 1;
	card_info->hw_mask_pg = (1 << (card_info->hw_off_blk - card_info->hw_off_pg)) - 1;
	card_info->hw_mask_lu = (1 << (card_info->hw_off_ce - card_info->hw_off_lu)) - 1;
	card_info->hw_mask_ce = (1 << (card_info->hw_off_ch - card_info->hw_off_ce)) - 1;
	card_info->hw_mask_ch = (1 << (32 - card_info->hw_off_ch)) - 1; // 32 bit pba
	if (card_info->nand_type == TSB_BICS) {
		//only toshiba nand have nand type
		card_info->hw_mask_lp =
			(1 << find_cont_bits_c(card_info->num_hw_pl * card_info->num_hw_pt)) - 1;
		card_info->hw_mask_pt = (1 << (card_info->hw_off_pg - card_info->hw_off_pt)) - 1;
	} else {
		card_info->hw_mask_lp = (1 << find_cont_bits_c(card_info->num_hw_pl)) - 1;
		card_info->hw_mask_pt = 0;
	}

	card_info->hw_mask_pl = (1 << (card_info->hw_off_pt - card_info->hw_off_pl)) - 1;
	card_info->hw_mask_of = (1 << (card_info->hw_off_pl - 0)) - 1;

	if (card_info->nand_type == TSB_BICS) {
		card_info->page_data_unit = 24; // data size of 4K each page
		sfx_strcpy(card_info->nand_name, "TOSHIBA");
	} else {
		card_info->page_data_unit = 16;
		sfx_strcpy(card_info->nand_name, "MICRON");
		if (card_info->nand_type == MU_B17A) {
			card_info->hw_mask_ch = (1 << 4) - 1;
		}
	}
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info(
		"%s: Based on OPN: card capacity %d TB, board_type %d, nand_type %d, number_of_ce %d, number_of_lun %d\n",
		__FUNCTION__, card_info->card_capacity, card_info->board_type, card_info->nand_type,
		card_info->num_ce, card_info->num_lun);
	sfx_pr_info("board_type 0: %s, 1: %s, 2: %s, 3: %s\n", "PCB_PUMA_AB", "PCB_LYNX_A", "PCB_PUMA_C",
		    "PCB_LYNX_B");
	sfx_pr_info("nand_type 0: %s, 1: %s, 2: %s\n", "MU_L06B", "TSB_BICS", "MU_B17A");
	sfx_pr_info("page_data_unit: %d, free_block_fifo_size:%d\n", card_info->page_data_unit,
		    card_info->free_block_fifo_size);
#endif

	/*print_card_info(card_info);*/
	return sfx_true;

invalid_opn:
	sfx_pr_err("sfx%s, Invalid opn info:%s board=%d nand=%d capacity=%d lun=%d ce=%d ch=%d, now exit.\n",
		   dev->instance, dev->opn, card_info->board_type, card_info->nand_type,
		   card_info->card_capacity, card_info->num_lun, card_info->num_ce, card_info->num_ch);
	return sfx_false;
}

void b17a_mlc_susp_fix(struct sfx_dev *dev, sfx_bool printw)
{
	xt_u32 val, lsb, msb, feature;
	sfx_load_sequence(dev, b17a_MLC_prog_ctrl);
	// program control register 1
	val = 0x3c;
	msb = 0x05;
	feature = (val << 24) | (msb << 4) | 0x20000;
	lsb = 0x1f;
	do_set_feature_all_ce(dev, lsb, feature, printw);
	// program control register 2
	lsb = 0x21;
	do_set_feature_all_ce(dev, lsb, feature, printw);
	// program control register 3
	msb = 0x06;
	lsb = 0xDF;
	feature = (val << 24) | (msb << 4) | 0x20000;
	do_set_feature_all_ce(dev, lsb, feature, printw);
	// program control register 4
	lsb = 0xE1;
	do_set_feature_all_ce(dev, lsb, feature, printw);
	// configure program control output
	val = 0x3f;
	msb = 0x80;
	feature = (val << 24) | (msb << 4) | 0x20000;
	lsb = 0xDF;
	do_set_feature_all_ce(dev, lsb, feature, printw);
	// Back to set feature cmd sequence
	sfx_load_sequence(dev, b17a_ddr2_enh_set_feat);
}

int sfx_init_card(struct sfx_dev *dev)
{
	int ret;
	int init_cnt, loop_cnt;
	xt_u32 rev, revid;
	xt_u32 intr_mask;
	xt_u32 dev_feature_reg_val, reg_val;
	sfx_board_nand_type *card_info;
	xt_u32 nor_did_info[3], opn_start_addr, sn_start_addr;

	sfx_spin_lock_init(&dev->i2c_lock);
	init_cnt = 0;
	dev_feature_reg_val = fis_indirect_read32(dev, dev->bar, REG_DEV_FEATURE);
	if (IS_DEV_FEAT_GOLDEN(dev_feature_reg_val)) {
		/* Image is golden image; usable for download only */
		dev->goldimg = 1;
		sfx_pr_info("%s: %s, Detect gold image\n", __FUNCTION__, dev->name);
	}
	rev = fis_indirect_read32(dev, dev->bar, REG_IMAGE_VERSION);
	sfx_pr_info("%s: %s, REV=0x%08x(%08d)\n", __FUNCTION__, dev->name, rev, (rev & 0xfffff));
	revid = rev & 0xfffff;

	intr_mask = fis_indirect_read32(dev, dev->bar, REG_INTR_MASK);
	/* skip_init skips NOR operation, board type checking and nand reset. */
	/* It is for internal use. Use it with caution. */
	if (skip_init) {
		sfx_pr_info("%s: %s, skip_init specified, return\n", __FUNCTION__, dev->name);
		return 0;
	}

	sfx_snprintf(dev->firmware_rev, sizeof(dev->firmware_rev), "%08d", (rev & 0xfffff));
	if (sfx_read_nor_did(dev, nor_did_info)) {
		sfx_pr_err("%s: %s sfx_read_nor_did(0x%p) failed\n", __FUNCTION__, dev->name, dev);
		return -1;
	}
	sfx_pr_err("%s: sfx_read_nor_did(sfx%d): 0x%x, 0x%x, 0x%x\n", __FUNCTION__, dev->instance,
		   nor_did_info[0], nor_did_info[1], nor_did_info[2]);
	opn_start_addr = nor_did_info[2] - NOR_IDENTITY_OPN_OFFSET;
	sn_start_addr = nor_did_info[2] - NOR_IDENTITY_SN_OFFSET;
	dev->nor_sw = nor_did_info[2] - NOR_IDENTITY_SW_OFFSET;
	dev->sn_start_addr = sn_start_addr;
	sfx_memset(dev->opn, 0, sizeof(dev->opn));
	if (sfxdriver_nor_flash_read(dev, opn_start_addr, 16, (xt_u32 *)dev->opn)) {
		sfx_pr_info("%s: sfxdriver_nor_flash_read(0x%p) for opn failed\n", __FUNCTION__, dev);
	} else {
		char *sp;
		int i = 0;
		sp = dev->opn;
		while (*sp && i < 16) {
			if (!sfx_isalnum(*sp)) {
				*sp = '\0';
				break;
			}
			sp++;
			i++;
		}
		if (i == 16) {
			sfx_pr_err("%s: sfxdriver_nor_flash_read OPN=%s length may overflow\n", __FUNCTION__,
				   dev->opn);
		}
	}
	sfx_memset(dev->serial, 0, sizeof(dev->serial));
	if (sfxdriver_nor_flash_read(dev, sn_start_addr, 20, (xt_u32 *)dev->serial)) {
		sfx_pr_info("%s: sfxdriver_nor_flash_read(0x%p) for sn failed\n", __FUNCTION__, dev);
	} else {
		char *sp;
		int i = 0;
		sp = dev->serial;
		while (*sp && i < 20) {
			if (!sfx_isalnum(*sp)) {
				*sp = '\0';
				break;
			}
			sp++;
			i++;
		}
		if (i == 20) {
			sfx_pr_err("%s: sfxdriver_nor_flash_read SN=%s length may overflow\n", __FUNCTION__,
				   dev->serial);
		}
	}
	sfx_pr_info("%s: %s OPN=%s SN=%s SW=0x%x\n", __FUNCTION__, dev->name, dev->opn, dev->serial,
		    dev->nor_sw);

	ret = sfx_opn_parser(dev);
	if (ret == sfx_false && !dev->goldimg) {
		sfx_pr_err("%s: %s Invalid OPN\n", __FUNCTION__, dev->name);
		return -1;
	}
	card_info = &dev->card_info;
	card_info->image_rev = rev;
	dev->init_err = 0;
	dev->init_fatal_err = 0;

#ifdef SFXDRIVER_BASE_DEBUG
	if (card_info->nand_type == MU_L06B) {
		sfx_pr_info("%s: Detect Micron L06B MLC NAND\n", __FUNCTION__);
	}
	if (card_info->nand_type == MU_B17A) {
		sfx_pr_info("%s: Detect Micron B17A TLC NAND\n", __FUNCTION__);
	}
	if (card_info->nand_type == TSB_BICS) {
		sfx_pr_info("%s: Detect Toshiba BiCS TLC NAND\n", __FUNCTION__);
	}
#endif
	if (dev->goldimg || dev->comp_only) {
		return 0;
	}
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: Performing card init from driver\n", __FUNCTION__);
#endif
	fis_indirect_write32(dev, dev->bar, FCE_CONTROL_1, 0x407084);

#if 0 /* reduce LDPC iteration after CCS is up */
	if (0 == IS_DEV_FEAT_RC(fis_indirect_read32(dev, dev->bar, REG_DEV_FEATURE))) {
		// R2C feature is not enabled.
		// feisun: ECC control iteration number setup: 0x80 for max and 0x78 for post_trigger
		reg_val = fis_indirect_read32(dev, dev->bar, REG_ECC_CONTROL_0);
		// [15:4] - max_dec_iter
		reg_val = (reg_val & 0xffff000f) | 0x800;
		// [29:18] - post_trigger_iter
		reg_val = (reg_val & 0xc003ffff) | 0x1e00000;
		fis_indirect_write32(dev, dev->bar, REG_ECC_CONTROL_0, reg_val);
	}
#endif

#ifdef MQ_NEWHW
	reg_val = fis_indirect_read32(dev, dev->bar, REG_CMD_SCHEDULE);
	if ((rev & 0xfffff) < 4153) {
		reg_val &= 0xfffffffe;
		fis_indirect_write32(dev, dev->bar, REG_CMD_SCHEDULE, reg_val);
	}
#endif

	// cfg MI bram for basic management cmd code 0x8: serial num
	if (IS_DEV_FEAT_NVME_MI(dev_feature_reg_val)) {
		xt_u8 i;

		// code segment to work with image 8101
		fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_ADDR, 51); // Hard code to 51 for now
		// {rec_opc, rec_len in byte}
		reg_val = (1 << 16) + 12; //SN 12B
		// sfx_pr_info("%s: write mi_reg_val 0x%x\n", __FUNCTION__, reg_val);
		fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_DATA, reg_val);
		// 12 Bytes serial num
		for (i = 0; i < 3; i++) {
			reg_val = (dev->serial[4 * i + 3] << 24) + (dev->serial[4 * i + 2] << 16) +
				  (dev->serial[4 * i + 1] << 8) + dev->serial[4 * i];
			// sfx_pr_info("%s: write mi_reg_val 0x%x\n", __FUNCTION__, reg_val);
			fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_DATA, reg_val);
		}

		// code segment to work with image 8181
		fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_ADDR, 0);
		// {rec_opc, rec_len in byte}
		reg_val = (1 << 16) + 12; //SN 12B
		// sfx_pr_info("%s: write mi_reg_val 0x%x\n", __FUNCTION__, reg_val);
		fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_DATA, reg_val);
		// 12 Bytes serial num
		for (i = 0; i < 3; i++) {
			reg_val = (dev->serial[4 * i + 3] << 24) + (dev->serial[4 * i + 2] << 16) +
				  (dev->serial[4 * i + 1] << 8) + dev->serial[4 * i];
			// sfx_pr_info("%s: write mi_reg_val 0x%x\n", __FUNCTION__, reg_val);
			fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_DATA, reg_val);
		}
		fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_DATA, 0);

		// read back to cross check
		// fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_ADDR, 51);
		// for (i = 0; i < 4; i++) {
		//     sfx_pr_info("%s: read mi_reg_val 0x%x\n", __FUNCTION__, fis_indirect_read32(dev, dev->bar, NVME_MI_BRAM_DATA));
		// }
		// fis_indirect_write32(dev, dev->bar, NVME_MI_BRAM_ADDR, 0);
		// for (i = 0; i < 4; i++) {
		//     sfx_pr_info("%s: read mi_reg_val 0x%x\n", __FUNCTION__, fis_indirect_read32(dev, dev->bar, NVME_MI_BRAM_DATA));
		// }
	}

	// Enable hw interrupt controller, effective for image version 6136 or above
	reg_set_bit(dev, POWER_MASK, 16); // sticky bit, hw_intr_handler_en
	// Enable PF timeout counter 6.2ms
	fis_indirect_write32(dev, dev->bar, CSS_PWRFAIL_ABORT_CTRL, 0x1300001);
	// Set ERASE page detection threshold to 0xfe
	fis_indirect_write32(dev, dev->bar, ERASE_PAGE_THR, 0xfe);

	// Allow 2 outstanding read command per die
	reg_val = fis_indirect_read32(dev, dev->bar, REG_CMD_SCHEDULE);
	if (card_info->nand_type == MU_B17A) {
		reg_val = (reg_val & 0xf0ffff0f) |
			  0x7000010; // enable scheduler send on erase, read on same die in order
	} else {
		reg_val = (reg_val & 0xffffff0f) | 0x10;
	}
	reg_val |= 0x66000000;
	fis_indirect_write32(dev, dev->bar, REG_CMD_SCHEDULE, reg_val);

	fis_indirect_write32(dev, dev->bar, COAL_AGG, 0x0707);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: die_remap = %d\n", __FUNCTION__, card_info->die_remap);
#endif
	// Jinjin, enable ce-remapping
	if (card_info->die_remap == 1) {
		reg_set_bit(dev, REG_WR_JOB_CHAN, 24);
	} else if (card_info->die_remap == 2) {
		reg_set_bit(dev, REG_WR_JOB_CHAN, 25);
	}

//This code might cause more problem, comment out
#if 0
	// check NAND Vcc, set to 3.0V for PUMA_C drive only
	if ((card_info->board_type == PCB_PUMA_C) && (card_info->nand_type == MU_B17A)) {
		/*sfx_pr_info("%s: %s, BoardType == %u (%s), check NAND VCC \n", __FUNCTION__, dev->name,
			    card_info->board_type, card_info->board_type);*/
		i2c_axi_direct_reset(dev);
		i2c_direct_write(dev, 0x40, 0x00, 1, 0x01, 1);
		reg_val = i2c_direct_read(dev, 0x40, 0x21, 2, 1);

		// 3.0v VOUT 3000 34CD 335C 3266 2D9A 2CA4 2B33
		// 3.3v VOUT 34CD 3A15 387F 3771 3229 311B 2F85
		if (reg_val == 0x3000) {
#ifdef SFXDRIVER_BASE_DEBUG
			i2c_direct_read(dev, 0x40, 0x40, 2, 1);
			i2c_direct_read(dev, 0x40, 0x42, 2, 1);
			i2c_direct_read(dev, 0x40, 0x25, 2, 1);
			i2c_direct_read(dev, 0x40, 0x26, 2, 1);
			i2c_direct_read(dev, 0x40, 0x43, 2, 1);
			i2c_direct_read(dev, 0x40, 0x44, 2, 1);
			reg_val = i2c_direct_read(dev, 0x40, 0x21, 2, 1);
			sfx_pr_info("%s: %s, NAND Vcc value is 0x%x\n", __FUNCTION__, dev->name, reg_val);
#endif
			sfx_pr_info("%s: %s, NAND Vcc is already set to 3.00V\n", __FUNCTION__, dev->name);
		} else { // set NAND Vcc to 3.0s
			i2c_direct_write(dev, 0x40, 0x26, 2, 0x2D9A, 1);
			i2c_direct_write(dev, 0x40, 0x43, 2, 0x2CA4, 1);
			i2c_direct_write(dev, 0x40, 0x44, 2, 0x2B33, 1);
			i2c_direct_write(dev, 0x40, 0x21, 2, 0x3000, 1);
			i2c_direct_write(dev, 0x40, 0x25, 2, 0x3266, 1);
			i2c_direct_write(dev, 0x40, 0x40, 2, 0x34CD, 1);
			i2c_direct_write(dev, 0x40, 0x42, 2, 0x335C, 1);
			i2c_direct_write(dev, 0x40, 0x15, 0, 0x0000, 1); // write eeprom
			sfx_pr_info("%s: %s, NAND Vcc is set to 3.00V\n", __FUNCTION__, dev->name);
		}
	}
#endif

	//////////////////////////////////
	//     init for Micron L06B     //
	//////////////////////////////////
	if ((card_info->nand_type == MU_L06B) | (card_info->nand_type == MU_B17A)) {
		///////////////////////////////////////////////////////
		//               pre-conditioning                    //
		///////////////////////////////////////////////////////
		// enable polling timeout for all command
		reg_set_bit(dev, FCE_CONTROL_0, 14);
		// configure timeout_control register
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMEOUT_CTRL0, 0x1fff0100);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMEOUT_CTRL1, 0x1fff0500);
		// let the command finish when dqs is missing
		reg_set_bit(dev, FCE_CONTROL_0, 9);
		//fis_indirect_write32(dev, dev->bar, BMGR_CONTROL_0, 0x190080);

		///////////////////////////////////////////////////////
		//                     main body                     //
		///////////////////////////////////////////////////////
		while (1) {
			/*sfx_pr_info("%s: %s, Micron NAND init round %d\n", __FUNCTION__, dev->name,
				    (init_cnt + 1));*/
			if (init_cnt < MAX_RETRY) {
				if (init_cnt == 0) {
					dev->init_msg_store = 1;
				} else {
					dev->init_msg_store = 0;
				}
				ret = micron_nand_init(dev, rev, 0);
			} else {
				ret = micron_nand_init(dev, rev, 1);
			}
			if (!ret) {
				if (dev->init_err == 0 && dev->init_fatal_err == 0) {
					sfx_pr_info(
						"%s: %s, SUCCESSFULLY INITIALIZE MICRON NAND DEVICE AFTER %d ATTEMPTS\n",
						__FUNCTION__, dev->name, (init_cnt + 1));
					break;
				} else {
					if (init_cnt == MAX_RETRY || dev->init_fatal_err != 0) {
						sfx_pr_info(
							"%s: %s, !!!FATAL: MICRON NAND INITIALIZATION FAILED AFTER %d ATTEMPTS, return -ENODEV!!!\n",
							__FUNCTION__, dev->name, (init_cnt + 1));
						nand_init_fail_print(dev);
						return -ENODEV;
					} else {
						init_cnt++;
						dev->init_err = 0;
					}
				}
			} else {
				if (init_cnt == MAX_RETRY) {
					sfx_pr_info(
						"%s: %s, !!!FATAL: MICRON NAND INITIALIZATION FAILED AFTER %d ATTEMPTS, return -ENODEV!!!\n",
						__FUNCTION__, dev->name, (init_cnt + 1));
					nand_init_fail_print(dev);
					return -ENODEV;
				}
				init_cnt++;
			}
		}
		///////////////////////////////////////////////////////
		//               post-conditioning                   //
		///////////////////////////////////////////////////////

		// enable erase suspend if rev_id>='d2257
		if ((rev & 0xfffff) >= 2257) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: Enable erase suspend feature\n", __FUNCTION__);
#endif
			fis_indirect_write32(dev, dev->bar, REG_SUSP_CTRL, 0x05340811);
#ifdef SFXDRIVER_BASE_DEBUG
		} else {
			sfx_pr_info("%s: The image does NOT support seperate erase and program controls\n",
				    __FUNCTION__);
#endif
		}

		// configure FIS register based on SW performance tuning result in Jan. 2018
		if ((rev & 0xfffff) >= 4331) {
			reg_val = fis_indirect_read32(dev, dev->bar, FIS_ERA_CREDIT);
			reg_val = (reg_val & 0xffffff00) | 0x3;
			fis_indirect_write32(dev, dev->bar, FIS_ERA_CREDIT, reg_val);
			if (IS_DEV_FEAT_BIGBUF(dev_feature_reg_val)) {
				fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x666f666f);
			} else {
				fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x66666666);
			}
		} else {
			fis_indirect_write32(dev, dev->bar, FIS_ERA_CREDIT, 0x106);
		}

		// feisun: 09/25/2018 update b2n credit for B17A to improve write performance
		if (card_info->nand_type == MU_B17A) {
			if (IS_DEV_FEAT_BIGBUF(dev_feature_reg_val)) {
				fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x666f666f);
				reg_val = fis_indirect_read32(dev, dev->bar, BMGR_CONTROL_0);
				reg_val = (reg_val & 0xFFFFF800) | 0x200;
				fis_indirect_write32(dev, dev->bar, BMGR_CONTROL_0, reg_val);
			} else {
				fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x66666666);
			}
		}

		fis_indirect_write32(dev, dev->bar, REG_Q3_THROTT_CTRL, 0x10);

		// disable polling timeout
		reg_unset_bit(dev, FCE_CONTROL_0, 14);
		// reconfigure timeout_control register
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMEOUT_CTRL0, 0x00100100);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMEOUT_CTRL1, 0x00020500);
		// let the command finish when dqs is missing
		reg_unset_bit(dev, FCE_CONTROL_0, 9);
		// JPL, enable seq_rd
		reg_set_bit(dev, FCE_CONTROL_0, 19);

		reg_val = 0xf340431;
		fis_indirect_write32(dev, dev->bar, REG_SUSP_CTRL, reg_val);
		if (card_info->nand_type == MU_B17A) {
			if (revid >= 6139) {
				/*sfx_pr_info("%s: %s, Check status bit[6] for read job.\n", __FUNCTION__,
					    dev->name);*/
				reg_set_bit(dev, FCE_CONTROL_0, 24);
			}
			if (IS_DEV_FEAT_MUSUSPFIX(dev_feature_reg_val)) {
				/*sfx_pr_info("%s: %s, enable MLC suspend workaround.\n", __FUNCTION__,
					    dev->name);*/
				b17a_mlc_susp_fix(dev, 0);
			}
		}
	}

	//////////////////////////////////
	//      init for TSB BiCS       //
	//////////////////////////////////
	if (card_info->nand_type == TSB_BICS) {
		///////////////////////////////////////////////////////
		//               pre-conditioning                    //
		///////////////////////////////////////////////////////
		// enable NAND electronic mirroring
		/*sfx_pr_info("%s: %s, Enable FCE NAND electronic mirroring for TSB device on PUMAC board.\n",
			    __FUNCTION__, dev->name);*/
		reg_set_bit(dev, FCE_CONTROL_0, 18);

		// turn off read_refresh - work around for a card issue
		fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_0, 0x0);
		fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1, 0x0);
		sfx_msleep(1);
		/*sfx_pr_info("%s: %s, READ_REFRESH_CTRL_0=0x%x\n", __FUNCTION__, dev->name,
			    fis_indirect_read32(dev, dev->bar, READ_REFRESH_CTRL_0));
		sfx_pr_info("%s: %s, READ_REFRESH_CTRL_1=0x%x\n", __FUNCTION__, dev->name,
			    fis_indirect_read32(dev, dev->bar, READ_REFRESH_CTRL_1)); */

		///////////////////////////////////////////////////////
		//                     main body                     //
		///////////////////////////////////////////////////////
		while (1) {
			/*sfx_pr_info("%s: %s, TSB BiCS NAND init round %d\n", __FUNCTION__, dev->name,
				    (init_cnt + 1));*/
			if (card_info->num_blk == 2958) { // cTLC
				if (init_cnt < MAX_RETRY) {
					if (init_cnt == 0) {
						dev->init_msg_store = 1;
					} else {
						dev->init_msg_store = 0;
					}
					ret = tsb_nand_init(dev, rev, 0, 0); // cTLC
				} else {
					ret = tsb_nand_init(dev, rev, 1, 0);
				}
			} else {
				if (init_cnt < MAX_RETRY) {
					if (init_cnt == 0) {
						dev->init_msg_store = 1;
					} else {
						dev->init_msg_store = 0;
					}
					ret = tsb_nand_init(dev, rev, 0, 1); //eTLC
				} else {
					ret = tsb_nand_init(dev, rev, 1, 1); // eTLC
				}
			}

			if (!ret) {
				if (dev->init_err == 0) {
					sfx_pr_info(
						"%s: %s, SUCCESSFULLY INITIALIZE TSB NAND DEVICE AFTER %d ATTEMPTS\n",
						__FUNCTION__, dev->name, (init_cnt + 1));
					break;
				} else {
					if (init_cnt == MAX_RETRY) {
						sfx_pr_info(
							"%s: %s, !!!FATAL: TSB NAND INITIALIZATION FAILED AFTER %d ATTEMPTS, return -ENODEV!!!\n",
							__FUNCTION__, dev->name, (init_cnt + 1));
						nand_init_fail_print(dev);
						return -ENODEV;
					} else {
						init_cnt++;
						dev->init_err = 0;
					}
				}
			} else {
				if (init_cnt == MAX_RETRY) {
					sfx_pr_info(
						"%s: %s, !!!FATAL: TSB NAND INITILIZATION FAILED AFTER %d ATTEMPTS, return -ENODEV!!!\n",
						__FUNCTION__, dev->name, (init_cnt + 1));
					nand_init_fail_print(dev);
					return -ENODEV;
				}
				init_cnt++;
			}
		}

		/* enable read refresh*/
		{
			xt_u32 rd_ref_stat;
			int loop_cnt;
			if ((rev & 0xfffff) >= 4205) {
				//sfx_pr_info("%s: %s, enable read refresh\n", __FUNCTION__, dev->name);
				if (card_info->num_lun == 1) {
					if (card_info->num_blk == 1478) {
						fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1,
								     0x3d0);
					} else if (card_info->num_blk == 2958) {
						fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1,
								     0x3d2);
					}
				} else if (card_info->num_lun == 2) {
					if (card_info->num_blk == 1478) {
						fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1,
								     0x3d1);
					} else if (card_info->num_blk == 2958) {
						fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1,
								     0x3d3);
					}
				}
				fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_0, 0x1);
				loop_cnt = 1;
				while (1) {
					sfx_msleep(1);
					rd_ref_stat = fis_indirect_read32(dev, dev->bar, READ_REFRESH_STAT);
					if (rd_ref_stat & 0x1) {
						sfx_pr_info(
							"%s: %s, Read refresh is enabled successfully within %dms!\n",
							__FUNCTION__, dev->name, (loop_cnt * 1));
						break;
					}
					if (loop_cnt == 1280) {
						sfx_pr_info(
							"%s: %s, Fail to enable Read refresh within %dms!\n",
							__FUNCTION__, dev->name, (loop_cnt * 10));
						dev->init_err++;
						break;
					}
					loop_cnt++;
				}
			}
		}

		///////////////////////////////////////////////////////
		//               post-conditioning                   //
		///////////////////////////////////////////////////////
		// enable multi-plane polling
		reg_set_bit(dev, FCE_CONTROL_0, 16);
		reg_val = 0xf340431;
		fis_indirect_write32(dev, dev->bar, REG_SUSP_CTRL, reg_val);

		if (IS_DEV_FEAT_BIGBUF(dev_feature_reg_val)) {
			fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x666f666f);
			// cfg the write buffer size 1.25MB, so PF won't wrap around 64 rsvd PBAs
			reg_val = fis_indirect_read32(dev, dev->bar, BMGR_CONTROL_0);
			reg_val = (reg_val & 0xFFFFF800) | 0x200;
			fis_indirect_write32(dev, dev->bar, BMGR_CONTROL_0, reg_val);
		} else {
			// hzhao: 10/2/2018 update b2n credit to improve write performance
			fis_indirect_write32(dev, dev->bar, FIS_B2N_CREDIT, 0x66696668);
		}
		// hzhao: 10/2/2018 to improve performance
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL0, 0x1fff1f3f);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL1, 0x800090);
		fis_indirect_write32(dev, dev->bar, REG_RS_TIMER_CTRL3, 0x100010);

		fis_indirect_write32(dev, dev->bar, REG_Q3_THROTT_CTRL, 0x10);

		if (card_info->die_remap != 0) {
			if ((rev & 0xfffff) <= 4487) {
				// bypass wcmd_scheduler to avoid hanging
				// the issue is fixed in rev. 4487
				reg_set_bit(dev, SFX_P1_CTRL, 31);
			}
		}
	}

	//////////////////////////////////
	//  Other global configuration  //
	//////////////////////////////////

	reg_val = fis_indirect_read32(dev, dev->bar, SFX_P1_CTRL);
	reg_val &= ~0x300; // enable scrambler
	fis_indirect_write32(dev, dev->bar, SFX_P1_CTRL, reg_val);
	if ((rev & 0xfffff) < 4153) {
		reg_set_bit(dev, SFX_P1_CTRL,
			    31); // temporarily disable wcmd schd because of the erase bug
	}

	// scrambler seed LUT configure
#ifdef SFXDRIVER_BASE_DEBUG
	if ((rev & 0xfffff) >= 2767) {
		sfx_pr_info("%s: Using default scrmbler seed LUT RAM value loaded during image build.\n",
			    __FUNCTION__);
	} else if ((rev & 0xfffff) >= 2746) {
		sfx_pr_info("%s: Configure scrambler seed LUT RAM\n", __FUNCTION__);
		do_init_scr_seed_tab(dev);
	} else {
		sfx_pr_info("%s: Using scrambler seed LUT ROM\n", __FUNCTION__);
	}
#else
	if (((rev & 0xfffff) >= 2746) && ((rev & 0xfffff) >= 2767))
		do_init_scr_seed_tab(dev);
#endif

	// set up LTC3350 Vshunt configuration
	if ((card_info->board_type == PCB_PUMA_C) || (card_info->board_type == PCB_LYNX_B) ||
	    (card_info->board_type == PCB_PANTHER_A) || (card_info->board_type == PCB_LEOPARD)) {
		reg_val = 0;
		i2c_axi_direct_reset(dev);
		i2c_direct_write(dev, 0x9, 0x6, 2, VSHUNT, 1);
		reg_val = i2c_direct_read(dev, 0x9, 0x6, 2, 1);
		// try 32 times vshunt settings
		loop_cnt = 0;
		while (reg_val != VSHUNT) {
			i2c_direct_write(dev, 0x9, 0x6, 2, VSHUNT, 1);
			reg_val = i2c_direct_read(dev, 0x9, 0x6, 2, 1);
			if (reg_val == VSHUNT) {
				sfx_pr_info("%s: %s, LTC3350 configuration is set to 0x%x!!!\n", __FUNCTION__,
					    dev->name, VSHUNT);
				break;
			} else {
				i2c_axi_direct_reset(dev);
				if (loop_cnt == 31) {
					sfx_pr_info(
						"%s: %s, WARNING: LTC3350 I2C Config Failed, expect value 0x%x, and actual value is 0x%x!!!\n",
						__FUNCTION__, dev->name, VSHUNT, reg_val);
					break;
				}
			}
			loop_cnt++;
		}
	} else { // Puma A and B boards
		sfx_pr_info("%s: %s, BoardType == %u, calls puma_i2c_init()\n", __FUNCTION__, dev->name,
			    card_info->board_type);
		puma_i2c_init(dev);
		i2c_direct_init(dev);
	}
	sfx_read_power(dev);
	if (intr_mask != 0xfff) {
		sfx_pr_info("%s: %s, warning intr_mask 0x%x != default 0xfff)\n", __FUNCTION__, dev->name,
			    intr_mask);
	}

	// disable 6703 PF bug fix since the fix in image 8288 has issue
	reg_unset_bit(dev, REG_MISC_CONTROL, 3);

	//deactivate the read after write enhancement (trac#4291)
	reg_unset_bit(dev, SFX_P1_EXT_CTRL, 21);

	/* activate power failuer handling of firmware, need to read INTR_RC to clear register first */
	fis_indirect_read32(dev, dev->bar, INTR_RC);
	if ((rev & 0xfffff) < 4153) {
		fis_indirect_write32(dev, dev->bar, REG_INTR_MASK, intr_mask & 0xffffffff);
	} else {
		fis_indirect_write32(dev, dev->bar, REG_INTR_MASK, intr_mask & 0xfffffffc);
	}
	if (sfx_cc) {
		if (!strncmp(sfx_cc, dev->serial, strlen(dev->serial))) {
			sfx_pr_info("%s: %s, module_param sfx_cc %s == SN, do card clean\n", __FUNCTION__,
				    dev->name, sfx_cc);
			dev->to_clean = 1;
		}
	}

	return 0;
}

void sfx_init_caps(struct sfx_dev *dev, xt_u32 caps_th)
{
	i2c_direct_write(dev, 0x62, 0x0a, 2, 0xff, 1); //clear all the i2c interrupt
	i2c_direct_write(dev, 0x9, 0x16, 2, caps_th, 1); //set the threshold of capacitor
	i2c_direct_write(dev, 0x9, 0x01, 2, 1 << MSK_CAP_IO_POS, 1); //enable mask reg
}

void sfx_trigger_caps_intr(struct sfx_dev *dev, xt_u32 caps_th)
{
	i2c_direct_write(dev, 0x9, 0x16, 2, caps_th, 1); //set the threshold of capacitor
	//i2c_direct_write(dev, 0x9, 0x01, 2, 1 << MSK_CAP_IO_POS, 1); //enable mask reg
	//i2c_direct_write(dev, 0x9, 0x00, 2, 1 << CLR_CAP_IO_POS, 1); //clear clr_alarm
}

void sfx_poll_caps_intr(struct sfx_dev *dev)
{
	//fis_indirect_read32(dev, dev->bar, CHIP_INTR_RC); //read intr_rc to clear intr_status
	i2c_direct_write(dev, 0x9, 0x00, 2, 1 << CLR_CAP_IO_POS, 1); //clear clr_alarm
	i2c_direct_write(dev, 0x9, 0x17, 2, 0x9, 1); //write 0x9 @ ctl_reg
}

int sfx_chk_caps_intr(struct sfx_dev *dev)
{
	xt_u32 i2c_reg_val = 0;
	i2c_reg_val = i2c_direct_read(dev, 0x9, 0x1d, 2, 1); //read clr_alarms_reg
	if (((i2c_reg_val >> ALARM_CAP_IO_POS) & 0x1) == 1) {
		return 0; //failure
	} else {
		return 1; //success
	}
}

int sfx_capacitor_handle(struct sfx_dev *dev, xt_u32 op, xt_u32 para)
{
	int ret = 0;
	switch (op) {
	case 0:
		sfx_init_caps(dev, para);
		break;
	case 1:
		sfx_trigger_caps_intr(dev, para);
		break;
	case 2:
		sfx_poll_caps_intr(dev);
		break;
	case 3:
		ret = sfx_chk_caps_intr(dev);
		break;
	default:
		break;
	}
	return ret;
}
EXPORT_SYMBOL(sfx_capacitor_handle);
