/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2016-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfxdriver_common.h
 * ---------------------------------------------------------------------------
 */

#ifndef __SFXDRIVER_COMMON_H__
#define __SFXDRIVER_COMMON_H__

#include "sfx_hw_regs.h"
#include "sfx_os_headers.h"
#include "sfx_api.h"
#include "sfx_types.h"
#include "feat.h"
#include "osal.h"
#include "uapi_nvme.h"
#include "nvme310_327.h"
#include "sfx_driver_cb.h"
#include "version_tmp.h"
#include "sfxdriver_spi_common.h"

//#define TWO_DEFAULT_IO_QS
//#define SFXDRIVER_BASE_DEBUG

#define INIT_DB_ENTRY_SIZE              16
#define MAX_Q_NUM                       128

/* Arguments to sfx_get_page_ctr_val */

#define SFX_COUNTER_UNLOCKED            0
#define SFX_COUNTER_LOCKED              1
#define SFX_COUNTER_TRIES               2

#define NO_BLK_FTL                      2

#define PR_INFO(fmt, ...)               sfx_pr_info("%s: " fmt, __FUNCTION__, __VA_ARGS__)

#define SFX_BD_HEAP_SIZE_32T            0x90000000   //max allowed 0xc0000000-0x4000
#define SFX_BD_HEAP_SIZE_64T            0xBC000000
#define SFX_BD_HEAP_SIZE_16T            0x70000000

#define LED_CONTROL_MASK                (~0x70)

#define SFX_ADMIN_TIMEOUT               (admin_timeout * SFX_HZ)
#define SFX_Q_DEPTH                     (1024 + 512)
#define SQ_SIZE(depth)                  ((depth) * sizeof(struct nvme_command))
#define CQ_SIZE(depth)                  ((depth) * sizeof(struct nvme_completion))
#define DEV_NAME_prefix                 "sfx"
#define MAX_SLOTS                       (32 * 1024)
#define PROBE_CNT                       10
#define PROBE_ASSERT_INC				5
#define MAX_IO_LENGTH                   (32 * 1024)

// these offsets are used to caculate the address form
// the start of the nor_sw
#define NOR_IDENTITY_SW_PROBECNT_OFFSET   0
#define NOR_IDENTITY_SW_LIFECNT_OFFSET    BYTE_PER_SUBSECTOR
// !!! LIFE CNT will use two sub sectors
// !!! please pay attention when adding next info to nor_sw
// !!! should use BYTE_PER_SUBSECTOR*3 as the offset

typedef enum {
    PROBE_ADD,
    PROBE_CLR,
    PROBE_INVALID,
}probecnt_ope_t;

typedef enum {
    LIFE_ADD,
    LIFE_CLR,
    LIFE_INVALID,
}lifecnt_ope_t;


// #define USE_KTIME_ALL
struct sync_cmd_info
{
    sfx_thread_t task;
    xt_u32 result;
    xt_32 status;
    xt_u32 ext_result;
#ifdef USE_KTIME_CTX
    xt_u16 opcode;
    xt_u64 latency;
    sfx_ktime_t its; /* initial timestamp */
    sfx_ktime_t smt; /* submission timestamp */
    sfx_ktime_t irq; /* completion timestamp */
#endif
};

/*
 * The sfx_iod describes the data in an I/O, including the list of PRP
 * entries.  You can't see it in this data structure because C doesn't let
 * me express that.  Use sfx_alloc_iod to ensure there's enough space
 * allocated to store the PRP list.
 */
struct sfx_iod
{
    void *private;      /* For the use of the submitter of the I/O */
    xt_32 npages;       /* In the PRP list. 0 means small pool in use */
    xt_32 offset;       /* Of PRP list */
    xt_32 nents;        /* Used in scatterlist */
    xt_32 length;       /* Of data, in bytes */
    unsigned long start_time;
    sfx_dma_addr_t first_dma;
    sfx_dma_addr_t prp_dma;
    struct sfx_list_head node;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    struct {
        sfx_ktime_t init_time;
        sfx_ktime_t smt_time;
        sfx_ktime_t irq_time;
        sfx_ktime_t ftl_cb_smt_time;
        sfx_ktime_t ftl_cb_rtn_time;
        sfx_ktime_t cmpl_time;
#if (READ_HW_LAT)
        xt_u32 hw_dbell_tcnt;
        xt_u32 hw_cpl_tcnt;
        xt_u32 hw_intr_tcnt;
#endif
    };
#endif
#ifdef USE_SGELEM
    sfx_scatterlist sg[MAX_IO_LENGTH/0x1000 + 1];
    sfx_scatterlist sgo[MAX_IO_LENGTH/0x1000 + 1];
#else
    struct sfx_scatterlist sg[MAX_IO_LENGTH/0x1000 + 1];
#endif
    void *prp_array[1];      /* with current max io length, one is enoug */
    sfx_bool static_alloc;
};

/*
 * For Async_IO
 */
struct async_io_cmd_info
{
    struct sfx_list_head node;
    struct async_cmd_info *queue_cmd_info;
    struct sfx_iod *iod;
    xt_u16 fids[MAX_COMBINED_FCMD];
    xt_u16 nr_fcmd;
    xt_u16 opcode;
    xt_u16 apptag;  /* nid from upper layer */
    xt_u16 sqid;
    xt_32 cmdid;
    xt_u32 result;
    void * addr;
  //  xt_u32 lba;
    xt_u32 ext_result;   // to replace lba
    sfx_bool from_kernel; /* Request originated from kernel */
    xt_u32 fake_result; /* Substitute this for the real one */
    struct sfx_fd *owner;
#ifdef USE_KTIME_CTX
    xt_u64 latency;
    sfx_ktime_t its; /* initial timestamp */
    sfx_ktime_t smt; /* submission timestamp */
    sfx_ktime_t irq; /* completion timestamp */
#endif
    struct sfx_iod cmd_iod;
};

struct async_cmd_info
{
    struct sfx_work_struct work;
    sfx_worker_t *worker;
    xt_u32 result;
  //  xt_u32 lba;
    xt_u32 ext_result;   // change from lba to ext_result
    xt_32 status;
    void *ctx;
#ifdef USE_KTIME_CTX
    xt_u16 opcode;
    xt_u64 latency;
    sfx_ktime_t its; /* initial timestamp */
    sfx_ktime_t smt; /* submission timestamp */
    sfx_ktime_t irq; /* completion timestamp */
#endif
};

#ifdef USE_KTIME_CTX
struct sfx_lat_stats
{
    xt_u64 nandreset_rtt;
    xt_u64 nandreset_smt;
    xt_u64 nandreset_cnt;
    xt_u64 nandreset_max;
    xt_u64 aes_rtt;
    xt_u64 aes_smt;
    xt_u64 aes_cnt;
    xt_u64 aes_max;
    xt_u64 ai_rtt;
    xt_u64 ai_smt;
    xt_u64 ai_cnt;
    xt_u64 ai_max;
    xt_u64 gf_rtt;
    xt_u64 gf_smt;
    xt_u64 gf_cnt;
    xt_u64 gf_max;
    xt_u64 sf_rtt;
    xt_u64 sf_smt;
    xt_u64 sf_cnt;
    xt_u64 sf_max;
    xt_u64 dcq_rtt;
    xt_u64 dcq_smt;
    xt_u64 dcq_cnt;
    xt_u64 dcq_max;
    xt_u64 dsq_rtt;
    xt_u64 dsq_smt;
    xt_u64 dsq_cnt;
    xt_u64 dsq_max;
    xt_u64 other_rtt;
    xt_u64 other_smt;
    xt_u64 other_cnt;
    xt_u64 other_max;
    xt_u64 wr_rtt;
    xt_u64 wr_smt;
    xt_u64 wr_cnt;
    xt_u64 wr_max;
    xt_u64 rd_rtt;
    xt_u64 rd_smt;
    xt_u64 rd_cnt;
    xt_u64 rd_max;
    xt_u64 other_asyncio_rtt;
    xt_u64 other_asyncio_smt;
    xt_u64 other_asyncio_cnt;
    xt_u64 other_asyncio_max;
};
#endif

struct sfx_q_stats
{
    xt_u64 sq_counter;
    xt_u64 irq_counter;
    xt_u64 irq_counter_total;
    xt_u64 cq_counter;
    xt_u64 cpl_counter;
    xt_u64 poll_counter;
    xt_u64 poll_total;
    xt_u64 polling_counter;
    xt_u64 polling_total;
#ifdef USE_KTIME_ALL
    xt_u64 lat_rtt;
#endif
#ifdef USE_KTIME_CTX
    struct sfx_lat_stats lat_s;
#endif
};

/*
 * An NVM Express queue.  Each device has at least two (one for admin
 * commands and one for I/O commands).
 */
struct sfx_queue
{
    struct sfx_rcu_head             r_head;
    struct device                   *q_dmadev;
    struct sfx_dev                  *dev;
    char                            irqname[24];    // nvme4294967295-65535\0
    sfx_spinlock_t                  q_lock;
    struct sfx_q_stats              q_stats;
    ftl_cmpl_cb                     cmpl_cb;
    struct nvme_command             *sq_cmds;
    volatile struct nvme_completion *cqes;
    sfx_dma_addr_t                  sq_dma_addr;
    sfx_dma_addr_t                  cq_dma_addr;
    sfx_iomem                       q_db;
    xt_u16                          q_depth;
    xt_u16                          cq_vector;
    xt_u16                          sq_head;
    xt_u16                          sq_tail;
    xt_u16                          cq_head;
    xt_u16                          qid;
    xt_u16                          cq_phase;
    xt_u16                          cqe_seen;
    xt_u16                          q_suspended;
    sfx_cpumask_var_t               cpu_mask;
    xt_u32                          q_type;
    // Async_IO
    struct async_cmd_info           cmdinfo;
    sfx_spinlock_t                  list_lock;
    struct sfx_list_head            sq_list;
    struct sfx_list_head            cq_list;
    struct sfx_list_head            free_list;
    /*
     * TODO: Make it scalable, or merge/retire cmdid_data, which is for sync command
     */
    struct async_io_cmd_info        iod_pool[SFX_Q_DEPTH];
    //-------------------------------------------------------------------------
    // WARNING:
    //-------------------------------------------------------------------------
    // Keep this cmdid_data[] conformant array member as the LAST in this struct!!!
    // This conformant array member will get its storage allocated in runtime.
    //-------------------------------------------------------------------------
    unsigned long                   cmdid_data[];
};

typedef void (*sfx_completion_fn)(struct sfx_queue *, void *, struct nvme_completion *);

/*
 * For sync IO command
 */
struct sfx_cmd_info
{
    sfx_completion_fn fn;
    void *ctx;
    unsigned long timeout;
    xt_32 aborted;
#ifdef USE_KTIME_ALL
    // sfx_ktime_t its; /* initial timestamp */
    sfx_ktime_t sts; /* submission timestamp */
    sfx_ktime_t cts; /* completion timestamp */
#endif
};

struct sfx_delq_ctx
{
    sfx_thread_t waiter;
    sfx_worker_t *worker;
    sfx_atomic_t refcount;
};

#define SFX_NUM_QUEUE                   256
#define SFX_INJECT_COUNTER              60  //15000000 //inverval seconds of two error injection
#define SFX_INJECT_ATTEMPT              1024
#define SFX_READ_QUEUE_SIZE_THROTTLE    (127)
#define SFX_WRITE_QUEUE_SIZE_THROTTLE   (111)

struct sfx_stats {
    xt_u32 sq_counter[SFX_NUM_QUEUE];
    xt_u32 cq_counter[SFX_NUM_QUEUE];
    xt_u32 cpl_counter[SFX_NUM_QUEUE];
    xt_u32 check_counter;
};

/*
 * A placeholder for various counters. Intends to remove the global ones.
 * Will be tuned.
 */
struct sfx_cntrs
{
    xt_32 irq_counter;
    xt_u32 irq_total;
    xt_32 erase_error_counter;
    xt_u64 read_counter;
    xt_32 debug_flag;        /* this will need to be relocated */
    xt_32 polling_counter;
    xt_u32 polling_total;
    xt_u32 local_locked_pages;
    xt_u32 local_unlocked_pages;
};

typedef struct sfx_pages
{
    struct sfx_list_head node;
    struct sfx_list_head on_fd;
    struct sfx_fd *owner;
    xt_32      id;
    sfx_page   **pages;
    sfx_page   **pages_prealloc;
    xt_u64     addr;
    xt_16      count;      //once count dwon to zero, free pages.
    xt_32      type:2;     //0:user; 1: kernel
    xt_32      prealloc:1; //1:prealloc for splitted token
    xt_32      rsvd:29;
    int        offset;
} sfx_pages_t;

/*
 * For edl page management.
 */
struct pg_mgr
{
    struct sfx_list_head free_pages_list;
    struct sfx_list_head corrupt_list;
    sfx_spinlock_t  pages_list_lock;
    xt_u32    pages_free_slots;       /* initialize at MAX_SLOTS */
    sfx_pages_t pages_list[MAX_SLOTS];
    xt_u64    mem_locked_counter;
    xt_u64    mem_unlocked_counter;
    xt_u32 unlock_tries;
    xt_32  initDone;
};

typedef struct
{
    xt_u8                           family[3];
    xt_u8                           board_type[2];
    xt_u8                           FPGA[1];
    xt_u8                           flash_type[1];
    xt_u8                           capacity[3];
    xt_u8                           revision[2];
    xt_u8                           status[1];
} __attribute__((packed)) opn_info;

/*
 * Represents an NVM Express device.  Each sfx_dev is a PCI function.
 */
struct sfx_dev
{
    struct sfx_list_head            node;
    struct sfx_queue sfx__rcu       **queues;
    sfx_iomem                       dbs;
    struct sfx_dma_pool             *prp_page_pool;
    struct sfx_dma_pool             *prp_small_pool;
    struct sfx_list_head            inject_list;
    struct sfx_list_head            errobj_list;
    xt_64                           last_time;          // previous inject time, for frequency control
    sfx_spinlock_t                  inject_lock;
    sfx_spinlock_t                  errobj_lock;
    sfx_spinlock_t                  i2c_lock;
    xt_32                           instance;
    xt_u32                          queue_count;
    xt_u32                          ioqueue_count;
    xt_u32                          online_queues;
    xt_u32                          max_qid;
    xt_32                           q_depth;
    xt_u32                          db_stride;
    xt_u32                          ctrl_config;
    sfx_msix_entry                  *entry;
    struct nvme_bar sfx__iomem      *bar;
    struct sfx_kref                 kref;
    sfx_work_func_t                 reset_workfn;
    struct sfx_work_struct          reset_work;
    struct sfx_work_struct          cpu_work;
    // May need to adjust the following two data structures later on
    struct sfx_stats                sfx_stats;          // sfx dev related statistics
    struct sfx_cntrs                sfx_cntrs;          // sfx dev related counters
    sfx_spinlock_t                  indirect_reg_lock;  // lock for indirect reg access
    sfx_board_nand_type             card_info;
    struct pg_mgr                   page_mgr;           // will allocate dynamically later on
    xt_u8                           device_gone;            // surprise removal
    xt_u8                           dev_gone_notified;
    void                            *test_mem;
    bd_param_t                      *sfx_bd_param;      // parameters to pass to block device driver
    void                            *os_ctrlr;
    sfx_dma_addr_t                  test_dma_addr;
    xt_u32                          stripe_size;
    xt_32                           init_err;
    xt_32                           init_fatal_err;
    xt_32                           vecnt;
    xt_32                           cp;                 // for debugging purpose from ccs
    struct sfx_miscdevice           miscdev;
    struct sfx_pci_dev              *pci_dev;
    struct sfx_notifier_block       sfx_nb;             // for sfx cpu notifier
    sfx_heap_id                     sfx_bd_heap1;
    xt_u32                          sfx_bd_heap1_size;
    sfx_heap_id                     sfx_bd_heap2;
    xt_u32                          sfx_bd_heap2_size;
    xt_u16                          oncs;
    xt_u16                          abort_limit;
    int                             numa_node;
    char                            name[12];
    char                            serial[20];
    char                            model[40];
    char                            firmware_rev[9];
    char                            devfname[16];
    xt_u8                           opn[OPNSZ + 1];
    xt_u8                           to_clean;
    xt_u8                           initialized;
    xt_u8                           goldimg;
    xt_u8                           comp_only;
    xt_u8                           fw_act_mode;
    xt_u8                           ledactoset;
    xt_u8                           probe_cnt_limit;
    xt_u8                           force_probe;
    xt_u8                           inject_active;
    xt_u8							fail_flg;		//hotreset fail flg
    xt_u32                          probe_cnt;
    xt_u32                          nor_sw; /* SW starting area in NOR */
    xt_u32                          sn_start_addr;
    sfx_bool                        init_msg_store;                 // At most 16 * 8 * 3 = 384 byte to store
    unsigned char                   fail_reset_store[400];          // reset result store
    unsigned char                   fail_drive_strength_store[400]; // drive strength change store
    unsigned char                   fail_en_diffmode_store[400];    // enable differential mode store
    unsigned char                   fail_switch_ddr_store[400];     // switch nand ddr2 timing mode store
    //-------------------------------------------------------------------------
    // WARNING: Keep the "cpumask" member as the LAST in this struct!!!
    // This member could have varying sizes from kernel to kernel,
    // based on the value of CONFIG_NR_CPUS kernel config macro.
    //-------------------------------------------------------------------------
    ftl_mq_ctx                      ftl_mq_ctx;
    sfx_atomic_t					blk_ref_cnt;	//count of opened sfx_bd for this mdrv
    xt_u8							force_ida_release;	//force release ida_instance
    sfx_cpumask_var_t               msix_requested;
    sfx_atomic_t                    nvme_fw_download;
    xt_u32                          fw_saddr;
    struct sfx_kobject              *block_kobj;
    xt_u32                          totalLifeCount;
    xt_u32                          lifeACount;
    sfx_mutex_t                     nor_sw_lock;
    xt_u32							keep_disk;		//keep blk disk not del when remove sfx_bd_dev
    xt_u32							nor_dump_sector;
};

// Similar to SFX_CHECK_NVME_STATUS, but shorter, use 128, instead of 256
#define STATUS_Q_DEPTH  128
// #define USE_CCS_NID

typedef struct
{
    xt_u32  status; //reserved
    xt_u32  cq_len;
    SFX_NVME_CMD_RESULT cpl[STATUS_Q_DEPTH];
} sfx_check_status_cmd_t;

#ifdef USE_KTIME_CTX
typedef struct {
    xt_u32 status;     /* reserved */
    xt_u32 qcnt;
    SFX_NVME_QSTATS q_stats[NUM_MAXQ];
} sfx_get_qstats_cmd_t;
#endif

/*
 * The sfx_fd describes the data specific for each dev_open,
 * so that we could have multiple device sharing same device.
 */
struct sfx_fd
{
    struct sfx_list_head            node;
    struct sfx_list_head            lockmem_list;
    struct sfx_dev                  *dev;
    sfx_check_status_cmd_t          _status;
    sfx_atomic_t                    mem_locked;
    sfx_atomic_t                    mem_unlocked;
#ifdef USE_KTIME_CTX
    sfx_get_qstats_cmd_t            _qstats;
#endif
};

/*
 * For random error injection
 */
typedef struct sfx_errorinject_obj
{
    struct sfx_list_head            list;
    xt_64                           pba;
    xt_32                           blk;
    xt_32                           page;
    xt_32                           attempt;
} sfx_errorinject_obj_t;

/*
 * Error injection list element
 */
struct sfx_errinj_listelem
{
    struct sfx_list_head            list;
    struct sfx_errorinject_cmd      cmd;
};

struct bd_probe
{
        struct sfx_dev    *dev;
        struct sfx_driver *drv;
};

struct nor_sw_probe
{
    xt_u32 hdr;
    xt_u32 count;
    xt_u32 rsv;
    xt_u32 sum;
};

typedef struct nor_sw_lifecnt
{
    xt_u32 hdr;
    xt_u32 totalLifeCount;
    xt_u32 lifeACount;
    xt_u32 sum;
} nor_sw_lifecnt_t;

typedef struct nor_sw_lifecnt_dual
{
    nor_sw_lifecnt_t alpha;
    nor_sw_lifecnt_t beta;
} nor_sw_lifecnt_dual_t;

static inline xt_u32 nor_sw_probe_checksum_comp(struct nor_sw_probe *ps)
{
    xt_u8 *p = (xt_u8 *)ps;
    int i;
    xt_u32 sum = 0;

    for (i = 0; i < (sizeof(struct nor_sw_probe) - sizeof(xt_u32)); i++) {
        sum += *p++;
    }
    return sum;
}

#define SW_PROBECNT_READ_RD_ERR             0xfffffffe
#define SW_PROBECNT_READ_SUM_ERR            0xfffffffd

static inline int nor_sw_probecnt_read(struct sfx_dev *dev, xt_u32 *count)
{
    struct nor_sw_probe probe = {0, 0, 0, 0};

//    sfx_spin_lock(&dev->nor_sw_lock);
    if (sfxdriver_nor_flash_read(dev,
        dev->nor_sw + NOR_IDENTITY_SW_PROBECNT_OFFSET,
        sizeof(struct nor_sw_probe), (xt_u32 *)&probe)) {
        sfx_pr_err("%s: %s sfxdriver_nor_flash_read failed\n", __FUNCTION__, dev->name);
        *count = SW_PROBECNT_READ_RD_ERR;
//        sfx_spin_unlock(&dev->nor_sw_lock);
        return -EFAULT;
    } else {
        if (probe.count != 0xffffffff) {
            xt_u32 sum = 0;

            sum = nor_sw_probe_checksum_comp(&probe);
            if (probe.sum != sum) {
                sfx_pr_err("%s: %s, probe.sum 0x%x != cal. sum 0x%x\n", __FUNCTION__, dev->name, probe.sum, sum);
                sfx_pr_info("probe: %08x %08x %08x %08x\n", probe.hdr, probe.count, probe.rsv, probe.sum);
                *count = SW_PROBECNT_READ_SUM_ERR;
//                sfx_spin_unlock(&dev->nor_sw_lock);
                return -EFAULT;
            }
        }
        *count = probe.count;
    }
//    sfx_spin_unlock(&dev->nor_sw_lock);
    return 0;
}

static inline xt_u32 nor_sw_lifecnt_checksum_comp(nor_sw_lifecnt_t *ps)
{
    xt_u8 *p = (xt_u8 *)ps;
    int i;
    xt_u32 sum = 0;

    for (i = 0; i < (sizeof(nor_sw_lifecnt_t) - sizeof(xt_u32)); i++) {
        sum += *p++;
    }
    return sum;
}

#define SW_LIFECNT_READ_RD_ERR  0xfffffffe
#define SW_LIFECNT_READ_SUM_ERR 0xfffffffd
static inline int nor_sw_lifecnt_read(struct sfx_dev *dev, xt_u32 *totalCnt, xt_u32 *aCnt)
{
    nor_sw_lifecnt_dual_t life_dual= {{0, 0, 0, 0},{0, 0, 0, 0}};
    nor_sw_lifecnt_t life_tmp = {0, 0, 0, 0};
    xt_u8 valid = 0;
    int backupIndex;

    // Since there are two copy in the same sub sector,
    // when they are different, use the one valid and with larger totalLifeCount

    // Since there are two backup in two sub sectors,
    // when they are different, use the one valid and with larger totalLifeCount

//    sfx_spin_lock(&dev->nor_sw_lock);
    for (backupIndex = 1; backupIndex <= 2; backupIndex++) {
        if (sfxdriver_nor_flash_read(dev,
                dev->nor_sw + NOR_IDENTITY_SW_LIFECNT_OFFSET * backupIndex,
                sizeof(nor_sw_lifecnt_dual_t), (xt_u32 *)&life_dual)) {
            sfx_pr_err("%s: %s sfxdriver_nor_flash_read failed at offset: 0x%x\n",
                __FUNCTION__, dev->name,
                dev->nor_sw + NOR_IDENTITY_SW_LIFECNT_OFFSET * backupIndex);
            if (backupIndex == 1)
                goto backup;
            *totalCnt = SW_LIFECNT_READ_RD_ERR;
            *aCnt = SW_LIFECNT_READ_RD_ERR;
//            sfx_spin_unlock(&dev->nor_sw_lock);
            return -EFAULT;
        } else {
            if (life_dual.alpha.totalLifeCount != 0xffffffff &&
                    life_dual.alpha.lifeACount != 0xffffffff) {
                xt_u32 sum = 0;
                sum = nor_sw_lifecnt_checksum_comp(&(life_dual.alpha));
                if (life_dual.alpha.sum != sum) {
                    sfx_pr_err("%s: %s, life alpha.sum 0x%x != cal.sum 0x%x,"
                        " backup index: %d\n",
                        __FUNCTION__, dev->name, life_dual.alpha.sum, sum,
                        backupIndex);
                    sfx_pr_info("life alpha: %08x %08x %08x %08x,"
                        "backup index: %d\n",
                        life_dual.alpha.hdr, life_dual.alpha.totalLifeCount,
                        life_dual.alpha.lifeACount, life_dual.alpha.sum,
                        backupIndex);
                } else {
                    valid = 1;
                    if (life_dual.beta.totalLifeCount > life_tmp.totalLifeCount)
                        life_tmp = life_dual.alpha;
                }
            }
            if (life_dual.beta.totalLifeCount != 0xffffffff &&
                    life_dual.beta.lifeACount != 0xffffffff) {
                xt_u32 sum = 0;
                sum = nor_sw_lifecnt_checksum_comp(&(life_dual.beta));
                if (life_dual.beta.sum != sum) {
                    sfx_pr_err("%s: %s, life beta.sum 0x%x != cal.sum 0x%x"
                        " backup index: %d\n",
                        __FUNCTION__, dev->name, life_dual.beta.sum, sum,
                        backupIndex);
                    sfx_pr_info("life beta: %08x %08x %08x %08x,"
                        " backup index: %d\n",
                        life_dual.beta.hdr, life_dual.beta.totalLifeCount,
                        life_dual.beta.lifeACount, life_dual.beta.sum,
                        backupIndex);
                } else {
                    valid = 1;
                    if (life_dual.beta.totalLifeCount > life_tmp.totalLifeCount)
                        life_tmp = life_dual.beta;
                }
            }
        }
backup: ;
    }
    if (valid) {
        *totalCnt = life_tmp.totalLifeCount;
        *aCnt = life_tmp.lifeACount;
    } else {
        *totalCnt = SW_LIFECNT_READ_SUM_ERR;
        *aCnt = SW_LIFECNT_READ_SUM_ERR;
//        sfx_spin_unlock(&dev->nor_sw_lock);
        return -EFAULT;
    }
//    sfx_spin_unlock(&dev->nor_sw_lock);
    return NO_ERROR;
}

extern unsigned char admin_timeout;
extern sfx_rwlock_t dev_list_lock;
extern struct sfx_list_head dev_list;
extern struct sfx_list_head fail_list;
extern sfx_rwlock_t driver_list_lock;
extern struct sfx_list_head driver_list;
extern sfx_atomic_t s_dev_cnt;
extern sfx_atomic_t bd_probe_cnt;
extern xt_u32 in_crashdump;
extern xt_32 cqe_single_process;
extern xt_32 msix_disable;
extern int in_hotreset;

xt_32 sfx_submit_cmd(struct sfx_queue *nvmeq, struct nvme_command *cmd);
sfx_irqreturn_t sfx_irq(xt_32 irq, void *data);
xt_32 sfx_submit_admin_cmd(struct sfx_dev *dev, struct nvme_command *cmd, xt_u32 *result);
xt_32 adapter_delete_cq(struct sfx_dev *dev, xt_u16 cqid);
xt_32 adapter_delete_sq(struct sfx_dev *dev, xt_u16 sqid);
xt_32 sfx_submit_nvme_io(struct sfx_fd *fd, struct sfx_userio_cmd *io, sfx_bool sync, sfx_bool from_kernel);
xt_32 sfx_process_cq(void *ctx, xt_32 lock_need, xt_u32 cmpl_target);
void sfx_create_io_queues(struct sfx_dev *dev);

void sfx_disable_queue(struct sfx_dev *dev, xt_32 qid);
void sfx_clear_queue(struct sfx_queue *nvmeq);
xt_32 sfx_delete_cq(struct sfx_queue *nvmeq);
xt_32 adapter_async_del_queue(struct sfx_queue *nvmeq, xt_u8 opcode, sfx_work_func_t fn);
xt_32 sfx_configure_admin_queue(struct sfx_dev *dev);
void sfx_init_queue(struct sfx_queue *nvmeq, xt_u16 qid);
sfx_bool nvme_cqe_valid(struct sfx_queue *q, xt_u16 head, xt_u16 phase);

struct sfx_queue *lock_nvmeq(struct sfx_dev *dev, xt_32 q_idx) sfx__acquires(RCU);
void unlock_nvmeq(struct sfx_queue *nvmeq) sfx__releases(RCU);
struct sfx_queue *raw_nvmeq(struct sfx_dev *dev, xt_32 qid);
xt_32 queue_request_irq(struct sfx_dev *dev, struct sfx_queue *nvmeq, const char *name);
xt_32 sfx_assign_interrupts(struct sfx_dev *dev);
xt_32 sfx_delete_sq(struct sfx_queue *nvmeq);
void sfx_del_queue_start(struct sfx_work_struct *work);
struct sfx_delq_ctx *sfx_get_dq(struct sfx_delq_ctx *dq);
xt_32 sfx_disable_ctrl(struct sfx_dev *dev, xt_u64 cap);
xt_32 sfx_enable_ctrl(struct sfx_dev *dev, xt_u64 cap);
xt_32 sfx_shutdown_ctrl(struct sfx_dev *dev);
void sfx_trigger_powerfailure(struct sfx_dev *dev);

struct sfx_iod *sfx_map_kernel_pages(struct sfx_dev *dev, int write, unsigned long addr, unsigned length);
int sfx_setup_prps(struct sfx_dev *dev, struct sfx_iod *iod, int total_len, sfx_gfp_t gfp);
void sfx_free_iod(struct sfx_dev *dev, struct sfx_iod *iod);
xt_u32 fis_direct_read32(void *bar, xt_u32 addr);
xt_u32 fis_indirect_read32(struct sfx_dev *dev, void *bar, xt_u32 addr);
void fis_indirect_write32(struct sfx_dev *dev, void *bar, xt_u32 addr, xt_u32 value);
void sfxdriver_vu_get_feat_data(struct sfx_dev *dev, xt_u32 *feat_data);

int sfx_wait_ready(struct sfx_dev *dev, xt_u64 cap, sfx_bool enabled);
int sfx_get_user_pages_fast(xt_u64 addr, xt_32 count, xt_32 write, sfx_page **p);

void * sfx_dma_alloc_coherent(struct sfx_dev *dev, sfx_size_t size, sfx_dma_addr_t *handle,sfx_gfp_t flag);
void sfx_dma_free_coherent(struct sfx_dev *dev, sfx_size_t size, void *vaddr, sfx_dma_addr_t dma_handle);
void * sfx_get_dmadev(struct sfx_dev *dev);

void *sfx_kzalloc_node(struct sfx_dev *dev, sfx_size_t size, sfx_gfp_t flags);

//todo:
xt_32 sfx_suspend_queue(struct sfx_queue *nvmeq);
extern struct task_struct *sfx_thread;

sfx_pages_t *sfx_get_page_info_from_index(struct sfx_dev *dev, sfx_ssize_t index);

void sfx_dev_info(struct sfx_dev *dev);
int sfx_init_card(struct sfx_dev *dev);
int sfx_page_list_init(struct sfx_dev *dev);
int sfx_get_vector(struct sfx_queue *nvmeq);
void sfx_free_queue_common(struct sfx_queue *nvmeq);
void sfx_free_queue(struct sfx_rcu_head *r);
void sfx_free_queues(struct sfx_dev *dev, int lowest);
void ccs_clean_nvme_sq(struct sfx_dev *dev, struct sfx_driver *drv);


void *sfx_alloc_nvmeq(void *sfx_driver_handle, struct sfx_driver_nvmeq_ctx *init_ctx, ftl_cmpl_cb cb);
int sfx_make_bd_parameter(struct sfx_dev *dev);
int sfx_proc_stats_show(struct sfx_seq_file *m, void *v);
int sfx_proc_hw_qlists_show(struct sfx_seq_file *m, void *v);
int sfx_proc_cmdraw_qlists_show(struct sfx_seq_file *m, void *v);
xt_u32 sfx_get_page_ctr_val(struct sfx_dev *dev, int locked);
void sfx_dev_list_remove(struct sfx_dev *dev);
struct sfx_iod * sfx_alloc_iod(unsigned nseg, unsigned nbytes, sfx_gfp_t gfp);
struct sfx_iod *sfx_map_user_pages_post_ex(struct sfx_dev *dev, int write,
                unsigned long addr, unsigned length, struct sfx_iod *iod);
struct sfx_iod *sfx_map_user_pages_ex(struct sfx_dev *dev, int write,
                unsigned long addr, unsigned length, struct sfx_iod *iod);
struct sfx_iod *sfx_map_kernel_pages_ex(struct sfx_dev *dev, int write, unsigned long addr, unsigned length, struct sfx_iod *iod);
int sfx_user_check_status(struct sfx_fd *fd);
int sfx_user_check_q_status(struct sfx_fd *fd);
#ifdef USE_KTIME_CTX
int sfx_user_get_qstats(struct sfx_fd *fd);
#endif
int ccs_reg_dump(struct sfx_dev *dev, void *ibuf, void *ibuf_end);
int sfx_driver_probe(struct sfx_driver *sdrv, struct sfx_dev *sdev);
void sfx_driver_remove(struct sfx_dev *sdev);
void sfx_driver_shutdown(struct sfx_dev *sdev);
xt_u32 sfx_kernel_get_nvmeq_head(struct sfx_fd *fd, xt_u32 qid);
xt_u32 sfx_kernel_get_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid);
xt_u32 sfx_kernel_get_nvmeq_depth(struct sfx_fd *fd, xt_u32 qid);
int sfx_kernel_set_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid, xt_u32 tail);
int sfx_kernel_nvmeq_reset(struct sfx_fd *fd, xt_u32 qid);
void *sfx_dma_alloc(struct sfx_dev *dev, sfx_size_t size, sfx_dma_addr_t *handle);
void sfx_dma_free(struct sfx_dev *dev, sfx_size_t size, void *vaddr, sfx_dma_addr_t dma_handle);
int sfx_alloc_prps(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo);
void sfx_free_prps(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo);
#ifdef SG_PREALLOC
void *sfx_alloc_sgarray(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo);
void sfx_free_sgarray(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo);
#endif
xt_u32 sfx_get_fakeresult(struct sfx_dev *dev, struct sfx_userio_cmd *io, int *ret);
void sfx_remove_injection(struct sfx_dev *dev);
xt_u32 get_pci_bar_csts(struct sfx_dev *dev);
xt_u32 check_device_gone(struct sfx_dev* dev);

int sfx_get_free_slot(struct sfx_dev *dev, xt_u32 *nfslot);
void sfx_length_one_sgl(struct sfx_dev *dev, xt_u32 *vaddr, xt_u32 *list, xt_u32 len, xt_u8 *mask, void *prd_buff);
int sfx_set_pagelist(struct sfx_fd *fd, sfx_page **list, void **token, xt_u32 count, int type, int offset);
xt_u32 sfx_create_sgl(struct sfx_fd *fd, xt_u32 *vaddr, xt_u32 *list, xt_u32 len, xt_u8 *mask, void *prd_buff, void **token, sfx_bool from_kernel);
int sfx_delete_sgl(struct sfx_fd *fd, void *token);
void *sfx_map_user_pages_simple(struct sfx_fd *fd, unsigned long addr, xt_u32 count);
int sfx_unmap_user_pages_simple(struct sfx_fd *fd, sfx_pages_t *p);
void sfx_dev_reset(struct sfx_dev *dev);
void sfx_dev_hotreset(struct sfx_dev *dev);
void sfx_hotreset_rm_ctrl(struct sfx_dev *dev, char *when);
void sfx_hotreset_q_failed_ctrl(struct sfx_dev *dev, char *when);
void sfx_stop_threads(void);
void sfx_start_threads(void);
int write_nor_sw_probecnt(struct sfx_dev *dev, xt_u32 value);
int sfx_pre_probe(struct sfx_dev *device);
void sfx_post_probe(struct sfx_dev *device);
void *free_cmdid(struct sfx_queue *nvmeq, int cmdid, sfx_completion_fn *fn);
int match_dev_list(struct sfx_dev *device);
int match_fail_list(struct sfx_dev *device);
int write_nor_sw_lifecnt(struct sfx_dev *dev, xt_u32 totalCnt, xt_u32 aCnt);
int sfx_fw_nor_dump_ctrl(struct sfx_dev *sdev, int enable);

#endif // __SFXDRIVER_COMMON_H__
