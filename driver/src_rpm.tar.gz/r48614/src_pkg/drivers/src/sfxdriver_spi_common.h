// -----------------------------------------------------------------------------
//
// Copyright 2017 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfxdriver_spi_common.h
//
// -----------------------------------------------------------------------------

#ifndef __SFXDRIVER_SPI_COMMON_H__
#define __SFXDRIVER_SPI_COMMON_H__

// Arundina Registers
#define EPCQ_ENABLE_ADDR  0x001000c0
#define dev_feature       0x00100054
#define spi_base_addr     0x00100200
#define spi_srr           spi_base_addr+0x40 // Reset
#define spi_spicr         spi_base_addr+0x60 // SPI Control
#define spi_spisr         spi_base_addr+0x64 // SPI Status
#define spi_spidtr        spi_base_addr+0x68 // SPI Data Transmit
#define spi_spidrr        spi_base_addr+0x6C // SPI Data Receive
#define spi_spissr        spi_base_addr+0x70 // SPI Slave Select
#define spi_spitfo        spi_base_addr+0x74 // Transmit FIFO Occupancy; # of entries-1
#define spi_spirfo        spi_base_addr+0x78 // Receive FIFO Occupancy; # of entries-1
#define spi_dgier         spi_base_addr+0x1C // Device Global Interrrupt Enable
#define spi_ipisr         spi_base_addr+0x20 // IP Interrupts Status
#define spi_ipier         spi_base_addr+0x28 // IP Interrupts Enable
#define spi_spidtr_4B     spi_base_addr+0x68+0x80 // SPI Data Transmit; Write 4B
#define spi_spidrr_4B     spi_base_addr+0x6C+0x80 // SPI Data Receive; Write 4B

// SPICR
// [9]: LSB First
// [8]: Master Transcation Inhibit; 0: Master Transcation enabled; 1:  Master Transcation disabled
// [7]: Manual Slave Select
// [6]: TX FIFO Reset
// [5]: RX FIFO Reset
// [4]: CPHA; Clock phase
// [3]: CPOL; 0: Active high clock; 1: Active low clock
// [2]: Master; 0: Slave; 1: Master
// [1]: SPE; SPI system Enable
// [0]: LOOP

// Interrupts
// [13]: Command Error
// [12]: Loopback Error
// [11]: MSB Error
// [10]: Slave Mode Error
// [ 9]: CPOL_CPHA Error
// [ 8]: DRR_Not_Empty (Date Receive Register/FIFO Not Empty)
// [ 7]: Slave_Select Mode
// [ 6]: TX FIFO Half Empty
// [ 5]: DRR Overturn
// [ 4]: DRR Full
// [ 3]: DTR Underturn
// [ 2]: DTR Empty
// [ 1]: Slave MODF
// [ 0]: MODF (Mode Fault Error)

#define FIFO_DEPTH       256
#define BYTE_PER_SECTOR  65536
#define BYTE_PER_SUBSECTOR  4096
// Micron Flash Commands
// ==============================================================================================
// Command                 Addr Bytes      Dummy Clocks      Notes
// ==============================================================================================
#define RD_DID                0x9F  // 0            0
#define RD_MDID               0xAF  // 0            0

#define RD_STA_REG            0x05  // 0            0
#define WR_STA_REG            0x01  // 0            0
#define RD_VOL_CFG            0x85  // 0            0
#define RD_EVOL_REG           0x65  // 0            0
#define RD_NONVOL_CFG         0xB5  // 0            0
#define RD_LOCK_REG           0xE8  // 0            0
#define RD_EADDR_REG          0xC8  // 0            0
#define WR_EADDR_REG          0xC5  // 0            0
#define RD_FLAG_REG           0x70  // 0            0
#define CLR_FLAG_REG          0x50  // 0

#define RD                    0x03  // 3(4)         0
#define FAST_RD               0x0B  // 3(4)         8
#define DUAL_O_FAST_RD        0x3B  // 3(4)         8
#define DUAL_IO_FAST_RD       0xBB  // 3(4)         8        Extended dual input fast read
#define QUAD_O_FAST_RD        0x6B  // 3(4)         8
#define QUAD_IO_FAST_RD       0xEB  // 3(4)         8        Extended quad input fast read

#define RD_4B                 0x13  // 4            0
#define FAST_RD_4B            0x0C  // 4            8
#define DUAL_O_FAST_RD_4B     0x3C  // 4            8
#define DUAL_IO_FAST_RD_4B    0xBC  // 4            8
#define QUAD_O_FAST_RD_4B     0x6C  // 4            8
#define QUAD_IO_FAST_RD_4B    0xEC  // 4            8

#define WR_EN                 0x06  // 0
#define WR_DIS                0x04  // 0
#define WR_NONVOL_CFG         0xB1  // 0

#define PAGE_PROG             0x02  // 3(4)
#define DUAL_I_FAST_PROG      0xA2  // 3(4)
#define EXT_DUAL_I_FAST_PROG  0xD2  // 3(4)
#define QUAD_I_FAST_PROG      0x32  // 3(4)
#define EXT_QUAD_I_FAST_PROG  0x38  // 3(4)

#define PAGE_PROG_4B          0x12  // 3(4)                   x
#define QUAD_I_FAST_PROG_4B   0x34  // 3(4)                   x

#define BULK_ERASE            0xC7  // 0
#define ERASE_SUSP            0x75  // 0
#define ERASE_RESU            0x7A  // 0
#define SECT_ERASE            0xD8  // 0                      Works for both 3B & 4B address; 64KB in N25Q 256Mb
#define SECT_ERASE_4B         0xDC  // 0                      x
#define SUBSECT_ERASE_4KB     0x20  // 0                      Works for both 3B & 4B address
#define SUBSECT_ERASE_4KB_4B  0x21  // 0                      x

#define RESET_ENABLE          0x66  // 0
#define RESET_MEMORY          0x99  // 0

#define EN_4B_ADDR            0xB7  // 0
#define EXIT_4B_ADDR          0xE9  // 0

#define ENTER_QUAD            0x35  // 0                      x
#define EXIT_QUAD             0xF5  // 0                      x

#define ERASE_RETRY           0x3
#define WRITE_RETRY           0x3

xt_u32 sfxdriver_spi_init(struct sfx_dev *dev);
xt_u32 sfxdriver_spi_init_read_only(struct sfx_dev *dev);
xt_u32 sfxdriver_NOR_init(struct sfx_dev *dev);
xt_u32 sfxdriver_spi_write_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data) __attribute__ ((unused));
xt_u32 sfxdriver_nor_flash_read(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len, xt_u32 *datao);
xt_u32 sfxdriver_spi_erase_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len) __attribute__ ((unused));
void sfxdriver_spi_exit(struct sfx_dev *dev);
xt_u32 sfxdriver_spi_read_nor_did(struct sfx_dev *dev, xt_u32 len, xt_u32 *datao);
xt_u32 sfxdriver_norsw_erase_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len);

#endif // __SFXDRIVER_SPI_COMMON_H__
