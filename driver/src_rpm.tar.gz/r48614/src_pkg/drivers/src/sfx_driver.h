/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_driver.h
 * ---------------------------------------------------------------------------
 */

#ifndef __SFX_DRIVER_H__
#define __SFX_DRIVER_H__

#include "sfxdriver_common.h"
#include "sfx.h"

#ifdef SFX_LINUX
int sfx_suspend(struct device *dev);
int sfx_resume(struct device *dev);
int sfx_probe(struct pci_dev *pdev, const struct pci_device_id *id);
void sfx_remove(struct pci_dev *pdev);
void sfx_shutdown(struct pci_dev *pdev);
int sfx_dev_open(struct inode *inode, struct file *f);
int sfx_dev_release(struct inode *inode, struct file *f);
long sfx_dev_ioctl(struct file *f, unsigned int cmd, unsigned long arg);
int _sfx_dev_init(void);
void _sfx_dev_exit(void);
#endif

/*
 * page list management function prototype (global based)
 */
long sfx_lock_user_pages(struct sfx_fd *fd, struct sfx_mem_cmd sfx__user *umem );
long sfx_unlock_user_pages(struct sfx_fd *fd, struct sfx_mem_cmd sfx__user *umem );
long sfx_user_split_token(struct sfx_fd *fd, struct sfx_tk_spl_cmd sfx__user *umem);
long sfx_user_split_token_release(struct sfx_fd *fd, struct sfx_tk_spl_cmd sfx__user *umem);
void sfx_unmap_all_pages(struct sfx_fd *fd);
void sfx_page_list_deinit(struct sfx_dev *dev);
xt_u32 sfx_get_page_ctr_val(struct sfx_dev *dev, int locked);
long sfx_driver_user_set_pagelist(struct sfx_fd *fd, struct sfx_driver_user_set_pglist_cmd sfx__user *umem);
int sfx_get_user_freeslot(struct sfx_dev *dev, struct sfx_get_user_freeslot_cmd sfx__user *umem);
#ifdef ENABLE_PAGES_CONTEXT_CLEANUP
void sfx_try_to_cleanup_pages_context(struct sfx_dev *dev, struct sfx_iod *iod);
#else
#define sfx_try_to_cleanup_pages_context(...)
#endif

/*
 * Other Function prototypes
 */
int sfx_submit_sync_cmd(struct sfx_dev *dev, int q_idx, struct nvme_command *cmd, xt_u32 *result, xt_u64 timeout);
void sfx_unmap_user_pages_only(struct sfx_dev *dev, int write, struct sfx_iod *iod);
void sfx_unmap_user_pages(struct sfx_dev *dev, int write, struct sfx_iod *iod);
int sfx_init_card(struct sfx_dev *dev);
int sfx_nand_device_reset(struct sfx_dev *dev, xt_u32 ch, xt_u32 ce);
int sfx_nand_pba_reset(struct sfx_dev *dev, xt_u64 pba, xt_u32 *rp);
void *sfx_alloc_nvmeq(void *sfx_driver_handle, struct sfx_driver_nvmeq_ctx *init_ctx, ftl_cmpl_cb cb);
int sfx_free_nvmeq(void *sfx_driver_handle, xt_u8 qid);
void sfx_dump_driver_counter(void *sfx_driver_handle);
void sfx_compressionq_throttle(void *sfx_driver_handle, int base_qid, int write_val);
void sfx_comp_readq_throttle(void *sfx_driver_handle, int base_qid, int write_val);
void sfx_remove_sysfiles(struct sfx_dev *dev);

#endif // __SFX_DRIVER_H__
