// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfxdriver_firmware.c
//
// ---------------------------------------------------------------------------

#include <linux/bitops.h>
#include <linux/cpu.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kdev_t.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/pci.h>
#include <linux/percpu.h>
#include <linux/poison.h>
#include <linux/ptrace.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/vermagic.h>
#include <linux/utsname.h>
#include <asm/uaccess.h>
#include <linux/pid.h>
#include <linux/random.h>
#include <linux/idr.h>
#include <linux/ktime.h>
#include <linux/hrtimer.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/sched.h>
#include <linux/irq.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/sched/types.h>
#endif

#include "sfx_ioctl.h"
#include "sfx_driver.h"
#include "sfx.h"
#include "sfx_api.h"
#include "osal.h"
#include "sfxdriver_common.h"
#include "sfxdriver_spi_common.h"
#include "sfx_driver.h"
#include "sfxdriver_firmware.h"

#define ONEM 0xfffff
#define BYTE_PER_RW 128
#define REG_BOARD_TYPE 0x10005c
#define IMAGE_START_ADDR_KUS 0x800000
#define IMAGE_START_ADDR_KUSP 0x1000000

int sfx_unlock_fw(struct sfx_dev *dev)
{
	return (int)sfxdriver_spi_init(dev);
}

void sfx_lock_fw(struct sfx_dev *dev)
{
	sfxdriver_spi_exit(dev);
}

xt_u32 sfx_get_fw_start_addr(struct sfx_dev *dev)
{
	int rval;
	xt_u32 saddr;

	rval = fis_indirect_read32(dev, dev->bar, (xt_u32)REG_BOARD_TYPE);
	if ((rval >= 0x20) && (rval < 0x30)) {
		saddr = IMAGE_START_ADDR_KUSP;
		sfx_pr_info("REG_BOARD_TYPE KUSP start addr 0x%x\n", saddr);
	} else {
		saddr = IMAGE_START_ADDR_KUS;
		sfx_pr_info("REG_BOARD_TYPE KUS start addr 0x%x\n", saddr);
	}
	sfx_pr_info("REG_BOARD_TYPE KUSP start addr 0x%x\n", saddr);
	return saddr;
}

int sfx_download_fw(struct sfx_dev *dev, xt_u32 offset_in, xt_u32 xfer_len, void *ibuf)
{
	xt_u32 *bufp, offset, ret = 0;
	int i, n, res, xl;

	if (!offset_in) {
		sfx_pr_info("%s: fw-download starts\n", __FUNCTION__);
	} else if (!(offset_in & ONEM)) {
		sfx_pr_info("%s: 0x%x written\n", __FUNCTION__, offset_in);
	}

	offset = dev->fw_saddr + offset_in;

	if ((ret = sfxdriver_spi_erase_data(dev, offset, xfer_len))) {
		if (ret != 4) {
			sfx_pr_info("%s: sfxdriver_spi_erase_data() returns %u\n", __FUNCTION__, ret);
			return ret;
		} // else ignore alignment error to support xfer_len less than 64k.
	}

	n = xfer_len / BYTE_PER_RW;
	if ((res = xfer_len % BYTE_PER_RW)) {
		n++;
	}
	bufp = (xt_u32 *)ibuf;
	xl = BYTE_PER_RW;
	for (i = 0; i < n; i++) {
		if (i == n - 1 && res) {
			xl = res;
		}
		if ((ret = sfxdriver_spi_write_data(dev, offset, xl, bufp))) {
			sfx_pr_info("%s: sfxdriver_spi_write_data() returns %u offset 0x%x xl 0x%x\n",
				    __FUNCTION__, ret, offset, xl);
			return ret;
		}
		bufp += xl / 4;
		offset += xl;
	}
	return ret;
}

int sfx_verify_fw(struct sfx_dev *dev, xt_u32 offset_in, xt_u32 xfer_len, void *wbufp)
{
	char *wbuf = NULL;
	xt_u32 offset, ret = 0;
	int i, j, n, res, xl;
	xt_u32 rbuf[BYTE_PER_RW >> 2];

	if (!offset_in) {
		sfx_pr_info("%s: fw-verify starts\n", __FUNCTION__);
	} else if (!(offset_in & ONEM)) {
		sfx_pr_info("%s: 0x%x verified\n", __FUNCTION__, offset_in);
	}

	offset = dev->fw_saddr + offset_in;

	n = xfer_len / BYTE_PER_RW;
	if ((res = xfer_len % BYTE_PER_RW)) {
		n++;
	}
	wbuf = (char *)wbufp;
	xl = BYTE_PER_RW;
	for (i = 0; i < n; i++) {
		if (i == n - 1 && res) {
			xl = res;
		}
		if ((ret = sfxdriver_nor_flash_read(dev, offset, xl, rbuf))) {
			sfx_pr_info("%s: sfxdriver_spi_nor_flash_read() returns %u offset 0x%x xl 0x%x\n",
				    __FUNCTION__, ret, offset, xl);
			return ret;
		}
		{
			char *wp = (char *)wbuf;
			char *rp = (char *)rbuf;
			for (j = 0; j < xl; wp++, rp++, j++) {
				if (*wp != *rp) {
					sfx_pr_info("%s: Compare failed at %d, wp 0x%x rp 0x%x\n",
						    __FUNCTION__, offset + j, *wp, *rp);
					return -1;
				}
			}
		}
		wbuf += xl;
		offset += xl;
	}
	return ret;
}

int sfx_nvme_download_fw(struct sfx_dev *dev, void *addr, xt_u32 offset, int data_len)
{
	int ret = NO_ERROR;
	int tlen = 0, dlen = 0, i = 0;
	void *tmp_mem = NULL;
	xt_u64 retval;

	if (!capable(CAP_SYS_ADMIN))
		return -EACCES;
	if (!sfx_atomic_dec_and_test(&dev->nvme_fw_download))
		return -EBUSY;
	tlen = data_len;

#define FWMEMSZ 0x20000
	if (!(tmp_mem = sfx_malloc(FWMEMSZ))) {
		sfx_pr_err("%s: sfx_malloc %u failed\n", __FUNCTION__, FWMEMSZ);
		sfx_atomic_set(&dev->nvme_fw_download, 1);
		return -ENOMEM;
	}
	//disable nor dump when do fw download
	sfx_fw_nor_dump_ctrl(dev, 0);
	sfx_mutex_lock(&dev->nor_sw_lock);
	if (sfx_unlock_fw(dev)) {
		sfx_mutex_unlock(&dev->nor_sw_lock);
		sfx_fw_nor_dump_ctrl(dev, 1);
		sfx_pr_err("%s: sfx_unlock_fw failed, tlen %u addr %p offset %u, return -EFAULT\n",
			   __FUNCTION__, tlen, addr, offset);
		kfree(tmp_mem);
		sfx_atomic_set(&dev->nvme_fw_download, 1);
		return -EFAULT;
	}

	while (tlen > 0) {
		dlen = min_t(int, tlen, FWMEMSZ);
		if ((retval = copy_from_user(tmp_mem, addr, dlen))) {
			sfx_mutex_unlock(&dev->nor_sw_lock);
			sfx_pr_err("%s: copy_from_user() returns %d, i %d tlen %u addr %p offset %u\n",
				   __FUNCTION__, retval, i, tlen, addr, offset);
			kfree(tmp_mem);
			sfx_fw_nor_dump_ctrl(dev, 1);
			sfx_atomic_set(&dev->nvme_fw_download, 1);
			return -1;
		}
		if ((retval = sfx_download_fw(dev, offset, dlen, tmp_mem))) {
			sfx_pr_info("%s: sfx_download_fw() returns %d, i %d tlen %u addr %p offset %u\n",
				    __FUNCTION__, retval, i, tlen, addr, offset);
			ret = -1;
			break;
		}
		if ((retval = sfx_verify_fw(dev, offset, dlen, tmp_mem))) {
			sfx_pr_info("%s: sfx_verify_fw() returns %d, i %d tlen %u addr %p offset %u\n",
				    __FUNCTION__, retval, i, tlen, addr, offset);
			{ /* Retry 3 times */
				int r1 = 0, r2 = 0;
				while ((r1 + r2) < 3) {
					retval = sfx_download_fw(dev, offset, dlen, tmp_mem);
					if (!retval) {
						retval = sfx_verify_fw(dev, offset, dlen, tmp_mem);
						if (!retval) {
							sfx_pr_info(
								"%s: sfx_verify_fw() succeeded %d,"
								"r1 %d r2 %d tlen %u addr %p offset %u break\n",
								__FUNCTION__, retval, r1, r2, tlen, addr,
								offset);
							break;
						} else {
							sfx_pr_info("%s: sfx_verify_fw() returns %d,"
								    "r1 %d r2 %d tlen %u addr %p offset %u\n",
								    __FUNCTION__, retval, r1, r2, tlen, addr,
								    offset);
							r2++;
						}
					} else {
						sfx_pr_info("%s: sfx_download_fw() returns %d,"
							    "r1 %d r2 %d tlen %u addr %p offset %u\n",
							    __FUNCTION__, retval, r1, r2, tlen, addr, offset);
						r1++;
					}
				}
			}
			if (retval) {
				sfx_pr_err("%s: Retry failed %d returned\n", __FUNCTION__, retval);
				ret = -1;
				break;
			}
		}
		addr += dlen;
		offset += dlen;
		tlen -= dlen;
		i++;
	}
	sfx_lock_fw(dev);
	sfx_mutex_unlock(&dev->nor_sw_lock);
	sfx_fw_nor_dump_ctrl(dev, 1);
	kfree(tmp_mem);
	sfx_atomic_set(&dev->nvme_fw_download, 1);
	return ret;
}

void sfx_init_fw(struct sfx_dev *dev)
{
	dev->fw_saddr = sfx_get_fw_start_addr(dev);
	sfx_atomic_set(&dev->nvme_fw_download, 1);
}
