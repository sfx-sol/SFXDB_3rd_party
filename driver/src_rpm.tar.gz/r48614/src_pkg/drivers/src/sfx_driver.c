/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 * Copyright (c) 2011-2014, Intel Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_driver.c
 * ---------------------------------------------------------------------------
 */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/bitops.h>
#include <linux/cpu.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/kdev_t.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/pci.h>
#include <linux/percpu.h>
#include <linux/poison.h>
#include <linux/ptrace.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/vermagic.h>
#include <linux/utsname.h>
#include <asm/uaccess.h>
#include <linux/pid.h>
#include <linux/random.h>
#include <linux/idr.h>
#include <linux/ktime.h>
#include <linux/hrtimer.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/sched.h>
#include <linux/irq.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/sched/types.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 10, 0)
#include <linux/blk-mq.h>
#endif

#include "sfx_driver.h"
#include "sfx_ioctl.h"
#include "uapi_nvme.h"
#include "sfxdriver_firmware.h"

#define DEV_FILE_NAME_prefix "/dev/sfx"
#define IOD_TIMEOUT (retry_time * SFX_HZ)

#define SFX_DEBUG_CQ_LIST (1 << 0)
#define SFX_DEBUG_SUBMIT (1 << 1)

#ifndef topology_thread_cpumask
#define topology_thread_cpumask(cpu) cpumask_of(cpu)
#endif

#if 1
#define F_ENTER
#define F_LEAVE
#else
#define F_ENTER sfx_pr_info("+++ %s[%5d]:Enter +++\n", __FUNCTION__, __LINE__)
#define F_LEAVE sfx_pr_info("--- %s[%5d]:Exit  ---\n", __FUNCTION__, __LINE__)
#endif

#define F_TRACE sfx_pr_info("--- %s[%5d]: ===>\n", __FUNCTION__, __LINE__)
#define F_TRACE_QUEUE                                                                                  \
	sfx_pr_info("--- %s[%5d]: == qid=%d==============================>\n", __FUNCTION__, __LINE__, \
		    nvmeq->qid)

static unsigned int debug_flag_poll = 0;
static unsigned char retry_time = 30;
module_param(retry_time, byte, 0644);
MODULE_PARM_DESC(retry_time, "time in seconds to retry failed I/O");

#ifdef SFX_DRIVER_REGISTER_BLKDEV
static int sfx_major;
module_param(sfx_major, int, 0);
#endif

static int use_threaded_interrupts;
module_param(use_threaded_interrupts, int, 0);

static char *bar0;
module_param(bar0, charp, 0);
MODULE_PARM_DESC(bar0, "BAR0 Address for manual recover(hexadecimal),only lower-32bit");

static int use_intx = 0;
module_param(use_intx, int, 0);

int in_hotreset = 0;

/* static int use_set_irq_affinity = 1; */
/* module_param(use_set_irq_affinity, int, 0); */
/* MODULE_PARM_DESC(use_set_irq_affinity, "set irq affinity to assign CPU per IRQ evenly"); */

static int interrupt_coalescing_param;
module_param(interrupt_coalescing_param, int, 0);
MODULE_PARM_DESC(interrupt_coalescing_param, "interrupt coalescing param(time/threshold : 0x00~0xFF");

char *sfx_cc;
module_param(sfx_cc, charp, 0);
MODULE_PARM_DESC(sfx_cc, "Serial number to do card clean");

DEFINE_RWLOCK(dev_list_lock);
LIST_HEAD(dev_list);
LIST_HEAD(fail_list);

DEFINE_RWLOCK(driver_list_lock);
LIST_HEAD(driver_list);

DEFINE_MUTEX(sfx_remove_mutex); /*mutex to let sfx_remove execute sequencely*/

static struct workqueue_struct *sfx_workq; /* mostly for dev reset work */
static wait_queue_head_t sfx_kthread_wait; /* wait for creation of sfx_kthread to complete */
static struct task_struct *sfx_kthread_task = NULL;

static void sfx_reset_failed_dev(struct work_struct *ws);
static int sfx_proc_stats_open(struct inode *inode, struct file *file);
static int sfx_proc_qlists_open(struct inode *inode, struct file *file);
static int sfx_proc_hw_qlists_open(struct inode *inode, struct file *file);
static int sfx_proc_cmdraw_qlists_open(struct inode *inode, struct file *file);

static ssize_t sfx_proc_debug_read(struct file *filp, char __user *buf, size_t count, loff_t *offp);
static ssize_t sfx_proc_debug_write(struct file *filp, const char __user *buf, size_t count, loff_t *offp);
static ssize_t sfx_proc_reg_read(struct file *filp, char __user *buf, size_t count, loff_t *offp);
static ssize_t sfx_proc_reg_write(struct file *filp, const char __user *buf, size_t count, loff_t *offp);

struct sfx_dev *sfx_get_active_sdev(int minor);
void sfx_driver_cleanup(void);
struct sfx_driver *g_driver = NULL;
sfx_atomic_t s_dev_cnt;
sfx_atomic_t bd_probe_cnt;
static atomic_t cpuidx;
static int cpumax = 0;
static struct cpumask cpumask_g;
static sfx_thread_t check_dev_gone_thread = NULL;

#define TEST_MEM_SIZE 8192
#define PROC_REG 0x08 /* FIS.nvme_vs */

#ifdef TRAKCER
u32 tracker[8192 * 4];
u32 tracker_cur = 0;
#endif

xt_u32 balloc = 0;
#define CMD_COMB 0

/* workaround for crashdump on 4.4 or older kernel */
xt_u32 in_crashdump = 0;

extern const struct file_operations sfx_dev_fops;
extern struct pci_driver sfx_driver;

/*
 * Leave this global buffer for debug purpose.
 * This could be shared by multiple devices.
 */
static char s_proc_debug_buffer[128];

static struct proc_dir_entry *sfx_proc_dir;
static struct proc_dir_entry *sfx_proc_stats;
static struct proc_dir_entry *sfx_proc_qlists;
static struct proc_dir_entry *sfx_proc_hw_qlists;
static struct proc_dir_entry *sfx_proc_cmdraw_qlists;
static struct proc_dir_entry *sfx_proc_debug;
static struct proc_dir_entry *sfx_proc_reg;

static const struct file_operations sfx_proc_stats_fops = {
	.owner = THIS_MODULE,
	.open = sfx_proc_stats_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static const struct file_operations sfx_proc_qlists_fops = {
	.owner = THIS_MODULE,
	.open = sfx_proc_qlists_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static const struct file_operations sfx_proc_hw_qlists_fops = {
	.owner = THIS_MODULE,
	.open = sfx_proc_hw_qlists_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static const struct file_operations sfx_proc_cmdraw_qlists_fops = {
	.owner = THIS_MODULE,
	.open = sfx_proc_cmdraw_qlists_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static const struct file_operations sfx_proc_debug_fops = {
	.owner = THIS_MODULE,
	.read = sfx_proc_debug_read,
	.write = sfx_proc_debug_write,
};

static const struct file_operations sfx_proc_reg_fops = {
	.owner = THIS_MODULE,
	.read = sfx_proc_reg_read,
	.write = sfx_proc_reg_write,
};

/*---------------------------------------------------------------------*/

#define INC_SLOT(a) (a) = ((a) + 1) % MAX_SLOTS

/* 2.6.32-279 (Centos 6.3) has the definition in linux/err.h */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
static inline long IS_ERR_OR_NULL(const void *ptr)
{
	return !ptr || unlikely((unsigned long)ptr >= (unsigned long)-MAX_ERRNO);
}
#endif

int sfx_vprintk_driver(const char *fmt, va_list args)
{
	char header_str[256];
	snprintf(header_str, sizeof(header_str), KERN_DEBUG "%s: %s", "SFXPK", fmt);
	return vprintk(header_str, args);
}
EXPORT_SYMBOL(sfx_vprintk_driver);

/*
 * For multiple instances, will get device based on minor number
 */
struct sfx_dev *sfx_get_active_sdev(int minor)
{
	struct sfx_dev *dev = NULL;
	struct sfx_dev *next = NULL;
	struct sfx_dev *my_sdev = NULL;

	sfx_read_lock(&dev_list_lock);
	list_for_each_entry_safe (dev, next, &dev_list, node) {
		if (dev && dev->instance == minor) {
			my_sdev = dev;
		}
	}
	sfx_read_unlock(&dev_list_lock);

	return (struct sfx_dev *)my_sdev;
}
EXPORT_SYMBOL(sfx_get_active_sdev);

int sfx_get_dev_count(void)
{
	struct sfx_dev *dev = NULL;
	int i = 0;

	sfx_read_lock(&dev_list_lock);
	list_for_each_entry (dev, &dev_list, node) {
		i++;
	}
	sfx_read_unlock(&dev_list_lock);

	return i;
}
EXPORT_SYMBOL(sfx_get_dev_count);

static int sfx_proc_qlists_show(struct seq_file *m, void *v)
{
	struct sfx_dev *dev, *next;

	struct list_head *p;
	struct sfx_queue *nvmeq;
#ifdef TRACKER
	int i;
#endif

	sfx_read_lock(&dev_list_lock);
	list_for_each_entry_safe (dev, next, &dev_list, node) {
		seq_printf(m, "dev[%d]/next: %p/%p \n", dev->instance, dev, next);

		nvmeq = lock_nvmeq(dev, 2);

		if (nvmeq) {
			seq_printf(m, "Completion List\n");
			list_for_each (p, &(nvmeq->cq_list)) {
				seq_printf(m, "\t%p\n", p);
			}

			seq_printf(m, "Submission List\n");
			list_for_each (p, &(nvmeq->sq_list)) {
				seq_printf(m, "\t%p\n", p);
			}

			unlock_nvmeq(nvmeq);
		} else {
			seq_printf(m, "q[2] NON-EXIST\n");
		}

#ifdef TRAKCER
		seq_printf(m, "Tracker: %d\n", tracker_cur);
		for (i = 0; i < tracker_cur; i++) {
			switch (tracker[i]) {
			case 0:
				sfx_printk("<");
				break;
			case 1:
				sfx_printk("> ");
				break;
			case 2:
				sfx_printk("[");
				break;
			case 3:
				sfx_printk("] ");
				break;
			case 4:
				sfx_printk("{");
				break;
			case 5:
				sfx_printk("} ");
				break;
			case 6:
				sfx_printk("+");
				break;
			case 7:
				sfx_printk("- ");
				break;
			default:
				sfx_printk("%3d", tracker[i]);
			}
			if ((i + 1) % 48 == 0)
				sfx_printk("\n");
		}
		sfx_printk("\n");
		tracker_cur = 0;
#endif
	}
	sfx_read_unlock(&dev_list_lock);

	return 0;
}

void *sfx_kzalloc_node(struct sfx_dev *dev, sfx_size_t size, sfx_gfp_t flags)
{
	return kzalloc_node(size, flags, dev_to_node(&(dev->pci_dev->dev)));
}

void *sfx_get_dmadev(struct sfx_dev *dev)
{
	return &dev->pci_dev->dev;
}

void *sfx_dma_alloc_coherent(struct sfx_dev *dev, sfx_size_t size, sfx_dma_addr_t *handle, sfx_gfp_t flag)
{
	struct device *dmadev = &dev->pci_dev->dev;

	return dma_alloc_coherent(dmadev, size, handle, flag);
}

void sfx_dma_free_coherent(struct sfx_dev *dev, sfx_size_t size, void *vaddr, sfx_dma_addr_t dma_handle)
{
	struct device *dmadev = &dev->pci_dev->dev;
	dma_free_coherent(dmadev, size, vaddr, dma_handle);
}

int sfx_wait_ready(struct sfx_dev *dev, xt_u64 cap, sfx_bool enabled)
{
	unsigned long timeout;
	xt_u32 bit = enabled ? NVME_CSTS_RDY : 0;

	timeout = ((NVME_CAP_TIMEOUT(cap) + 1) * SFX_HZ / 2) + jiffies;

	while ((sfx_readl(&dev->bar->csts) & NVME_CSTS_RDY) != bit) {
		sfx_msleep(1);

		if (dev->device_gone || check_device_gone(dev)) {
			sfx_pr_err("%s, device removed\n", dev->name);
			return -ENODEV;
		}
		if (fatal_signal_pending(current)) {
			sfx_pr_err("%s, fatal signal pending\n", dev->name);
			return -EINTR;
		}
		if (sfx_time_after(jiffies, timeout)) {
			dev_err(&dev->pci_dev->dev, "%s, Device not ready; aborting %s\n", dev->name,
				enabled ? "initialisation" : "reset");
			return -ENODEV;
		}
	}
	return 0;
}

static int sfx_proc_stats_open(struct inode *inode, struct file *file)
{
	return single_open(file, sfx_proc_stats_show, NULL);
}

static int sfx_proc_qlists_open(struct inode *inode, struct file *file)
{
	return single_open(file, sfx_proc_qlists_show, NULL);
}

static int sfx_proc_hw_qlists_open(struct inode *inode, struct file *file)
{
	return single_open(file, sfx_proc_hw_qlists_show, NULL);
}

static int sfx_proc_cmdraw_qlists_open(struct inode *inode, struct file *file)
{
	return single_open(file, sfx_proc_cmdraw_qlists_show, NULL);
}

static ssize_t sfx_proc_reg_write(struct file *filp, const char __user *buf, size_t count, loff_t *offp)
{
	struct sfx_dev *dev;

// check if there is f_inode in struct file
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
	dev = container_of(filp->private_data, struct sfx_dev, miscdev);
	if (!dev) {
		return -EINVAL;
	}
#else
	struct sfx_dev *lst_dev;
	sfx_read_lock(&dev_list_lock);
	list_for_each_entry (lst_dev, &dev_list, node) {
		if (lst_dev->miscdev.minor == iminor(filp->f_inode)) {
			dev = lst_dev;
		}
	}
	sfx_read_unlock(&dev_list_lock);
	if (!dev) {
		return -EINVAL;
	}
#endif

	sfx_pr_err("%s, 0x%08x: 0x%08x\n", dev->name, PROC_REG, fis_direct_read32(dev->bar, PROC_REG));
	return count;
}

static ssize_t sfx_proc_reg_read(struct file *filp, char __user *buf, size_t count, loff_t *offp)
{
	return 0;
}

static ssize_t sfx_proc_debug_write(struct file *filp, const char __user *buf, size_t count, loff_t *offp)
{
	struct sfx_dev *dev;
	unsigned long ret;

	count = (count > 127) ? 127 : count;
	ret = copy_from_user(s_proc_debug_buffer, buf, count);
	s_proc_debug_buffer[count] = '\0';
	sscanf(s_proc_debug_buffer, "%x", &debug_flag_poll);
	sfx_pr_info("%s: debug_flag_poll %x triggered\n", __FUNCTION__, debug_flag_poll);
	sfx_read_lock(&dev_list_lock);
	list_for_each_entry (dev, &dev_list, node) {
		count = (count > 127) ? 127 : count;
		ret = copy_from_user(s_proc_debug_buffer, buf, count);
		sscanf(s_proc_debug_buffer, "%x", &dev->sfx_cntrs.debug_flag);
	}
	sfx_read_unlock(&dev_list_lock);

	/* the last count will be returned */
	return count;
}

static ssize_t sfx_proc_debug_read(struct file *filp, char __user *buf, size_t count, loff_t *offp)
{
	struct sfx_dev *dev;

	static int flag = 1;
	unsigned long ret;

	sfx_read_lock(&dev_list_lock);
	list_for_each_entry (dev, &dev_list, node) {
		if (flag) {
			sprintf(s_proc_debug_buffer, "debug_flag: 0x%08x, debug_flag_poll: 0x%08x\n",
				dev->sfx_cntrs.debug_flag, debug_flag_poll);
			ret = copy_to_user(buf, s_proc_debug_buffer, strlen(s_proc_debug_buffer) + 1);
			count = strlen(s_proc_debug_buffer) + 1;
			flag = 0;
		} else {
			flag = 1;
			count = 0;
		}
	}
	sfx_read_unlock(&dev_list_lock);

	/* the last count will be returned */
	return count;
}

#ifndef POISON_POINTER_DELTA
#define POISON_POINTER_DELTA 0
#endif

#if (HOT_READ_PERF || HOT_WRITE_PERF)
void _sfx_rd_statistics(struct sfx_dev *dev, xt_u8 qid, struct sfx_iod *iod)
{
	SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
	sfx_nvmeq = ((dev->ftl_mq_ctx.drvg_ctx)[qid]).sfx_nvme_cmd_queue;
	if (sfx_qid_is_rdq(qid, dev->ftl_mq_ctx.ioq_config)) {
		sfx_nvmeq->hot_rd_drv_cmd_init2smt_lat +=
			(sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time));
		sfx_nvmeq->hot_rd_drv_cmd_smt2irq_lat +=
			(sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time));
		sfx_nvmeq->hot_rd_drv_cmd_irq2cb_lat +=
			(sfx_ktime_to_ns(iod->ftl_cb_smt_time) - sfx_ktime_to_ns(iod->irq_time));
		sfx_nvmeq->hot_rd_drv_cmd_cb_lat +=
			(sfx_ktime_to_ns(iod->ftl_cb_rtn_time) - sfx_ktime_to_ns(iod->ftl_cb_smt_time));
#if (READ_HW_LAT)
		sfx_nvmeq->hot_rd_drv_hwcnt_smt2irq_lat += (iod->hw_cpl_tcnt - iod->hw_dbell_tcnt) * 16 / 125;
#endif
		sfx_nvmeq->num_drv_read++;
		if (sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time) >= LONG_LAT_TARGET) {
			sfx_pr_info("%s %d: %s, driver init to submmit takes too long %llu us\n",
				    __FUNCTION__, __LINE__, dev->name,
				    (sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time)) /
					    1000);
			dump_stack();
		}

		if (sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time) >= LONG_LAT_TARGET) {
			sfx_pr_info("%s %d: %s, driver cmd from submit to irq takes too long %llu us\n",
				    __FUNCTION__, __LINE__, dev->name,
				    (sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time)) / 1000);
			dump_stack();
		}

		if ((sfx_ktime_to_ns(iod->ftl_cb_smt_time) - sfx_ktime_to_ns(iod->irq_time)) >=
		    LONG_LAT_TARGET) {
			sfx_pr_info("%s %d: %s, driver from irq rececive to issue ftl callback "
				    "takes too long %llu us\n",
				    __FUNCTION__, __LINE__, dev->name,
				    (sfx_ktime_to_ns(iod->ftl_cb_smt_time) - sfx_ktime_to_ns(iod->irq_time)) /
					    1000);
			dump_stack();
		}

		if ((sfx_ktime_to_ns(iod->ftl_cb_rtn_time) - sfx_ktime_to_ns(iod->ftl_cb_smt_time)) >=
		    LONG_LAT_TARGET) {
			sfx_pr_info("%s %d: %s, driver ftl function takes too long %llu us\n", __FUNCTION__,
				    __LINE__, dev->name,
				    (sfx_ktime_to_ns(iod->ftl_cb_rtn_time) -
				     sfx_ktime_to_ns(iod->ftl_cb_smt_time)) /
					    1000);
			dump_stack();
		}
	} else if (sfx_qid_is_hotwrioq(qid, dev->ftl_mq_ctx.ioq_config)) {
		sfx_nvmeq->hot_wr_drv_cmd_init2smt_lat +=
			(sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time));
		sfx_nvmeq->hot_wr_drv_cmd_smt2irq_lat +=
			(sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time));
		sfx_nvmeq->hot_wr_drv_cmd_irq2cb_lat +=
			(sfx_ktime_to_ns(iod->ftl_cb_smt_time) - sfx_ktime_to_ns(iod->irq_time));
		sfx_nvmeq->hot_wr_drv_cmd_cb_lat +=
			(sfx_ktime_to_ns(iod->ftl_cb_rtn_time) - sfx_ktime_to_ns(iod->ftl_cb_smt_time));
		sfx_nvmeq->num_drv_write++;
	}
	if (sfx_nvmeq->drv_init2smt_max <
	    (sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time))) {
		sfx_nvmeq->drv_init2smt_max =
			(sfx_ktime_to_ns(iod->smt_time) - sfx_ktime_to_ns(iod->init_time));
	}
	if (sfx_nvmeq->drv_cmb_cb_max <
	    (sfx_ktime_to_ns(iod->ftl_cb_rtn_time) - sfx_ktime_to_ns(iod->ftl_cb_smt_time))) {
		sfx_nvmeq->drv_cmb_cb_max =
			(sfx_ktime_to_ns(iod->ftl_cb_rtn_time) - sfx_ktime_to_ns(iod->ftl_cb_smt_time));
	}
	if (sfx_nvmeq->drv_smt2rtn_max < (sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time))) {
		sfx_nvmeq->drv_smt2rtn_max =
			(sfx_ktime_to_ns(iod->irq_time) - sfx_ktime_to_ns(iod->smt_time));
	}
}
#endif

struct sfx_queue *raw_nvmeq(struct sfx_dev *dev, int qid)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 34)
	return rcu_dereference(dev->queues[qid]);
#else
	return rcu_dereference_raw(dev->queues[qid]);
#endif
}

struct sfx_queue *lock_nvmeq(struct sfx_dev *dev, int q_idx) __acquires(RCU)
{
	struct sfx_queue *nvmeq;

	rcu_read_lock();
	nvmeq = rcu_dereference(dev->queues[q_idx]);
	if (nvmeq)
		return nvmeq;

	rcu_read_unlock();
	return NULL;
}

void unlock_nvmeq(struct sfx_queue *nvmeq) __releases(RCU)
{
	rcu_read_unlock();
}

static __le64 **iod_list(struct sfx_iod *iod)
{
	return ((void *)iod) + iod->offset;
}

void sfx_free_iod(struct sfx_dev *dev, struct sfx_iod *iod)
{
	const int last_prp = PAGE_SIZE / 8 - 1;
	int i;
	__le64 **list = iod_list(iod);
	dma_addr_t prp_dma = iod->first_dma;

	if (iod->npages == 0)
		dma_pool_free(dev->prp_small_pool, list[0], prp_dma);
	for (i = 0; i < iod->npages; i++) {
		__le64 *prp_list = list[i];
		dma_addr_t next_prp_dma = le64_to_cpu(prp_list[last_prp]);
		dma_pool_free(dev->prp_page_pool, prp_list, prp_dma);
		prp_dma = next_prp_dma;
	}
	if (!iod->static_alloc)
		kfree(iod);
}

/* length is in bytes.  gfp flags indicates whether we may sleep. */
int sfx_setup_prps(struct sfx_dev *dev, struct sfx_iod *iod, int total_len, gfp_t gfp)
{
	struct dma_pool *pool;
	int length = total_len;
	struct scatterlist *sg = iod->sg;
	int dma_len = sg_dma_len(sg);
	u64 dma_addr = sg_dma_address(sg);
	int offset = offset_in_page(dma_addr);
	__le64 *prp_list;
	__le64 **list = iod_list(iod);
	sfx_dma_addr_t prp_dma;
	int nprps, i;

	length -= (PAGE_SIZE - offset);
	if (length <= 0)
		return total_len;

	dma_len -= (PAGE_SIZE - offset);
	if (dma_len) {
		dma_addr += (PAGE_SIZE - offset);
	} else {
		sg = sg_next(sg);
		dma_addr = sg_dma_address(sg);
		dma_len = sg_dma_len(sg);
	}

	if (length <= PAGE_SIZE) {
		iod->first_dma = dma_addr;
		return total_len;
	}

	nprps = DIV_ROUND_UP(length, PAGE_SIZE);
	if (nprps <= (256 / 8)) {
		pool = dev->prp_small_pool;
		iod->npages = 0;
	} else {
		pool = dev->prp_page_pool;
		iod->npages = 1;
	}

	prp_list = dma_pool_alloc(pool, gfp, &prp_dma);
	if (!prp_list) {
		iod->first_dma = dma_addr;
		iod->npages = -1;
		return (total_len - length) + PAGE_SIZE;
	}
	list[0] = prp_list;
	iod->first_dma = prp_dma;
	i = 0;
	for (;;) {
		if (i == PAGE_SIZE / 8) {
			__le64 *old_prp_list = prp_list;
			prp_list = dma_pool_alloc(pool, gfp, &prp_dma);
			if (!prp_list)
				return total_len - length;
			list[iod->npages++] = prp_list;
			prp_list[0] = old_prp_list[i - 1];
			old_prp_list[i - 1] = cpu_to_le64(prp_dma);
			i = 1;
		}
		prp_list[i++] = cpu_to_le64(dma_addr);
		dma_len -= PAGE_SIZE;
		dma_addr += PAGE_SIZE;
		length -= PAGE_SIZE;
		if (length <= 0)
			break;
		if (dma_len > 0)
			continue;
		BUG_ON(dma_len < 0);
		sg = sg_next(sg);
		dma_addr = sg_dma_address(sg);
		dma_len = sg_dma_len(sg);
	}

	return total_len;
}

static irqreturn_t sfx_irq_check(int irq, void *data)
{
	struct sfx_queue *nvmeq = data;
	if (nvme_cqe_valid(nvmeq, nvmeq->cq_head, nvmeq->cq_phase))
		return IRQ_WAKE_THREAD;
	return IRQ_NONE;
}

int sfx_identify(struct sfx_dev *dev, unsigned nsid, unsigned cns, dma_addr_t dma_addr)
{
	struct nvme_command c;

	memset(&c, 0, sizeof(c));
	c.identify.opcode = nvme_admin_identify;
	c.identify.nsid = cpu_to_le32(nsid);
	c.identify.prp1 = cpu_to_le64(dma_addr);
	c.identify.cns = cpu_to_le32(cns);

	return sfx_submit_admin_cmd(dev, &c, NULL);
}

int sfx_get_features(struct sfx_dev *dev, unsigned fid, unsigned nsid, dma_addr_t dma_addr, u32 *result)
{
	struct nvme_command c;

	memset(&c, 0, sizeof(c));
	c.features.opcode = nvme_admin_get_features;
	c.features.nsid = cpu_to_le32(nsid);
	c.features.prp1 = cpu_to_le64(dma_addr);
	c.features.fid = cpu_to_le32(fid);

	return sfx_submit_admin_cmd(dev, &c, result);
}

int sfx_set_features(struct sfx_dev *dev, unsigned fid, unsigned dword11, dma_addr_t dma_addr, u32 *result)
{
	struct nvme_command c;

	memset(&c, 0, sizeof(c));
	c.features.opcode = nvme_admin_set_features;
	c.features.prp1 = cpu_to_le64(dma_addr);
	c.features.fid = cpu_to_le32(fid);
	c.features.dword11 = cpu_to_le32(dword11);

	return sfx_submit_admin_cmd(dev, &c, result);
}

/* Centos 6.3 (2.6.32-279) has this inline function defined in linux/interrupt.h */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
static int irq_set_affinity_hint(unsigned int irq, const struct cpumask *m)
{
	return 0; //irq_set_affinity(irq, m);
}
#endif

static int sfx_set_irq_affinity(unsigned int irq, const struct cpumask *mask, bool force)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)) && (LINUX_VERSION_CODE < KERNEL_VERSION(4, 0, 0))
	int ret;
	unsigned long flags;
	struct irq_desc *desc;
	struct irq_data *data;
	struct irq_chip *chip;

	desc = irq_to_desc(irq);
	if (!desc)
		return -EINVAL;
	data = irq_desc_get_irq_data(desc);
	if (!data)
		return -EINVAL;
	if (irqd_irq_disabled(data)) {
		sfx_pr_err("%s: IRQ %d DISABLED\n");
	}
	chip = irq_data_get_irq_chip(data);
	if (!chip)
		return -EINVAL;
	raw_spin_lock_irqsave(&desc->lock, flags);
	ret = chip->irq_set_affinity(data, mask, force);
	if (irqd_is_setaffinity_pending(data)) {
		sfx_pr_info("%s: IRQD_SETAFFINITY_PENDING set for irq %d data->irq %d, clear it \n",
			    __FUNCTION__, irq, data->irq);
		data->state_use_accessors = data->state_use_accessors & ~IRQD_SETAFFINITY_PENDING;
	}
	raw_spin_unlock_irqrestore(&desc->lock, flags);
	return ret;
#else
	return 0;
#endif
}

int queue_request_irq(struct sfx_dev *dev, struct sfx_queue *nvmeq, const char *name)
{
	if (use_threaded_interrupts) {
		return request_threaded_irq(dev->entry[nvmeq->cq_vector].vector, sfx_irq_check, sfx_irq,
					    IRQF_SHARED | IRQF_NOBALANCING, name, nvmeq);
	}
#ifdef MQ_IRQSHARED
	return request_irq(dev->entry[nvmeq->cq_vector].vector, sfx_irq, IRQF_SHARED | IRQF_NOBALANCING, name,
			   nvmeq);
#else

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32)
#ifdef UCLOUD6_OS
	return request_irq(dev->entry[nvmeq->cq_vector].vector, sfx_irq, IRQF_SHARED, name, nvmeq);
#else
	return request_irq(dev->entry[nvmeq->cq_vector].vector, sfx_irq, IRQF_SHARED | IRQF_NOBALANCING, name,
			   nvmeq);
#endif
#else
	return request_irq(dev->entry[nvmeq->cq_vector].vector, sfx_irq, IRQF_SHARED, name, nvmeq);
#endif // LINUX_VERSION_CODE > KERNEL_VERSION(2,6,32)

#endif // MQ_IRQSHARED
}

struct sfx_iod *sfx_map_user_pages_ex(struct sfx_dev *dev, int write, unsigned long addr, unsigned length,
				      struct sfx_iod *iod)
{
	int i, err, count, nents, offset_in, offset;
	struct scatterlist *sg;
	struct page **pages;

	if (addr & 3)
		return ERR_PTR(-EINVAL);
	if (!length || length > INT_MAX - PAGE_SIZE)
		return ERR_PTR(-EINVAL);

	offset = offset_in = offset_in_page(addr);
	count = DIV_ROUND_UP(offset + length, PAGE_SIZE);
	pages = kcalloc(count, sizeof(*pages), GFP_KERNEL);
	if (!pages)
		return ERR_PTR(-ENOMEM);

	err = get_user_pages_fast(addr, count, 1, pages);
	if (err < count) {
		count = err;
		err = -EFAULT;
		goto put_pages;
	}

	dev->sfx_cntrs.local_locked_pages += count;
	err = -ENOMEM;
	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		if (offset_in && (i == count - 1)) {
			sg_set_page(&sg[i], pages[i], offset_in, offset);
			length -= offset_in;
			BUG_ON(length != 0);
		} else {
			sg_set_page(&sg[i], pages[i], min_t(unsigned, length, PAGE_SIZE - offset), offset);
			length -= (PAGE_SIZE - offset);
		}
		offset = 0;
	}
	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto put_pages;

	kfree(pages);
	return iod;

put_pages:
	for (i = 0; i < count; i++)
		put_page(pages[i]);
	kfree(pages);
	return ERR_PTR(err);
}

struct sfx_iod *sfx_map_user_pages(struct sfx_dev *dev, int write, unsigned long addr, unsigned length)
{
	int i, err, count, nents, offset;
	struct scatterlist *sg;
	struct page **pages;
	struct sfx_iod *iod;

	if (addr & 3)
		return ERR_PTR(-EINVAL);
	if (!length || length > INT_MAX - PAGE_SIZE)
		return ERR_PTR(-EINVAL);

	offset = offset_in_page(addr);
	count = DIV_ROUND_UP(offset + length, PAGE_SIZE);
	pages = kcalloc(count, sizeof(*pages), GFP_KERNEL);
	if (!pages)
		return ERR_PTR(-ENOMEM);

	err = get_user_pages_fast(addr, count, 1, pages);
	if (err < count) {
		count = err;
		err = -EFAULT;
		goto put_pages;
	}

	dev->sfx_cntrs.local_locked_pages += count;

	err = -ENOMEM;
	iod = sfx_alloc_iod(count, length, GFP_ATOMIC);
	if (!iod)
		goto put_pages;

	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		sg_set_page(&sg[i], pages[i], min_t(unsigned, length, PAGE_SIZE - offset), offset);
		length -= (PAGE_SIZE - offset);
		offset = 0;
	}
	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto free_iod;

	kfree(pages);
	return iod;

free_iod:
	kfree(iod);
put_pages:
	for (i = 0; i < count; i++)
		put_page(pages[i]);
	kfree(pages);
	return ERR_PTR(err);
}

void sfx_unmap_user_pages_only(struct sfx_dev *dev, int write, struct sfx_iod *iod)
{
	dma_unmap_sg(&dev->pci_dev->dev, iod->sg, iod->nents, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
}

void sfx_unmap_user_pages(struct sfx_dev *dev, int write, struct sfx_iod *iod)
{
	int i;

	dma_unmap_sg(&dev->pci_dev->dev, iod->sg, iod->nents, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);

	for (i = 0; i < iod->nents; i++)
		put_page(sg_page(&iod->sg[i]));

	dev->sfx_cntrs.local_unlocked_pages += iod->nents;
}

struct sfx_iod *sfx_map_user_pages_post_ex(struct sfx_dev *dev, int write, unsigned long addr,
					   unsigned length, struct sfx_iod *iod)
{
	int i, err, count, nents, offset = 0;
	struct scatterlist *sg;
	ssize_t index, start;
	sfx_pages_t *p;

	index = (addr >> 32) & 0xFFFF;

	p = sfx_get_page_info_from_index(dev, index);

	start = (addr & 0xFFFFFFFF) >> 12;
	count = length >> 12;
	offset = p->offset;
	if (offset)
		count++;
	if (!p->pages) {
		sfx_pr_err("%s: %s, !p->pages, addr 0x%lx index %zu start: %zu, count %d p->count: %d\n",
			   __FUNCTION__, dev->name, addr, index, start, count, p->count);
		dump_stack();
		err = -EFAULT;
		goto pages_err;
	}

#if KV_DEBUG
	sfx_pr_err("%s: p->pages, addr 0x%lx index %zu start: %zu, count %d p->count: %d, off %x, len %x\n",
		   __FUNCTION__, addr, index, start, count, p->count, offset, length);
#endif
	//PR_INFO("Index=%ld, start=0x%08lx, count=%d, length=0x%08x\n", index, start, count, length);

	err = -ENOMEM;

	iod->private = (void *)index;

	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		//DEBUG ticket 219
		if (start + i >= p->count) {
			int x;
			sfx_pr_err(
				"%s: %s, user page index out of range, start: %zu, i %d, p->count %d, count %d\n",
				__FUNCTION__, dev->name, start, i, p->count, count);
			sfx_pr_err("input parameters: addr: %xh, length: %d\n", addr, length);
			sfx_pr_err("page fields: count: %d, type: %d, id %d, addr: %xh, owner: %p\n",
				   p->count, p->type, p->id, p->addr, p->owner);
			for (x = 0; x < p->count; x++) {
				sfx_pr_err("pages content: %p\t", p->pages[x]);
			}
			// goto pages_err;
			BUG();
		}
		if ((unsigned long)p->pages[start + i] & 0x03) {
			int x;
			sfx_pr_err(
				"%s: %s, odd page address, start %zu, i %d, count %d p->count %d, addr %lu\n",
				__FUNCTION__, dev->name, start, i, count, p->count, p->addr);
			for (x = 0; x < p->count; x++) {
				sfx_pr_err("pages content: %p\t", p->pages[x]);
			}
			sfx_pr_err("\n");
			goto pages_err;
		}
		//end of debugging ticket 219
		if (p->offset && (i == count - 1)) {
			sg_set_page(&sg[i], p->pages[start + i], p->offset, offset);
#if KV_DEBUG
			sfx_pr_err("%s: last pages[%d] %p, len %x, off %x\n", __FUNCTION__, start + i,
				   p->pages[start + i], p->offset, offset);
#endif
			length -= p->offset;
			BUG_ON(length != 0);
		} else {
			sg_set_page(&sg[i], p->pages[start + i], min_t(unsigned, length, PAGE_SIZE - offset),
				    offset);
#if KV_DEBUG
			sfx_pr_err("%s: pages[%d] %p, len %x, off %x\n", __FUNCTION__, start + i,
				   p->pages[start + i], min_t(unsigned, length, PAGE_SIZE - offset), offset);
#endif
			length -= (PAGE_SIZE - offset);
		}
		offset = 0;
	}
	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto pages_err;

	return iod;

pages_err:
	return ERR_PTR(err);
}

struct sfx_iod *sfx_map_user_pages_post(struct sfx_dev *dev, int write, unsigned long addr, unsigned length)
{
	int i, err, count, nents;
	struct scatterlist *sg;
	struct sfx_iod *iod;
	ssize_t index, start;
	sfx_pages_t *p;

	index = (addr >> 32) & 0xFFFF;

	p = sfx_get_page_info_from_index(dev, index);

	start = (addr & 0xFFFFFFFF) >> 12;
	count = length >> 12;
	if (!p->pages) {
		sfx_pr_err("%s: %s, !p->pages, addr 0x%lx index %zu start: %zu, count %d p->count: %d\n",
			   __FUNCTION__, dev->name, addr, index, start, count, p->count);
		dump_stack();
		BUG();
	}

	err = -ENOMEM;
	iod = sfx_alloc_iod(count, length, GFP_ATOMIC);
	if (!iod)
		goto pages_err;

	iod->private = (void *)index;

	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		//DEBUG ticket 219
		if (start + i >= p->count) {
			int x;
			sfx_pr_err(
				"%s: %s, user page index out of range, start: %zu, i %d, p->count %d, count %d\n",
				__FUNCTION__, dev->name, start, i, p->count, count);
			sfx_pr_err("input parameters: addr: %xh, length: %d\n", addr, length);
			sfx_pr_err("page fields: count: %d, type: %d, id %d, addr: %xh, owner: %p\n",
				   p->count, p->type, p->id, p->addr, p->owner);
			for (x = 0; x < p->count; x++) {
				sfx_pr_err("pages content: %p\t", p->pages[x]);
			}
			// goto free_iod;
			BUG();
		}
		if ((unsigned long)p->pages[start + i] & 0x03) {
			int x;
			sfx_pr_err(
				"%s: %s, odd page address, start %zu, i %d, count %d p->count %d, addr %lu\n",
				__FUNCTION__, dev->name, start, i, count, p->count, p->addr);
			for (x = 0; x < p->count; x++) {
				sfx_pr_err("pages content: %p\t", p->pages[x]);
			}
			sfx_pr_err("\n");
			goto free_iod;
		}
		//end of debugging ticket 219
		sg_set_page(&sg[i], p->pages[start + i], min_t(unsigned, length, PAGE_SIZE), 0);
		length -= PAGE_SIZE;
	}
	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto free_iod;

	return iod;

free_iod:
	kfree(iod);
pages_err:
	return ERR_PTR(err);
}

struct sfx_iod *sfx_map_kernel_pages_ex(struct sfx_dev *dev, int write, unsigned long addr, unsigned length,
					struct sfx_iod *iod)
{
	int i, err, count, nents;
	struct scatterlist *sg;
	unsigned long laddr = addr;

	count = length >> 12;

	err = -ENOMEM;
	if ((unsigned long)addr & 0xfff) {
		sfx_pr_err("%s: %s, not aligned addr %lx\n", __FUNCTION__, dev->name, addr);
		BUG();
	}

	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		sg_set_page(&sg[i],
			    is_vmalloc_addr((void *)laddr) ? vmalloc_to_page((void *)laddr) :
							     virt_to_page(laddr),
			    min_t(unsigned, length, PAGE_SIZE), 0);
		length -= PAGE_SIZE;
		laddr += PAGE_SIZE;
	}

	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto pages_err;

	return iod;

pages_err:
	return ERR_PTR(err);
}

struct sfx_iod *sfx_map_kernel_pages(struct sfx_dev *dev, int write, unsigned long addr, unsigned length)
{
	int i, err, count, nents;
	struct scatterlist *sg;
	struct sfx_iod *iod;
	unsigned long laddr = addr;

	count = length >> 12;

	err = -ENOMEM;
	if ((unsigned long)addr & 0xfff) {
		sfx_pr_err("%s: %s, not aligned addr %lu\n", __FUNCTION__, dev->name, addr);
		BUG();
	}
	iod = sfx_alloc_iod(count, length, GFP_ATOMIC);
	if (!iod)
		goto pages_err;

	sg = iod->sg;
	sg_init_table(sg, count);
	for (i = 0; i < count; i++) {
		sg_set_page(&sg[i],
			    is_vmalloc_addr((void *)laddr) ? vmalloc_to_page((void *)laddr) :
							     virt_to_page(laddr),
			    min_t(unsigned, length, PAGE_SIZE), 0);
		length -= PAGE_SIZE;
		laddr += PAGE_SIZE;
	}

	sg_mark_end(&sg[i - 1]);
	iod->nents = count;

	nents = dma_map_sg(&dev->pci_dev->dev, sg, count, write ? DMA_TO_DEVICE : DMA_FROM_DEVICE);
	if (!nents)
		goto free_iod;

	return iod;

free_iod:
	kfree(iod);
pages_err:
	return ERR_PTR(err);
}

/* Move to device-independent system when it is ready */
#define PUMA_06B_CHANNEL_OFFSET 28
#define PUMA_06B_CE_OFFSET 25

int sfx_nand_device_reset(struct sfx_dev *dev, u32 ch, u32 ce)
{
	struct nvme_command c;
	int status;
	u32 result;

	F_ENTER;

	memset(&c, 0, sizeof(c));
	c.rw.opcode = sfx_cmd_nand_reset;
	c.rw.slba = ((ch << PUMA_06B_CHANNEL_OFFSET) | (ce << PUMA_06B_CE_OFFSET)) & 0xFFFFFFFF;

	status = sfx_submit_sync_cmd(dev, 0, &c, &result, NVME_IO_TIMEOUT);

	F_LEAVE;

	return result;
}
EXPORT_SYMBOL(sfx_nand_device_reset);

static int sfx_handle_ioctl_submit(struct sfx_fd *fd, struct sfx_userio_cmd __user *uio, bool sync)
{
	struct sfx_userio_cmd io;
	int ret;

	if (copy_from_user(&io, uio, sizeof(io))) {
		sfx_pr_err("%s:%d %s, copy_from_user failed, uio=%p\n", __FUNCTION__, __LINE__, fd->dev->name,
			   uio);
		F_LEAVE;
		return -EFAULT;
	}

	ret = sfx_submit_nvme_io(fd, &io, sync, false);

	if (copy_to_user(uio, &io, sizeof(io))) {
		sfx_pr_err("%s:%d %s, copy_to_user failed, uio=%p\n", __FUNCTION__, __LINE__, fd->dev->name,
			   uio);
	}

	return ret;
}

static int sfx_user_admin_cmd(struct sfx_dev *dev, struct nvme_admin_cmd __user *ucmd)
{
	struct nvme_admin_cmd cmd;
	struct nvme_command c;
	int status, length;
	struct sfx_iod *uninitialized_var(iod);
	unsigned timeout;

	if (!capable(CAP_SYS_ADMIN))
		return -EACCES;
	if (copy_from_user(&cmd, ucmd, sizeof(cmd)))
		return -EFAULT;

	memset(&c, 0, sizeof(c));
	c.common.opcode = cmd.opcode;
	c.common.flags = cmd.flags;
	c.common.nsid = cpu_to_le32(cmd.nsid);
	c.common.cdw2[0] = cpu_to_le32(cmd.cdw2);
	c.common.cdw2[1] = cpu_to_le32(cmd.cdw3);
	c.common.cdw10[0] = cpu_to_le32(cmd.cdw10);
	c.common.cdw10[1] = cpu_to_le32(cmd.cdw11);
	c.common.cdw10[2] = cpu_to_le32(cmd.cdw12);
	c.common.cdw10[3] = cpu_to_le32(cmd.cdw13);
	c.common.cdw10[4] = cpu_to_le32(cmd.cdw14);
	c.common.cdw10[5] = cpu_to_le32(cmd.cdw15);

	length = cmd.data_len;
	if (cmd.data_len) {
		iod = sfx_map_user_pages(dev, cmd.opcode & 1, (unsigned long)cmd.addr, length);
		if (IS_ERR(iod))
			return PTR_ERR(iod);
		length = sfx_setup_prps(dev, iod, length, GFP_KERNEL);
		c.common.prp1 = cpu_to_le64(sg_dma_address(iod->sg));
		c.common.prp2 = cpu_to_le64(iod->first_dma);
	}

	timeout = cmd.timeout_ms ? msecs_to_jiffies(cmd.timeout_ms) : SFX_ADMIN_TIMEOUT;
	if (length != cmd.data_len)
		status = -ENOMEM;
	else
		status = sfx_submit_sync_cmd(dev, 0, &c, &cmd.result, timeout);

	if (cmd.data_len) {
		sfx_unmap_user_pages(dev, cmd.opcode & 1, iod);
		sfx_free_iod(dev, iod);
	}

	if ((status >= 0) && copy_to_user(&ucmd->result, &cmd.result, sizeof(cmd.result)))
		status = -EFAULT;

	return status;
}

static int sfx_kthread(void *data)
{
	struct sfx_dev *dev;

	while (!kthread_should_stop()) {
		set_current_state(TASK_INTERRUPTIBLE);
		if (in_hotreset == 1) {
			sfx_pr_info("%s: in_hotreset, msleep(1000)\n", __FUNCTION__);
			sfx_msleep(1000);
			continue;
		}
		if (!(debug_flag_poll & 0x1)) {
			schedule_timeout(round_jiffies_relative(HZ / 4));
			continue;
		}
		sfx_read_lock(&dev_list_lock);
		list_for_each_entry (dev, &dev_list, node) {
			int i;

			rcu_read_lock();

			dev->sfx_cntrs.polling_total++;

			for (i = 0; i < dev->queue_count; i++) {
				struct sfx_queue *nvmeq = rcu_dereference(dev->queues[i]);
				if (!nvmeq) {
					continue;
				}
				spin_lock_irq(&nvmeq->q_lock);
				if (nvmeq->q_suspended) {
					goto unlock;
				}
				dev->sfx_cntrs.polling_counter++;
				nvmeq->q_stats.polling_total++;
				sfx_process_cq(nvmeq, 0, 0xffffffff);
				if (!nvmeq->cqe_seen) {
					dev->sfx_cntrs.polling_counter--;
				} else {
					nvmeq->cqe_seen = 0;
				}
			unlock:
				spin_unlock_irq(&nvmeq->q_lock);
			}
			rcu_read_unlock();
		}
		sfx_read_unlock(&dev_list_lock);
		schedule_timeout(round_jiffies_relative(HZ / 4));
	}
	return 0;
}

static void sfx_free_dev(struct kref *kref);

#ifdef ALL_CPU
static int sfx_find_closest_node(int node)
{
	int n, val, min_val = INT_MAX, best_node = node;

	for_each_online_node (n) {
		if (n == node)
			continue;
		val = node_distance(node, n);
		if (val < min_val) {
			min_val = val;
			best_node = n;
		}
	}
	return best_node;
}

static void sfx_set_queue_cpus(cpumask_t *qmask, struct sfx_queue *nvmeq, int count)
{
	int cpu;
	for_each_cpu (cpu, qmask) {
		if (cpumask_weight(nvmeq->cpu_mask) >= count)
			break;
	}
}

static void sfx_add_cpus(cpumask_t *mask, const cpumask_t *unassigned_cpus, const cpumask_t *new_mask,
			 struct sfx_queue *nvmeq, int cpus_per_queue)
{
	int next_cpu;
	for_each_cpu (next_cpu, new_mask) {
		cpumask_or(mask, mask, get_cpu_mask(next_cpu));
		cpumask_or(mask, mask, topology_thread_cpumask(next_cpu));
		cpumask_and(mask, mask, unassigned_cpus);
		sfx_set_queue_cpus(mask, nvmeq, cpus_per_queue);
	}
}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 1, 0)
#define cpus_weight(cpumask) bitmap_weight((cpumask).bits, NR_CPUS)
#endif

/*
 * If there are fewer queues than online cpus, this will try to optimally
 * assign a queue to multiple cpus by grouping cpus that are "close"
 * together: thread siblings, core, socket, closest node, then whatever
 * else is available.
 */
static void sfx_assign_io_queues(struct sfx_dev *dev)
{
#ifdef ALL_CPU
	unsigned cpu, cpus_per_queue, queues, remainder, i;
	cpumask_var_t unassigned_cpus;
	cpumask_t *mask_t;
#else
	unsigned queues, i;
#endif
	int ret = 0;

	sfx_create_io_queues(dev);

#ifdef ALL_CPU
	if (!queues)
		return;

	cpus_per_queue = sfx_num_online_cpus() / queues;
	remainder = queues - (sfx_num_online_cpus() - queues * cpus_per_queue);

	if (!alloc_cpumask_var(&unassigned_cpus, GFP_KERNEL))
		return;

	cpumask_copy(unassigned_cpus, cpu_online_mask);

	if (!(mask_t = (cpumask_t *)kmalloc(sizeof(cpumask_t), GFP_KERNEL))) {
		sfx_pr_err("%s: %s, kmalloc(%u) failed\n", __FUNCTION__, dev->name, sizeof(cpumask_t));
		free_cpumask_var(unassigned_cpus);
		return;
	}

	cpu = cpumask_first(unassigned_cpus);
	for (i = 1; i <= queues; i++) {
		struct sfx_queue *nvmeq = lock_nvmeq(dev, i);
		cpumask_t *mask;

		cpumask_clear(nvmeq->cpu_mask);
		if (!cpumask_weight(unassigned_cpus)) {
			unlock_nvmeq(nvmeq);
			break;
		}

		*mask_t = *get_cpu_mask(cpu);
		mask = mask_t;
		sfx_set_queue_cpus(mask, nvmeq, cpus_per_queue);
		if (cpus_weight(*mask) < cpus_per_queue)
			sfx_add_cpus(mask, unassigned_cpus, topology_thread_cpumask(cpu), nvmeq,
				     cpus_per_queue);
		if (cpus_weight(*mask) < cpus_per_queue)
			sfx_add_cpus(mask, unassigned_cpus, topology_core_cpumask(cpu), nvmeq,
				     cpus_per_queue);
		if (cpus_weight(*mask) < cpus_per_queue)
			sfx_add_cpus(mask, unassigned_cpus, cpumask_of_node(cpu_to_node(cpu)), nvmeq,
				     cpus_per_queue);
		if (cpus_weight(*mask) < cpus_per_queue)
			sfx_add_cpus(mask, unassigned_cpus,
				     cpumask_of_node(sfx_find_closest_node(cpu_to_node(cpu))), nvmeq,
				     cpus_per_queue);
		if (cpus_weight(*mask) < cpus_per_queue)
			sfx_add_cpus(mask, unassigned_cpus, unassigned_cpus, nvmeq, cpus_per_queue);

		WARN(cpumask_weight(nvmeq->cpu_mask) != cpus_per_queue,
		     "%s, nvme%d qid:%d mis-matched queue-to-cpu assignment\n", dev->name, dev->instance, i);

		sfx_pr_info("%s: %s, q[%d].cpu_mask %*pb\n", __FUNCTION__, dev->name, nvmeq->qid,
			    cpumask_pr_args(nvmeq->cpu_mask));
		if ((ret = irq_set_affinity_hint(dev->entry[nvmeq->cq_vector].vector, nvmeq->cpu_mask))) {
			sfx_pr_err(
				"%s: %s, irq_set_affinity_hint(IRQ%d->CPUMASK %*pb) for q[%d] faled, %d retuned\n",
				__FUNCTION__, dev->name, dev->entry[nvmeq->cq_vector].vector,
				cpumask_pr_args(nvmeq->cpu_mask), nvmeq->qid, ret);
		}
		sfx_pr_info("%s, set affinity(IRQ%d->CPUMASK %*pb) for q[%d]\n", dev->name,
			    dev->entry[nvmeq->cq_vector].vector, cpumask_pr_args(nvmeq->cpu_mask),
			    nvmeq->qid);
		ret = sfx_set_irq_affinity(dev->entry[nvmeq->cq_vector].vector, nvmeq->cpu_mask, false);
		if (ret < 0 || ret > 2) {
			sfx_pr_info("%s: %s, !!! sfx_set_irq_affinity returns %d\n", __FUNCTION__, dev->name,
				    ret);
		}
		cpumask_andnot(unassigned_cpus, unassigned_cpus, nvmeq->cpu_mask);
		cpu = cpumask_next(cpu, unassigned_cpus);
		if (remainder && !--remainder)
			cpus_per_queue++;
		unlock_nvmeq(nvmeq);
	}
	sfx_kfree(mask_t);
	WARN(cpumask_weight(unassigned_cpus), "%s, nvme%d unassigned online cpus\n", dev->name,
	     dev->instance);
	i = 0;
	cpumask_andnot(unassigned_cpus, cpu_possible_mask, cpu_online_mask);
	free_cpumask_var(unassigned_cpus);
#else
	queues = min(dev->online_queues - 1, sfx_num_online_cpus());
	if (!queues)
		return;
	for (i = 1; i <= queues; i++) {
		struct sfx_queue *nvmeq = lock_nvmeq(dev, i);

		cpumask_clear(nvmeq->cpu_mask);
		/* set to 1 to correctly manage ioqueue_count. */
		cpumask_set_cpu(i, nvmeq->cpu_mask);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		sfx_pr_info("%s: %s, q[%d].cpu_mask %*pb\n", __FUNCTION__, dev->name, nvmeq->qid,
			    cpumask_pr_args(nvmeq->cpu_mask));
#endif
		if ((ret = irq_set_affinity_hint(dev->entry[nvmeq->cq_vector].vector, nvmeq->cpu_mask))) {
			sfx_pr_err(
				"%s: %s, irq_set_affinity_hint(IRQ%d->CPUMASK %*pb) for q[%d] faled, %d retuned\n",
				__FUNCTION__, dev->name, dev->entry[nvmeq->cq_vector].vector,
				cpumask_pr_args(nvmeq->cpu_mask), nvmeq->qid, ret);
		}
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		sfx_pr_info("%s, set affinity(IRQ%d->CPUMASK %*pb) for q[%d]\n", dev->name,
			    dev->entry[nvmeq->cq_vector].vector, cpumask_pr_args(nvmeq->cpu_mask),
			    nvmeq->qid);
#endif
		ret = sfx_set_irq_affinity(dev->entry[nvmeq->cq_vector].vector, nvmeq->cpu_mask, false);
		if (ret < 0 || ret > 2) {
			sfx_pr_info("%s: %s, !!! sfx_set_irq_affinity returns %d\n", __FUNCTION__, dev->name,
				    ret);
		}
		unlock_nvmeq(nvmeq);
	}
#endif
}

#ifdef TWO_DEFAULT_IO_QS
static int set_queue_count(struct sfx_dev *dev, int count)
{
	return 2;
}
#endif

static size_t db_bar_size(struct sfx_dev *dev, unsigned nr_io_queues)
{
	return 4096 + ((nr_io_queues + 1) * 8 * dev->db_stride);
}

static void sfx_cpu_workfn(struct work_struct *work)
{
	struct sfx_dev *dev = container_of(work, struct sfx_dev, cpu_work);
	if (dev->initialized)
		sfx_assign_io_queues(dev);
}

static int sfx_cpu_notify(struct notifier_block *self, unsigned long action, void *hcpu)
{
	struct sfx_dev *dev;

	switch (action) {
	case CPU_ONLINE:
	case CPU_DEAD:
		sfx_read_lock(&dev_list_lock);
		list_for_each_entry (dev, &dev_list, node)
			schedule_work(&dev->cpu_work);
		sfx_read_unlock(&dev_list_lock);
		break;
	}
	return NOTIFY_OK;
}

/*
 * These symbols are already defined in Red Hat 7.2, possibly in earlier
 * ones as well. If we're not on red hat, the right side evaluates to
 * true, so then the kernel version takes precedence
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 14, 0)
#undef NEED_LOCAL_PCI_HELPER
#ifdef CENTOS_TLINUX
#define NEED_LOCAL_PCI_HELPER
#endif
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(6, 6)) || (RHEL_RELEASE_CODE == RHEL_RELEASE_VERSION(7, 0))
#define NEED_LOCAL_PCI_HELPER
#endif
#else
#define NEED_LOCAL_PCI_HELPER
#endif
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7)
#define NEED_LOCAL_PCI_HELPER
#endif
#ifdef NEED_LOCAL_PCI_HELPER
int pci_enable_msi_range(struct pci_dev *dev, int minvec, int maxvec)
{
	int nvec = maxvec;
	int rc;

	if (maxvec < minvec)
		return -ERANGE;

	do {
		rc = pci_enable_msi_block(dev, nvec);
		if (rc < 0) {
			return rc;
		} else if (rc > 0) {
			if (rc < minvec)
				return -ENOSPC;
			nvec = rc;
		}
	} while (rc);

	return nvec;
}

int pci_enable_msix_range(struct pci_dev *dev, struct msix_entry *entries, int minvec, int maxvec)
{
	int nvec = maxvec;
	int rc;

	if (maxvec < minvec)
		return -ERANGE;

	do {
		rc = pci_enable_msix(dev, entries, nvec);
		if (rc < 0) {
			return rc;
		} else if (rc > 0) {
			if (rc < minvec)
				return -ENOSPC;
			nvec = rc;
		}
	} while (rc);

	return nvec;
}
#endif
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0))
static int pci_enable_msi_range(struct pci_dev *dev, int minvec, int maxvec)
{
	return 0;
}
#endif

static int request_msix(struct sfx_dev *dev, int nr_entry)
{
	int i, vecs;
	struct pci_dev *pdev = dev->pci_dev;

	/* allocate max entry to meet the need of sfx_alloc_nvmeq() from blk_ftl */
	for (i = 0; i < nr_entry; i++)
		dev->entry[i].entry = i;

	if (!msix_disable) {
		vecs = pci_enable_msix_range(pdev, dev->entry, 1, nr_entry);
#ifdef SFXDRIVER_DEBUG1
		sfx_pr_info("%s: nr_entry=%d vecs=%d\n", __FUNCTION__, nr_entry, vecs);
#endif
		BUG_ON(vecs <= 0);
#ifdef SFXDRIVER_DEBUG1
		for (i = 0; i < vecs; i++)
			sfx_pr_info("%s: dev->entry[%d].vector %u\n", __FUNCTION__, i, dev->entry[i].vector);
#endif
	} else {
		vecs = -1;
	}

	if (vecs < 0) {
		vecs = pci_enable_msi_range(pdev, 1, min(nr_entry, 32));
		sfx_pr_info("%s: %s, nr_entry=%d vecs=%d\n", __FUNCTION__, dev->name, nr_entry, vecs);
		BUG_ON(vecs <= 0);
		for (i = 0; i < vecs; i++)
			dev->entry[i].vector = i + pdev->irq;
	}
	return 0;
}

#ifdef TWO_DEFAULT_IO_QS
static int sfx_setup_io_queues(struct sfx_dev *dev)
{
	struct sfx_queue *adminq = raw_nvmeq(dev, 0);
	struct pci_dev *pdev = dev->pci_dev;
	int result, i, vecs, nr_io_queues, nr_entry, size;

	nr_io_queues = sfx_num_possible_cpus();
	sfx_pr_info("%s: %s, number of possible cpu is: %d\n", __FUNCTION__, dev->name, nr_io_queues);

	result = set_queue_count(dev, nr_io_queues);

	if (result < 0)
		return result;
	if (result < nr_io_queues)
		nr_io_queues = result;

	size = db_bar_size(dev, nr_io_queues);
	sfx_pr_info("%s: %s, nr_io_queues %d door bell size is %d dev->bar %p\n", __FUNCTION__, dev->name,
		    nr_io_queues, size, dev->bar);

	if (size > (32 * 1024) /*8192*/) {
		iounmap(dev->bar);
		do {
			dev->bar = ioremap(pci_resource_start(pdev, 0), size);
			if (dev->bar)
				break;
			if (!--nr_io_queues)
				return -ENOMEM;
			size = db_bar_size(dev, nr_io_queues);
		} while (1);
		dev->dbs = ((void __iomem *)dev->bar) + 4096;
		adminq->q_db = dev->dbs;
	}

	/* Deregister the admin queue's interrupt */
	free_irq(dev->entry[0].vector, adminq);

	/* allocate max entry to meet the need of sfx_alloc_nvmeq() from blk_ftl */
	nr_entry = min(dev->vecnt, MAX_Q_NUM);
	for (i = 0; i < nr_entry; i++)
		dev->entry[i].entry = i;

	if (use_intx) {
		vecs = nr_io_queues - 1;
		/* entry[0] is already filled with pdev->irq and shared by
         * adminq and q[1], we only need to initialize q[2].
         */
		for (i = 1; i < vecs; i++)
			dev->entry[i].vector = pdev->irq;
	} else if (!msix_disable) {
		vecs = pci_enable_msix_range(pdev, dev->entry, 1, nr_entry);
		sfx_pr_info("%s: %s, nr_io_queues=%d, nr_entry=%d vecs=%d\n", __FUNCTION__, dev->name,
			    nr_io_queues, nr_entry, vecs);
		BUG_ON(vecs <= 0);
		for (i = 0; i < vecs; i++)
			sfx_pr_info("%s: %s, dev->entry[%d].vector %u\n", __FUNCTION__, dev->name, i,
				    dev->entry[i].vector);
	} else {
		vecs = -1;
	}

	if (vecs < 0) {
		vecs = pci_enable_msi_range(pdev, 1, min(nr_entry, 32));
		BUG_ON(vecs <= 0);
		for (i = 0; i < vecs; i++)
			dev->entry[i].vector = i + pdev->irq;
	}

	/*
     * Should investigate if there's a performance win from allocating
     * more queues than interrupt vectors; it might allow the submission
     * path to scale better, even if the receive path is limited by the
     * number of interrupts.
     */

	dev->max_qid = nr_io_queues;

	result = queue_request_irq(dev, adminq, adminq->irqname);
	if (result) {
		adminq->q_suspended = 1;
		goto free_queues;
	}

	/* Free previously allocated queues that are no longer usable */
	sfx_free_queues(dev, nr_io_queues + 1);
	sfx_assign_io_queues(dev);

	return 0;

free_queues:
	sfx_free_queues(dev, 1);
	return result;
}
#endif

/*
 * Return: error value if an error occurred setting up the queues or
 * calling Identify Device.  0 if these succeeded, even if adding some
 * of the namespaces failed.  At the moment, these failures are silent.
 * TBD which failures should be reported.
 */
#ifdef TEST_DMA_ALLOC_COHERENT
static int sfx_dev_add(struct sfx_dev *dev)
{
	struct pci_dev *pdev = dev->pci_dev;
	int res;
	void *mem;
	dma_addr_t dma_addr;

	mem = dma_alloc_coherent(&pdev->dev, 8192, &dma_addr, GFP_KERNEL);
	if (!mem) {
		sfx_pr_err("%s: %s, no memory", __FUNCTION__, dev->name);
		return -ENOMEM;
	}

	res = 0;

	// out:
	dma_free_coherent(&dev->pci_dev->dev, 8192, mem, dma_addr);
	return res;
}
#endif

/* Centos 6.3 (2.6.32-279) has this inline function defined in dma-mapping.h */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
#ifdef RHEL_RELEASE_CODE
#if RHEL_RELEASE_CODE <= RHEL_RELEASE_VERSION(7, 1)
static inline int dma_set_coherent_mask(struct device *dev, u64 mask)
{
	if (!dma_supported(dev, mask)) {
		return -EIO;
	}
	dev->coherent_dma_mask = mask;
	return 0;
}
#endif
#endif
#endif

/* Centos 6.3 (2.6.32-279) does not have this function defined */
// #if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0)) && (RHEL_RELEASE_CODE <= RHEL_RELEASE_VERSION(7,1))
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 13, 0))
#undef NEED_LOCAL_PCI_HELPER
#ifdef CENTOS_TLINUX
#define NEED_LOCAL_PCI_HELPER
#endif
#ifdef RHEL_RELEASE_CODE
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(6, 6)
#define NEED_LOCAL_PCI_HELPER
#endif
#else
#define NEED_LOCAL_PCI_HELPER
#endif
#ifdef NEED_LOCAL_PCI_HELPER
static int dma_set_mask_and_coherent(struct device *dev, u64 mask)
{
	int rc = dma_set_mask(dev, mask);
	if (rc == 0) {
		rc = dma_set_coherent_mask(dev, mask);
	}
	return rc;
}
#endif
#endif // (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))

#define MSI_X_DISABLE()                                                           \
	if (dev->pci_dev->msix_enabled) {                                         \
		pci_disable_msix(dev->pci_dev);                                   \
	} else if (dev->pci_dev->msi_enabled) {                                   \
		pci_disable_msi(dev->pci_dev);                                    \
	} else {                                                                  \
		sfx_pr_info("%s: %s, !msix and !msi\n", __FUNCTION__, dev->name); \
	}

static int sfx_dev_map(struct sfx_dev *dev)
{
	u64 cap;
	int bars, vecs, result = -ENODEV;
	struct pci_dev *pdev = dev->pci_dev;
	xt_u32 csts;

	F_ENTER;

	if (pci_enable_device_mem(pdev)) {
		sfx_pr_info("%s: %s, pci_enable_device disable!\n", __FUNCTION__, dev->name);
		return -ENOMEM;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36)
	pdev->mmio_always_on = 1;
#endif

	vecs = pci_enable_msix_range(pdev, dev->entry, 1, 1);
	if (vecs <= 0) {
		sfx_pr_err(
			"%s: %s, pci_enable_msix_range() for adminq failed, call pci_enable_msi and assign pdev->irq %d\n",
			__FUNCTION__, dev->name, pdev->irq);
		pci_enable_msi(pdev);
		dev->entry[0].vector = pdev->irq;
	}
	if (!dev->entry[0].vector) {
		sfx_pr_err("%s: %s, !dev->entry[0].vector, pdev->irq %d\n", __FUNCTION__, dev->name,
			   pdev->irq);
		return result;
	}

	pci_set_master(pdev);
	bars = pci_select_bars(pdev, IORESOURCE_MEM);
	if (pci_request_selected_regions(pdev, bars, KBUILD_MODNAME)) {
		sfx_pr_err("%s: %s, select regions failed!\n", __FUNCTION__, dev->name);
		goto disable_pci;
	}

	if (dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(64)) &&
	    dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32))) {
		sfx_pr_err("%s: %s, dma setting failed!\n", __FUNCTION__, dev->name);
		goto disable;
	}

	dev->bar = ioremap(pci_resource_start(pdev, 0), 32 * 1024 /*8192*/);

	if (!dev->bar) {
		sfx_pr_err("%s: %s, !dev->bar\n", __FUNCTION__, dev->name);
		goto disable;
	}

	csts = readl(&dev->bar->csts);
	if (csts == -1 || csts == 0xdeadbeef) {
		sfx_pr_err("%s: %s, Bad dev->bar->csts 0x%08x\n", __FUNCTION__, dev->name, csts);
		goto unmap;
	}

	cap = readq(&dev->bar->cap);
	dev->q_depth = min_t(int, NVME_CAP_MQES(cap) + 1, SFX_Q_DEPTH);
	dev->db_stride = 1 << NVME_CAP_STRIDE(cap);
	dev->dbs = ((void __iomem *)dev->bar) + 4096;

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_dev_info(dev);
#endif

	F_LEAVE;
	return 0;

unmap:
	iounmap(dev->bar);
	dev->bar = NULL;
disable:
	pci_release_regions(pdev);
disable_pci:
	MSI_X_DISABLE();
	pci_disable_device(pdev);
	F_LEAVE;
	return result;
}

static void sfx_dev_unmap(struct sfx_dev *dev)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	unregister_hotcpu_notifier(&dev->sfx_nb);
#endif
	/*
     * make sure no inode page list activities after this exit point.
     */
	sfx_page_list_deinit(dev);

	MSI_X_DISABLE();

	if (dev->bar) {
		iounmap(dev->bar);
		dev->bar = NULL;
		pci_release_regions(dev->pci_dev);
	}

	if (pci_is_enabled(dev->pci_dev))
		pci_disable_device(dev->pci_dev);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s done\n", __FUNCTION__, dev->name);
#endif
}

static void sfx_wait_dq(struct sfx_delq_ctx *dq, struct sfx_dev *dev)
{
	int i;
	dq->waiter = current;
	mb();

	for (;;) {
		set_current_state(TASK_KILLABLE);
		if (!atomic_read(&dq->refcount)) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: !dq->refcount, break\n", __FUNCTION__);
#endif
			break;
		}
		if (!schedule_timeout(SFX_ADMIN_TIMEOUT) || fatal_signal_pending(current)) {
			set_current_state(TASK_RUNNING);

			sfx_disable_ctrl(dev, readq(&dev->bar->cap));
			sfx_disable_queue(dev, 0);
			for (i = dev->queue_count - 1; i > 0; i--) {
				struct sfx_queue *nvmeq = raw_nvmeq(dev, i);
				cancel_work_sync(&nvmeq->cmdinfo.work);
			}
			flush_workqueue(dq->worker);
			sfx_pr_info("%s: %s, return from SFX_ADMIN_TIMEOUT\n", __FUNCTION__, dev->name);
			return;
		}
	}
	set_current_state(TASK_RUNNING);
}

static void sfx_disable_io_queues(struct sfx_dev *dev)
{
	int i, num_q = 0, num_ioq = 0;
	struct sfx_delq_ctx dq;
	sfx_worker_t *worker;

#define SFX_DEV_NAME_SIZE 10
	char sfx_devname[SFX_DEV_NAME_SIZE];
	snprintf(sfx_devname, SFX_DEV_NAME_SIZE, "nvme%d", dev->instance);
	worker = create_singlethread_workqueue(sfx_devname);
	if (!worker) {
		dev_err(&dev->pci_dev->dev, "%s, Failed to create queue del task\n", dev->name);
		for (i = dev->queue_count - 1; i > 0; i--)
			sfx_disable_queue(dev, i);
		return;
	}

	dq.waiter = NULL;
	atomic_set(&dq.refcount, 0);
	dq.worker = worker;
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: dev %p queue/ioq count %u/%u\n", __FUNCTION__, dev, dev->queue_count,
		    dev->ioqueue_count);
#endif
	for (i = dev->queue_count - 1; i > 0; i--) {
		struct sfx_queue *nvmeq = raw_nvmeq(dev, i);

		sfx_pr_info("%s: %s, i %d nvmeq %p\n", __FUNCTION__, dev->name, i, nvmeq);
		if (!nvmeq) {
			for (i = 0; i < dev->queue_count; i++) {
				struct sfx_queue *q = raw_nvmeq(dev, i);
				sfx_pr_info("%s,     q[%d]%p\n", dev->name, i, q);
			}
			if (dev->ftl_mq_ctx.ftl_ctx.device_ready == 2) {
				sfx_pr_info("%s: %s, BLK FTL Freeze detected\n", __func__, dev->name);
			} else {
				BUG();
			}
		}
		if (sfx_suspend_queue(nvmeq))
			continue;
		nvmeq->cmdinfo.ctx = sfx_get_dq(&dq);
		nvmeq->cmdinfo.worker = dq.worker;
		INIT_WORK(&nvmeq->cmdinfo.work, sfx_del_queue_start);
		sfx_queue_work(worker, &nvmeq->cmdinfo.work);
		if (!cpumask_empty(nvmeq->cpu_mask))
			num_ioq++;
		num_q++;
	}
#ifndef TWO_DEFAULT_IO_QS
	dev->queue_count -= num_q;
	dev->ioqueue_count -= num_ioq;
#endif
	sfx_wait_dq(&dq, dev);
	destroy_workqueue(worker);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s done, q/ioq count %u/%u\n", __FUNCTION__, dev->name, dev->queue_count,
		    dev->ioqueue_count);
#endif
}

static void sfx_dev_shutdown(struct sfx_dev *dev)
{
	int i;
	u32 v = 1;
	struct task_struct *tmp = NULL;

	F_ENTER;

	dev->initialized = 0;

	/*
     * This should be the only entry point to remove dev from list
     */
	// sfx_driver_shutdown(dev);
	// if ((dev->init_err == 0) && (dev->init_fatal_err == 0))
	sfx_dev_list_remove(dev);

	sfx_read_lock(&dev_list_lock);
	if (list_empty(&dev_list) && !IS_ERR_OR_NULL(sfx_kthread_task)) {
		tmp = sfx_kthread_task;
		sfx_kthread_task = NULL;
	}
	sfx_read_unlock(&dev_list_lock);

	if (tmp)
		kthread_stop(tmp);

	/* -1: pcie is not accessible
     *  0: controller is not ready to receive command
     */
	if (!dev->bar || ((v = readl(&dev->bar->csts)) == -1) || ((v = readl(&dev->bar->csts)) == 0)) {
		sfx_pr_info("%s: %s, !dev->bar or csts == 0x%x\n", __FUNCTION__, dev->name, v);
		for (i = dev->queue_count - 1; i >= 0; i--) {
			struct sfx_queue *nvmeq = raw_nvmeq(dev, i);
			sfx_suspend_queue(nvmeq);
			sfx_clear_queue(nvmeq);
		}
	} else {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: dev->bar && csts == 0x%x\n", __FUNCTION__, v);
#endif
		sfx_disable_io_queues(dev);
		sfx_disable_queue(dev, 0);
		sfx_shutdown_ctrl(dev);
		sfx_trigger_powerfailure(dev);
	}
	sfx_dev_unmap(dev);
	//sfx_pr_info("%s: %s done\n", __FUNCTION__, dev->name);
}

static int sfx_setup_prp_pools(struct sfx_dev *dev)
{
	struct device *dmadev = &dev->pci_dev->dev;
	dev->prp_page_pool = dma_pool_create("prp list page", dmadev, PAGE_SIZE, PAGE_SIZE, 0);
	if (!dev->prp_page_pool)
		return -ENOMEM;

	/* Optimisation for I/Os between 4k and 128k */
	dev->prp_small_pool = dma_pool_create("prp list 256", dmadev, 256, 256, 0);
	if (!dev->prp_small_pool) {
		dma_pool_destroy(dev->prp_page_pool);
		return -ENOMEM;
	}
	return 0;
}

static void sfx_release_prp_pools(struct sfx_dev *dev)
{
	dma_pool_destroy(dev->prp_page_pool);
	dma_pool_destroy(dev->prp_small_pool);
}

static DEFINE_IDA(sfx_instance_ida);

void sfx_release_instance(xt_32 instance);
static int sfx_set_instance(struct sfx_dev *dev)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 19, 0)
	int instance, error;

	do {
		if (!ida_pre_get(&sfx_instance_ida, GFP_KERNEL)) {
			return -ENODEV;
		}
		/*sfx_instance_ida is global for all cards, must use lock to protect it*/
		sfx_write_lock(&dev_list_lock);
		error = ida_get_new(&sfx_instance_ida, &instance);
		sfx_write_unlock(&dev_list_lock);
	} while (error == -EAGAIN);

	if (error) {
		return -ENODEV;
	}
#else
	int instance = ida_simple_get(&sfx_instance_ida, 0, 0, GFP_KERNEL);
	if (instance < 0) {
		return -ENODEV;
	}
#endif
	/*MAX support dev is 0 ~ 31*/
	if (instance >= MAX_NR_DRIVE) {
		sfx_release_instance(instance);
		return -ENODEV;
	}

	SFX_INFO("===========Get New Instance %d \n", instance);
	dev->instance = instance;
	return 0;
}

void sfx_release_instance(xt_32 instance)
{
	SFX_INFO("===========Release Instance %d \n", instance);
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 19, 0)
	sfx_write_lock(&dev_list_lock);
	ida_remove(&sfx_instance_ida, instance);
	sfx_write_unlock(&dev_list_lock);
#else
	ida_simple_remove(&sfx_instance_ida, instance);
#endif
}
EXPORT_SYMBOL(sfx_release_instance);

static void sfx_free_dev(struct kref *kref)
{
	struct sfx_dev *dev = container_of(kref, struct sfx_dev, kref);

#ifdef MQ_IRQSHARED
	free_cpumask_var(dev->msix_requested);
#endif
	kfree(dev->queues);
	kfree(dev->entry);
	if (dev->sfx_bd_param) {
		kfree(dev->sfx_bd_param);
	}
	kfree(dev);
}

void sfx_dev_get(struct sfx_dev *dev)
{
	kref_get(&dev->kref);
}
EXPORT_SYMBOL(sfx_dev_get);

void sfx_dev_put(struct sfx_dev *dev)
{
	kref_put(&dev->kref, sfx_free_dev);
}
EXPORT_SYMBOL(sfx_dev_put);

int sfx_fd_init(struct sfx_fd **fd, struct sfx_dev *dev)
{
	int ret = 0;
	/* dev_list_lock is held */
	*fd = kzalloc(sizeof(struct sfx_fd), GFP_KERNEL);

	if (*fd) {
		(*fd)->dev = dev;
		SFX_INIT_LIST_HEAD(&(*fd)->lockmem_list);
#if (LINUX_VERSION_CODE <= KERNEL_VERSION(3, 5, 7))
		kref_get(&dev->kref);
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("sfx_fd_init: dev %s(%p) fd %p\n", dev->name, dev, *fd);
#endif
#else
#ifdef SFXDRIVER_BASE_DEBUG
		if (!kref_get_unless_zero(&dev->kref))
			ret = -ENODEV;
		else
			sfx_pr_info("sfx_fd_init: dev %s(%p) fd %p\n", dev->name, dev, *fd);
#else
		if (!kref_get_unless_zero(&dev->kref))
			ret = -ENODEV;
#endif
#endif
	} else
		ret = -ENOMEM;

	return ret;
}
EXPORT_SYMBOL(sfx_fd_init);

int sfx_dev_open(struct inode *inode, struct file *f)
{
	struct sfx_dev *dev;
	struct sfx_fd *fd;
	int ret;

	sfx_read_lock(&dev_list_lock);

	// Not sure when the default setting of f->private_data was first
	// introduced, but it's first used by the nvme driver in 3.10
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
	dev = container_of(f->private_data, struct sfx_dev, miscdev);
#else
	{
		struct sfx_dev *lst_dev;
		dev = NULL;
		list_for_each_entry (lst_dev, &dev_list, node) {
			if (lst_dev->miscdev.minor == iminor(inode)) {
				dev = lst_dev;
			}
		}
		if (NULL == dev) {
			sfx_read_unlock(&dev_list_lock);
			return -ENODEV;
		}
	}
#endif
	fd = NULL;
	ret = sfx_fd_init(&fd, dev);
	if ((0 == ret) && (NULL != fd)) {
		f->private_data = fd;
	}
	sfx_read_unlock(&dev_list_lock);
	return ret;
}

void sfx_fd_destroy(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	int mem_locked, mem_unlocked;
	sfx_pages_t *pl = NULL, *next = NULL;
	int counter = 0;

	sfx_read_lock(&dev_list_lock);
	mem_locked = atomic_read(&fd->mem_locked);
	mem_unlocked = atomic_read(&fd->mem_unlocked);
	if (mem_locked != mem_unlocked) {
		sfx_pr_info("sfx_fd_dstr: WARNING: %s, fd %p mem %u/%u\n", dev->name, fd, mem_locked,
			    mem_unlocked);
		if (sfx_list_empty(&fd->lockmem_list)) {
			sfx_pr_info("sfx_fd_dstr: WARNING: fd->lockmem_list empty\n");
		} else {
			sfx_list_for_each_entry_safe(pl, next, &fd->lockmem_list, on_fd)
			{
				counter = sfx_unmap_user_pages_simple(fd, pl);
				atomic_add(counter, &fd->mem_unlocked);
			}
			mem_unlocked = atomic_read(&fd->mem_unlocked);
			if (mem_locked != mem_unlocked)
				sfx_pr_info("sfx_fd_dstr: WARNING: final unequal mem %u/%u\n", mem_locked,
					    mem_unlocked);
		}
	}

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("sfx_fd_dstr: dev %p fd %p freed\n", dev, fd);
#endif

	kref_put(&dev->kref, sfx_free_dev);
	fd->dev = NULL;
	kfree(fd);
	sfx_read_unlock(&dev_list_lock);
}
EXPORT_SYMBOL(sfx_fd_destroy);

int sfx_dev_release(struct inode *inode, struct file *f)
{
	struct sfx_fd *fd = f->private_data;

	sfx_fd_destroy(fd);

	return 0;
}

static int sfx_user_errorinject_cmd(struct sfx_dev *dev, struct sfx_errorinject_cmd *ucmd)
{
	struct sfx_errinj_listelem *listelem;
	xt_u32 ret = 0;
	unsigned long flag;

	listelem = kmalloc(sizeof(struct sfx_errinj_listelem), GFP_KERNEL);
	if (!listelem) {
		return -ENOMEM;
	}

	if (copy_from_user(&listelem->cmd, ucmd, sizeof(struct sfx_errorinject_cmd))) {
		F_LEAVE;
		ret = -EFAULT;
		goto free_listelem;
	}

	dev->inject_active = 1;
	sfx_spin_lock_irqsave(&dev->inject_lock, flag);
	if (listelem->cmd.opcode == OP_READ) {
		xt_u32 magic_key;
		do {
			sfx_get_random_bytes(&magic_key, sizeof(magic_key));
		} while (!(magic_key & 0x10));
		listelem->cmd.fake_results &= 0xFFFFF00F;
		listelem->cmd.fake_results |= (magic_key & 0xFF0);
	}
	sfx_pr_info(
		"%s, EHANDLE add injection pba=%x mask=%x opcode=%x fake_result=%x enable_random=%d counter=%d\n",
		dev->name, listelem->cmd.pba, listelem->cmd.mask, listelem->cmd.opcode,
		listelem->cmd.fake_results, listelem->cmd.enable_random, listelem->cmd.counter);
	list_add_tail(&listelem->list, &dev->inject_list);
	dev->last_time = jiffies / SFX_HZ;
	sfx_spin_unlock_irqrestore(&dev->inject_lock, flag);
	return ret;

free_listelem:
	sfx_kfree(listelem);
	return ret;
}

static int sfx_user_test_cmd(struct sfx_dev *dev, struct sfx_test_cmd *ucmd)
{
	struct sfx_test_cmd cmd;
	int i;
	u32 *buffer = dev->test_mem; //use test_mem as buffer
	unsigned long ret;

	F_ENTER;
	if (!dev->test_mem) {
		F_LEAVE;
		return -EFAULT;
	}

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		F_LEAVE;
		return -EFAULT;
	}

	if ((cmd.length * sizeof(int)) > TEST_MEM_SIZE) {
		if (cmd.opcode != SFX_SPI_ERASE_DATA) {
			sfx_pr_info("%s: %s, for cmd opcode %u length(%d) to %lu!!!\n", __FUNCTION__,
				    dev->name, cmd.opcode, cmd.length, TEST_MEM_SIZE / sizeof(int));
		}
		cmd.length = TEST_MEM_SIZE / sizeof(int);
	}
	switch (cmd.opcode) {
	case SFX_TEST_WRITE:
		// unsigned long ret;
		ret = copy_from_user(dev->test_mem, cmd.buffer, sizeof(int) * cmd.length);
		for (i = 0; i < cmd.length; i++) {
			fis_indirect_write32(dev, dev->bar, cmd.address + (i << 2), buffer[i]);
		}
		break;
	case SFX_TEST_READ:
		for (i = 0; i < cmd.length; i++) {
			buffer[i] = fis_indirect_read32(dev, dev->bar, cmd.address + (i << 2));
		}
		break;
	case SFX_SPI_INIT:
		if (sfxdriver_spi_init(dev))
			return -EFAULT;
		else
			return 0;
	case SFX_SPI_INIT_READ_ONLY:
		if (sfxdriver_spi_init_read_only(dev))
			return -EFAULT;
		else
			return 0;
	case SFX_SPI_EXIT:
		sfxdriver_spi_exit(dev);
		return 0;
	case SFX_SPI_WRITE_DATA:
		if (sfxdriver_spi_write_data(dev, cmd.address, cmd.length, cmd.buffer))
			return -EFAULT;
		else
			return 0;
	case SFX_SPI_NOR_FLASH_READ:
		if (sfxdriver_nor_flash_read(dev, cmd.address, cmd.length, buffer)) {
			return -EFAULT;
		} else {
			if (copy_to_user(cmd.buffer, buffer, cmd.length)) {
				F_LEAVE;
				return -EFAULT;
			}
			F_LEAVE;
			return 0;
		}
	case SFX_SPI_NOR_READ_DID:
		if (sfxdriver_spi_read_nor_did(dev, cmd.length, buffer)) {
			return -EFAULT;
		} else {
			if (copy_to_user(cmd.buffer, buffer, cmd.length)) {
				F_LEAVE;
				return -EFAULT;
			}
			F_LEAVE;
			return 0;
		}
	case SFX_SPI_ERASE_DATA:
		if (sfxdriver_spi_erase_data(dev, cmd.address, cmd.length))
			return -EFAULT;
		else
			return 0;

	case SFX_VU_GET_FEAT_DATA:
		sfxdriver_vu_get_feat_data(dev, buffer);
		if (copy_to_user(cmd.buffer, buffer, 2 * sizeof(xt_u32))) {
			F_LEAVE;
			return -EFAULT;
		}
		return 0;

	default:
		sfx_pr_info("%s: %s, Unknown opcode!!!\n", __FUNCTION__, dev->name);
		F_LEAVE;
		return -EFAULT;
	}

	if (copy_to_user(cmd.buffer, buffer, sizeof(int) * cmd.length)) {
		F_LEAVE;
		return -EFAULT;
	}

	F_LEAVE;
	return 0;
}

static int sfx_set_bd_parameter(struct sfx_dev *dev, bd_param_t *ucmd)
{
	F_ENTER;

	if (!dev->sfx_bd_param) {
		dev->sfx_bd_param = kzalloc(sizeof(bd_param_t), GFP_KERNEL);

		if (!dev->sfx_bd_param) {
			sfx_pr_info("%s: %s, Unknown mem addr !!!\n", __FUNCTION__, dev->name);
			F_LEAVE;
			return -ENOMEM;
		}
	}

	/* just save the content, no checking/interpretation */
	if (copy_from_user(dev->sfx_bd_param, ucmd, sizeof(bd_param_t))) {
		/* don't pass garbage info to block device driver */
		memset(dev->sfx_bd_param, 0, sizeof(bd_param_t));
		sfx_pr_info("%s: %s, Unknown copy !!!\n", __FUNCTION__, dev->name);
		F_LEAVE;
		return -EFAULT;
	}

	F_LEAVE;
	return 0;
}

static int sfx_user_get_feature(struct sfx_dev *dev, sfx_get_feature_t *ucmd)
{
	struct sfx_get_feature cmd;

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}
	switch (cmd.opcode) {
	case FEAT_OP_OPN:
		// strncpy(cmd.opn, dev->opn, sizeof(cmd.opn));
		if (copy_to_user((void *)cmd.data, (void *)dev->opn,
				 sizeof(dev->opn) < cmd.len ? sizeof(dev->opn) : cmd.len)) {
			return -EFAULT;
		}
		break;
	case FEAT_OP_CARD_INFO:
		if (copy_to_user((void *)cmd.data, (void *)&dev->card_info,
				 sizeof(dev->card_info) < cmd.len ? sizeof(dev->card_info) : cmd.len)) {
			return -EFAULT;
		}
		break;
	default:
		sfx_pr_info("%s: %s, SFX_IOCTL_GET_FEATURE, opcode=0x%x not supported\n", __FUNCTION__,
			    dev->name, cmd.opcode);
		return -EINVAL;
	}
	return 0;
}

static int sfx_allocate_nvmeq(struct sfx_dev *dev, struct sfx_q_info *ucmd)
{
	struct sfx_q_info cmd;
#ifdef MASK_BY_APP
	int rtn = 0, i, bit_count;
#else
	int rtn = 0;
#endif
	cpumask_var_t mask;
	unsigned long mask_long;
	struct sfx_driver_nvmeq_ctx init_ctx = { 0 };

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}
	if (!alloc_cpumask_var(&mask, GFP_KERNEL)) {
		return -ENOMEM;
	}

	mask_long = cmd.mask;
	cpumask_clear(mask);
#ifdef MASK_BY_APP
	bit_count = 8 * sizeof(mask_long);
	for (i = 0; i < bit_count; i++) {
		if (mask_long % 2)
			cpumask_set_cpu(i, mask);
		mask_long >>= 1;
	}
#else
	cpumask_copy(mask, cpu_online_mask);
#endif
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	sfx_pr_info(
		"%s: %s, SFX_IOCTL_CREATE_NVMEQ qid=%u q_type=%d, stream_id=%d, flag=%d, cmd_input.mask=0x%lx mask=%*pb, last=%u\n",
		__FUNCTION__, dev->name, cmd.qid, cmd.q_type, cmd.stream_id, cmd.flag, cmd.mask,
		cpumask_pr_args(mask), cmd.flag);
#endif
	init_ctx.qid = cmd.qid;
	init_ctx.queue_type = cmd.q_type;
	init_ctx.stream_id = cmd.stream_id;
	init_ctx.cpumask = mask;
	init_ctx.flag_last = cmd.flag;
	if (!sfx_alloc_nvmeq((void *)dev, &init_ctx, NULL)) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
		sfx_pr_err(
			"%s: %s, SFX_IOCTL_CREATE_NVMEQ failed, qid=%u mask_input=0x%x mask=%*pb, last=%u\n",
			__FUNCTION__, dev->name, cmd.qid, mask_long, cpumask_pr_args(mask), cmd.flag);
#endif
		rtn = -EFAULT;
	}
	free_cpumask_var(mask);
	return rtn;
}

int sfx_remove_nvmeq(struct sfx_dev *dev, struct sfx_q_info *ucmd)
{
	struct sfx_q_info cmd;

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}
	sfx_pr_info("%s: %s, SFX_IOCTL_DELETE_NVMEQ, delete nvmeq id=%u\n", __FUNCTION__, dev->name, cmd.qid);
	return sfx_free_nvmeq(dev, cmd.qid);
}

static int sfx_nvme_admin_cmd(struct sfx_dev *dev, struct nvme_admin_cmd __user *ucmd)
{
	struct nvme_admin_cmd cmd;

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}

	/* Only support fw-download currently, we should move the workaround
 	 * in nvme-cli that relates to char device driver here
 	 */
	switch (cmd.opcode) {
	case nvme_admin_download_fw:
		return sfx_nvme_download_fw(dev, (void *)cmd.addr, cmd.cdw11, cmd.data_len);

	default:
		sfx_pr_err("%s no support for cmd.opcode 0x%x\n", __FUNCTION__, cmd.opcode);
		return -EINVAL;
	}
	return 0;
}

/*force release ida_instance when nvme reset called*/
static int sfx_nvme_reset(struct sfx_dev *dev)
{
	dev->keep_disk = 1;
	dev->force_ida_release = 1;
	sfx_pr_info("%s: %s keep_disk %d, force_ida_realease=%d\n", __func__, dev->name, dev->keep_disk,
		    dev->force_ida_release);
	return 0;
}

struct nvme_aes_command {
	__u8 opcode;
	__u8 flags;
	__u16 command_id;
	__le32 nsid;
	__u8 key[32];
	__u32 rsvd0;
	__u8 rsvd1;
	__u8 session_id; //only lower 4 bit valid
	__u16 rsvd2;
	__u8 iv[16];
};

static int sfx_user_config_aes(struct sfx_dev *dev, SFX_AES_CONFIG_CMD __user *ucmd)
{
	SFX_AES_CONFIG_CMD cmd;
	struct nvme_aes_command c;
	int status;
	unsigned timeout;

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}

	memset(&c, 0, sizeof(c));
	c.opcode = sfx_cmd_aes_program;

	//byte 8:39, AES/IV key
	memcpy(c.key, cmd.key, 32);
	memcpy(c.iv, cmd.iv, 16);
	c.session_id = cmd.session_id;

	timeout = SFX_ADMIN_TIMEOUT;
	status = sfx_submit_sync_cmd(dev, (cmd.op == 1) ? 1 : 2, (struct nvme_command *)&c, &cmd.result,
				     timeout);
	//PR_INFO("status=%d\n", status);

	if ((status >= 0) && copy_to_user(&ucmd->result, &cmd.result, sizeof(cmd.result))) {
		status = -EFAULT;
	}

	return status;
}

/**
 * @brief get parent pci bus info of pci_dev
 *
 * @param dev
 * @param ucmd
 *
 * @return  0 success; other fail;
 */
static int sfx_user_get_pci_bus_info(struct sfx_dev *dev, sfx_get_pci_bus_info_t *ucmd)
{
	sfx_get_pci_bus_info_t cmd;
	pci_bus_info_t info;
	struct pci_dev *pdev = (dev->pci_dev)->bus->self;

	if (copy_from_user(&cmd, ucmd, sizeof(cmd))) {
		return -EFAULT;
	}
	info.bus_domain = pci_domain_nr(pdev->bus);
	info.bus_number = pdev->bus->number;
	info.dev_slot = PCI_SLOT(pdev->devfn);
	info.dev_func = PCI_FUNC(pdev->devfn);

	if (copy_to_user((void *)cmd.info, (void *)&info, sizeof(info) < cmd.len ? sizeof(info) : cmd.len)) {
		return -EFAULT;
	}

	return 0;
}
#if 0
//temporary retain for furture use
/**
 * @brief trigger hardware reset
 *
 * @param dev
 *
 * @return
 */
static int sfx_hw_reset(struct sfx_dev *dev)
{
	xt_u32 timeout = 0;

	if (sfx_atomic_read(&dev->ftl_mq_ctx.vir_surprise_remove))
		return 0;

	sfx_pr_info("%s: %s, hardware reset start\n", __FUNCTION__, dev->name);
	sfx_trigger_powerfailure(dev);
	sfx_atomic_set(&dev->ftl_mq_ctx.vir_surprise_remove, 1);
	while (!sfx_atomic_read(&dev->ftl_mq_ctx.surprise_remove_done)) {
		sfx_usleep(1000);
		timeout++;
		if (timeout > 5000) {
			sfx_pr_info("%s: %s, ioctl timeout\n", __FUNCTION__, dev->name);
			sfx_pr_err("%s: csts: 0x%x\n", __FUNCTION__, readl(&dev->bar->csts));
			sfx_pr_err("%s: cc: 0x%x\n", __FUNCTION__, readl(&dev->bar->cc));
			timeout = 0;
		}
	}
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x40000000);
	sfx_pr_info("%s: %s, hardware reset done\n", __FUNCTION__, dev->name);
	return 0;
}
#endif

long sfx_dev_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
	struct sfx_fd *fd = f->private_data;
	struct sfx_dev *dev = fd->dev;
	int ret;

	if (dev->goldimg && cmd != SFX_IOCTL_TEST_CMD && cmd != SFX_IOCTL_INIT_CMD &&
	    cmd != SFX_IOCTL_GET_FEATURE && cmd != SFX_NVME_IOCTL_ADMIN_CMD) {
		sfx_pr_info("%s: %s, goldimg %u, cmd 0x%x return -ENODEV\n", __FUNCTION__, dev->name,
			    dev->goldimg, cmd);
		return -ENODEV;
	}
	switch (cmd) {
	case SFX_IOCTL_ADMIN_CMD:
		return sfx_user_admin_cmd(dev, (void __user *)arg);
	case SFX_IOCTL_SUBMIT_IO:
		return sfx_handle_ioctl_submit(fd, (void __user *)arg, true);
	case SFX_IOCTL_ASYNC_SUBMIT_IO:
		return sfx_handle_ioctl_submit(fd, (void __user *)arg, false);

	case SFX_IOCTL_TEST_CMD:
		return sfx_user_test_cmd(dev, (void __user *)arg);

	case SFX_IOCTL_ERRORINJECT_CMD:
		return sfx_user_errorinject_cmd(dev, (void __user *)arg);

	case SFX_IOCTL_CHECK_STATUS:
		ret = sfx_user_check_status(fd);
		if (copy_to_user((void __user *)arg, &fd->_status, sizeof(sfx_check_status_cmd_t))) {
			return -EFAULT;
		} else {
			return ret;
		}

#ifdef USE_KTIME_CTX
	case SFX_IOCTL_GET_QSTATS:
		ret = sfx_user_get_qstats(fd);
		if (copy_to_user((void __user *)arg, &fd->_qstats, sizeof(sfx_get_qstats_cmd_t))) {
			return -EFAULT;
		} else {
			return ret;
		}
#endif

	case SFX_IOCTL_CONFIG_AES:
		return sfx_user_config_aes(dev, (void __user *)arg);

	case SFX_IOCTL_LOCK_MEM: {
		long counter = sfx_lock_user_pages(fd, (void __user *)arg);
		/* counter > 0 or counter == -EFAULT, token addr is in arg. */
		return counter > 0 ? 0 : -1;
	}

	case SFX_IOCTL_UNLOCK_MEM: {
		long counter = sfx_unlock_user_pages(fd, (void __user *)arg);
		/* counter > 0 or counter == -EFAULT */
		return counter > 0 ? 0 : -1;
	}

	case SFX_IOCTL_SPLIT_TOKEN:
		return sfx_user_split_token(fd, (void __user *)arg);

	case SFX_IOCTL_SPLIT_TOKEN_RELEASE:
		return sfx_user_split_token_release(fd, (void __user *)arg);

	case SFX_IOCTL_INIT_CMD:
		return sfx_init_card(dev);

	case SFX_IOCTL_USER_SET_PGLIST:
		return sfx_driver_user_set_pagelist(fd, (void __user *)arg);

	case SFX_IOCTL_BD_PARAMETERS:
		return sfx_set_bd_parameter(dev, (void __user *)arg);

	case SFX_IOCTL_GET_USER_FREESLOT:
		return sfx_get_user_freeslot(dev, (void __user *)arg);

	case SFX_IOCTL_GET_FEATURE:
		return sfx_user_get_feature(dev, (void __user *)arg);

	case SFX_IOCTL_CREATE_NVMEQ:
		return sfx_allocate_nvmeq(dev, (void __user *)arg);

	case SFX_IOCTL_DELETE_NVMEQ:
		return sfx_remove_nvmeq(dev, (void __user *)arg);

	case SFX_IOCTL_GET_PCI_BUS_INFO:
		return sfx_user_get_pci_bus_info(dev, (void __user *)arg);

	case SFX_NVME_IOCTL_ADMIN_CMD:
		return sfx_nvme_admin_cmd(dev, (void __user *)arg);
	case NVME_IOCTL_RESET:
		return sfx_nvme_reset(dev);

	default:
		return -ENOTTY;
	}
}

static int sfx_dev_start(struct sfx_dev *dev)
{
	int result = 0;
	bool start_kthread = false;
#ifdef MQ_IRQSHARED
	int r;
#endif
	xt_u32 scratch_hi;

	F_ENTER;

	result = sfx_dev_map(dev);
	if (result) {
		sfx_pr_err("%s: %s sfx_dev_map()failed, return %d\n", __FUNCTION__, dev->name, result);
		return result;
	}
	scratch_hi = fis_indirect_read32(dev, dev->bar, SCRATCH_HI);
	if (scratch_hi == SCRATCH_HI_PF_PATTERN) {
		xt_u32 reg_val;

		/*sfx_pr_info("%s: before reset, scratch_hi = 0x%08x\n", __FUNCTION__, scratch_hi);*/

		/* trigger a PF */
		reg_val = 0xffe;
		fis_indirect_write32(dev, dev->bar, REG_INTR_MASK, reg_val);
		reg_val = 0x1;
		fis_indirect_write32(dev, dev->bar, REG_INTR_SHADOW, reg_val);
		sfx_mdelay(100);
	}

	/* nvme hot reset */
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x40000000);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: wrote 0x40000000 to SFX_RST_CTRL\n", __FUNCTION__);
#endif
	sfx_mdelay(1);

	scratch_hi = fis_indirect_read32(dev, dev->bar, SCRATCH_HI);
	/*sfx_pr_info("%s: after reset, scratch_hi = 0x%08x\n", __FUNCTION__, scratch_hi);*/

	result = sfx_configure_admin_queue(dev);
	if (result) {
		sfx_pr_err("%s: %s sfx_configure_admin_queue() failed, result %d, goto unmap\n", __FUNCTION__,
			   dev->name, result);
		sfx_dev_unmap(dev);
		return result;
	}

	if ((result = sfx_init_card(dev))) {
		sfx_pr_err("%s: %s sfx_init_card() failed, %d reuturned\n", __FUNCTION__, dev->name, result);
#ifdef TWO_DEFAULT_IO_QS
		goto disable_ioqs;
#else
		sfx_write_lock(&dev_list_lock);
		list_add_tail(&dev->node, &fail_list);
		sfx_write_unlock(&dev_list_lock);
		return -ENXIO;
#endif
	}

	sfx_write_lock(&dev_list_lock);
	if (list_empty(&dev_list) && IS_ERR_OR_NULL(sfx_kthread_task)) {
		start_kthread = true;
		sfx_kthread_task = NULL;
	}

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s, dev%d: added to dev list\n", __FUNCTION__, dev->name, dev->instance);
#endif
	list_add_tail(&dev->node, &dev_list);
	sfx_write_unlock(&dev_list_lock);

	if (start_kthread) {
		sfx_kthread_task = kthread_run(sfx_kthread, NULL, KBUILD_MODNAME);
		wake_up_all(&sfx_kthread_wait);
		/*sfx_pr_info("%s: sfx_kthread() started and wake up all waiting thread\n", __FUNCTION__);*/
	} else {
		sfx_pr_info("%s: %s waiting sfx_kthread()\n", __FUNCTION__, dev->name);
		wait_event_killable(sfx_kthread_wait, sfx_kthread_task);
	}
	if (IS_ERR_OR_NULL(sfx_kthread_task)) {
		sfx_pr_err("%s: %s sfx_kthread_task error\n", __FUNCTION__, dev->name);
	}

#ifdef TWO_DEFAULT_IO_QS
	result = sfx_setup_io_queues(dev);
#else
#ifdef MQ_IRQSHARED
	if ((r = cpumask_test_and_set_cpu(0, dev->msix_requested)))
		sfx_pr_info("%s: %s, WARNING initialize msix_requested return %d\n", __FUNCTION__, dev->name,
			    result);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	sfx_pr_info("%s: %s, msix_requested initialized to %*pb\n", __FUNCTION__, dev->name,
		    cpumask_pr_args(dev->msix_requested));
#endif
#endif
#ifdef MQ_DEBUG
	{
		struct cpumask mask;
		unsigned long mask_long;
		int i, bit_count, cpu, w;

		mask_long = 6;
		cpumask_clear(&mask);
		bit_count = 8 * sizeof(mask_long);
		for (i = 0; i < bit_count; i++) {
			if (mask_long % 2)
				cpumask_set_cpu(i, &mask);
			mask_long >>= 1;
		}
		w = cpumask_weight(&mask);
		sfx_pr_info("%s: ======== DEBUG weight %d\n", __FUNCTION__, w);
		for_each_cpu (cpu, &mask) {
			sfx_pr_info("%s: ======== DEBUG cpu %d\n", __FUNCTION__, cpu);
		}
	}
#endif
#endif

	dev->block_kobj = kobject_create_and_add("block", &dev->pci_dev->dev.kobj);
	if (!dev->block_kobj) {
		sfx_pr_info("%s: failed to create sysfs in sfxdriver\n", __FUNCTION__);
	}

	F_LEAVE;
	return result;

#ifdef TWO_DEFAULT_IO_QS
disable_ioqs:
	sfx_disable_io_queues(dev);
	sfx_shutdown_ctrl(dev);
#endif
}

static int sfx_remove_dead_ctrl(void *arg)
{
	struct sfx_dev *dev = (struct sfx_dev *)arg;
	struct pci_dev *pdev = dev->pci_dev;

	if (pci_get_drvdata(pdev))
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 4, 0)
		pci_remove_bus_device(pdev);
#else
		pci_stop_and_remove_bus_device(pdev);
#endif
	kref_put(&dev->kref, sfx_free_dev);
	return 0;
}

static int sfx_dev_resume(struct sfx_dev *dev)
{
	int ret;

	ret = sfx_dev_start(dev);
	if (ret && ret != -EBUSY)
		return ret;
	dev->initialized = 1;
	return 0;
}

void sfx_hotreset_rm_ctrl(struct sfx_dev *dev, char *when)
{
	if (IS_ERR(kthread_run(sfx_remove_dead_ctrl, dev, "sfx%d_hotreset_rm_ctrl", dev->instance))) {
		dev_err(&dev->pci_dev->dev, "%s, Failed to start controller remove task at %s\n", dev->name,
			when);
		kref_put(&dev->kref, sfx_free_dev);
	} else {
		sfx_pr_info("%s: %s, dead ctrl removed at %s\n", __FUNCTION__, dev->name, when);
	}
}

void sfx_hotreset_q_failed_ctrl(struct sfx_dev *dev, char *when)
{
	sfx_pr_info("%s: %s, ctrl failed at %s\n", __FUNCTION__, dev->name, when);
	sfx_remove_sysfiles(dev);
	sfx_remove_injection(dev);
	dev->inject_active = 0;
	dev->fail_flg = 1;
}

void sfx_dev_hotreset(struct sfx_dev *dev)
{
	int vecs;
	xt_u32 scratch_hi;
	int result;
	xt_u32 aqa;
	xt_u64 cap = sfx_readq(&dev->bar->cap);
	struct sfx_queue *nvmeq;
	xt_u32 v = 1;

	/* sfx_bd_dev is unloaded.
     * has only admin_queue.
     */
	if (!dev->bar || ((v = sfx_readl(&dev->bar->csts)) == -1) || v == 0xdeadbeef) {
		sfx_pr_info("%s: %s, !dev->bar or csts == 0x%x\n", __FUNCTION__, dev->name, v);
		sfx_hotreset_rm_ctrl(dev, "pf_trigger");
		return;
	} else {
		BUG_ON(dev->queue_count != 1);
		BUG_ON(dev->online_queues != 1);
		BUG_ON(!dev->queues[0]);
		/* suspend q, free_irq, process_cq and cancel_ios */
		sfx_disable_queue(dev, 0); /* online_queue -> 0 */
	}

	MSI_X_DISABLE();

	sfx_msleep(10);

	/* nvme hot reset */
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x40000000);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: wrote 0x40000000 to SFX_RST_CTRL\n", __FUNCTION__);
#endif
	sfx_mdelay(100);

	scratch_hi = fis_indirect_read32(dev, dev->bar, SCRATCH_HI);
	sfx_pr_info("%s: after reset, scratch_hi = 0x%08x\n", __FUNCTION__, scratch_hi);

	nvmeq = raw_nvmeq(dev, 0);
	if (!nvmeq) {
		sfx_pr_err("%s: %s, !nvmeq[0]\n", __FUNCTION__, dev->name);
		BUG();
	}
	aqa = nvmeq->q_depth - 1;
	aqa |= aqa << 16;

#ifdef MQ_NEWHW
	dev->ctrl_config = NVME_CC_ENABLE | NVME_CC_CSS_NVM | NVME_CC_ARB_VS;
#else
	dev->ctrl_config = NVME_CC_ENABLE | NVME_CC_CSS_NVM;
#endif
	dev->ctrl_config |= (SFX_PAGE_SHIFT - 12) << NVME_CC_MPS_SHIFT;
	dev->ctrl_config |= NVME_CC_ARB_RR | NVME_CC_SHN_NONE;
	dev->ctrl_config |= NVME_CC_IOSQES | NVME_CC_IOCQES;

	sfx_writel(aqa, &dev->bar->aqa);
	sfx_writeq(nvmeq->sq_dma_addr, &dev->bar->asq);
	sfx_writeq(nvmeq->cq_dma_addr, &dev->bar->acq);
	sfx_writel(dev->ctrl_config, &dev->bar->cc);

	result = sfx_enable_ctrl(dev, cap);
	if (result == -ENODEV) {
		sfx_pr_err("%s: %s, sfx_enable_ctrl failed with -ENODEV\n", __FUNCTION__, dev->name);
		sfx_hotreset_q_failed_ctrl(dev, "enable_ctrl");
		return;
	}

	vecs = sfx_pci_enable_msix_range(dev->pci_dev, dev->entry, 1, 1);
	if (vecs <= 0) {
		sfx_pr_err("%s: %s, pci_enable_msix_range() for adminq failed, return\n", __FUNCTION__,
			   dev->name);
		sfx_hotreset_q_failed_ctrl(dev, "enable_msix");
		return;
	}
	if (!dev->entry[0].vector) {
		sfx_pr_err("%s: %s, !dev->entry[0].vector\n", __FUNCTION__, dev->name);
		sfx_hotreset_q_failed_ctrl(dev, "!vector");
		return;
	} else {
		sfx_pr_err("%s: %s, dev->entry[0].vector %d for adminq\n", __FUNCTION__, dev->name,
			   dev->entry[0].vector);
	}

	if ((result = queue_request_irq(dev, nvmeq, nvmeq->irqname))) {
		sfx_pr_err("%s: %s, queue_request_irq q[0] failed, %d returned\n", __FUNCTION__, dev->name,
			   result);
		sfx_hotreset_q_failed_ctrl(dev, "request_irq");
		return;
	}

	sfx_spin_lock_irq(&nvmeq->q_lock);
	sfx_init_queue(nvmeq, 0);
	sfx_spin_unlock_irq(&nvmeq->q_lock);

#if 0
	/* This section of code may not be needed. */
	/* Can be deleted if no regression occurs after this check-in */
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x3f0);
	sfx_msleep(1);
	fis_indirect_write32(dev, dev->bar, SFX_RST_CTRL, 0x0);
	sfx_msleep(1);
#endif

	BUG_ON(dev->queue_count != 1);
	BUG_ON(dev->online_queues != 1);

	if ((result = sfx_init_card(dev))) {
		sfx_pr_info("%s: %s sfx_init_card() failed\n", __FUNCTION__, dev->name);
		sfx_hotreset_q_failed_ctrl(dev, "init_card");
		return;
	}
	sfx_pr_info("%s: %s done\n", __FUNCTION__, dev->name);
}

void sfx_dev_reset(struct sfx_dev *dev)
{
	sfx_driver_shutdown(dev);
	sfx_dev_shutdown(dev);
	sfx_msleep(10);
	if (sfx_dev_resume(dev)) {
		dev_err(&dev->pci_dev->dev, "%s, Device failed to resume\n", dev->name);
		kref_get(&dev->kref);
		if (IS_ERR(kthread_run(sfx_remove_dead_ctrl, dev, "nvme%d", dev->instance))) {
			dev_err(&dev->pci_dev->dev, "%s, Failed to start controller remove task\n",
				dev->name);
			kref_put(&dev->kref, sfx_free_dev);
		}
	}
}

static void sfx_reset_failed_dev(struct work_struct *ws)
{
	struct sfx_dev *dev = container_of(ws, struct sfx_dev, reset_work);
	sfx_dev_reset(dev);
}

static void sfx_reset_workfn(struct work_struct *work)
{
	struct sfx_dev *dev = container_of(work, struct sfx_dev, reset_work);
	dev->reset_workfn(work);
}

/*
 * Initialize the memory for instance based sfx stats and counters.
 */
void sfx_init_stats_cntrs(struct sfx_dev *dev)
{
	memset(&dev->sfx_stats, 0, sizeof(struct sfx_stats));
	memset(&dev->sfx_cntrs, 0, sizeof(struct sfx_cntrs));
}

int sfx_get_pci_dev_info(struct pci_dev *pdev)
{
	/* Added by JPLi, Apr.8, 2015 */

	u16 VendorID, DeviceID;
	u8 pr_offset[6], CID_offset[6];
	u32 data, data1;
	int cnt_pci_set = 0; /* cnt_register=0; */
	u16 cmd;
	u8 pin;

	F_ENTER;

	pci_read_config_word(pdev, PCI_VENDOR_ID, &VendorID);
	pci_read_config_word(pdev, PCI_DEVICE_ID, &DeviceID);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: pdev 0x%p\n", __FUNCTION__, pdev);
	sfx_pr_info("    Vendor_ID:0x%x\n", VendorID);
	sfx_pr_info("    Device_ID:0x%x\n", DeviceID);
#endif
	if (VendorID == 0xFFFF || DeviceID == 0xFFFF)
		return -1;

	pci_read_config_byte(pdev, PCI_INTERRUPT_PIN, &pin);
	if (pin) {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("    Using interrrupt pin, pdev->irq %d\n", pdev->irq);
#else
		sfx_pr_info("    Vendor_ID:0x%x Device_ID:0x%x pdev->irq %d\n", VendorID, DeviceID,
			    pdev->irq);
#endif
		pci_read_config_word(pdev, PCI_COMMAND, &cmd);
		if (!(cmd & PCI_COMMAND_INTX_DISABLE)) {
			/*sfx_pr_info("    set PCI_COMMAND_INTX_DISABLE\n");*/
			pci_write_config_word(pdev, PCI_COMMAND, cmd | PCI_COMMAND_INTX_DISABLE);
		}
	} else {
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("    Not using interrrupt pin\n");
#else
		sfx_pr_info("    Vendor_ID:0x%x Device_ID:0x%x, Not using interrrupt pin\n", VendorID,
			    DeviceID);
#endif
	}

	pci_read_config_byte(pdev, PCI_CAPABILITY_LIST, pr_offset);
	while (cnt_pci_set < 5) {
		/* get the current register set ID */
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("    pr_offset[%d] 0x%x\n", cnt_pci_set, pr_offset[cnt_pci_set]);
#endif
		pci_read_config_byte(pdev, pr_offset[cnt_pci_set], &CID_offset[cnt_pci_set]);
		if (CID_offset[cnt_pci_set] == PCI_CAP_ID_MSI) { /* MSICAP */
			pci_read_config_word(pdev, pr_offset[cnt_pci_set] + PCI_MSI_FLAGS, (u16 *)&data);
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("    MSICAP/MC:0x%04x pr_offset[%d]\n", data, cnt_pci_set);
#endif
		}

		if (CID_offset[cnt_pci_set] == PCI_CAP_ID_MSIX) { /* MSIXCAP */
			pci_read_config_word(pdev, pr_offset[cnt_pci_set] + PCI_MSIX_FLAGS, (u16 *)&data1);
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("    MSIXCAP/MC:0x%02x pr_offset[%d]\n", data, cnt_pci_set);
#endif
		}

		/* get the next address */
		pci_read_config_byte(pdev, pr_offset[cnt_pci_set] + 1, &pr_offset[cnt_pci_set + 1]);
		if (pr_offset[++cnt_pci_set] == 0x00) {
			break;
		}
	}

	if (cnt_pci_set == 5)
		sfx_pr_info("    No MSI[X]CAP available from PCI_CAPABILITY_LIST\n");
	/*else
		sfx_pr_info("    MSICAP/MC:0x%04x MSIXCAP/MC:0x%02x\n", data, data1); */
	return 0;
}

static DEVICE_ATTR(goldimg, S_IWUSR | S_IRUGO, NULL, NULL);

static ssize_t fw_act_status_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);

	return sfx_sprintf(buf, "%08x\n", fis_indirect_read32(sdev, sdev->bar, 0x0000507C));
}
static DEVICE_ATTR(fwactstatus, S_IRUGO, fw_act_status_show, NULL);

static ssize_t fw_act_mode_set(struct device *dev, struct device_attribute *attr, const char *buf,
			       size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	unsigned int n = 0;

	sscanf(buf, "%u", &n);
	if (n == 1) {
		sfx_pr_info("%s: %s, set fw_act_mode_set for dev %p\n", __FUNCTION__, sdev->name, sdev);
		fis_indirect_write32(sdev, sdev->bar, 0x0000507C, 0x0A0A0505);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0xffffffff);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x5599AA66);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x04000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x0C400080);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x00000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x0C000180);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x04000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000120, 0xFEEDBABE);
		sfx_msleep(1);
		fis_indirect_write32(sdev, sdev->bar, 0x0000507C, 0x0A0A0505);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0xffffffff);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x5599AA66);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x04000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x0C400080);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x00000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x0C000180);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x000000F0);
		fis_indirect_write32(sdev, sdev->bar, 0x01000124, 0x04000000);
		fis_indirect_write32(sdev, sdev->bar, 0x01000120, 0xFEEDBABE);
		sdev->fw_act_mode = 1;
		sfx_msleep(1000);
		return count;
	} else {
		sfx_pr_info("%s: %s, n=%u for dev  %p\n", __FUNCTION__, n, sdev->name, sdev);
		return -1;
	}
}
static DEVICE_ATTR(fwactmode, S_IWUSR, NULL, fw_act_mode_set);

static ssize_t ledact_get(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);

	return sfx_sprintf(buf, "%08x\n", fis_indirect_read32(sdev, sdev->bar, REG_MISC_CONTROL));
}
static DEVICE_ATTR(ledactget, S_IRUGO, ledact_get, NULL);

static ssize_t ledact_set(struct device *dev, struct device_attribute *attr, const char *buf, size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	unsigned int n = 0;
	xt_u32 misc_control, reg_val = 0;

	sscanf(buf, "%u", &n);
	if ((n >= 1) && (n <= 4)) {
		// 0001_0000 - 000 + software_control, ON
		// 0011_0000 - 001 + software_control, OFF
		// 0101_0000 - 010 + software_control, OFF
		// 0111_0000 - 011 + software_control, OFF
		reg_val = 0x10 + (n - 1) * 0x20;
	} else if (n == 5) {
		sdev->ledactoset = 1;
	} else {
		if (n != 0) {
			sfx_pr_info("%s: n=%u for dev %s(%p)\n", __FUNCTION__, n, sdev->name, sdev);
			return -1;
		} /* else -> reg_val = 0: hardware_control, default */
	}
	sfx_pr_info("%s: set activity led for dev %s(%p)\n", __FUNCTION__, sdev->name, sdev);
	/* Turn off activity led */
	misc_control = fis_indirect_read32(sdev, sdev->bar, REG_MISC_CONTROL);
	reg_val |= (misc_control & LED_CONTROL_MASK);
	sfx_pr_info("%s: misc_control 0x%08x, set to 0x%x\n", __FUNCTION__, misc_control, reg_val);
	fis_indirect_write32(sdev, sdev->bar, REG_MISC_CONTROL, reg_val);
	// sdev->blink_mode = 1;
	sfx_msleep(1000);
	return count;
}
static DEVICE_ATTR(ledactset, S_IWUSR, NULL, ledact_set);

static ssize_t sfx_cc_status_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);

	return sfx_sprintf(buf, "%08x\n", sdev->to_clean);
}
static DEVICE_ATTR(sfxccstatus, S_IRUGO, sfx_cc_status_show, NULL);

static ssize_t sfx_cc_set(struct device *dev, struct device_attribute *attr, const char *buf, size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	unsigned int n = 0;

	sscanf(buf, "%x", &n);
	if (n != 0xccbeefcc) {
		sfx_pr_info("%s: %s invalid n=0x%x\n", __FUNCTION__, sdev->name, n);
		return -1;
	}
	sfx_pr_info("%s: %s sfxcc=0x%x, set to_clean\n", __FUNCTION__, sdev->name, n);
	sdev->to_clean = 1;
	sfx_msleep(1000);
	return count;
}
static DEVICE_ATTR(sfxcc, S_IWUSR, NULL, sfx_cc_set);

static ssize_t sfx_probecnt_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);

	return sfx_sprintf(buf, "%08x %08x\n", sdev->probe_cnt, sdev->probe_cnt_limit);
}
static ssize_t sfx_probecnt_set(struct device *dev, struct device_attribute *attr, const char *buf,
				size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	xt_u32 n = 0;

	sscanf(buf, "%x", &n);
	sfx_pr_info("%s: %s arg=0x%x\n", __FUNCTION__, sdev->name, n);
	if (n == 0x8) {
		sfx_mutex_lock(&sdev->nor_sw_lock);
		if (sfxdriver_spi_init(sdev)) {
			sfx_mutex_unlock(&sdev->nor_sw_lock);
			sfx_pr_err("%s: %s, sfxdriver_spi_init() failed", __FUNCTION__, sdev->name);
			return -1;
		}
		/* erase set to all 1's */
		if (sfxdriver_norsw_erase_data(sdev, NOR_IDENTITY_SW_PROBECNT_OFFSET, BYTE_PER_SUBSECTOR)) {
			sfx_pr_err("%s: %s, erase 4K failed", __FUNCTION__, sdev->name);
		}
		sfxdriver_spi_exit(sdev);
		sfx_mutex_unlock(&sdev->nor_sw_lock);
		sfx_pr_info("%s: %s nor is reinitialized\n", __FUNCTION__, sdev->name);
		return count;
	}
	sdev->probe_cnt_limit = n;
	sfx_msleep(1000);
	return count;
}
static DEVICE_ATTR(probecnt, (S_IRUGO | S_IWUSR), sfx_probecnt_show, sfx_probecnt_set);

static ssize_t sfx_forceprobe_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);

	return sfx_sprintf(buf, "%08x\n", sdev->force_probe);
}
static ssize_t sfx_forceprobe_set(struct device *dev, struct device_attribute *attr, const char *buf,
				  size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	unsigned int n = 0;

	sscanf(buf, "%x", &n);
	if (n != 0x9) {
		sfx_pr_info("%s: %s invalid n=0x%x\n", __FUNCTION__, sdev->name, n);
		return -1;
	}
	//sfx_pr_info("%s: %s force_probe=0x%x\n", __FUNCTION__, sdev->name, n);
	sdev->force_probe = 1;
	//    sfx_msleep(1000);
	return count;
}
static DEVICE_ATTR(forceprobe, (S_IRUGO | S_IWUSR), sfx_forceprobe_show, sfx_forceprobe_set);

static ssize_t keep_disk_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n", sdev->keep_disk);
}

static ssize_t keep_disk_store(struct device *dev, struct device_attribute *attr, const char *buf,
			       size_t count)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *sdev = pci_get_drvdata(pdev);
	int val = simple_strtol(buf, NULL, 0);
	val = val ? 1 : 0;
	sdev->keep_disk = val;
	SFX_INFO("%s: %d keep_disk=%d\n", __func__, sdev->name, sdev->keep_disk);
	return count;
}

static DEVICE_ATTR(keep_disk, S_IWUSR | S_IRUGO, keep_disk_show, keep_disk_store);

int sfx_probe(struct pci_dev *pdev, const struct pci_device_id *id)
{
	int node, result = -ENOMEM;
	struct sfx_dev *dev;

	if (sfx_get_pci_dev_info(pdev) < 0) {
		sfx_pr_err("%s: sfx_get_pci_dev_info() failed, return -EFAULT\n", __FUNCTION__);
		return -EFAULT;
	}

	node = dev_to_node(&pdev->dev);
	if (node == NUMA_NO_NODE) {
		sfx_pr_err("%s: NUMA_NO_NODE, set_dev_node(0)\n", __FUNCTION__);
		set_dev_node(&pdev->dev, 0);
		node = dev_to_node(&pdev->dev);
	}

	dev = kzalloc_node(sizeof(*dev), GFP_KERNEL, node);
	if (!dev) {
		sfx_pr_err("%s: kzalloc_node(size=%u) failed, return -ENOMEM\n", __FUNCTION__, sizeof(*dev));
		return -ENOMEM;
	}

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: sizeof(*dev) %u\n", __FUNCTION__, sizeof(*dev));
#endif

	/*
     * Initialize the following device based structs
     * struct task_struct *sfx_thread;
     * struct workqueue_struct *sfx_workq;
     * wait_queue_head_t sfx_kthread_wait;
     * struct notifier_block sfx_nb;
     */

	dev->sfx_nb.notifier_call = &sfx_cpu_notify;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	result = register_hotcpu_notifier(&dev->sfx_nb);
	if (result) {
		sfx_pr_err("%s: %p after register_hot_cpu_notifier %d returned\n", __FUNCTION__, dev, result);
		goto free_dev;
	}
#endif

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	dev->vecnt = pci_msix_vec_count(pdev);
#else
	dev->vecnt = MAX_Q_NUM;
#endif
	/*sfx_pr_info("%s: node=%d msix_vec_count=%d CONFIG_NR_CPUS %d cpu_online_mask 0x%*pb\n", __FUNCTION__,
		    node, dev->vecnt, CONFIG_NR_CPUS, cpumask_pr_args(cpu_online_mask));*/
	dev->entry = kzalloc_node((min(dev->vecnt, MAX_Q_NUM) * sizeof(*dev->entry)), GFP_KERNEL, node);
	if (!dev->entry) {
		sfx_pr_err("%s: %p kzalloc_node vecnt*sizeof(*dev->entry) failed, num_cpus %d\n",
			   __FUNCTION__, dev, (min(dev->vecnt, MAX_Q_NUM) * sizeof(*dev->entry)),
			   num_possible_cpus());
		goto free;
	}
	dev->queues = kzalloc_node((min(dev->vecnt, MAX_Q_NUM) * sizeof(void *)), GFP_KERNEL, node);
	if (!dev->queues) {
		sfx_pr_err("%s: %p kzalloc_node sizeof(*dev->queues) %lu failed\n", __FUNCTION__, dev,
			   (min(dev->vecnt, MAX_Q_NUM) * sizeof(void *)));
		goto free;
	}

#ifdef MQ_IRQSHARED
	if (!zalloc_cpumask_var_node(&dev->msix_requested, GFP_KERNEL, node))
		goto free;
#endif

	dev->page_mgr.initDone = 0;
	result = sfx_page_list_init(dev);
	if (result) {
		sfx_pr_err("%s: %p sfx_page_list_init faulty: result %d \n", __FUNCTION__, dev, result);
		goto free;
	}

	/* Initialize device level stats and counters */
	sfx_init_stats_cntrs(dev);

	/* make sure the lock is not used before this point. */
	spin_lock_init(&dev->indirect_reg_lock);
	dev->reset_workfn = sfx_reset_failed_dev;
	INIT_WORK(&dev->reset_work, sfx_reset_workfn);
	INIT_WORK(&dev->cpu_work, sfx_cpu_workfn);
	dev->pci_dev = pdev;
	pci_set_drvdata(pdev, dev);
	result = sfx_set_instance(dev);
	if (result) {
		sfx_pr_err("%s: %p sfx_set_instacne failed\n", __FUNCTION__, dev);
		goto free;
	}
	scnprintf(dev->name, sizeof(dev->name), DEV_NAME_prefix "%d", dev->instance);

	result = sfx_setup_prp_pools(dev);
	if (result) {
		sfx_pr_err("%s: %s sfx_setup_prp_pools failed\n", __FUNCTION__, dev->name);
		goto release_free;
	}

	kref_init(&dev->kref);
	sfx_mutex_init(&dev->nor_sw_lock);
	result = sfx_dev_start(dev);
	if (result) {
		if (result == -ENXIO) {
			sfx_pr_err("%s: %s sfx_dev_start() return -ENXIO, create_cdev for debug\n",
				   __FUNCTION__, dev->name);
			goto create_cdev;
		}
		sfx_pr_err("%s: %s sfx_dev_start() failed %d returned, goto release_pools\n", __FUNCTION__,
			   dev->name);
		goto release_pools;
	}

	/* MD-TAG: Need to handle unwinding when error happens */
	sfx_atomic_inc(&s_dev_cnt);
	sfx_atomic_inc(&bd_probe_cnt);

#ifdef TEST_DMA_ALLOC_COHERENT
	result = sfx_dev_add(dev);
#endif

	/* Error injection init */
	INIT_LIST_HEAD(&dev->inject_list);
	INIT_LIST_HEAD(&dev->errobj_list);
	spin_lock_init(&dev->inject_lock);
	spin_lock_init(&dev->errobj_lock);
	dev->inject_active = 0;
	dev->fail_flg = 0;

	scnprintf(dev->devfname, sizeof(dev->devfname), DEV_FILE_NAME_prefix "%d", dev->instance);
	dev->numa_node = pdev->dev.numa_node;

	if (dev->goldimg) {
		if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_goldimg.attr))
			sfx_pr_err("%s: %s, goldimg, failed to sysfs_create_file goldimg\n", __FUNCTION__,
				   dev->name);
	}
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_fwactstatus.attr))
		sfx_pr_err("%s: %s, failed to sysfs_create_file fwactstatus\n", __FUNCTION__, dev->name);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_fwactmode.attr))
		sfx_pr_err("%s: %s, failed to sysfs_create_file fwactmode\n", __FUNCTION__, dev->name);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_ledactget.attr))
		sfx_pr_err("%s: failed to sysfs_create_file ledactget\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_ledactset.attr))
		sfx_pr_err("%s: failed to sysfs_create_file ledactset\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_sfxccstatus.attr))
		sfx_pr_err("%s: failed to sysfs_create_file sfxccstatus\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_sfxcc.attr))
		sfx_pr_err("%s: failed to sysfs_create_file sfxcc\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_probecnt.attr))
		sfx_pr_err("%s: failed to sysfs_create_file probecnt\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_forceprobe.attr))
		sfx_pr_err("%s: failed to sysfs_create_file forceprobe\n", __FUNCTION__);
	if (sysfs_create_file(&(pdev->dev.kobj), &dev_attr_keep_disk.attr))
		sfx_pr_err("%s: failed to sysfs_create_file keep_disk\n", __FUNCTION__);

	sfx_init_fw(dev);
	dev->probe_cnt_limit = PROBE_CNT;
	SFX_INIT_LIST_HEAD(&dev->ftl_mq_ctx.probe_on);

	/*create a thread to do dev probe*/
	sfx_read_lock(&driver_list_lock);
	if (!sfx_list_empty(&driver_list)) {
		sfx_thread_t probe_thread;
		if (IS_ERR((void *)(unsigned long)sfx_thread_create(&probe_thread, &sfx_dev_probe_thread, dev,
								    "sfx_dev_probe"))) {
			sfx_pr_err("%s: Failed to start sfx_dev_probe\n", __FUNCTION__);
			sfx_read_unlock(&driver_list_lock);
			goto remove;
		}
	}
	sfx_read_unlock(&driver_list_lock);

	cpumax = sfx_num_online_cpus();
	sfx_atomic_set(&cpuidx, 0);
	cpumask_clear(&cpumask_g);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: cpumax %d cpuidx %d\n", __FUNCTION__, cpumax, cpuidx);
#endif

create_cdev : {
/* test_mem is created for sfx_reg_read() and sfx_req_write().
         * It contains data be read/written from/to a register at a
         * user specified address.
         */
#define MAILBOX_BASE (0x5000)
	dev->test_mem = dma_alloc_coherent(&pdev->dev, TEST_MEM_SIZE, &dev->test_dma_addr, GFP_KERNEL);

	/*sfx_pr_info("%s:    pcie_mailbox(0x5000):0x%08x\n", __FUNCTION__,
			    fis_indirect_read32(dev, dev->bar, MAILBOX_BASE));*/
}

	dev->miscdev.minor = MISC_DYNAMIC_MINOR;

	dev->miscdev.parent = &pdev->dev;
	dev->miscdev.name = dev->name;
	dev->miscdev.fops = &sfx_dev_fops;
	result = misc_register(&dev->miscdev);
	if (result) {
		if (pdev->slot && dev->opn[3] == 'U')
			sfx_pr_info(
				"%s: misc_register failed %d returned, dev:%p instance %d slot %s goto remove\n",
				__FUNCTION__, result, dev, dev->instance, pci_slot_name(pdev->slot));
		else
			sfx_pr_info("%s: misc_register failed %d returned, dev:%p instance %d goto remove\n",
				    __FUNCTION__, result, dev, dev->instance);
		goto remove;
	}

	dev->initialized = 1;

#ifdef SFXDRIVER_BASE_DEBUG
	if (pdev->slot && dev->opn[3] == 'U') {
		sfx_pr_info("%s: miscdev: %p dev:%p instance %d slot %s\n", __FUNCTION__, &dev->miscdev, dev,
			    dev->instance, pci_slot_name(pdev->slot));
	} else {
		sfx_pr_info("%s: miscdev: %p dev:%p instance %d\n", __FUNCTION__, &dev->miscdev, dev,
			    dev->instance);
	}
#endif

	F_LEAVE;
	return 0;

remove:
	/* sfx_free_namespaces(dev); */
release_pools:
	/* when sfx_dev_start() fails, adminq is not created
     * or is freed and dev is unmapped.
     */
	sfx_release_prp_pools(dev);
release_free:
	sfx_release_instance(dev->instance);
free:
	if (dev->queues) {
		kfree(dev->queues);
	}
	if (dev->entry) {
		kfree(dev->entry);
	}

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
	unregister_hotcpu_notifier(&dev->sfx_nb);

free_dev:
#endif
	kfree(dev);

	F_LEAVE;
	return result;
}

void sfx_shutdown(struct pci_dev *pdev)
{
	struct sfx_dev *dev = pci_get_drvdata(pdev);
	sfx_driver_shutdown(dev);
	sfx_dev_shutdown(dev);
}

void sfx_remove_sysfiles(struct sfx_dev *dev)
{
	if (dev->goldimg) {
		sfx_pr_info("%s: %s, remove sysfile goldimg\n", __FUNCTION__, dev->name);
		sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_goldimg.attr);
	}
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s remove sysfile fwactstatus\n", __FUNCTION__, dev->name);
#endif
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_fwactstatus.attr);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s remove sysfile fwactmode\n", __FUNCTION__, dev->name);
#endif
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_fwactmode.attr);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s remove sysfile ledactget\n", __FUNCTION__, dev->name);
#endif
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_ledactget.attr);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s remove sysfile ledactset\n", __FUNCTION__, dev->name);
#endif
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_ledactset.attr);
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_sfxccstatus.attr);
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_sfxcc.attr);
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_probecnt.attr);
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_forceprobe.attr);
	sysfs_remove_file(&(dev->pci_dev->dev.kobj), &dev_attr_keep_disk.attr);

	if (dev->block_kobj) {
		kobject_put(dev->block_kobj);
	}
}

void sfx_remove(struct pci_dev *pdev)
{
	struct sfx_dev *dev = pci_get_drvdata(pdev);

	F_ENTER;

	if (!dev) {
		sfx_pr_err("%s: Try to access NULL dev\n", __FUNCTION__);
		return;
	}
	mutex_lock(&sfx_remove_mutex);
	//sfx_pr_info("%s: %s(%p) ===== s\n", __FUNCTION__, dev->name, dev);

	// if ((dev->init_err == 0) && (dev->init_fatal_err == 0))
	if (match_dev_list(dev)) {
		// the card has good did and valid opn and nand was successfully initialized.
		if (!dev->goldimg) {
			// turn off read_refresh, used by bics3 nand
			fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_0, 0x0);
			fis_indirect_write32(dev, dev->bar, READ_REFRESH_CTRL_1, 0x0);
			sfx_msleep(10);
			/*sfx_pr_info("%s: %s, READ_REFRESH_CTRL_0=0x%x\n", __FUNCTION__, dev->name,
				    fis_indirect_read32(dev, dev->bar, READ_REFRESH_CTRL_0));
			sfx_pr_info("%s: %s, READ_REFRESH_CTRL_1=0x%x\n", __FUNCTION__, dev->name,
				    fis_indirect_read32(dev, dev->bar, READ_REFRESH_CTRL_1));*/
		}
		sfx_driver_remove(dev);
		sfx_remove_sysfiles(dev);
		sfx_remove_injection(dev);
	} else if (match_fail_list(dev)) {
		sfx_pr_info("%s: %s: on fail_dev_list, skip bd remove, release source and unreg cdev\n",
			    __FUNCTION__, dev->name);
	} else {
		sfx_pr_info("%s: %s: not on dev_list, skip sfx_remove.\n", __FUNCTION__, dev->name);
		goto exit;
	}

	if (dev->test_mem) {
		dma_free_coherent(&pdev->dev, TEST_MEM_SIZE, dev->test_mem, dev->test_dma_addr);
		dev->test_mem = NULL;
	}

	pci_set_drvdata(pdev, NULL);
	flush_work(&dev->reset_work);
	flush_work(&dev->cpu_work);
	misc_deregister(&dev->miscdev);

	sfx_dev_shutdown(dev);
	sfx_free_queues(dev, 0);
	rcu_barrier();
	/*do not release ida_instance if related block_device is not idle*/
	if (sfx_atomic_read(&dev->blk_ref_cnt) == 0 || dev->force_ida_release) {
		sfx_release_instance(dev->instance);
	}
	sfx_release_prp_pools(dev);
	/*sfx_pr_info("%s: %s q/ioq count %u/%u, do sfx_free_dev()\n", __FUNCTION__, dev->name,
		    dev->queue_count, dev->ioqueue_count);*/
	kref_put(&dev->kref, sfx_free_dev);

	sfx_destroy_spinlock(&dev->indirect_reg_lock);
	sfx_destroy_spinlock(&dev->page_mgr.pages_list_lock);
	sfx_destroy_spinlock(&dev->inject_lock);
	sfx_destroy_spinlock(&dev->errobj_lock);
	sfx_mutex_destroy(&dev->nor_sw_lock);

exit:
	mutex_unlock(&sfx_remove_mutex);

	//sfx_pr_info("%s: %s, done ===== e\n", __FUNCTION__, dev->name);

	F_LEAVE;
}

#ifdef CONFIG_PM_SLEEP
int sfx_suspend(struct device *dev)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *ndev = pci_get_drvdata(pdev);

	sfx_driver_shutdown(ndev);
	sfx_dev_shutdown(ndev);
	return 0;
}

int sfx_resume(struct device *dev)
{
	struct pci_dev *pdev = to_pci_dev(dev);
	struct sfx_dev *ndev = pci_get_drvdata(pdev);

	if (sfx_dev_resume(ndev)) {
		flush_work(&ndev->reset_work);
		ndev->reset_workfn = sfx_reset_failed_dev;
		queue_work(sfx_workq, &ndev->reset_work);
	}
	return 0;
}
#endif

void cpu_rr(void)
{
	cpumask_clear(&cpumask_g);
	cpumask_set_cpu(atomic_read(&cpuidx), &cpumask_g);
	atomic_inc(&cpuidx);
	if (atomic_read(&cpuidx) == cpumax)
		atomic_set(&cpuidx, 0);
}

int sfx_assign_interrupts(struct sfx_dev *dev)
{
	struct sfx_queue *adminq = raw_nvmeq(dev, 0);
	struct pci_dev *pdev = dev->pci_dev;
	int result, i, nr_queues, size;
#ifdef MQ_DEBUG
	unsigned max, idxs;
#else
	unsigned idxs, idxe;
#endif
	int ret = 0;

	nr_queues = dev->queue_count;
	for (i = 0; i < nr_queues; i++) {
		if (!raw_nvmeq(dev, i)) {
			sfx_pr_err("%s: %s, null nvmeq[%d]\n", __FUNCTION__, dev->name, i);
			BUG();
		}
	}
	/*sfx_pr_info("%s: %s, >> number of qs q/ioq/online %u/%u/%d\n", __FUNCTION__, dev->name,
		    dev->queue_count, dev->ioqueue_count, dev->online_queues);*/

	free_irq(dev->entry[0].vector, dev->queues[0]);
	MSI_X_DISABLE();
#ifdef MQ_IRQSHARED
	i = cpumask_weight(dev->msix_requested);
	sfx_pr_info("%s: %s, Need %d msix entries\n", __FUNCTION__, dev->name, i);
	request_msix(dev, min_t(int, dev->vecnt, i));
#else
	request_msix(dev, min_t(int, dev->vecnt, nr_queues));
#endif
	queue_request_irq(dev, dev->queues[0], dev->queues[0]->irqname);

	size = db_bar_size(dev, nr_queues);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: door bell size is %d, dev->bar %p\n", __FUNCTION__, size, dev->bar);
#endif

	if (size > (32 * 1024) /*8192*/) {
		iounmap(dev->bar);
		do {
			dev->bar = ioremap(pci_resource_start(pdev, 0), size);
			if (dev->bar) {
				sfx_pr_info("%s: %s, size %d nr_queues %d dev->bar %p, break\n", __FUNCTION__,
					    dev->name, size, nr_queues, dev->bar);
				break;
			}
			if (!--nr_queues)
				return -ENOMEM;
			size = db_bar_size(dev, nr_queues);
		} while (1);
		dev->dbs = ((void __iomem *)dev->bar) + 4096;
		adminq->q_db = dev->dbs;
	}

#ifdef MQ_DEBUG
	if (!pdev->irq) {
		sfx_pr_info(
			"+++++++++%s: %s, NO INTx, !pdev->irq, call pci_disable_msix pin %u dev->entry[0].vector %u\n",
			__FUNCTION__, dev->name, pdev->pin, dev->entry[0].vector);
	} else
		sfx_pr_info("+++++++++%s: %s, pdev->irq %u, pin %u dev->entry[0].vector %u\n", __FUNCTION__,
			    dev->name, pdev->irq, pdev->pin, dev->entry[0].vector);
#endif

	idxs = dev->online_queues;
	BUG_ON(idxs <= 0);
	idxe = (idxs + (nr_queues - dev->online_queues)) - 1;
	for (i = idxs; i <= idxe; i++) {
		struct sfx_queue *q = raw_nvmeq(dev, i);

		if (q) {
			result = queue_request_irq(dev, q, q->irqname);
			if (result < 0) {
				sfx_pr_info("%s: %s, i %d queue_request_irq for q[%u] failed\n", __FUNCTION__,
					    dev->name, i, q->qid);
				adapter_delete_sq(dev, i);
				adapter_delete_cq(dev, i);
			} else {
				spin_lock_irq(&q->q_lock);
				sfx_init_queue(q, i);
				spin_unlock_irq(&q->q_lock);

				if (cpumask_empty(q->cpu_mask))
					sfx_pr_info("%s: %s, empty q[%d]->cpu_mask\n", __FUNCTION__,
						    dev->name, i);

				if (cpumask_equal(q->cpu_mask, cpu_online_mask) &&
				    (q->q_type == SFX_MIXED_WRQ || q->q_type == SFX_MIXED_RDQ ||
				     q->q_type == SFX_HOT_B2NQ)) {
#ifdef SFXDRIVER_DEBUG
					sfx_pr_info("%s: %s, q[%d].cpu_mask %*pb\n", __FUNCTION__, dev->name,
						    q->qid, cpumask_pr_args(q->cpu_mask));
#endif
					cpu_rr();
					cpumask_copy(q->cpu_mask, &cpumask_g);
#ifdef SFXDRIVER_DEBUG
					sfx_pr_info("%s: %s, q[%d].cpu_mask %*pb\n", __FUNCTION__, dev->name,
						    q->qid, cpumask_pr_args(q->cpu_mask));
#endif
				}

				if ((ret = irq_set_affinity_hint(dev->entry[q->cq_vector].vector,
								 q->cpu_mask))) {
					sfx_pr_err(
						"%s: %s, irq_set_affinity_hint(IRQ%d->CPUMASK %*pb) for q[%d] failed, %d returned\n",
						__FUNCTION__, dev->name, dev->entry[q->cq_vector].vector,
						cpumask_pr_args(q->cpu_mask), q->qid, ret);
				}
#ifdef SFXDRIVER_DEBUG
				sfx_pr_info("%s, set affinity(IRQ%d->CPUMASK %*pb) for q[%d] phase %u\n",
					    dev->name, dev->entry[q->cq_vector].vector,
					    cpumask_pr_args(q->cpu_mask), q->qid, q->cq_phase);
#endif
				ret = sfx_set_irq_affinity(dev->entry[q->cq_vector].vector, q->cpu_mask,
							   false);
				if (ret < 0 || ret > 2) {
					sfx_pr_info("%s: %s, !!! sfx_set_irq_affinity returns %d\n",
						    __FUNCTION__, dev->name, ret);
				}
			}
		} else {
			sfx_pr_info("%s: %s, !q[%d]\n", __FUNCTION__, dev->name, i);
			BUG();
		}
	}
	/*sfx_pr_info("%s: %s, << number of qs q/ioq/online %u/%u/%d\n", __FUNCTION__, dev->name,
		    dev->queue_count, dev->ioqueue_count, dev->online_queues);*/
	return 0;
}

xt_u32 sfx_get_irq(void *sfx_driver_handle, xt_u16 qid)
{
	struct sfx_dev *dev = sfx_driver_handle;
	return dev->entry[qid].vector;
}
EXPORT_SYMBOL(sfx_get_irq);

void *sfx_get_nvmeq_lock(void *nvmeq)
{
	struct sfx_queue *q = nvmeq;
	return &(q->q_lock);
}
EXPORT_SYMBOL(sfx_get_nvmeq_lock);

void sfx_dump_driver_counter(void *sfx_driver_handle)
{
	struct sfx_dev *dev = sfx_driver_handle;
	struct sfx_queue *nvmeq;
	xt_u16 qid;

	sfx_pr_info(
		"====================================== Driver Counters ======================================");
	for (qid = 0; qid < dev->queue_count; qid++) {
		nvmeq = dev->queues[qid];
		sfx_pr_info(
			"S[%d]:%-12llu IRQ[%d]:%-12llu IRQ_T[%d]:%-12llu C[%d]:%-12llu CB/Completion[%d]:%-12llu "
			"P[%d]:%-12llu PT[%d]:%-12llu PP[%d]:%-12llu PPT[%d]:%-12llu\n",
			qid, nvmeq->q_stats.sq_counter, qid, nvmeq->q_stats.irq_counter, qid,
			nvmeq->q_stats.irq_counter_total, qid, nvmeq->q_stats.cq_counter, qid,
			nvmeq->q_stats.cpl_counter, qid, nvmeq->q_stats.poll_counter, qid,
			nvmeq->q_stats.poll_total, qid, nvmeq->q_stats.polling_counter, qid,
			nvmeq->q_stats.polling_total);
	}
	sfx_pr_info(
		"============================================================================================\n");
}
EXPORT_SYMBOL(sfx_dump_driver_counter);

int sfx_free_nvmeq(void *sfx_driver_handle, xt_u8 qid)
{
	struct sfx_dev *dev = sfx_driver_handle;
	struct sfx_queue *nvmeq;
#ifdef MQ_IRQSHARED
	int cpu, i;
#endif

	BUG_ON(!dev);
	BUG_ON(!dev->queues[0]);
	if (!qid) {
		sfx_pr_info("%s: !qid, cannot delete adminq, dev %p count q/ioq %u/%u\n", __FUNCTION__, dev,
			    dev->queue_count, dev->ioqueue_count);
		return -EINVAL;
	}
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: enter, dev %p qid %u count q/ioq %u/%u\n", __FUNCTION__, dev, qid, dev->queue_count,
		    dev->ioqueue_count);
#endif

	sfx_disable_queue(dev, qid);
	nvmeq = raw_nvmeq(dev, qid);
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info(
		"%s: S[%d]:%-12llu IRQ[%d]:%-12llu IRQ_T[%d]:%-12llu C[%d]:%-12llu CB/Completion[%d]:%-12llu\n",
		__FUNCTION__, qid, nvmeq->q_stats.sq_counter, qid, nvmeq->q_stats.irq_counter, qid,
		nvmeq->q_stats.irq_counter_total, qid, nvmeq->q_stats.cq_counter, qid,
		nvmeq->q_stats.cpl_counter);
#endif
	rcu_assign_pointer(dev->queues[qid], NULL);
#ifdef MQ_IRQSHARED
	i = 0;
	for_each_cpu (cpu, nvmeq->cpu_mask) {
		if (i > 0) {
			sfx_pr_info("%s: %s, WARNING %d cpu set in q->cpu_mask", __FUNCTION__, dev->name,
				    cpumask_weight(nvmeq->cpu_mask));
			// BUG();
			break;
		}
		sfx_pr_info("%s: %s, clear msix_requested on cpu %d\n", __FUNCTION__, dev->name, cpu);
		if (cpumask_test_and_clear_cpu(cpu, dev->msix_requested))
			sfx_pr_info("%s: %s, Firstime clearing cpu %d on msix_requested\n", __FUNCTION__,
				    dev->name, cpu);
		else
			sfx_pr_info("%s: %s, Reclearing cpu %d on msix_requested\n", __FUNCTION__, dev->name,
				    cpu);
		i++;
	}
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
	sfx_pr_info("%s: %s, msix_requested IRQ %*pb after freeing q[%u]\n", __FUNCTION__, dev->name,
		    cpumask_pr_args(dev->msix_requested), qid);
#endif
#endif
	if (nvmeq->qid && !cpumask_empty(nvmeq->cpu_mask))
		dev->ioqueue_count--;
	call_rcu(&nvmeq->r_head, sfx_free_queue);
	dev->queue_count--;
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: exit, dev %p qid %u count q/ioq %u/%u\n", __FUNCTION__, dev, qid, dev->queue_count,
		    dev->ioqueue_count);
#endif
	return 0;
}
EXPORT_SYMBOL(sfx_free_nvmeq);

static int sfx_check_dev_gone(void *arg)
{
	struct sfx_dev *dev, *next;

	while (!kthread_should_stop()) {
		set_current_state(TASK_INTERRUPTIBLE);
		if (in_hotreset == 1) {
			sfx_msleep(1000);
			sfx_pr_info("%s: in_hotreset, m_sleep(1000)\n", __FUNCTION__);
			continue;
		}
		/*driver or device is doing remove, hold the thread*/
		if (!sfx_read_trylock(&driver_list_lock)) {
			sfx_msleep(1000);
			continue;
		}
		if (sfx_list_empty(&driver_list)) {
			sfx_read_unlock(&driver_list_lock);
			sfx_msleep(1000);
			continue;
		}

		sfx_read_lock(&dev_list_lock);
		if (!sfx_list_empty(&dev_list)) {
			xt_u32 status;
			sfx_list_for_each_entry_safe(dev, next, &dev_list, node)
			{
				status = check_device_gone(dev);
				if (status && !dev->dev_gone_notified) {
					struct sfx_driver *drv = NULL;
					struct sfx_driver *driver = NULL;

					sfx_list_for_each_entry(driver, &driver_list, node)
					{
						if (driver->dev_gone) {
							drv = driver;
							sfx_pr_info("%s: call dev_gone(%s) for driver %s\n",
								    __FUNCTION__, dev->devfname,
								    driver->name);
							driver->dev_gone(dev->devfname);
						}
					}
					dev->dev_gone_notified = 1;
					if (status != NO_BLK_FTL && !dev->goldimg) {
						/* sleep 1ms to wait "ongoing" irq handler finished */
						msleep_interruptible(1);
						ccs_clean_nvme_sq(dev, drv);
					}
				}
			}
		}
		sfx_read_unlock(&dev_list_lock);

		sfx_read_unlock(&driver_list_lock);
		schedule_timeout(round_jiffies_relative(SFX_HZ / 1000));
	}
	return 0;
}

void sfx_stop_threads(void)
{
	if (!IS_ERR_OR_NULL(sfx_kthread_task)) {
		kthread_stop(sfx_kthread_task);
		/* set to NULL because kthread_stop is synchronized */
		sfx_kthread_task = NULL;
	} else {
		sfx_pr_info("%s: already invalid sfx_kthread_task!\n", __FUNCTION__);
	}
	if (!IS_ERR_OR_NULL(check_dev_gone_thread)) {
		kthread_stop(check_dev_gone_thread);
		check_dev_gone_thread = NULL;
	} else {
		sfx_pr_info("%s: already invalid check_dev_gone_thread!\n", __FUNCTION__);
	}
}

void sfx_start_threads(void)
{
	sfx_kthread_task = kthread_run(sfx_kthread, NULL, KBUILD_MODNAME);
	if (IS_ERR_OR_NULL(sfx_kthread_task)) {
		sfx_pr_err("%s: Failed to create sfx_kthread_task\n", __FUNCTION__);
	}
	if (IS_ERR_OR_NULL((void *)(unsigned long)sfx_thread_create(
		    &check_dev_gone_thread, sfx_check_dev_gone, NULL, "sfx_chk_dev_gone"))) {
		sfx_pr_err("%s: Failed to start sfx_check_dev_gone\n", __FUNCTION__);
	}
}

int __init _sfx_dev_init(void)
{
	int result;

	F_ENTER;

	init_waitqueue_head(&sfx_kthread_wait);

	if (strcmp(UTS_RELEASE, utsname()->release) != 0) {
		sfx_pr_err("%s: module built for %s kernel release - cannot be loaded on %s kernel\n",
			   __FUNCTION__, UTS_RELEASE, utsname()->release);
		return -EPERM;
	} else {
		const xt_u8 target_for_preempt = (strlen(MODULE_VERMAGIC_PREEMPT) != 0);
		const xt_u8 running_on_preempt = (strstr(utsname()->version, "PREEMPT") != 0);
		if (target_for_preempt != running_on_preempt) {
			sfx_pr_err("%s: module built for %s kernel - cannot be loaded on %s kernel\n",
				   __FUNCTION__, target_for_preempt ? "preemptible" : "non-preemptible",
				   running_on_preempt ? "preemptible" : "non-preemptible");
			return -EPERM;
		}
	}

	sfx_workq = create_singlethread_workqueue(KBUILD_MODNAME);
	if (NULL == sfx_workq) {
		sfx_pr_err("%s: create_singlethread_workqueue %s failed\n", __FUNCTION__, KBUILD_MODNAME);
		return -ENOMEM;
	}

	sfx_atomic_set(&s_dev_cnt, 0);
	sfx_atomic_set(&bd_probe_cnt, 0);

#ifdef SFX_DRIVER_REGISTER_BLKDEV
	result = register_blkdev(sfx_major, KBUILD_MODNAME);
	if (result < 0) {
		sfx_pr_info("register_blkdev failed\n");
		goto kill_workq;
	} else if (result > 0) {
		sfx_major = result;
	}
#endif

	result = pci_register_driver(&sfx_driver);
	if (result) {
#ifdef SFX_DRIVER_REGISTER_BLKDEV
		goto unregister_blkdev;
#else
		goto kill_workq;
#endif
	}
	sfx_proc_dir = proc_mkdir(DEV_NAME_prefix, NULL);
	if (sfx_proc_dir) {
		sfx_proc_stats = proc_create("stats", 0, sfx_proc_dir, &sfx_proc_stats_fops);
		sfx_proc_qlists = proc_create("qlists", 0, sfx_proc_dir, &sfx_proc_qlists_fops);
		sfx_proc_hw_qlists = proc_create("hw_qlists", 0, sfx_proc_dir, &sfx_proc_hw_qlists_fops);
		sfx_proc_cmdraw_qlists =
			proc_create("cmdraw_qlists", 0, sfx_proc_dir, &sfx_proc_cmdraw_qlists_fops);
		sfx_proc_debug = proc_create("debug", 0, sfx_proc_dir, &sfx_proc_debug_fops);
		sfx_proc_reg = proc_create("reg", 0, sfx_proc_dir, &sfx_proc_reg_fops);
	} else {
		sfx_pr_err("Failed to create proc!\n");
	}

	if (IS_ERR_OR_NULL((void *)(unsigned long)sfx_thread_create(
		    &check_dev_gone_thread, sfx_check_dev_gone, NULL, "sfx_chk_dev_gone"))) {
		sfx_pr_err("%s: Failed to start sfx_check_dev_gone\n", __FUNCTION__);
		result = -ENOMEM;
#ifdef SFX_DRIVER_REGISTER_BLKDEV
		goto unregister_blkdev;
#else
		goto kill_workq;
#endif
#ifdef SFXDRIVER_BASE_DEBUG
	} else {
		sfx_pr_info("%s: sfx_check_dev_gone thread started\n", __FUNCTION__);
#endif
	}

	/* determine whether we're in crashdump kernel by trying to allocate large amount of memory
     * i.e. exceed the system reserved memory for crashdump kernel
     */
	{
#define MEM_BLOCKS 1024 // 1024*1MB = 1GB
		void **p;

		in_crashdump = 0;
		p = sfx_kmalloc(sizeof(void *) * MEM_BLOCKS, GFP_KERNEL);
		if (p) {
			int i, j;
			for (i = 0; i < MEM_BLOCKS; i++) {
				p[i] = 0;
			}
			/* allocate many small blocks instead of one large block to reduce chance of false-positive */
			for (i = 0; i < MEM_BLOCKS; i++) {
				p[i] = sfx_vmalloc(1024 * 1024);
				if (!p[i])
					break;
			}
			if (i >= MEM_BLOCKS) {
				for (j = 0; j < MEM_BLOCKS; j++) {
					sfx_vfree(p[j]);
				}
			} else {
				/* memory allocation failed at certain point, must be crashdump kernel loading us */
				in_crashdump = 1;
				for (j = 0; j < i; j++) {
					if (p[j])
						sfx_vfree(p[j]);
				}
			}
			sfx_kfree(p);
		} else {
			/* cannot even get the basic memory, better quit */
			in_crashdump = 1;
		}
		if (in_crashdump) {
			sfx_pr_err("%s: in_crashdump 1\n", __FUNCTION__);
		}
	}

	F_LEAVE;
	return 0;

#ifdef SFX_DRIVER_REGISTER_BLKDEV
unregister_blkdev:
	unregister_blkdev(sfx_major, KBUILD_MODNAME);
#endif

kill_workq:
	destroy_workqueue(sfx_workq);
	return result;
}

void __exit _sfx_dev_exit(void)
{
	F_ENTER;

	sfx_driver_cleanup();

	if (sfx_proc_dir) {
		if (sfx_proc_stats)
			remove_proc_entry("stats", sfx_proc_dir);
		if (sfx_proc_qlists)
			remove_proc_entry("qlists", sfx_proc_dir);
		if (sfx_proc_hw_qlists)
			remove_proc_entry("hw_qlists", sfx_proc_dir);
		if (sfx_proc_cmdraw_qlists)
			remove_proc_entry("cmdraw_qlists", sfx_proc_dir);
		if (sfx_proc_debug)
			remove_proc_entry("debug", sfx_proc_dir);
		if (sfx_proc_reg)
			remove_proc_entry("reg", sfx_proc_dir);
		remove_proc_entry(DEV_NAME_prefix, NULL);
	}

	pci_unregister_driver(&sfx_driver);

	if (!IS_ERR_OR_NULL(sfx_kthread_task)) {
		sfx_read_lock(&dev_list_lock);
		if (!list_empty(&dev_list)) {
			sfx_pr_info("%s: Warning: stop sfx_kthread_task but dev_list !empty\n", __FUNCTION__);
		} else {
			sfx_pr_info("%s: stop still alive sfx_kthread_task\n", __FUNCTION__);
		}
		sfx_read_unlock(&dev_list_lock);
		kthread_stop(sfx_kthread_task);
		sfx_kthread_task = NULL;
	}

#ifdef SFX_DRIVER_REGISTER_BLKDEV
	unregister_blkdev(sfx_major, KBUILD_MODNAME);
#endif

	sfx_atomic_set(&s_dev_cnt, 0);
	sfx_atomic_set(&bd_probe_cnt, 0);

	if (!IS_ERR_OR_NULL(check_dev_gone_thread)) {
		kthread_stop(check_dev_gone_thread);
		check_dev_gone_thread = NULL;
	}

	destroy_workqueue(sfx_workq);

	F_LEAVE;
}

/* a global to sync sfx_driver_probe() and sfx_bd_remove() */
int sfx_get_user_pages_fast(xt_u64 addr, xt_32 count, xt_32 write, sfx_page **p)
{
	return get_user_pages_fast(addr, count, write, p);
}
EXPORT_SYMBOL(sfx_get_user_pages_fast);

int sfx_get_vector(struct sfx_queue *nvmeq)
{
	return nvmeq->dev->entry[nvmeq->cq_vector].vector;
}

int sfx_get_drv_checkpoint(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	sfx_proc_stats_show(NULL, NULL);
	return dev->cp;
}
EXPORT_SYMBOL(sfx_get_drv_checkpoint);

int sfx_alloc_prps(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo)
{
	return 0;
}

void sfx_free_prps(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo)
{
	return;
}

#ifdef SG_PREALLOC
void *sfx_alloc_sgarray(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo)
{
	return (void *)&cmdinfo->cmd_iod;
}

void sfx_free_sgarray(struct sfx_dev *dev, struct async_io_cmd_info *cmdinfo)
{
	return;
}
#endif

void sfxdriver_set_queue_dying(void *q)
{
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(7, 2))
	blk_set_queue_dying(q);
#else
	queue_flag_set_unlocked(QUEUE_FLAG_DEAD, q);
#endif
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0))
	blk_set_queue_dying(q);
#else
	queue_flag_set_unlocked(QUEUE_FLAG_DEAD, q);
#endif
#endif
}
EXPORT_SYMBOL(sfxdriver_set_queue_dying);
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7, 4))
void sfxdriver_blk_mq_freeze_queue_start(void *q)
{
	blk_mq_freeze_queue_start(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_freeze_queue_start);
#else
void sfxdriver_blk_mq_freeze_queue(void *q)
{
	blk_mq_freeze_queue(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_freeze_queue);
#endif
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 12, 0))
void sfxdriver_blk_mq_freeze_queue_start(void *q)
{
	blk_freeze_queue_start(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_freeze_queue_start);
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0))
void sfxdriver_blk_mq_freeze_queue_start(void *q)
{
	blk_mq_freeze_queue_start(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_freeze_queue_start);
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0))
void sfxdriver_blk_mq_freeze_queue_start(void *pq)
{
	struct request_queue *q = (struct request_queue *)pq;
	bool freeze;

	spin_lock_irq(q->queue_lock);
	freeze = !q->mq_freeze_depth++;
	spin_unlock_irq(q->queue_lock);

	if (freeze) {
		percpu_ref_kill(&q->mq_usage_counter);
		blk_mq_run_queues(q, false);
	}
}
EXPORT_SYMBOL(sfxdriver_blk_mq_freeze_queue_start);
#endif
#endif

#ifdef RHEL_RELEASE_CODE
void sfxdriver_blk_mq_unfreeze_queue(void *q)
{
	blk_mq_unfreeze_queue(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_unfreeze_queue);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
void sfxdriver_blk_mq_unfreeze_queue(void *q)
{
	blk_mq_unfreeze_queue(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_unfreeze_queue);
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0))
void sfxdriver_blk_mq_unfreeze_queue(void *pq)
{
	struct request_queue *q = (struct request_queue *)pq;
	bool wake;

	spin_lock_irq(q->queue_lock);
	wake = !--q->mq_freeze_depth;
	WARN_ON_ONCE(q->mq_freeze_depth < 0);
	spin_unlock_irq(q->queue_lock);
	if (wake) {
		percpu_ref_reinit(&q->mq_usage_counter);
		wake_up_all(&q->mq_freeze_wq);
	}
}
EXPORT_SYMBOL(sfxdriver_blk_mq_unfreeze_queue);
#endif
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 10, 0)
#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7, 4))
void sfxdriver_blk_mq_cancel_requeue_work(void *q)
{
	blk_mq_cancel_requeue_work(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_cancel_requeue_work);
#endif
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
void sfxdriver_blk_mq_cancel_requeue_work(void *q)
{
	blk_mq_cancel_requeue_work(q);
}
EXPORT_SYMBOL(sfxdriver_blk_mq_cancel_requeue_work);
#endif
#endif
#endif

#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

void sfxdriver_schedule_hrtimeout(ktime_t *expires, const enum hrtimer_mode mode)
{
	schedule_hrtimeout(expires, mode);
}
EXPORT_SYMBOL(sfxdriver_schedule_hrtimeout);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)
struct workqueue_struct *sfxdriver_alloc_workqueue(char *qname)
{
	return alloc_workqueue(qname, WQ_MEM_RECLAIM, 256);
}
EXPORT_SYMBOL(sfxdriver_alloc_workqueue);
#else
struct workqueue_struct *sfxdriver_create_workqueue(const char *qname)
{
	return create_workqueue(qname);
}
EXPORT_SYMBOL(sfxdriver_create_workqueue);
#endif

ktime_t sfxdriver_ktime_get(void)
{
	return ktime_get();
}
EXPORT_SYMBOL(sfxdriver_ktime_get);

struct device *sfxdriver_device_create(struct class *class, struct device *parent, dev_t devno, void *drv,
				       char *devname)
{
	return device_create(class, parent, devno, drv, devname);
}
EXPORT_SYMBOL(sfxdriver_device_create);

void sfxdriver_device_destroy(struct class *class, dev_t devno)
{
	device_destroy(class, devno);
}
EXPORT_SYMBOL(sfxdriver_device_destroy);

void __percpu *sfxdriver_alloc_percpu(size_t size, size_t align)
{
	return __alloc_percpu(size, align);
}
EXPORT_SYMBOL(sfxdriver_alloc_percpu);

void sfxdriver_free_percpu(void __percpu *__pdata)
{
	free_percpu(__pdata);
}
EXPORT_SYMBOL(sfxdriver_free_percpu);

int sfxdriver_kobject_init_and_add(struct kobject *kobj, struct kobj_type *ktype, struct kobject *kparent,
				   const char *fmt, char *name)
{
	return kobject_init_and_add(kobj, ktype, kparent, fmt, name);
}
EXPORT_SYMBOL(sfxdriver_kobject_init_and_add);

int sfxdriver_sysfs_create_link(struct kobject *kobj, struct kobject *target, const char *name)
{
	return sysfs_create_link(kobj, target, name);
}
EXPORT_SYMBOL(sfxdriver_sysfs_create_link);

void sfxdriver_sysfs_remove_link(struct kobject *kobj, const char *name)
{
	sysfs_remove_link(kobj, name);
}
EXPORT_SYMBOL(sfxdriver_sysfs_remove_link);

int sfxdriver_set_cpus_allowed_ptr(struct task_struct *tp, const struct cpumask *mask)
{
	return set_cpus_allowed_ptr(tp, mask);
}
EXPORT_SYMBOL(sfxdriver_set_cpus_allowed_ptr);

void sfxdriver_destroy_workqueue(sfx_worker_t *worker)
{
	destroy_workqueue(worker);
}
EXPORT_SYMBOL(sfxdriver_destroy_workqueue);

const struct cpumask *sfxdriver_cpumask_of(unsigned int cpu)
{
	return cpumask_of(cpu);
}
EXPORT_SYMBOL(sfxdriver_cpumask_of);

void sfxdriver_do_exit(long ecode)
{
	return do_exit(ecode);
}
EXPORT_SYMBOL(sfxdriver_do_exit);

#if SFX_USE_REMOTE_CMPL
void sfxdriver_smp_call_function_single_async(xt_u32 cpuid, void *func)
{
	smp_call_function_single_async(cpuid, func);
}
EXPORT_SYMBOL(sfxdriver_smp_call_function_single_async);
#endif

int sfxdriver_sysfs_create_file(struct kobject *dev_kobj, const struct attribute *attr)
{
	return sysfs_create_file(dev_kobj, attr);
}
EXPORT_SYMBOL(sfxdriver_sysfs_create_file);

int sfxdriver_sysfs_create_group(struct kobject *dev_kobj, const struct attribute_group *group)
{
	return sysfs_create_group(dev_kobj, group);
}
EXPORT_SYMBOL(sfxdriver_sysfs_create_group);

void sfxdriver_sysfs_remove_group(struct kobject *dev_kobj, const struct attribute_group *group)
{
	sysfs_remove_group(dev_kobj, group);
}
EXPORT_SYMBOL(sfxdriver_sysfs_remove_group);

void sfxdriver_sched_setscheduler(void *thread)
{
	struct sched_param param = { .sched_priority = 40 };
	sched_setscheduler(thread, SCHED_RR, &param);
}
EXPORT_SYMBOL(sfxdriver_sched_setscheduler);

void sfxdriver_class_destroy(struct class *class)
{
	return class_destroy(class);
}
EXPORT_SYMBOL(sfxdriver_class_destroy);

struct class *sfxdriver_class_create(void *module, char *name)
{
	return class_create(module, name);
}
EXPORT_SYMBOL(sfxdriver_class_create);

int sfxdriver_get_user_pages_fast(xt_u64 addr, xt_u32 count, xt_u8 is_write, struct page **pages)
{
	return get_user_pages_fast(addr, count, is_write, pages);
}
EXPORT_SYMBOL(sfxdriver_get_user_pages_fast);

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0))
void sfxdriver_part_round_stats(void *q, int cpu, void *part)
{
	part_round_stats(q, cpu, part);
}
EXPORT_SYMBOL(sfxdriver_part_round_stats);
#else
void sfxdriver_part_round_stats(int cpu, void *part)
{
	part_round_stats(cpu, part);
}
EXPORT_SYMBOL(sfxdriver_part_round_stats);
#endif
#endif

bool sfxdriver_queue_work_on(int cpu, void *wq, void *work)
{
	return queue_work_on(cpu, wq, work);
}
EXPORT_SYMBOL(sfxdriver_queue_work_on);
