#!/bin/bash
# 10/09/2018 by Wendy
# ---------------------------------------------------------------------------------------------

echo "NOTE: NEVER USE 'SUDO' WHEN RUNNING THIS SCRIPT!"

# EUID check
if [[ $EUID -eq 0 ]];
then
	echo "Please never use sudo to run this script! Program exits."
	exit 0
fi

echo "sfxmatinstall.sh starts..."

# ----------------------------------------- constants ----------------------------------------
#current_dir=$(echo $0 | rev | cut --complement -d "/" -f 1 |rev)
current_dir=$(dirname $(realpath $0))
echo "Current directory is $current_dir"
sfx_mat_tar=$(ls $current_dir |grep sfx_mat)
echo "The sfx_mat_tar file for this package is $sfx_mat_tar"
sfx_mat=$(ls $current_dir | grep sfx_mat | sed 's/.tar.gz//')
master_mat_tests_folder='/home/mat_master/blk_ftl_4kRW/software/applications/mat_tests'
master_scripts_folder="$master_mat_tests_folder/matGUI_master/scripts_folder"
slave_mat_tests_folder='/home/mat_tests/blk_ftl_4kRW/software/applications/mat_tests'
slave_scripts_folder="$slave_mat_tests_folder/matGUI_slave/scripts_folder"
internal_tools=$current_dir/sfx_internal_tools.tar.gz
sfxinstall=$current_dir/../../sfxinstall.sh
mat_tests_folder=""
scripts_folder=""
depend_folder=""
internal_tools=""
software_folder=""

# ------------------------------------------- flags --------------------------------------------
master=n
slave=n
setup=n
update=n

# -------------------------------------- program flow controls --------------------------------------
### If no extra arguments are given, do slave setup
if [ $# -eq 0 ]; then
	slave=y
	setup=y
fi
### Otherwise, decide the task to run (Please check out "main method")
while test $# -gt 0 ; do
	case $1 in
		-s)         slave=y;;
		--slave)    slave=y;;
		-m)         master=y;;
		--master)   master=y;;
		-u)         update=y;;
		--update)   update=y;;
		--setup)    setup=y;;
	esac
	shift
done


# -------------------------------------------- functions ------------------------------------------
# -------------------------------- BEGINNING OF FUNCTION DEFINITIONS -----------------------------------------
usagehelp() {
	echo "WARNING: NEVER USE 'SUDO' WHEN RUNNING THIS SCRIPT!"
	echo "Usage: default run (with no parameters passed) --> slave machine setup"
	echo "       [-s / --slave   |  slave machine]"
	echo "       [-m / --master  |  master machine]"
	echo "       [--setup        |  first time setup (NO OVERWRITE, "
	echo "                          old scripts will be saved for your record)]"
    echo "       [--update / -u  |  update installation or OVERWRITE previous setup]"
	echo "       [-h / any other non-empty string  |  for help]"
	echo "Note: tags '--master' and '-slave' are mutually exclusive, so do '--setup' and '--update'."
	exit 0
}

check_dir() {
	### check if the current directory is the release directory
	files=("$internal_tools" "$sfxinstall" "sfx_qual_suite.tar.gz" "sfx_utils.tar.gz")
	for i in ${files[@]}
		do
		if ! [ -e $i ];
		then
			echo -e "\e[91mError\e[39m! Please go to the correct tool directory or installation file $i is missing."
			exit 1
		fi
	done
}

check_history() {
	### check if the machine was previously setup as a master machine
	# if the script or depend folder had files, save them and give space for new files
	tar_time=$(date +%Y%m%d_%H-%M-%S)
	if [ -e '/home/mat_master/blk_ftl_4kRW' ] && [[ ! -z $(ls -A $master_script_folder) ]]
	then
		cd /home/mat_master
		mv -f blk_ftl_4kRW blk_ftl_4kRW_backup_$tar_time
		tar -czf "master_$tar_time.tar.gz" blk_ftl_4kRW_backup_$tar_time
		echo "The previous code has been saved to master_$tar_time.tar.gz under home directory."
	fi

	### check if the machine was previously setup as a slave machine
	# if the script or depend folder had files, save them and give space for new files
	if [ -e '/home/mat_tests/blk_ftl_4kRW' ] &&
		([[ ! -z $(ls -A $slave_script_folder) ]] || [[ ! -z $(ls -A $slave_script_folder/depend) ]]);
	then
		cd /home/mat_tests
		mv -f blk_ftl_4kRW blk_ftl_4kRW_backup_$tar_time
		tar -czf "slave_$tar_time.tar.gz" blk_ftl_4kRW_backup_$tar_time
		echo "The previous code has been saved to slave_$tar_time.tar.gz under home directory."
	fi
}

master_setup_createDir() {
	### create the basic file structure on the master machine
	cd /home/mat_master
	echo "At home directory: $(pwd)"
	if ! [ -d $mat_tests_folder ];
	then
		mkdir -p $mat_tests_folder
	else
		echo -e "\e[91mError\e[39m! Could not make directory $mat_tests_folder."
		exit 1
	fi
}

master_setup_prepInternalTool() {
	cd $mat_tests_folder
	echo "Now the directory changed to $(pwd)"

	### copy source tar file to the master machine
	# currently in directory /matGUI_master
	cp $current_dir/sfx_internal_tools.tar.gz .
	cp $current_dir/$sfx_mat_tar .

	### untar files
	if ! [ -d $sfx_mat ];
	then
		if [ -e $sfx_mat_tar ];
		then
			tar -xzf $sfx_mat_tar
			echo "Untarring sfx_mat finished."
		else
			echo -e "\e[91mError\e[39m! No file to untar!"
			exit 1
		fi
	else
		echo "$sfx_mat exists, please double check with the package version."
	fi
}

master_cleanUp() {
	### delete intermediate folders
	rm -Rf $mat_tests_folder/$sfx_mat
	rm -Rf $mat_tests_folder/$sfx_mat_tar
	rm -Rf $mat_tests_folder/sfx_internal_tools
	rm -Rf $mat_tests_folder/sfx_internal_tools.tar.gz
	### delete compiled Python files
	if [ -e $scripts_folder ];
	then
		cd $scripts_folder
		sudo rm -rf __pycache__
	fi
}

slave_setup_createDir() {
	### create the basic file structure on the slave machine
	cd /home/mat_tests
	echo "At home directory: $(pwd)"
	if ! [ -d $mat_tests_folder ];
	then
		mkdir -p $mat_tests_folder
	else
		echo -e "\e[91mError\e[39m! Could not make directory $mat_tests_folder."
		exit 1
	fi
}

slave_setup_prepInternalTool() {
	cd $mat_tests_folder
	echo "Now the directory changed to $(pwd)"

	### copy source tar file to the slave machine
	# currently in directory /matGUI_slave
	cp $current_dir/sfx_internal_tools.tar.gz .
	cp $current_dir/$sfx_mat_tar .

	### untar files
	if ! [ -d sfx_internal_tools ];
	then
		if [ -e $internal_tools ];
		then
			tar -xzf sfx_internal_tools.tar.gz
			echo "Untarring sfx_internal_tools finished."
		else
			echo -e "\e[91mError\e[39m! No file to untar!"
			exit 1
		fi
	else
		echo "Directory sfx_internal_tools exists."
	fi

	if ! [ -d $sfx_mat ];
	then
		if [ -e $sfx_mat_tar ];
		then
			tar -xzf $sfx_mat_tar
			echo "Untarring sfx_mat finished."
		else
			echo -e "\e[91mError\e[39m! No file to untar!"
			exit 1
		fi
	else
		echo "$sfx_mat exists, please double check with the package version."
	fi
}

slave_setup_install() {
	############################ installation starts here ##################################
	cd $current_dir
	echo "------------------START of sfxinstall.sh"
	sudo $sfxinstall -o
	echo "------------------END of sfxinstall.sh"

	cd $mat_tests_folder/matGUI_slave/helpcontent
	sudo chmod 400 scaleflux-apoorva.pem

	### delete sfx.conf
	sfx_conf_file="/etc/modules-load.d/sfx.conf"
	if [ -e $sfx_conf_file ];
	then
		sudo rm $sfx_conf_file
		echo "sfx.conf is removed."
	fi

	### copy sfx*.ko files
	kernal_release_ver=$(uname -r)
	sfx_bd_dev_file="/lib/modules/$kernal_release_ver/extra/sfx_bd_dev/sfx_bd_dev.ko"
	sfxdriver_file="/lib/modules/$kernal_release_ver/extra/sfxdriver/sfxdriver.ko"
	sfv_file="/lib/modules/$kernal_release_ver/extra/sfxdriver/sfv.ko"
	if [[ (! -e $sfx_bd_dev_file) || (! -e $sfxdriver_file) ]];
	then
		echo -e "\e[91mError\e[39m! sfxinstall.sh failed to install driver!"
		exit 1
	else
	    if [ ! -d $software_folder ]
	    then
	    	echo -e "\e[91mError\e[39m! $software_folder does not exist."
	    	exit 1
	    fi
	    if [ ! -d $depend_folder ]
	    then
	        echo -e "\e[91mError\e[39m! $depend_folder does not exist."
	        exit 1
	    fi
		cp $sfx_bd_dev_file $depend_folder
		cp $sfx_bd_dev_file $software_folder
                sudo rm $sfx_bd_dev_file
		echo "Copied sfx_bd_dev.ko."
		cp $sfxdriver_file $depend_folder
		cp $sfxdriver_file $software_folder
                sudo rm $sfxdriver_file
		echo "Copied sfxdriver.ko."
		cp $sfv_file $depend_folder
		cp $sfv_file $software_folder
                sudo rm $sfv_file
		echo "Copied sfv.ko."
	fi

	### move files to the desired locations and make sure they function properly
	cd $mat_tests_folder/$sfx_mat/mat/service
	sudo cp boot_power_test.sh /usr/local/bin
	sudo chmod 755 /usr/local/bin/boot_power_test.sh
	sudo cp mat_pwr_cycle.service /etc/systemd/system
	sudo chmod 755 /etc/systemd/system/mat_pwr_cycle.service
	sudo systemctl enable mat_pwr_cycle
	if [ ! -z "$(sudo systemctl status mat_pwr_cycle | grep enabled)" ];
	then
		sudo systemctl start mat_pwr_cycle
	else
		echo -e "\e[91mError\e[39m! Failed to restart mat_pwr_cycle.service."
		exit 1
	fi

	### add sfx_functions
	sfx_functions="/usr/bin/sfx_functions"
	if [ -e $sfx_functions ];
	then
		cp $sfx_functions $depend_folder
		echo "Copied sfx_functions."
	fi
}

slave_update_cleanUp() {
	### delete intermediate folders
	rm -Rf $mat_tests_folder/sfx_internal_tools
	rm -Rf $mat_tests_folder/sfx_internal_tools.tar.gz
	rm -Rf $mat_tests_folder/$sfx_mat
	rm -Rf $mat_tests_folder/$sfx_mat_tar
	### delete compiled Python files
	cd $depend_folder
	sudo rm -f $(ls | grep .pyc)
}

slave_setup_cleanUp(){
	### remove empty directory
	sudo rm -Rf $mat_tests_folder/sfx_internal_tools
	sudo rm -Rf $mat_tests_folder/sfx_internal_tools.tar.gz
	rm -Rf $mat_tests_folder/$sfx_mat
	rm -Rf $mat_tests_folder/$sfx_mat_tar
}

create_slave_version_file(){
	cd $scripts_folder
	echo "MAT slave version " > MAT_ver.txt
	ls $current_dir | grep sfx_mat | cut -d '-' -f 2 >> MAT_ver.txt
	echo "software version " >> MAT_ver.txt
	ls $current_dir | grep sfx_mat | cut -d '-' -f 3 | cut -d '.' -f 1 >> MAT_ver.txt
	echo "driver version " >> MAT_ver.txt
	#ls $current_dir | grep sfx_bd_dev | cut -d '-' -f 4 >> MAT_ver.txt
	echo "Creating version file done."
}

create_master_version_file(){
	cd $scripts_folder
	echo "MAT master version " > MAT_ver.txt
	ls $current_dir | grep sfx_mat | cut -d '-' -f 2 >> MAT_ver.txt
	echo "software version " >> MAT_ver.txt
	ls $current_dir | grep sfx_mat | cut -d '-' -f 3 | cut -d '.' -f 1 >> MAT_ver.txt
	echo "Creating version file done."
}



# ------------------------------- END OF FUNCTION DEFINITIONS ---------------------------------


# -------------------------------------------- main ----------------------------------------------
# main method
# redefine constants according to master/slave tag
if [[ $slave = y ]];
then
	mat_tests_folder="$slave_mat_tests_folder"
	scripts_folder="$slave_scripts_folder"
	depend_folder="$scripts_folder/depend"
	internal_tools="$current_dir/sfx_internal_tools.tar.gz"
	software_folder="$scripts_folder/software/output"
elif [[ $master = y ]];
then
	mat_tests_folder="$master_mat_tests_folder"
	scripts_folder="$master_scripts_folder"
	internal_tools="$current_dir/sfx_internal_tools.tar.gz"
fi

# slave setup
if [[ $setup = y && $update = n && $slave = y && $master = n ]];
then
	# check_dir
	check_history
	echo "Slave setup starts..."
	slave_setup_createDir
	slave_setup_prepInternalTool
	cd $mat_tests_folder/sfx_internal_tools/mat
	mv matGUI_slave $mat_tests_folder
	cd $mat_tests_folder/$sfx_mat/mat
	cp -rf matGUI_slave $mat_tests_folder
	slave_setup_install
	cd $mat_tests_folder/matGUI_slave/helpcontent
	sudo chmod 400 scaleflux-apoorva.pem
	slave_setup_cleanUp
	create_slave_version_file
	echo -e '\033[37;42mThe slave setup is complete!\033[0m'
	echo "Note:"
	echo "Please change the content of reference.txt to map physical slots of the cards with the GUI slots"
	echo "and manually copy FPGA image file to the following directory:"
	echo "/home/mat_tests/blk_ftl_4kRW/software/applications/mat_tests/matGUI_slave/scripts_folder/depend."
	echo "Please make sure there is only one FPGA image file in this directory."

# master setup
elif [[ $setup = y && $update = n && $slave = n && $master = y ]];
then
	# check_dir
	check_history
	echo "Master setup starts..."
	master_setup_createDir
	master_setup_prepInternalTool
	cd $mat_tests_folder/$sfx_mat/mat
	mv matGUI_master $mat_tests_folder
	# change permission of .pem file
	cd $mat_tests_folder/matGUI_master/helpcontent
	sudo chmod 400 scaleflux-apoorva.pem
	master_cleanUp
	create_master_version_file
	echo -e '\033[37;42mThe master setup is complete!\033[0m'

# slave update
elif [[ $setup = n && $update = y && $slave = y && $master = n ]];
then
	# check_dir
	echo "Slave update starts..."
	slave_setup_prepInternalTool
	cd $mat_tests_folder/sfx_internal_tools/mat/matGUI_slave
	cp -fr scripts_folder $mat_tests_folder/matGUI_slave
	cd $mat_tests_folder/$sfx_mat/mat
	cp -rf matGUI_slave $mat_tests_folder
	slave_setup_install
	cd $mat_tests_folder/matGUI_slave/helpcontent
	sudo chmod 400 scaleflux-apoorva.pem
	slave_update_cleanUp
	create_slave_version_file
	echo -e '\033[37;42mUpdate complete!\033[0m'

# master update
elif [[ $setup = n && $update = y && $slave = n && $master =  y ]];
then
	# check_dir
	echo "Master update start..."
	master_setup_prepInternalTool
	cd $mat_tests_folder/$sfx_mat/mat/matGUI_master
	cp -fr scripts_folder $mat_tests_folder/matGUI_master
	# change permission of .pem file
	cd $mat_tests_folder/matGUI_master/helpcontent
	sudo chmod 400 scaleflux-apoorva.pem
	master_cleanUp
	create_master_version_file
	echo -e '\033[37;42mUpdate complete!\033[0m'

# error checking
elif [[ $setup = y && $update = n && $slave = n && $master = n ]];
then
	echo "Please specify setup type. Master [-m ] or slave [-s]."
	exit 0
elif [[ $setup = n && $update = y && $slave = n && $master = n ]];
then
	echo "Please specify update type. Master [-m] or slave [-s]."
	exit 0
elif [[ $setup = y && $update = y ]];
then
	echo -e "\e[91mError\e[39m! Cannot setup and update at the same time!"
	exit 1
elif [[ $slave = y && $master = y ]];
then
	echo -e "\e[91mError\e[39m! Cannot run as master and slave at the same time!"
	exit 1
# any other non-empty option strings will trigger the display of usage content
else
	usagehelp
fi

# end of script

