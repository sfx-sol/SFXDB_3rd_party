// -----------------------------------------------------------------------------
//
// Copyright 2017-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfxdriver_spi_common.c
// -----------------------------------------------------------------------------

#include "osutil.h"
#include "sfxdriver_common.h"
#include "sfxdriver_spi_common.h"

static inline xt_32 sfxdriver_spi_check_gone(struct sfx_dev *dev)
{
	if (dev->device_gone) {
		return 1;
	} else {
		return 0;
	}
}

// for SPI access use
static xt_u32 sfxdriver_spi_spicr_data_gen(xt_u32 master_inhibit, xt_u32 rfifo_rst, xt_u32 tfifo_rst,
					   xt_u32 master, xt_u32 spe)
{
	xt_u32 lsb_first = 0;
	xt_u32 slave_sel = 1;
	xt_u32 cpha = 0;
	xt_u32 cpol = 0;
	xt_u32 loop = 0;
	xt_u32 ret_val = ((lsb_first << 9) | (master_inhibit << 8) | (slave_sel << 7) | (rfifo_rst << 6) |
			  (tfifo_rst << 5) | (cpha << 4) | (cpol << 3) | (master << 2) | (spe << 1) | loop);
	return ret_val;
}

static xt_u32 sfxdriver_spi_transmit_empty(struct sfx_dev *dev, xt_u32 timeout)
{
	xt_u32 loop = 0;
	xt_u32 reg_data;
	while (1) {
		if (sfxdriver_spi_check_gone(dev))
			return 4;
		reg_data = fis_indirect_read32(dev, dev->bar, spi_spisr);
		loop++;
		if ((reg_data & 0x4) == 0x4) {
			return 0;
		}
		if (loop == timeout) {
			sfx_pr_info("[sfxdriver_spi_transmit_empty]ERROR: Transmit FIFO timeout!\n");
			sfx_pr_info("[sfxdriver_spi_transmit_empty]spi_spisr: %08x;", reg_data);
			reg_data = fis_indirect_read32(dev, dev->bar, spi_ipisr);
			sfx_pr_info("Xt_U32errupt Status: %08x\n", reg_data);
			return 1;
		}
	}
}

static xt_u32 sfxdriver_spi_cs_ms_setup(struct sfx_dev *dev)
{
	xt_u32 ret;
	//1) assert chip select
	fis_indirect_write32(dev, dev->bar, spi_spissr, 0xFFFE);
	//2) master inhibit enable
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(0, 0, 0, 1, 1));
	//3) check transmit FIFO empty
	// In either write or read, transmit FIFO empty indicates flash transaction finished
	// For erase, need to pull other info for transaction completion
	ret = sfxdriver_spi_transmit_empty(dev, 100);
	//4) de-assert chip select
	fis_indirect_write32(dev, dev->bar, spi_spissr, 0xFFFF);
	//5) master inhibit disable
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 0, 0, 1, 1));
	return ret;
}

static xt_u32 sfxdriver_spi_cmd(struct sfx_dev *dev, xt_u32 cmd, xt_u32 dummyclk)
{
	xt_u32 echo_data;
	xt_u32 i;
	xt_u32 ret;

	//1) cr reset
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));
	//2) push command
	fis_indirect_write32(dev, dev->bar, spi_spidtr, cmd);
	//3) push dummyclk
	for (i = 0; i < dummyclk; i++) {
		fis_indirect_write32(dev, dev->bar, spi_spidtr, 0x55);
	}
	//4) send command
	ret = sfxdriver_spi_cs_ms_setup(dev);
	if (ret == 1) {
		sfx_pr_info("[sfxdriver_spi_cmd]ERROR: command %08x; transmit FIFO timeout!\n", cmd);
		return ret;
	}

	//5) drop echo command+dummydata
	echo_data = fis_indirect_read32(dev, dev->bar, spi_spidrr);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_cmd:sent command %08x\n", cmd);
#endif
	return 0;
}

static void sfxdriver_spi_read_reg(struct sfx_dev *dev, xt_u32 cmd, xt_u32 data_len, xt_u32 *ret_data)
{
	xt_u32 echo_cmd;
	xt_u32 i;
	xt_u32 ret;
	//1) cr reset
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));
	//2) read registser
	fis_indirect_write32(dev, dev->bar, spi_spidtr, cmd);
	for (i = 0; i < data_len; i++) {
		fis_indirect_write32(dev, dev->bar, spi_spidtr, 0x55);
	}
	//3) send command
	ret = sfxdriver_spi_cs_ms_setup(dev);

	//4) read data
	echo_cmd = fis_indirect_read32(dev, dev->bar, spi_spidrr);
	for (i = 0; i < data_len; i++) {
		ret_data[i] = fis_indirect_read32(dev, dev->bar, spi_spidrr);
	}
}

static xt_u32 sfxdriver_spi_read_sta(struct sfx_dev *dev)
{
	xt_u32 ret_sta;
	sfxdriver_spi_read_reg(dev, RD_STA_REG, 1, &ret_sta);
	return ret_sta;
}

// Write to status register is self time of tW
// The tW is 1.3ms (typ) to 8.0ms (max)
static xt_u32 sfxdriver_spi_read_sta_with_check(struct sfx_dev *dev, xt_u32 value, xt_u32 mask, xt_u32 cnt)
{
	xt_u32 loop = 0;
	xt_u32 sta;

	while (1) {
		if (sfxdriver_spi_check_gone(dev))
			return 4;
		sta = sfxdriver_spi_read_sta(dev);
		loop++;
		if ((sta & mask) == value)
			return 0;
		sfx_usleep(1000); /* 1 milli-second */
		if (loop >= cnt) {
			sfx_pr_info(
				"[sfxdriver_spi_read_sta_with_check]ERROR: The value of status register is 0x%x while 0x%x is expected.\n",
				sta & mask, value & mask);
			return 1;
		}
	}
}

static xt_u32 sfxdriver_spi_read_flag(struct sfx_dev *dev)
{
	xt_u32 ret_flag;
	sfxdriver_spi_read_reg(dev, RD_FLAG_REG, 1, &ret_flag);
	if ((ret_flag & 0x7E) != 0) {
		sfx_pr_info(
			"[sfxdriver_spi_read_flag]ERROR: There are some errors in flag status register!\n");
		sfx_pr_info("[sfxdriver_spi_read_flag]: flag status reg: %08x\n", ret_flag);
		if ((ret_flag >> 7) & 0x1)
			sfx_pr_info("%s: ---- Device is ready\n", __FUNCTION__);
		else
			sfx_pr_info("%s: ---- Device is busy\n", __FUNCTION__);
		if ((ret_flag >> 6) & 0x1)
			sfx_pr_info("%s: ---- Erase is suspended\n", __FUNCTION__);
		if ((ret_flag >> 5) & 0x1)
			sfx_pr_info("%s: ---- Erase failed\n", __FUNCTION__);
		if ((ret_flag >> 4) & 0x1)
			sfx_pr_info("%s: ---- Program failed when Vpp=VppH\n", __FUNCTION__);
		if ((ret_flag >> 3) & 0x1)
			sfx_pr_info("%s: ---- Invalid Vpp\n", __FUNCTION__);
		if ((ret_flag >> 2) & 0x1)
			sfx_pr_info("%s: ---- Program is suspended\n", __FUNCTION__);
		if ((ret_flag >> 1) & 0x1)
			sfx_pr_info("%s: ---- Program failed due to protection\n", __FUNCTION__);
		if ((ret_flag >> 0) & 0x1)
			sfx_pr_info("%s: ---- 4B addressing\n", __FUNCTION__);
		else
			sfx_pr_info("%s: ---- 3B addressing\n", __FUNCTION__);
	}

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_read_flag:flag status reg: %08x\n", ret_flag);
#endif
	return ret_flag;
}

static xt_u32 sfxdriver_spi_write_enable(struct sfx_dev *dev)
{
	xt_u32 ret;

	ret = sfxdriver_spi_cmd(dev, WR_EN, 0);
	if (ret == 1)
		return ret;
	ret = sfxdriver_spi_read_sta_with_check(dev, 0x2, 0x2, 500);
	return ret;
}

static xt_u32 sfxdriver_spi_write_reg(struct sfx_dev *dev, xt_u32 cmd, xt_u32 data)
{
	xt_u32 ret;

	//1) cr reset
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));
	//2) enable write
	ret = sfxdriver_spi_write_enable(dev);
	if (ret == 1)
		return ret;
	//3) push cmd and data
	fis_indirect_write32(dev, dev->bar, spi_spidtr, cmd);
	fis_indirect_write32(dev, dev->bar, spi_spidtr, (data & 0xff));
	//4) send command
	ret = sfxdriver_spi_cs_ms_setup(dev);
	if (ret == 1)
		return ret;
	//5) wait until finish
	ret = sfxdriver_spi_read_sta_with_check(dev, 0x0, 0x1, 500);
	return ret;
}

static xt_u32 sfxdriver_spi_write_sta(struct sfx_dev *dev, xt_u32 data)
{
	return sfxdriver_spi_write_reg(dev, WR_STA_REG, data);
}

static xt_u32 sfxdriver_spi_4b_enable(struct sfx_dev *dev)
{
	xt_u32 loop = 0;
	xt_u32 ret;
	xt_u32 flag;
	ret = sfxdriver_spi_write_enable(dev);
	if (ret == 1)
		return ret;
	while (1) {
		if (sfxdriver_spi_check_gone(dev))
			return 4;
		ret = sfxdriver_spi_cmd(dev, EN_4B_ADDR, 0);
		if (ret == 1)
			return ret;
		flag = sfxdriver_spi_read_flag(dev);
		loop++;
		if ((flag & 0x1) == 0x1)
			return 0;
		sfx_usleep(1000); /* 1 milli-second */
		if (loop >= 500) {
			sfx_pr_info(
				"[sfxdriver_spi_4b_enable]ERROR: Enable 4B address failed after %d loops\n",
				loop);
			return 1;
		}
	}
}

xt_u32 sfxdriver_NOR_init(struct sfx_dev *dev)
{
	xt_u32 ret = 0;

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init:RESET NOR\n");
#endif

	//1)  Reset NOR
	// RESET ENABLE
	ret = sfxdriver_spi_cmd(dev, RESET_ENABLE, 0);
	if (ret == 1)
		return ret;
	sfx_usleep(100);

	// RESET MEMORY
	ret = sfxdriver_spi_cmd(dev, RESET_MEMORY, 0);
	if (ret == 1)
		return ret;
	sfx_usleep(100);

	ret = sfxdriver_spi_cmd(dev, CLR_FLAG_REG, 0);
	if (ret == 1)
		return ret;

	//2) enable write
	sfx_usleep(100);
	ret = sfxdriver_spi_write_enable(dev);
	if (ret == 1)
		return ret;

	//3) enable 4byte
	ret = sfxdriver_spi_4b_enable(dev);
	if (ret == 1)
		return ret;

	return ret;
}

xt_u32 sfxdriver_spi_init(struct sfx_dev *dev)
{
	xt_u32 ret = 0;
#ifdef SFX_SPI_DEBUG
	xt_u32 reg_data, reg_data_86;
#else
	xt_u32 reg_data;
#endif
	xt_u32 reg_status;
	xt_u32 retry = 0;

	//1) enable
	fis_indirect_write32(dev, dev->bar, EPCQ_ENABLE_ADDR, 0xbeadfeed);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init:enabel EPCQ.\n");
#endif

	//2) reset and sanity check
	{
		xt_u32 loop = 0;

		while (1) {
			if (sfxdriver_spi_check_gone(dev))
				return 4;
			fis_indirect_write32(dev, dev->bar, spi_srr, 0xa);
			loop++;
			sfx_usleep(200);

			// Read SPI Cntr Register
			reg_data = fis_indirect_read32(dev, dev->bar, spi_spicr);

			// Read SPI Status Register
			reg_status = fis_indirect_read32(dev, dev->bar, spi_spisr);

			if ((reg_data == 0x180) && (reg_status == 0xa5)) {
				break;
			}

			if (loop >= 200) {
				sfx_pr_info(
					"[sfxdriver_spi_init]ERROR: SPI register access failed! SPI control register returns %08x, expect 0x180\n",
					reg_data);
				return 1;
			}
		}
	}

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init:reset SPI\n");
#endif

	//3) write 0x86 ???
	fis_indirect_write32(dev, dev->bar, spi_spicr, 0x86);
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("%s: reg_data_86:\n", __FUNCTION__);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spicr);
	sfx_pr_info("%s: spicr 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spisr);
	sfx_pr_info("%s: spisr 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spidtr);
	sfx_pr_info("%s: spidtr 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spissr);
	sfx_pr_info("%s: spissr 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spitfo);
	sfx_pr_info("%s: spitfo 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_spirfo);
	sfx_pr_info("%s: spirfo 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_ipisr);
	sfx_pr_info("%s: ipisr 0x%08x\n", __FUNCTION__, reg_data_86);
#endif

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init:write 0x86\n");
#endif

	//4) enable xt_u32errupts
	fis_indirect_write32(dev, dev->bar, spi_dgier, 0x80000000);
	fis_indirect_write32(dev, dev->bar, spi_ipier, 0x1FFF);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("%s: enable interrupts:\n", __FUNCTION__);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_dgier);
	sfx_pr_info("%s: dgier 0x%08x\n", __FUNCTION__, reg_data_86);
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_ipier);
	sfx_pr_info("%s: ipier 0x%08x\n", __FUNCTION__, reg_data_86);
#endif

#ifdef SFX_SPI_DEBUG
	reg_data_86 = fis_indirect_read32(dev, dev->bar, spi_ipisr);
	sfx_pr_info("%s: ipisr 0x%08x\n", __FUNCTION__, reg_data_86);
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init:enable xt_u32errupts\n");
#else
	fis_indirect_read32(dev, dev->bar, spi_ipisr);
#endif

	//5) Reset NOR
	do {
		ret = sfxdriver_NOR_init(dev);
		if (ret == 1)
			return ret;
		sfx_usleep(100);

		// Disable protection
		{
			int loop_sta = 0;

			sfxdriver_spi_write_sta(dev, 0);
			ret = sfxdriver_spi_read_sta_with_check(dev, 0x0, 0x5C, 500);
			while (ret == 1) {
				if (sfxdriver_spi_check_gone(dev))
					return 4;
				sfxdriver_spi_write_sta(dev, 0);
				ret = sfxdriver_spi_read_sta_with_check(dev, 0x0, 0x5C, 500);
				loop_sta++;
				if (loop_sta > (100 / WRITE_RETRY)) {
					/*NOR reset fail, try again*/
					break;
				}
			}
		}
		retry++;
	} while (retry < WRITE_RETRY);

	if (ret && (retry >= WRITE_RETRY)) {
		sfx_pr_info("[SFX_SPI_DEBUG]%s: read_sta_with_check timeout and failed\n", __FUNCTION__);
		return ret;
	}

	reg_data = sfxdriver_spi_read_flag(dev);
	ret = sfxdriver_spi_cmd(dev, CLR_FLAG_REG, 0);
	if (ret) {
		sfx_pr_info("[SFX_SPI_DEBUG]%s: spi_cmd CLR_FLAG_REG return %d\n", __FUNCTION__, ret);
	}
	return ret;
}

xt_u32 sfx_kernel_spi_init(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_spi_init(dev);
}
EXPORT_SYMBOL(sfx_kernel_spi_init);

xt_u32 sfxdriver_spi_init_read_only(struct sfx_dev *dev)
{
	xt_u32 ret = 0;
	xt_u32 reg_data;
	xt_u32 reg_status;
	xt_u32 retry = 0;

	//1) enable
	fis_indirect_write32(dev, dev->bar, EPCQ_ENABLE_ADDR, 0xbeadfeed);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init_read_only:enabel EPCQ.\n");
#endif

	//2) reset and sanity check
	{
		xt_u32 loop = 0;

		while (1) {
			if (sfxdriver_spi_check_gone(dev))
				return 4;
			fis_indirect_write32(dev, dev->bar, spi_srr, 0xa);
			loop++;
			sfx_usleep(200);

			// Read SPI Cntr Register
			reg_data = fis_indirect_read32(dev, dev->bar, spi_spicr);

			// Read SPI Status Register
			reg_status = fis_indirect_read32(dev, dev->bar, spi_spisr);

			if ((reg_data == 0x180) && (reg_status == 0xa5)) {
				break;
			}

			if (loop >= 200) {
				sfx_pr_info(
					"[sfxdriver_spi_init]ERROR: SPI register access failed! SPI control register returns %08x, expect 0x180\n",
					reg_data);
				return 1;
			}
		}
	}

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init_read_only:reset SPI\n");
#endif

	//3) write 0x86 ???
	fis_indirect_write32(dev, dev->bar, spi_spicr, 0x86);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init_read_only:write 0x86\n");
#endif

	//4) enable xt_u32errupts
	fis_indirect_write32(dev, dev->bar, spi_dgier, 0x80000000);
	fis_indirect_write32(dev, dev->bar, spi_ipier, 0x1FFF);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_init_read_only:enable xt_u32errupts\n");
#endif

	do {
		//5) Reset NOR
		ret = sfxdriver_NOR_init(dev);
		if (ret == 1)
			return ret;
		sfx_usleep(100);

		{
			int loop_sta = 0;
			sfxdriver_spi_write_sta(dev, 0x5C);
			ret = sfxdriver_spi_read_sta_with_check(dev, 0x5C, 0x5C, 500);
			while (ret != 0) {
				if (sfxdriver_spi_check_gone(dev))
					return 4;
				sfx_pr_err("[SFX_SPI_DEBUG]%s:read_sta_with_check failed. Need lock\n",
					   __FUNCTION__);
				sfxdriver_spi_write_sta(dev, 0x5C); /* lock */
				ret = sfxdriver_spi_read_sta_with_check(dev, 0x5C, 0x5C, 500);
				loop_sta++;
				if (loop_sta > (100 / WRITE_RETRY)) {
					/*NOR reset fail, try again*/
					break;
				}
			}
		}
		retry++;
	} while (retry < WRITE_RETRY);

	if (ret && (retry >= WRITE_RETRY))
		sfx_pr_err("[SFX_SPI_DEBUG]%s:Lock failed\n", __FUNCTION__);
	return ret;
}

xt_u32 sfx_kernel_spi_init_read_only(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_spi_init_read_only(dev);
}
EXPORT_SYMBOL(sfx_kernel_spi_init_read_only);

static xt_u32 spi_write_disable(struct sfx_dev *dev)
{
	xt_u32 ret = 0;

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_write_disable\n");
#endif

	ret = sfxdriver_spi_cmd(dev, WR_DIS, 0);
	if (ret == 1)
		return ret;
	ret = sfxdriver_spi_read_sta_with_check(dev, 0x0, 0x2, 500);
	return ret;
}

void sfxdriver_spi_exit(struct sfx_dev *dev)
{
	xt_u32 flag, sta, reg_data;

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_spi_exit\n");
#endif

	if (sfxdriver_spi_check_gone(dev))
		return;

	// Enable Protection
	{
		int loop_sta = 0, ret;
		sfxdriver_spi_write_sta(dev, 0x5C);
		ret = sfxdriver_spi_read_sta_with_check(dev, 0x5C, 0x5C, 500);
		while (ret != 0) {
			if (sfxdriver_spi_check_gone(dev))
				return;
			sfxdriver_spi_write_sta(dev, 0x5C);
			ret = sfxdriver_spi_read_sta_with_check(dev, 0x5C, 0x5C, 500);
			loop_sta++;
			if (loop_sta > 100) {
				sfx_pr_err("[SFX_SPI_DEBUG]%s: !!!! Lock failed\n", __FUNCTION__);
				// return;
				break;
			}
		}
	}
	flag = sfxdriver_spi_read_flag(dev);

	if ((sta = spi_write_disable(dev)))
		sfx_pr_info("%s: spi_write_disable returns %u\n", __FUNCTION__, sta);

	// CR Reset
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));
	// Check Interrupts
	reg_data = fis_indirect_read32(dev, dev->bar, spi_ipisr);
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("%s: Interrupt Status: 0x%x", __FUNCTION__, reg_data);
#endif
	// Disable Interrupts
	fis_indirect_write32(dev, dev->bar, spi_dgier, 0x0);
	fis_indirect_write32(dev, dev->bar, spi_ipier, 0x0);
	// Reset
	fis_indirect_write32(dev, dev->bar, spi_srr,
			     0xa); // Reset for 16 clock cycles
	// Disable All
	fis_indirect_write32(dev, dev->bar, EPCQ_ENABLE_ADDR, 0x0);
	return;
}

void sfx_kernel_spi_exit(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	sfxdriver_spi_exit(dev);
	return;
}
EXPORT_SYMBOL(sfx_kernel_spi_exit);

static xt_u32 spi_4k_erase(struct sfx_dev *dev, xt_u32 start_addr)
{
	xt_u32 addr;
	xt_u32 sta;
	xt_u32 ret = 0;
	xt_u32 loop;
	xt_u32 erase_try;

	for (erase_try = 0; erase_try <= ERASE_RETRY; erase_try++) {
		//1) cr reset and write enable
		ret = sfxdriver_spi_write_enable(dev);
		if (ret == 1)
			return 1;
		fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));

		//2) erase command
		fis_indirect_write32(dev, dev->bar, spi_spidtr, SUBSECT_ERASE_4KB);

		//3) push address
		addr = (start_addr >> 24) & 0xFF;
		addr = (((start_addr >> 16) & 0xFF) << 8) | addr;
		addr = (((start_addr >> 8) & 0xFF) << 16) | addr;
		addr = ((start_addr & 0xFF) << 24) | addr;
		fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, addr);

		//4) command send
		ret = sfxdriver_spi_cs_ms_setup(dev);
		if (ret == 1) {
			sfx_pr_info("sfxdriver_spi_cs_ms_setup return 1 !\n");
			return 2;
		}

		//5) wait until finish
		loop = 0;
		while (1) {
			if (sfxdriver_spi_check_gone(dev))
				return 4;
			sfx_usleep(1000);
			sta = sfxdriver_spi_read_sta(dev);
			if ((sta & 0x1) == 0x0)
				return 0;
			loop++;
			if (loop >= 500) {
				if (erase_try >= ERASE_RETRY) {
					sfx_pr_info("[spi_4k_erase]ERROR: Erasing timeout!\n");
					return 3;
				} else {
					// Reset NOR
					ret = sfxdriver_NOR_init(dev);
					break;
				}
			}
		}
	}
	return ret;
}

//Erase a sector, and address must be already sector aligned here
static xt_u32 spi_sec_erase(struct sfx_dev *dev, xt_u32 start_addr)
{
	xt_u32 addr;
	xt_u32 sta;
	xt_u32 ret = 0;
	xt_u32 loop;

	//1) cr reset and write enable
	ret = sfxdriver_spi_write_enable(dev);
	if (ret == 1)
		return 1;
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));

	//2) erase command
	fis_indirect_write32(dev, dev->bar, spi_spidtr, SECT_ERASE);

	//3) push address
	addr = (start_addr >> 24) & 0xFF;
	addr = (((start_addr >> 16) & 0xFF) << 8) | addr;
	addr = (((start_addr >> 8) & 0xFF) << 16) | addr;
	addr = ((start_addr & 0xFF) << 24) | addr;
	fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, addr);

	//4) command send
	ret = sfxdriver_spi_cs_ms_setup(dev);
	if (ret == 1) {
		sfx_pr_info("sfxdriver_spi_cs_ms_setup return 1 !\n");
		return 2;
	}

	//5) wait until finish
	loop = 0;
	while (1) {
		if (sfxdriver_spi_check_gone(dev))
			return 4;
		sfx_usleep(1000);
		sta = sfxdriver_spi_read_sta(dev);
		if ((sta & 0x1) == 0x0)
			return 0;
		loop++;
		if (loop >= 10000) {
			sfx_pr_info("[spi_sec_erase]ERROR: Erasing timeout!\n");
			return 3;
		}
	}
}

xt_u32 sfxdriver_norsw_erase_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len)
{
	xt_32 subsector_addr = dev->nor_sw + start_addr;
	xt_32 subsector_num = len / BYTE_PER_SUBSECTOR;
	xt_32 i, ret = 0;

	if (subsector_addr < dev->nor_sw) {
		sfx_pr_info("%s: %s error, invalid starting offset 0x%x < lower of dev->nor_sw\n",
			    __FUNCTION__, dev->name, start_addr);
		return 1;
	}
	if (subsector_addr + len > (dev->nor_sw + BYTE_PER_SECTOR)) {
		sfx_pr_info("%s: %s error, invalid len %u causes ending address > upper of dev->nor_sw\n",
			    __FUNCTION__, dev->name, len);
		return 2;
	}
	if (subsector_addr % BYTE_PER_SUBSECTOR) {
		sfx_pr_info("%s: %s error, subsector address must be 4K aligned\n", __FUNCTION__, dev->name);
		return 4;
	}

	if (len % BYTE_PER_SUBSECTOR)
		subsector_num++;

	for (i = 0; i < subsector_num; i++) {
		if ((ret = spi_4k_erase(dev, subsector_addr)))
			return ret;
		subsector_addr += BYTE_PER_SUBSECTOR;
	}
	return 0;
}

xt_u32 sfxdriver_spi_erase_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len)
{
	xt_32 sector_addr = start_addr;
	xt_32 sector_num = len / BYTE_PER_SECTOR;
	xt_32 i, ret = 0;

	if (start_addr % BYTE_PER_SECTOR) {
		return 4;
	}

	if (len % BYTE_PER_SECTOR)
		sector_num++;

	for (i = 0; i < sector_num; i++) {
		if ((ret = spi_sec_erase(dev, sector_addr)))
			return ret;
		sector_addr += BYTE_PER_SECTOR;
	}

	return 0;
}

xt_u32 sfx_kernel_spi_erase_data(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_spi_erase_data(dev, start_addr, len);
}
EXPORT_SYMBOL(sfx_kernel_spi_erase_data);

xt_u32 sfxdriver_spi_write_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data)
{
	// by default, use 4-bytes fast mode
	// len must be 4-byte aligned for fast data transfer
	// len <=128 bytes, due to HW limitation
	xt_u32 addr;
	xt_u32 datai, sta;
	xt_u32 i;
	xt_u32 ret = 0;
	xt_u32 loop = 0;
	xt_u32 wr_try = 0;

	for (wr_try = 0; wr_try <= WRITE_RETRY; wr_try++) {
		//1) cr reset and write enable
		ret = sfxdriver_spi_write_enable(dev);
		if (ret == 1)
			return ret;
		fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));

#ifdef SFX_SPI_DEBUG
#endif

		//2) push command
		fis_indirect_write32(dev, dev->bar, spi_spidtr, PAGE_PROG);

#ifdef SFX_SPI_DEBUG
#endif

		//3) push address
		addr = (start_addr >> 24) & 0xFF;
		addr = (((start_addr >> 16) & 0xFF) << 8) | addr;
		addr = (((start_addr >> 8) & 0xFF) << 16) | addr;
		addr = ((start_addr & 0xFF) << 24) | addr;
		fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, addr);

#ifdef SFX_SPI_DEBUG
#endif

		//4) push data
		for (i = 0; i < (len >> 2); i++) {
			datai = trans_data[i];
			fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, datai);
		}

#ifdef SFX_SPI_DEBUG
#endif

		//5) command send
		ret = sfxdriver_spi_cs_ms_setup(dev);
		if (ret == 1) {
			sfx_pr_info("sfxdriver_spi_cs_ms_setup return 1 !\n");
			return 2;
		}
#ifdef SFX_SPI_DEBUG
#endif

		//6) wait until finish
		while (1) {
			if (sfxdriver_spi_check_gone(dev))
				return 4;
			sfx_usleep(1000);
			sta = sfxdriver_spi_read_sta(dev);
			loop++;
			if ((sta & 0x1) == 0x0)
				return 0;
			if (loop >= 500) {
				if (wr_try >= WRITE_RETRY) {
					sfx_pr_info("[sfxdriver_spi_write_data]ERROR: Write data timeout!\n");
					return 3;
				} else {
					// Reset NOR
					ret = sfxdriver_NOR_init(dev);
					break;
				}
			}
		}
	}
	return ret;
}

xt_u32 sfx_kernel_spi_write_data(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_spi_write_data(dev, start_addr, len, trans_data);
}
EXPORT_SYMBOL(sfx_kernel_spi_write_data);

static xt_u32 sfxdriver_spi_read_data(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len, xt_u32 *rec_data)
{
	// by default, use 4-bytes fast mode
	// len must be 4-byte aligned for fast data transfer
	// len <=128 bytes, due to HW limitation
	xt_u32 addr;
	xt_u32 ret_data;
	xt_u32 i;
	xt_u32 ret = 0;

	//1) cr reset
	fis_indirect_write32(dev, dev->bar, spi_spicr, sfxdriver_spi_spicr_data_gen(1, 1, 1, 1, 1));

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:reset cr.\n");
#endif

	//2) push command
	fis_indirect_write32(dev, dev->bar, spi_spidtr, QUAD_O_FAST_RD_4B);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:push read command\n");
#endif

	//3) push address
	addr = (start_addr >> 24) & 0xFF;
	addr = (((start_addr >> 16) & 0xFF) << 8) | addr;
	addr = (((start_addr >> 8) & 0xFF) << 16) | addr;
	addr = ((start_addr & 0xFF) << 24) | addr;
	fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, addr);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:push address\n");
#endif

	//4) push dummy data
	fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, 0x55);

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:push dummy data\n");
#endif

	//5) push read data cycle
	for (i = 0; i < (len >> 2); i++) {
		fis_indirect_write32(dev, dev->bar, spi_spidtr_4B, 0x55);
	}

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:push read cycle\n");
#endif

	//6) command send
	ret = sfxdriver_spi_cs_ms_setup(dev);
	if (ret == 1)
		return ret;

#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:send command\n");
#endif

	//7) flush echo command, address and dummy data
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:flush echo command, address and dummy data:\n");
#endif
	ret_data = fis_indirect_read32(dev, dev->bar, spi_spidrr);
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:%08x\n", ret_data);
#endif
	ret_data = fis_indirect_read32(dev, dev->bar, spi_spidrr_4B);
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:%08x\n", ret_data);
#endif
	ret_data = fis_indirect_read32(dev, dev->bar, spi_spidrr_4B);
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:%08x\n", ret_data);
#endif

	//8) read data
#ifdef SFX_SPI_DEBUG
	sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:receving data:\n");
#endif
	for (i = 0; i < (len >> 2); i++) {
		ret_data = fis_indirect_read32(dev, dev->bar, spi_spidrr_4B);
#ifdef SFX_SPI_DEBUG
		sfx_pr_info("[SFX_SPI_DEBUG]sfx_read_data:%08x\n", ret_data);
#endif
		rec_data[i] = ret_data;
	}
	return 0;
}

xt_u32 sfxdriver_nor_flash_read(struct sfx_dev *dev, xt_u32 start_addr, xt_u32 len, xt_u32 *datao)
{
	xt_u32 ret = sfxdriver_spi_read_data(dev, start_addr, len, datao);

#ifdef SFX_SPI_DEBUG
	{
		xt_u32 i;
		for (i = 0; i < len; i++) {
			sfx_pr_info("[SFX_SPI_DEBUG]sfxdriver_nor_flash_read:%08x\n", datao[i]);
		}
	}
#endif
	return ret;
}

xt_u32 sfx_kernel_nor_flash_read(struct sfx_fd *fd, xt_u32 start_addr, xt_u32 len, xt_u32 *datao)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_nor_flash_read(dev, start_addr, len, datao);
}
EXPORT_SYMBOL(sfx_kernel_nor_flash_read);

xt_u32 sfxdriver_spi_read_nor_did(struct sfx_dev *dev, xt_u32 len, xt_u32 *datao)
{
	xt_u32 loop = 0, rdata = 0, ret = 0;
	xt_u32 did_info[3] = { 0, 0, 0 };
	xt_u32 i;

	if (len > 12) {
		sfx_pr_err("%s len should be less than 4.\n", __FUNCTION__);
		return 1;
	}
	rdata = sfxdriver_spi_read_sta(dev);
	ret = sfxdriver_spi_cmd(dev, RD_DID, 4);
	while (1) {
		if (sfxdriver_spi_check_gone(dev))
			return 4;
		rdata = fis_indirect_read32(dev, dev->bar, spi_spidrr);
		if (loop == 0) {
			did_info[0] = rdata;
		} else if (loop == 1) {
			did_info[1] = rdata;
		} else if (loop == 2) {
			if (rdata == 0x22)
				did_info[2] = 0x10000000;
			else if (rdata == 0x21)
				did_info[2] = 0x8000000;
			else if (rdata == 0x20)
				did_info[2] = 0x4000000;
			else if (rdata == 0x19)
				did_info[2] = 0x2000000;
			else if (rdata == 0x18)
				did_info[2] = 0x1000000;
			/*sfx_pr_info("%s: NOR Memory Cap: 0x%x\n", __FUNCTION__, did_info[2]);*/
		}
		loop++;
		// Check Receive FIFO
		rdata = fis_indirect_read32(dev, dev->bar, spi_spisr);
		if ((rdata & 0x1) == 0x1) {
			break;
		}
		if (loop >= 100) {
			sfx_pr_err("%s: Receive FIFO timeout!", __FUNCTION__);
			ret = 1;
			break;
		}
	}
	for (i = 0; i < (len >> 2); i++) {
		datao[i] = did_info[i];
#ifdef SFX_SPI_DEBUG
		if (i == 0)
			sfx_pr_info("%s: NOR Manufacture ID: 0x%x\n", __FUNCTION__, datao[i]);
		if (i == 1)
			sfx_pr_info("%s: NOR Memory Type: 0x%x\n", __FUNCTION__, datao[i]);
		if (i == 2)
			sfx_pr_info("%s: NOR Capacity: 0x%x\n", __FUNCTION__, datao[i]);
#endif
	}
	return ret;
}

xt_u32 sfx_kernel_spi_read_nor_did(struct sfx_fd *fd, xt_u32 len, xt_u32 *datao)
{
	struct sfx_dev *dev = fd->dev;
	return sfxdriver_spi_read_nor_did(dev, len, datao);
}
EXPORT_SYMBOL(sfx_kernel_spi_read_nor_did);

void sfxdriver_vu_get_feat_data(struct sfx_dev *dev, xt_u32 *feat_data)
{
	feat_data[0] = dev->ftl_mq_ctx.vu_feat_flag;
	feat_data[1] = dev->ftl_mq_ctx.vu_feat_val;
}

void sfx_kernel_vu_get_feat_data(struct sfx_fd *fd, xt_u32 *feat_data)
{
	sfxdriver_vu_get_feat_data(fd->dev, feat_data);
	return;
}
EXPORT_SYMBOL(sfx_kernel_vu_get_feat_data);
