/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_lockpages.c
 * ---------------------------------------------------------------------------
 */

#include "sfx_os_headers.h"
#include "sfx_ioctl.h"
#include "sfx_driver.h"
#include "osal.h"

#define PREALLOC_CNT 9

int sfx_page_list_init(struct sfx_dev *dev)
{
	int i;
	sfx_page **pages_prealloc;

	if (dev->page_mgr.initDone) {
		sfx_pr_err("%s: %s, tried to init twice!\n", __FUNCTION__, dev->name);
		return -1;
	}

	sfx_spin_lock_init(&dev->page_mgr.pages_list_lock);
	SFX_INIT_LIST_HEAD(&dev->page_mgr.free_pages_list);
	SFX_INIT_LIST_HEAD(&dev->page_mgr.corrupt_list);
	for (i = 0; i < sizeof(dev->page_mgr.pages_list) / sizeof(struct sfx_pages); i++) {
		dev->page_mgr.pages_list[i].id = i;
		if (!(pages_prealloc = sfx_kcalloc(PREALLOC_CNT, sizeof(*pages_prealloc), SFX_GFP_KERNEL))) {
			int j;
			for (j = 0; j < i; j++)
				sfx_kfree(dev->page_mgr.pages_list[j].pages);
			return -ENOMEM;
		}
		sfx_memset(pages_prealloc, 0, sizeof(*(pages_prealloc)) * PREALLOC_CNT);
		dev->page_mgr.pages_list[i].pages_prealloc = pages_prealloc;
		dev->page_mgr.pages_list[i].prealloc = 1;
		dev->page_mgr.pages_list[i].pages = 0;
		sfx_list_add_tail(&dev->page_mgr.pages_list[i].node, &dev->page_mgr.free_pages_list);
		dev->page_mgr.pages_free_slots++;
		SFX_INIT_LIST_HEAD(&dev->page_mgr.pages_list[i].on_fd);
	}
	dev->page_mgr.mem_locked_counter = 0;
	dev->page_mgr.mem_unlocked_counter = 0;
	dev->page_mgr.unlock_tries = 0;

	dev->page_mgr.initDone = 1;
	return 0;
}

void sfx_page_list_deinit(struct sfx_dev *dev)
{
	int i;
	sfx_pages_t *p;
	sfx_page **pages;

	for (i = 0; i < MAX_SLOTS; i++) {
		pages = dev->page_mgr.pages_list[i].pages_prealloc;
		if (pages)
			sfx_kfree(pages);
		else
			sfx_pr_err("%s: !dev->page_mgr.pages_list[%d].pages_prealloc, corrupted\n",
				   __FUNCTION__, i);
	}
	i = 0;
	sfx_list_for_each_entry(p, &dev->page_mgr.corrupt_list, node)
	{
		if (p->prealloc) {
			pages = p->pages;
			if (pages)
				sfx_kfree(pages);
			else
				sfx_pr_err("%s: !corrupt_list[%d].pages\n", __FUNCTION__, i);
		}
		i++;
	}
	dev->page_mgr.initDone = 0;
}

static xt_u32 get_freeslot(struct sfx_fd *fd, sfx_pages_t **po, xt_u32 count)
{
	struct sfx_dev *dev = fd->dev;
	unsigned long flags = 0;
	sfx_pages_t *p = NULL;
	int i = 0, j = 0;

	/* best effort */
	sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);
	while (!p && i < MAX_SLOTS) {
		if (sfx_list_empty(&dev->page_mgr.free_pages_list)) {
			sfx_pr_err("%s: %s out of free slots!\n", __FUNCTION__, dev->name);
			*po = NULL;
			sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
			return ERROR_DRIVER_RESOURCE_NOT_AVAILABLE;
		}
		p = sfx_list_first_entry(&dev->page_mgr.free_pages_list, struct sfx_pages, node);
		if (p->pages || !p->prealloc) {
			sfx_pr_err(
				"%s: %s p->pages[%d] 0x%p or !prealloc 0x%p is not free, put on corrupt_list!\n",
				__FUNCTION__, dev->name, p->id, p->pages, p->prealloc);
			sfx_list_del(&p->node);
			sfx_list_add_tail(&p->node, &dev->page_mgr.corrupt_list);
			dev->page_mgr.pages_free_slots++;
			j++;
			p = NULL;
		}
		i++;
	}
	if (i == MAX_SLOTS) {
		sfx_pr_err(
			"%s: %s MAX_SLOTS %u reached, ran out of table slots! %d page table entry was put on corrupt_list\n",
			__FUNCTION__, dev->name, MAX_SLOTS, j);
		*po = NULL;
		sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
		return ERROR_DRIVER_RESOURCE_NOT_AVAILABLE;
	}
	sfx_list_del(&p->node);
	p->count = count;
	dev->page_mgr.pages_free_slots--;
	dev->page_mgr.mem_locked_counter += count;
	sfx_list_add_tail(&p->on_fd, &fd->lockmem_list);
	sfx_atomic_add(count, &fd->mem_locked);
	*po = p;
	sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
	return NO_ERROR;
}

static xt_u32 back_freeslot(struct sfx_fd *fd, sfx_pages_t *pi)
{
	struct sfx_dev *dev = fd->dev;
	unsigned long flags = 0;
	sfx_pages_t *p = pi;

	sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);
	sfx_list_del(&p->on_fd);
	dev->page_mgr.mem_unlocked_counter += p->count;
	sfx_atomic_add(p->count, &fd->mem_unlocked);
	if (p->pages || !p->prealloc) {
		sfx_pr_err("%s: %s p->pages[%d] 0x%p or !prealloc 0x%p, put on corrupted_list!\n",
			   __FUNCTION__, dev->name, p->id, p->pages, p->prealloc);
		sfx_list_add_tail(&p->node, &dev->page_mgr.corrupt_list);
		sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
		return ERROR_CODE;
	}
	sfx_list_add_tail(&p->node, &dev->page_mgr.free_pages_list);
	dev->page_mgr.pages_free_slots++;
	p->count = 0;
	sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
	return NO_ERROR;
}

int sfx_unmap_user_pages_simple(struct sfx_fd *fd, sfx_pages_t *p)
{
	struct sfx_dev *dev = fd->dev;
	int i;
	unsigned long flags = 0;
	xt_u32 total;

	BUG_ON(dev->page_mgr.pages_free_slots == MAX_SLOTS);
	if (!p->count) {
		return 0;
	}
	total = p->count;
	if (!p->type) {
		for (i = 0; i < p->count; i++) {
			if (!p->pages[i]) {
				return 0;
			}
			sfx_put_page(p->pages[i]);
		}
	}
	if (!p->prealloc) {
		if (!p->pages) {
			sfx_pr_err("%s: !prealloc and !pages, id %d type %d count %d offset %d\n",
				   __FUNCTION__, p->id, p->type, p->count, p->offset);
			sfx_dump_stack();
		} else {
			if (p->type) {
				sfx_kmem_cache_free_wrapper(p->pages); // allocated by blk_ftl
			} else {
				sfx_kfree(p->pages); // allocated by sfxdriver
			}
		}
	} else {
		sfx_memset(p->pages_prealloc, 0, sizeof(*(p->pages_prealloc)) * PREALLOC_CNT);
	}

	p->type = 0;
	p->pages = 0;
	p->prealloc = 1;
	sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);
	sfx_list_add_tail(&p->node, &dev->page_mgr.free_pages_list);
	sfx_list_del(&p->on_fd);
	dev->page_mgr.pages_free_slots++;
	dev->page_mgr.mem_unlocked_counter += p->count;
	sfx_atomic_add(p->count, &fd->mem_unlocked);
	p->count = 0;
	sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);

	if (flags)
		flags = 0;

	return (int)total;
}

sfx_pages_t *sfx_get_page_info_from_index(struct sfx_dev *dev, sfx_ssize_t index)
{
	return &dev->page_mgr.pages_list[index];
}

int sfx_clear_pagelist(struct sfx_fd *fd, void *token)
{
	return sfx_unmap_user_pages_simple(fd, &fd->dev->page_mgr.pages_list[sfx_token2idx(token)]);
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_clear_pagelist);
#endif

int sfx_set_pagelist(struct sfx_fd *fd, sfx_page **list, void **token, xt_u32 count, int type, int offset)
{
	struct sfx_dev *dev = fd->dev;
	sfx_pages_t *p = NULL;

	if (!list) {
		sfx_pr_err("%s: %s !list\n", __FUNCTION__, dev->name);
		return 0;
	}

	if (get_freeslot(fd, &p, count)) {
		sfx_pr_err("%s/%s: %s get_freeslot() failed!\n", __FUNCTION__, __LINE__, dev->name);
		return 0;
	}
	p->pages = (sfx_page **)list;
	p->type = type;
	p->offset = offset;
	p->prealloc = 0;

	*token = (void *)((0x4B1DL << 48) | (((unsigned long)p->id) << 32));

	/* pr_info("%s: token=%p\n", __FUNCTION__, *token); */
	return (int)count;
}

#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_set_pagelist);
#endif

void sfx_length_one_sgl(struct sfx_dev *dev, xt_u32 *vaddr, xt_u32 *list, xt_u32 len, xt_u8 *mask,
			void *prd_buff)
{
	sfx_pages_t *p;
	sfx_page *addr = NULL;

	if (sfx_is_token_addr(vaddr)) {
		p = sfx_get_page_info_from_index(dev, sfx_token2idx(vaddr));

		addr = p->pages[list[0]];
		if (addr == (sfx_page *)sfx_virt_to_page(prd_buff, len)) {
			*mask |= 1U;
		}
	}
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_length_one_sgl);
#endif

xt_u32 sfx_create_sgl(struct sfx_fd *fd, xt_u32 *vaddr, xt_u32 *list, xt_u32 len, xt_u8 *mask, void *prd_buff,
		      void **token, sfx_bool from_kernel)
{
	struct sfx_dev *dev = fd->dev;
	sfx_page **pages = NULL;
	sfx_pages_t *p = NULL, *pp = NULL;
	sfx_page *addr = NULL;
	xt_u32 len_4 = 4, len_8 = 8;
	int i;
	xt_u32 ret = NO_ERROR;
	xt_u8 pre_mask = *mask;
	int type = 1;
	int err, off_check = 0, off_cnt = 0;

	if (sfx_is_token_addr(vaddr)) {
		p = sfx_get_page_info_from_index(dev, sfx_token2idx(vaddr));
		if (p->offset) { /* XXX */
			len_4++;
			len_8++;
		}
		if ((ret = get_freeslot(fd, &pp, len > 4 ? len_8 : len_4))) {
			sfx_pr_err("%s/%s: %s get_freeslot() failed, %d returned\n", __FUNCTION__, __LINE__,
				   dev->name, ret);
			return ret;
		}
		pages = pp->pages_prealloc;
		for (i = 0; i < len; i++) {
			if ((pre_mask >> i) & 0x1) {
				if (off_check && p->offset && (off_cnt + 1 < p->count)) {
					addr = p->pages[off_cnt + 1];
					off_check = 0;
				} else {
					addr = (sfx_page *)sfx_virt_to_page(prd_buff, len);
				}
			} else {
				addr = p->pages[list[i]];
				if (addr == (sfx_page *)sfx_virt_to_page(prd_buff, len)) {
					*mask |= (1U << i);
				}
				off_check = 1;
				off_cnt = list[i];
			}
#if KV_DEBUG
			sfx_pr_info("%s page[%d] %p, len %d, off_cnt %d, off_check %d\n", __FUNCTION__, i,
				    addr, len, off_cnt, off_check);
#endif
			pages[i] = addr;
			if (!pages[i]) {
				sfx_pr_info("%s %s, hit Null pages with len %d and pre_mask %2x page %p\n",
					    __FUNCTION__, dev->name, len, pre_mask, pages[i]);
				sfx_dump_stack();
				BUG();
			} else if ((unsigned long)pages[i] & 0x3) {
				sfx_pr_info("%s %s, hit Odd pages with len %d and pre_mask %2x page %p\n",
					    __FUNCTION__, dev->name, len, pre_mask, pages[i]);
				sfx_dump_stack();
				BUG();
			}
		}
		if (p->offset) { /* last page for unaligned */
			if (off_cnt + 1 >= p->count)
				pages[i++] = (sfx_page *)sfx_virt_to_page(prd_buff, len);
			else
				pages[i++] = p->pages[off_cnt + 1];
#if KV_DEBUG
			sfx_pr_info(
				"%s one more page[%d] 0x%p, len %d, off_cnt %d, off_check %d, page->count %d, dummy 0x%p\n",
				__FUNCTION__, i - 1, pages[i - 1], len, off_cnt, off_check, p->count,
				prd_buff);
#endif
		}
		if (len > 4) {
			while (i < len_8) {
				pages[i] = (sfx_page *)sfx_virt_to_page(prd_buff, len);
				i++;
			}
			for (i = 0; i < len_8; i++) {
				if (!pages[i]) {
					sfx_pr_info("%s %s, read empty page i %d, length %d, mask %x!!!\n",
						    __FUNCTION__, dev->name, i, len, *mask);
				}
			}
		} else {
			while (i < len_4) {
				pages[i] = (sfx_page *)sfx_virt_to_page(prd_buff, len);
				i++;
			}
			for (i = 0; i < len_4; i++) {
				if (!pages[i]) {
					sfx_pr_info("%s %s, read empty page i %d, length %d, mask %x!!!\n",
						    __FUNCTION__, dev->name, i, len, *mask);
				}
			}
		}
		pp->type = type;
		pp->offset = p->offset;
		pp->pages = pages;

		*token = (void *)((0x4B1DL << 48) | (((unsigned long)pp->id) << 32));
		ret = NO_ERROR;
	} else {
		if (len > 8) {
			if (from_kernel) {
				sfx_pr_err("%s/%s: len %d > 8 from_kernel\n", __FUNCTION__, __LINE__, len);
				sfx_dump_stack();
				while (!(pages = sfx_kcalloc(len, sizeof(*pages), SFX_GFP_NOIO))) {
					return ERROR_MALLOC;
				}
			} else {
				sfx_pr_err("%s/%s: len %d > 8 !from_kernel\n", __FUNCTION__, __LINE__, len);
				sfx_dump_stack();
				while (!(pages = sfx_kcalloc(len, sizeof(*pages), GFP_KERNEL))) {
					return ERROR_MALLOC;
				}
			}
		} else {
			if ((ret = get_freeslot(fd, &pp, len))) {
				sfx_pr_err("%s/%s: %s get_freeslot() failed, %d returned\n", __FUNCTION__,
					   __LINE__, dev->name, ret);
				return ret;
			}
			pages = pp->pages_prealloc;
		}
		for (i = 0; i < len; i++) {
			if (from_kernel) {
				if ((pre_mask >> i) & 0x1) {
					pages[i] = (sfx_page *)sfx_virt_to_page(prd_buff, len);
				} else {
					pages[i] = (sfx_page *)sfx_virt_to_page(
						(void *)((char *)vaddr + list[i] * 4096), len);
				}
			} else {
				if ((pre_mask >> i) & 0x1) {
					err = sfx_get_user_pages_fast((unsigned long)((char *)prd_buff), 1, 1,
								      &pages[i]);
					if (err < 0) {
						sfx_pr_err(
							"%s: %s, get_user_pages_fast for 1 page failed! err 0x%x\n",
							__FUNCTION__, dev->name, err);
					}
					if (err < 1) {
						sfx_pr_err(
							"%s: %s, get_user_pages_fast cannot get 1 page, 0 returned!\n",
							__FUNCTION__, dev->name);
					}
					BUG_ON(err > 1);
					if (err != 1) {
						sfx_kfree(pages);
						BUG();
					}
				} else {
					err = sfx_get_user_pages_fast(
						(unsigned long)((char *)vaddr + list[i] * 4096), 1, 1,
						&pages[i]);
					if (err < 0) {
						sfx_pr_err(
							"%s: %s, get_user_pages_fast for 1 page failed! err 0x%x\n",
							__FUNCTION__, dev->name, err);
					}
					if (err < 1) {
						sfx_pr_err(
							"%s: %s, get_user_pages_fast cannot get 1 page, 0 returned!\n",
							__FUNCTION__, dev->name);
					}
					BUG_ON(err > 1);
					if (err != 1) {
						sfx_kfree(pages);
						BUG();
					}
				}
				type = 0;
			}
		}
		if (pp) {
			pp->type = type;
			pp->offset = 0;
			pp->pages = pages;

			*token = (void *)((0x4B1DL << 48) | (((unsigned long)pp->id) << 32));
			ret = NO_ERROR;
		} else {
			sfx_pr_info(
				"%s/%s: %s len > 8, !pp, len %d type %d, get slot from free_pages_slots\n",
				__FUNCTION__, __LINE__, dev->name, len, type);
			ret = sfx_set_pagelist(fd, pages, (void **)token, len, type, 0) == len ? NO_ERROR :
												 ERROR_CODE;
		}
	}
	if (ret == ERROR_CODE) {
		sfx_pr_err("%s: %s, error %d!\n", __FUNCTION__, ret);
	}
	return ret;
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_create_sgl);
#endif

sfx_page **sfx_get_page_from_token(union handle *hand, xt_u32 *vaddr)
{
	sfx_pages_t *p;
	struct sfx_dev *dev = ((struct sfx_fd *)hand->fdk)->dev;
	if (sfx_is_token_addr(vaddr)) {
		p = sfx_get_page_info_from_index(dev, sfx_token2idx(vaddr));
		return p->pages;
	} else {
		return (sfx_page **)NULL;
	}
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_get_page_from_token);
#endif

long sfx_user_split_token(struct sfx_fd *fd, struct sfx_tk_spl_cmd sfx__user *umem)
{
	struct sfx_tk_spl_cmd mem;
	xt_u8 kmask;
	int count = 0;

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return -EFAULT;
	}

	if (!mem.length) {
		sfx_pr_info("%s: !mem_legth\n", __FUNCTION__);
		return -EINVAL;
	}

	kmask = (xt_u8)((xt_u64)(mem.mask));
	if (sfx_create_sgl(fd, mem.addr, mem.list, mem.length, &kmask, mem.prd_buff, (void **)&mem.token_addr,
			   sfx_false) == NO_ERROR) {
		count = mem.length;
	}
	mem.mask = (xt_u8 *)((xt_u64)kmask);

	if (sfx_copy_to_user(umem, &mem, sizeof(mem))) {
		return -EFAULT;
	}

	return (long)count;
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_user_split_token);
#endif

int sfx_delete_sgl(struct sfx_fd *fd, void *token)
{
	if (!sfx_is_token_addr(token)) {
		sfx_pr_err("%s: %s, %p not a valid driver token address!\n", __FUNCTION__, fd->dev->name,
			   token);
		sfx_dump_stack();
		return 0;
	}
	return sfx_clear_pagelist(fd, token);
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_delete_sgl);
#endif

long sfx_user_split_token_release(struct sfx_fd *fd, struct sfx_tk_spl_cmd sfx__user *umem)
{
	struct sfx_tk_spl_cmd mem;
	int count = 0;

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return -EFAULT;
	}
	count = sfx_delete_sgl(fd, mem.token_addr);
	return (long)count;
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_user_split_token_release);
#endif

void sfx_copy_data_to_token(xt_u32 *token, void **ppbuff, xt_u32 size)
{
	xt_u32 index;
	sfx_pages_t *psfx_pages;
	xt_u32 i;
	void *pdest_buff;
	xt_u8 *psrc_buff = (xt_u8 *)(*ppbuff);

	index = sfx_token2idx(token);
	psfx_pages = sfx_get_page_info_from_index(NULL, index);
	for (i = 0; i < size; i++) {
		pdest_buff = sfx_page_address(psfx_pages->pages[i]);
		sfx_memcpy(pdest_buff, &psrc_buff[i * 4096], 4096);
	}

	sfx_free(*ppbuff);
	sfx_mfree(ppbuff);
}
#ifdef USE_EXPORT_SYMBOL
EXPORT_SYMBOL(sfx_copy_data_to_token);
#endif

void *sfx_map_user_pages_simple(struct sfx_fd *fd, unsigned long addr, xt_u32 count)
{
	int i, err;
	sfx_pages_t *pp = NULL;
	sfx_page **pages = NULL;
	void *token = NULL;
	struct sfx_dev *dev = fd->dev;

	if (addr & 0x7) {
		return ERR_PTR(-EINVAL); /* -22 */
	}

	if (count > 8) {
		pages = sfx_kcalloc(count, sizeof(*pages), GFP_KERNEL);
		if (!pages) {
			return ERR_PTR(-ENOMEM); /* -12 */
		}
	} else {
		if (get_freeslot(fd, &pp, count)) {
			sfx_pr_err("%s/%s: %s get_freeslot() failed\n", __FUNCTION__, __LINE__, dev->name);
			return ERR_PTR(-ENOMEM);
		}
		pages = pp->pages_prealloc;
	}

	err = sfx_get_user_pages_fast(addr, count, 1, pages);
	if (err < 0) {
		sfx_pr_err("%s: %s, get_user_pages_fast failed! err %d count %u\n", __FUNCTION__,
			   fd->dev->name, err, count);
		err = -EFAULT;
		goto free_pages_slot;
	}
	if (err < count || err > count) {
		sfx_pr_err("%s: %s, get_user_pages_fast partial! err %d count %u\n", __FUNCTION__,
			   fd->dev->name, err, count);
		count = err;
		err = -EFAULT; /* -14 */
		goto put_pages;
	}
	if (!pp) {
		xt_u32 rtn = 0;

		rtn = sfx_set_pagelist(fd, pages, (void **)&token, count, 0, 0);
		if (rtn != count) {
			sfx_pr_info("%s: sfx_set_pagelist failed, count %ld rtn %ld token %p\n", __FUNCTION__,
				    count, rtn, token);
			err = -EINTR; /* -4 */
			goto put_pages;
		}
	} else {
		pp->type = 0;
		pp->offset = 0;
		pp->pages = pages;

		token = (void *)((0x4B1DL << 48) | (((unsigned long)pp->id) << 32));
	}
	return token;

put_pages:
	for (i = 0; i < count; i++) {
		sfx_put_page(pages[i]);
	}
free_pages_slot:
	if (pages) {
		sfx_kfree(pages);
	}
	if (pp) {
		sfx_memset(pages, 0, sizeof(*(pp->pages_prealloc)) * PREALLOC_CNT);
		if (back_freeslot(fd, pp)) {
			sfx_pr_err("%s: %s back_freeslot sfx_pages_t[%u] failed!\n", __FUNCTION__, dev->name,
				   pp->id);
		}
	}
	return ERR_PTR(err);
}

long sfx_lock_user_pages(struct sfx_fd *fd, struct sfx_mem_cmd sfx__user *umem)
{
	struct sfx_mem_cmd mem;
	int err = 0;

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return -EFAULT;
	}

	if (!mem.length) {
		sfx_pr_err("%s: Not token addr!!! 0x%p vaddr 0x%p\n", __FUNCTION__, mem.token_addr, mem.addr);
		return -EINVAL;
	}
	mem.token_addr = sfx_map_user_pages_simple(fd, (unsigned long)mem.addr, mem.length);
	if (!sfx_is_token_addr(mem.token_addr)) {
		sfx_pr_err("%s: %s, Not token addr!!! 0x%p vaddr 0x%p\n", __FUNCTION__, fd->dev->name,
			   mem.token_addr, mem.addr);
		err = -EINTR;
	} else {
		err = (int)mem.length;
	}

	if (sfx_copy_to_user(umem, &mem, sizeof(mem))) {
		return -EFAULT;
	}

	return (long)err;
}

long sfx_unlock_user_pages(struct sfx_fd *fd, struct sfx_mem_cmd sfx__user *umem)
{
	struct sfx_mem_cmd mem;
	int counter = -EFAULT;

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return counter;
	}

	if (sfx_is_token_addr(mem.token_addr)) {
		counter = sfx_unmap_user_pages_simple(
			fd, &fd->dev->page_mgr.pages_list[sfx_token2idx(mem.token_addr)]);
	} else {
		sfx_pr_err("%s: %s, 0x%p Not token addr!!!\n", __FUNCTION__, fd->dev->name, mem.token_addr);
	}

	return (long)counter;
}

/* Race condition with sfx_unmap_user_pages_simple and
 * sfx_map_user_pages_simple: must not be called concurrently with
 * them due to p->pages */
void sfx_unmap_all_pages(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	int token, found_pages = 0;

	for (token = 0; token < MAX_SLOTS; token++) {
		sfx_pages_t *p = &dev->page_mgr.pages_list[token];

		if (p->pages) {
			if (found_pages == 0) {
				found_pages = 1;
				sfx_pr_info("%s: %s, Found unlocked pages during cleanup!\n", __FUNCTION__,
					    dev->name);
			}

			sfx_unmap_user_pages_simple(fd, &dev->page_mgr.pages_list[token]);
		}
	}
}

xt_u32 sfx_get_page_ctr_val(struct sfx_dev *dev, int locked)
{
	return locked ? (locked == SFX_COUNTER_TRIES ? dev->page_mgr.unlock_tries :
						       dev->page_mgr.mem_locked_counter) :
			dev->page_mgr.mem_unlocked_counter;
}

#ifdef ENABLE_PAGES_CONTEXT_CLEANUP
void sfx_try_to_cleanup_pages_context(struct sfx_dev *dev, struct sfx_iod *iod)
{
	unsigned long flags = 0;
	sfx_ssize_t index = (sfx_ssize_t)(iod->private);

	if (iod->private != iod) {
		sfx_pages_t *p = sfx_get_page_info_from_index(dev, index);

		dev->page_mgr.unlock_tries++;

		dev->page_mgr.mem_unlocked_counter += iod->nents;

		p->count -= iod->nents;
		if (p->count < 0) {
			PR_INFO("Warning... %s, ID:%d count=%d/%d, something wrong here!!!\n", dev->name,
				p->id, p->count, p->total);
		}

		if (p->count <= 0) {
			sfx_kfree(p->pages);
			p->pages = 0;

			sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);
			sfx_list_add_tail(&p->node, &dev->page_mgr.free_pages_list);
			dev->page_mgr.pages_free_slots++;
			sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);
		}
	}
}
#endif

/*
 * Following functions intend to migrate page list management into instance
 * based implementation. There are no funtional changes comparing to the
 * global based implementation.
 */
long sfx_driver_user_set_pagelist(struct sfx_fd *fd, struct sfx_driver_user_set_pglist_cmd sfx__user *umem)
{
	struct sfx_driver_user_set_pglist_cmd mem;
	xt_u32 count;
	int err = 0;

	/* So far, no body calls us */
	sfx_pr_err("%s: enter\n", __FUNCTION__);
	sfx_dump_stack();

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return -EFAULT;
	}

	if (!mem.cnt) {
		sfx_pr_err("%s: !mem.cnt\n", __FUNCTION__);
		return -EINVAL;
	}

	count = sfx_set_pagelist(fd, (sfx_page **)mem.pglist, &mem.token_addr, mem.cnt, mem.type, mem.offset);

	if (!sfx_is_token_addr(mem.token_addr)) {
		sfx_pr_err("%s: Not token addr!!! 0x%p\n", __FUNCTION__, mem.token_addr);
		return -EINTR;
	} else {
		if (count != mem.cnt) {
			sfx_pr_err("%s: count %u != mem.length %u\n", __FUNCTION__, count, mem.cnt);
			return -EINTR;
		} else {
			err = (int)mem.cnt;
		}
	}

	if (sfx_copy_to_user(umem, &mem, sizeof(mem))) {
		return -EFAULT;
	}

	return (long)err;
}

int sfx_get_free_slot(struct sfx_dev *dev, xt_u32 *nfslot)
{
	unsigned long flags = 0;

	sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);
	*nfslot = dev->page_mgr.pages_free_slots;
	sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);

	return 0;
}

int sfx_get_user_freeslot(struct sfx_dev *dev, struct sfx_get_user_freeslot_cmd sfx__user *umem)
{
	unsigned long flags = 0;
	struct sfx_get_user_freeslot_cmd mem;

	if (sfx_copy_from_user(&mem, umem, sizeof(mem))) {
		return -EFAULT;
	}

	sfx_spin_lock_irqsave(&dev->page_mgr.pages_list_lock, flags);

	mem.fscnt = dev->page_mgr.pages_free_slots;
	sfx_spin_unlock_irqrestore(&dev->page_mgr.pages_list_lock, flags);

	if (sfx_copy_to_user(umem, &mem, sizeof(mem))) {
		return -EFAULT;
	}

	return 0;
}
