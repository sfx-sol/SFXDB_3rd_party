/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2016-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfxdriver_common.c
 * ---------------------------------------------------------------------------
 */

#include "sfxdriver_common.h"
#include "sfx_driver.h"
#include "sfx_driver_api.h"

#define FTL_PERF_DEBUG 0
#define ERROR_INJECTION_TEST (1)
#define NVME_HW_QSIZE_BASE 0x21400
#define RTT_THRESHOLD 500000000

/* Special values must be less than 0x1000 */
#ifndef POISON_POINTER_DELTA
#define POISON_POINTER_DELTA 0
#endif
#define CMD_CTX_BASE ((void *)POISON_POINTER_DELTA)
#define CMD_CTX_CANCELLED (0x30C + CMD_CTX_BASE)
#define CMD_CTX_COMPLETED (0x310 + CMD_CTX_BASE)
#define CMD_CTX_INVALID (0x314 + CMD_CTX_BASE)
#define CMD_CTX_ABORT (0x318 + CMD_CTX_BASE)

static void async_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe);
static void async_simple_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe);
static int adapter_alloc_cq(struct sfx_dev *dev, xt_u16 qid, struct sfx_queue *nvmeq);
static int adapter_alloc_sq(struct sfx_dev *dev, xt_u16 qid, struct sfx_queue *nvmeq, xt_u8 q_type,
			    xt_u8 stream_id);
static void sfx_del_queue_end(struct sfx_queue *nvmeq);

unsigned char admin_timeout = 10;
module_param(admin_timeout, byte, 0644);
MODULE_PARM_DESC(admin_timeout, "timeout in seconds for admin commands");

unsigned char nvme_io_timeout = 30;
module_param_named(io_timeout, nvme_io_timeout, byte, 0644);
MODULE_PARM_DESC(io_timeout, "timeout in seconds for I/O");

int cqe_single_process = 0;
module_param(cqe_single_process, int, 0);

int msix_disable = 0;
module_param(msix_disable, int, 0);

/**
 * sfx_suspend_queue - put queue into suspended state
 * @nvmeq - queue to suspend
 *
 * Returns 1 if already suspended, 0 otherwise.
 */
int sfx_suspend_queue(struct sfx_queue *nvmeq)
{
	int vector;

#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: q[%d] %p cq_vector %u %s\n", __FUNCTION__, nvmeq->qid, nvmeq, nvmeq->cq_vector,
		    nvmeq->dev->name);
	sfx_pr_info("%s: entry %p\n", __FUNCTION__, nvmeq->dev->entry);
#endif

	sfx_spin_lock_irq(&nvmeq->q_lock);
	if (nvmeq->q_suspended) {
		sfx_pr_info("%s: %s q[%d] cq_vector %u, already suspended, return 1\n", __FUNCTION__,
			    nvmeq->dev->name, nvmeq->qid, nvmeq->cq_vector);
		sfx_spin_unlock_irq(&nvmeq->q_lock);
		return 1;
	}
	vector = sfx_get_vector(nvmeq);
	nvmeq->q_suspended = 1;
	nvmeq->dev->online_queues--;
	sfx_spin_unlock_irq(&nvmeq->q_lock);

	sfx_irq_set_affinity_hint(vector, NULL);
	sfx_free_irq(vector, nvmeq);
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: IRQ %d freed\n", __FUNCTION__, vector);
#endif

	return 0;
}

/**
 * sfx_abort_cmd - Attempt aborting a command
 * @cmdid: Command id of a timed out IO
 * @queue: The queue with timed out IO
 *
 * Schedule controller reset if the command was already aborted once
 * before and still hasn't been returned to the driver, or if this is
 * the admin queue.
 */
static void sfx_abort_cmd(int cmdid, struct sfx_queue *nvmeq)
{
	// TODO: unsupproted currtnly
}

static struct sfx_cmd_info *sfx_cmd_info(struct sfx_queue *nvmeq)
{
	return (void *)&nvmeq->cmdid_data[BITS_TO_LONGS(nvmeq->q_depth)];
}

static void special_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe)
{
	if (ctx == CMD_CTX_CANCELLED)
		return;
	if (ctx == CMD_CTX_ABORT) {
		//todo: dev is not defined yet
		//++nvmeq->dev->abort_limit;
		return;
	}
	if (ctx == CMD_CTX_COMPLETED) {
		sfx_dev_warn(nvmeq->q_dmadev, "%s, completed id %d twice on queue %d\n", nvmeq->dev->name,
			     cqe->command_id, cqe->sq_id);
		return;
	}
	if (ctx == CMD_CTX_INVALID) {
		sfx_dev_warn(nvmeq->q_dmadev, "%s, invalid id %d completed on queue %d\n", nvmeq->dev->name,
			     cqe->command_id, cqe->sq_id);
		return;
	}

	sfx_dev_warn(nvmeq->q_dmadev, "%s, Unknown special completion %p\n", nvmeq->dev->name, ctx);
}

static void *cancel_cmdid(struct sfx_queue *nvmeq, int cmdid, sfx_completion_fn *fn)
{
	void *ctx;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
	if (fn)
		*fn = info[cmdid].fn;
	ctx = info[cmdid].ctx;
	info[cmdid].fn = special_completion;
	info[cmdid].ctx = CMD_CTX_CANCELLED;
	return ctx;
}

static unsigned sfx_queue_extra(int depth)
{
	return DIV_ROUND_UP(depth, 8) + (depth * sizeof(struct sfx_cmd_info));
}

/*
 * If the device has been passed off to us in an enabled state, just clear
 * the enabled bit. The spec says we should set the 'shutdown notification
 * bits', but doing so may cause the device to complete commands to the
 * admin queue ... and we don't know what memory that might be pointing at!
 */
int sfx_disable_ctrl(struct sfx_dev *dev, xt_u64 cap)
{
	xt_u32 cc = sfx_readl(&dev->bar->cc);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: cc:0x%08x ~NVME_CC_ENABLE\n", __FUNCTION__, cc);
#endif

	if (cc & NVME_CC_ENABLE)
		sfx_writel(cc & ~NVME_CC_ENABLE, &dev->bar->cc);
	return sfx_wait_ready(dev, cap, sfx_false);
}

int sfx_enable_ctrl(struct sfx_dev *dev, xt_u64 cap)
{
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: cc:0x%08x\n", __FUNCTION__, sfx_readl(&dev->bar->cc));
#endif
	return sfx_wait_ready(dev, cap, sfx_true);
}

extern xt_32 balloc;
static struct sfx_queue *sfx_alloc_queue(struct sfx_dev *dev, int qid, int depth, int vector, ftl_cmpl_cb cb,
					 unsigned int node)
{
	unsigned extra = sfx_queue_extra(depth);
	struct sfx_queue *nvmeq = sfx_kzalloc_node(dev, sizeof(*nvmeq) + extra, GFP_KERNEL);
	int i;
	int ret;

#ifdef VMX_SIZE_DEBUG
	sfx_pr_info("%s: sizeof(nvmeq) %u extra %u\n", __FUNCTION__, sizeof(*nvmeq), extra);
#endif
	balloc += (sizeof(*nvmeq) + extra);
	if (!nvmeq)
		return NULL;

	nvmeq->cqes = sfx_dma_alloc_coherent(dev, CQ_SIZE(depth), &nvmeq->cq_dma_addr, GFP_KERNEL);

	if (!nvmeq->cqes)
		goto free_nvmeq;
	sfx_memset((void *)nvmeq->cqes, 0, CQ_SIZE(depth));

	nvmeq->sq_cmds = sfx_dma_alloc_coherent(dev, SQ_SIZE(depth), &nvmeq->sq_dma_addr, GFP_KERNEL);
	if (!nvmeq->sq_cmds)
		goto free_cqdma;
	sfx_memset(nvmeq->sq_cmds, 0, SQ_SIZE(depth));

	if (qid && !sfx_zalloc_cpumask_var(&nvmeq->cpu_mask, GFP_KERNEL))
		goto free_sqdma;
#ifdef VMX_SIZE_DEBUG
	sfx_pr_info("%s: sizeof(cpumask) %u\n", __FUNCTION__, sizeof(*(nvmeq->cpu_mask)));
#endif
	balloc += sizeof(*(nvmeq->cpu_mask));

	nvmeq->q_dmadev = sfx_get_dmadev(dev);
	nvmeq->dev = dev;
	sfx_snprintf(nvmeq->irqname, sizeof(nvmeq->irqname), DEV_NAME_prefix "%dq%d", dev->instance, qid);

	ret = sfx_spin_lock_init(&nvmeq->q_lock);
	if (ret) {
		goto free_cpu_mask;
	}
	/* initialize here to elminiate the following message seen on CentOS 6.x */
	nvmeq->cq_phase = 1;
	nvmeq->q_db = dev->dbs + 4 * (qid * 2 * dev->db_stride);

	//Async_IO
	//ESX: make sure dev is defined as sfx_dev data structure before calling sfx_spin_lock_init(&)
	ret = sfx_spin_lock_init(&nvmeq->list_lock);
	if (ret) {
		goto destroy_q_lock;
	}

	SFX_INIT_LIST_HEAD(&nvmeq->sq_list);
	SFX_INIT_LIST_HEAD(&nvmeq->free_list);
	SFX_INIT_LIST_HEAD(&nvmeq->cq_list);
	for (i = 0; i < sizeof(nvmeq->iod_pool) / sizeof(struct async_io_cmd_info); i++) {
		if (sfx_alloc_prps(dev, &nvmeq->iod_pool[i])) {
			goto free_prps;
		}
#ifdef SG_PREALLOC
		if (!sfx_alloc_sgarray(dev, &nvmeq->iod_pool[i])) {
			goto free_prps;
		}
#endif
		SFX_INIT_LIST_HEAD(&nvmeq->iod_pool[i].node);
		sfx_list_add_tail(&nvmeq->iod_pool[i].node, &nvmeq->free_list);
	}

	nvmeq->q_depth = depth;
	nvmeq->cq_vector = vector;
	nvmeq->qid = qid;
	nvmeq->q_suspended = 1;
	nvmeq->cmpl_cb = cb;
	sfx_rcu_assign_pointer(dev->queues[qid], nvmeq);
	if (vector)
		dev->ioqueue_count++;
	sfx_os_mb();
	dev->queue_count++;
#ifdef SFXDRIVER_DEBUG
	PR_INFO("dev[%d]=0x%p, q[%d]=0x%p depth %d cq_vector=%u q/ioq count %u/%u q.cntrs %llu/%llu/%llu/%llu\n",
		nvmeq->dev->instance, nvmeq->dev, qid, nvmeq, nvmeq->q_depth, nvmeq->cq_vector,
		dev->queue_count, dev->ioqueue_count, (long long unsigned int)nvmeq->q_stats.sq_counter,
		(long long unsigned int)nvmeq->q_stats.irq_counter,
		(long long unsigned int)nvmeq->q_stats.cq_counter,
		(long long unsigned int)nvmeq->q_stats.cpl_counter);
	PR_INFO("cqes: %p 0x%016llx\n", nvmeq->cqes, (long long unsigned int)nvmeq->cq_dma_addr);
	PR_INFO("sqes: %p 0x%016llx\n", nvmeq->sq_cmds, (long long unsigned int)nvmeq->sq_dma_addr);
#endif

	return nvmeq;

free_prps:
	for (i = 0; i < sizeof(nvmeq->iod_pool) / sizeof(struct async_io_cmd_info); i++) {
		sfx_free_prps(nvmeq->dev, &nvmeq->iod_pool[i]);
#ifdef SG_PREALLOC
		sfx_free_sgarray(nvmeq->dev, &nvmeq->iod_pool[i]);
#endif
	}
	//destroy_list_lock:
	sfx_destroy_spinlock(&nvmeq->list_lock);

destroy_q_lock:
	sfx_destroy_spinlock(&nvmeq->q_lock);

free_cpu_mask:
	if (qid) {
		sfx_free_cpumask_var(nvmeq->cpu_mask);
	}
free_sqdma:
	sfx_dma_free_coherent(dev, SQ_SIZE(depth), (void *)nvmeq->sq_cmds, nvmeq->sq_dma_addr);
free_cqdma:
	sfx_dma_free_coherent(dev, CQ_SIZE(depth), (void *)nvmeq->cqes, nvmeq->cq_dma_addr);
free_nvmeq:
	sfx_kfree(nvmeq);
	return NULL;
}

/**
 * sfx_cancel_ios - Cancel outstanding I/Os
 * @queue: The queue to cancel I/Os on
 * @timeout: True to only cancel I/Os which have timed out
 */
static void sfx_cancel_ios(struct sfx_queue *nvmeq, sfx_bool timeout)
{
	int depth = nvmeq->q_depth - 1;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
	unsigned long now = jiffies;
	int cmdid = 0;

	for_each_set_bit (cmdid, nvmeq->cmdid_data, depth) {
		void *ctx;
		sfx_completion_fn fn;
		static struct nvme_completion cqe = {
			.status = sfx_cpu_to_le16(NVME_SC_ABORT_REQ << 1),
		};

		if (timeout && !sfx_time_after(now, info[cmdid].timeout))
			continue;
		if (info[cmdid].ctx == CMD_CTX_CANCELLED)
			continue;
		if (timeout && nvmeq->dev->initialized) {
			sfx_abort_cmd(cmdid, nvmeq);
			continue;
		}
		sfx_dev_warn(nvmeq->q_dmadev, "%s, Cancelling I/O %d QID %d\n", nvmeq->dev->name, cmdid,
			     nvmeq->qid);
		ctx = cancel_cmdid(nvmeq, cmdid, &fn);
		fn(nvmeq, ctx, &cqe);
	}
}

static int sfx_clear_cmdids(struct sfx_queue *nvmeq)
{
	int depth = nvmeq->q_depth - 1;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
	int cmdid = 0, cnt = 0;

	for_each_set_bit (cmdid, nvmeq->cmdid_data, depth) {
		sfx_pr_info("%s: %s, q[%u] cmdinfo[%d].ctx=%p, clear its bit\n", __FUNCTION__,
			    nvmeq->dev->name, nvmeq->qid, cmdid, info[cmdid].ctx);
		clear_bit(cmdid, nvmeq->cmdid_data);
		cnt++;
	}
	return cnt;
}

void sfx_init_queue(struct sfx_queue *nvmeq, xt_u16 qid)
{
	struct sfx_dev *dev = nvmeq->dev;
	unsigned extra = sfx_queue_extra(nvmeq->q_depth);

	/* the following lines are needed to re-initialze nvmeq after sending command in sfx_create_hw_io_queue() */
	nvmeq->sq_head = 0;
	nvmeq->sq_tail = 0;
	nvmeq->cq_head = 0;
	nvmeq->cq_phase = 1;
	nvmeq->q_db = dev->dbs + 4 * (qid * 2 * dev->db_stride);
	sfx_memset(nvmeq->cmdid_data, 0, extra);
	sfx_memset((void *)nvmeq->cqes, 0, CQ_SIZE(nvmeq->q_depth));
	nvmeq->q_suspended = 0;
	dev->online_queues++;
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: q[%d]=0x%p q_db=0x%p success\n", __FUNCTION__, nvmeq->qid, nvmeq,
		    (void *)nvmeq->q_db);
#endif
}

int sfx_configure_admin_queue(struct sfx_dev *dev)
{
	int result;
	xt_u32 aqa;
	xt_u64 cap = sfx_readq(&dev->bar->cap);
	struct sfx_queue *nvmeq;
#ifdef SFXDRVIER_DEBUG
	xt_u32 v = 1;
#endif

	result = sfx_disable_ctrl(dev, cap);
	if (result < 0)
		return result;

	nvmeq = raw_nvmeq(dev, 0);
	if (!nvmeq) {
		nvmeq = sfx_alloc_queue(dev, 0, 64, 0, NULL, 0xFFFFFFFF);
		if (!nvmeq)
			return SFX_ERR_ENOMEM;
	}

	aqa = nvmeq->q_depth - 1;
	aqa |= aqa << 16;

#ifdef MQ_NEWHW
	dev->ctrl_config = NVME_CC_ENABLE | NVME_CC_CSS_NVM | NVME_CC_ARB_VS;
#else
	dev->ctrl_config = NVME_CC_ENABLE | NVME_CC_CSS_NVM;
#endif
	dev->ctrl_config |= (SFX_PAGE_SHIFT - 12) << NVME_CC_MPS_SHIFT;
	dev->ctrl_config |= NVME_CC_ARB_RR | NVME_CC_SHN_NONE;
	dev->ctrl_config |= NVME_CC_IOSQES | NVME_CC_IOCQES;

	sfx_writel(aqa, &dev->bar->aqa);
	sfx_writeq(nvmeq->sq_dma_addr, &dev->bar->asq);
	sfx_writeq(nvmeq->cq_dma_addr, &dev->bar->acq);
	sfx_writel(dev->ctrl_config, &dev->bar->cc);

	result = sfx_enable_ctrl(dev, cap);
	if (result) {
		sfx_pr_err("%s: %s, sfx_enable_ctrl failed, %d returned\n", __FUNCTION__, dev->name, result);
		goto sfx_configure_admin_queue_free_queue;
	}

	result = queue_request_irq(dev, nvmeq, nvmeq->irqname);
	if (result) {
		sfx_pr_err("%s: %s, queue_request_irq q[0] failed, %d returned\n", __FUNCTION__, dev->name,
			   result);
		goto sfx_configure_admin_queue_disable_ctrl;
	}

	sfx_spin_lock_irq(&nvmeq->q_lock);
	sfx_init_queue(nvmeq, 0);
	sfx_spin_unlock_irq(&nvmeq->q_lock);

#ifdef SFXDRVIER_DEBUG
	if ((v = sfx_readl(&dev->bar->csts)) == -1) {
		sfx_pr_info("%s: csts == -1\n", __FUNCTION__);
	} else {
		sfx_pr_info("%s: csts == 0x%08x\n", __FUNCTION__, v);
	}
#endif

	return result;

sfx_configure_admin_queue_disable_ctrl:
	sfx_disable_ctrl(dev, cap);
sfx_configure_admin_queue_free_queue:
	if (nvmeq)
		sfx_free_queues(dev, 0);

	return result;
}

static void sfx_put_dq(struct sfx_delq_ctx *dq)
{
	sfx_atomic_dec(&dq->refcount);
	sfx_pr_info("%s: dq->refcount--\n", __FUNCTION__);
	if (dq->waiter) {
		sfx_wake_up_process(dq->waiter);
	}
}

struct sfx_delq_ctx *sfx_get_dq(struct sfx_delq_ctx *dq)
{
	sfx_atomic_inc(&dq->refcount);
	sfx_pr_info("%s: dq->refcount++, return dq %p\n", __FUNCTION__, dq);
	return dq;
}

#ifdef USE_KTIME_CTX
inline void _sfx_statistics_sync(struct sfx_queue *q, struct sync_cmd_info *cmdinfo)
{
	struct sfx_dev *dev = q->dev;
	xt_u64 rtt, smt;

	rtt = (sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its));
	smt = (sfx_ktime_to_ns(cmdinfo->smt) - sfx_ktime_to_ns(cmdinfo->its));

	if (rtt >= RTT_THRESHOLD) {
		sfx_pr_info("%s: %s q[%d] Large rtt 0x%lx smt 0x%lx opcode=0x%x\n", __FUNCTION__, dev->name,
			    q->qid, rtt, smt, cmdinfo->opcode);
	}

	if (cmdinfo->opcode == sfx_cmd_nand_reset) {
		q->q_stats.lat_s.nandreset_rtt += rtt;
		q->q_stats.lat_s.nandreset_smt += smt;
		q->q_stats.lat_s.nandreset_cnt++;
		if (rtt > q->q_stats.lat_s.nandreset_max)
			q->q_stats.lat_s.nandreset_max = rtt;
	} else if (cmdinfo->opcode == sfx_cmd_aes_program) {
		q->q_stats.lat_s.aes_rtt += rtt;
		q->q_stats.lat_s.aes_smt += smt;
		q->q_stats.lat_s.aes_cnt++;
		if (rtt > q->q_stats.lat_s.aes_max)
			q->q_stats.lat_s.aes_max = rtt;
	} else if (cmdinfo->opcode == nvme_admin_identify) {
		q->q_stats.lat_s.ai_rtt += rtt;
		q->q_stats.lat_s.ai_smt += smt;
		q->q_stats.lat_s.ai_cnt++;
		if (rtt > q->q_stats.lat_s.ai_max)
			q->q_stats.lat_s.ai_max = rtt;
	} else if (cmdinfo->opcode == nvme_admin_get_features) {
		q->q_stats.lat_s.gf_rtt += rtt;
		q->q_stats.lat_s.gf_smt += smt;
		q->q_stats.lat_s.gf_cnt++;
		if (rtt > q->q_stats.lat_s.gf_max)
			q->q_stats.lat_s.gf_max = rtt;
	} else if (cmdinfo->opcode == nvme_admin_set_features) {
		q->q_stats.lat_s.sf_rtt += rtt;
		q->q_stats.lat_s.sf_smt += smt;
		q->q_stats.lat_s.sf_cnt++;
		if (rtt > q->q_stats.lat_s.sf_max)
			q->q_stats.lat_s.sf_max = rtt;
	} else {
		q->q_stats.lat_s.other_rtt += rtt;
		q->q_stats.lat_s.other_smt += smt;
		q->q_stats.lat_s.other_cnt++;
		if (rtt > q->q_stats.lat_s.other_max)
			q->q_stats.lat_s.other_max = rtt;
	}
	return;
}
inline void _sfx_statistics_async(struct sfx_queue *q, struct async_cmd_info *cmdinfo)
{
	struct sfx_dev *dev = q->dev;
	xt_u64 rtt, smt;

	rtt = (sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its));
	smt = (sfx_ktime_to_ns(cmdinfo->smt) - sfx_ktime_to_ns(cmdinfo->its));

	if (rtt >= RTT_THRESHOLD) {
		sfx_pr_info("%s: %s q[%d] Large rtt 0x%lx smt 0x%lx opcode=0x%x\n", __FUNCTION__, dev->name,
			    q->qid, rtt, smt, cmdinfo->opcode);
	}

	if (cmdinfo->opcode == nvme_admin_delete_cq) {
		q->q_stats.lat_s.dcq_rtt += rtt;
		q->q_stats.lat_s.dcq_smt += smt;
		q->q_stats.lat_s.dcq_cnt++;
		if (rtt > q->q_stats.lat_s.dcq_max)
			q->q_stats.lat_s.dcq_max = rtt;
	} else if (cmdinfo->opcode == nvme_admin_delete_cq) {
		q->q_stats.lat_s.dsq_rtt += rtt;
		q->q_stats.lat_s.dsq_smt += smt;
		q->q_stats.lat_s.dsq_cnt++;
		if (rtt > q->q_stats.lat_s.dsq_max)
			q->q_stats.lat_s.dsq_max = rtt;
	} else {
		q->q_stats.lat_s.other_rtt += rtt;
		q->q_stats.lat_s.other_smt += smt;
		q->q_stats.lat_s.other_cnt++;
		if (rtt > q->q_stats.lat_s.other_max)
			q->q_stats.lat_s.other_max = rtt;
	}
	return;
}
inline void _sfx_statistics_async_simple(struct sfx_queue *q, struct async_io_cmd_info *cmdinfo)
{
	struct sfx_dev *dev = q->dev;
	xt_u64 rtt, smt;

	rtt = (sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its));
	smt = (sfx_ktime_to_ns(cmdinfo->smt) - sfx_ktime_to_ns(cmdinfo->its));

	if (rtt >= RTT_THRESHOLD) {
		sfx_pr_info("%s: %s q[%d] Large rtt 0x%lx smt 0x%lx opcode=0x%x\n", __FUNCTION__, dev->name,
			    q->qid, rtt, smt, cmdinfo->opcode);
	}

	if (cmdinfo->opcode == sfx_cmd_nand_reset) {
		q->q_stats.lat_s.nandreset_rtt += rtt;
		q->q_stats.lat_s.nandreset_smt += smt;
		q->q_stats.lat_s.nandreset_cnt++;
		if (rtt > q->q_stats.lat_s.nandreset_max)
			q->q_stats.lat_s.nandreset_max = rtt;
	} else if (cmdinfo->opcode == nvme_cmd_write) {
		q->q_stats.lat_s.wr_rtt += rtt;
		q->q_stats.lat_s.wr_smt += smt;
		q->q_stats.lat_s.wr_cnt++;
		if (rtt > q->q_stats.lat_s.wr_max)
			q->q_stats.lat_s.wr_max = rtt;
	} else if (cmdinfo->opcode == nvme_cmd_read) {
		q->q_stats.lat_s.rd_rtt += rtt;
		q->q_stats.lat_s.rd_smt += smt;
		q->q_stats.lat_s.rd_cnt++;
		if (rtt > q->q_stats.lat_s.rd_max)
			q->q_stats.lat_s.rd_max = rtt;
	} else {
		q->q_stats.lat_s.other_asyncio_rtt += rtt;
		q->q_stats.lat_s.other_asyncio_smt += smt;
		q->q_stats.lat_s.other_asyncio_cnt++;
		if (rtt > q->q_stats.lat_s.other_asyncio_max)
			q->q_stats.lat_s.other_asyncio_max = rtt;
	}
	return;
}
#endif

static void sync_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe)
{
	struct sync_cmd_info *cmdinfo = ctx;

#ifdef USE_KTIME_CTX
	cmdinfo->irq = sfx_ktime_get();
	cmdinfo->latency = sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its);
	_sfx_statistics_sync(nvmeq, cmdinfo);
#endif
	cmdinfo->result = sfx_le32_to_cpup(&cqe->result);
	cmdinfo->ext_result = sfx_le32_to_cpup(&cqe->ext_result);
	cmdinfo->status = sfx_le16_to_cpup(&cqe->status) >> 1;
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: result 0x%x ext_result 0x%x status 0x%x\n", __FUNCTION__, cmdinfo->result,
		    cmdinfo->ext_result, cmdinfo->status);
#endif
	if (cmdinfo->status != NVME_SC_ABORT_REQ) {
		sfx_wake_up_process(cmdinfo->task);
	} else {
		sfx_pr_info("%s: %s, status 0x%x == NVME_SC_ABORT_REQ\n", __FUNCTION__, nvmeq->dev->name,
			    cmdinfo->status);
	}
}

/**
 * alloc_cmdid() - Allocate a Command ID
 * @nvmeq: The queue that will be used for this command
 * @ctx: A pointer that will be passed to the handler
 * @handler: The function to call on completion
 *
 * Allocate a Command ID for a queue.  The data passed in will
 * be passed to the completion handler.  This is implemented by using
 * the bottom two bits of the ctx pointer to store the handler ID.
 * Passing in a pointer that's not 4-byte aligned will cause a BUG.
 * We can change this if it becomes a problem.
 *
 * May be called with local interrupts disabled and the q_lock held,
 * or with interrupts enabled and no locks held.
 */
static int alloc_cmdid(struct sfx_queue *nvmeq, void *ctx, sfx_completion_fn handler, unsigned timeout)
{
	int depth = nvmeq->q_depth - 1;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
	int cmdid;

	do {
		cmdid = find_first_zero_bit(nvmeq->cmdid_data, depth);
		if (cmdid >= depth) {
			sfx_pr_info("%s, Returning EBUSY: cmdid=%i, depth=%i\n", nvmeq->dev->name, cmdid,
				    depth);
			return -EBUSY;
		}
	} while (test_and_set_bit(cmdid, nvmeq->cmdid_data));

	info[cmdid].fn = handler;
	info[cmdid].ctx = ctx;
	info[cmdid].timeout = jiffies + timeout;
	info[cmdid].aborted = 0;
	return cmdid;
}

#ifdef USE_CCS_NID
static int alloc_cmdid_simple(struct sfx_queue *nvmeq, struct async_io_cmd_info *ctx,
			      sfx_completion_fn handler, unsigned timeout)
{
	// int depth = nvmeq->q_depth - 1;
	int nid = ctx->apptag;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);

	if (!nvmeq->qid) {
		if (nid > HOT_IO_QD) {
			sfx_pr_err("%s: inconsistent nid %u > HOT_IO_QD for nvmeq0 submission\n",
				   __FUNCTION__, nid);
			dump_stack();
			return -EBUSY;
		}
		nid += HOT_IO_QD;
		sfx_pr_err("%s: send to nvmeq0 nid %u\n", __FUNCTION__, nid);
	}
	if (!test_bit(nid, nvmeq->cmdid_data)) {
		test_and_set_bit(nid, nvmeq->cmdid_data);
	} else {
		sfx_pr_err("%s: nid %u in use\n", __FUNCTION__, nid);
		return -EBUSY;
	}

	info[nid].fn = handler;
	info[nid].ctx = (void *)ctx;
	info[nid].timeout = jiffies + timeout;
	info[nid].aborted = 0;
	return nid;
}
#endif

static int alloc_cmdid_killable(struct sfx_queue *nvmeq, void *ctx, sfx_completion_fn handler,
				unsigned timeout)
{
	int cmdid;
	cmdid = alloc_cmdid(nvmeq, ctx, handler, timeout);
	return (cmdid < 0) ? -EINTR : cmdid;
}

sfx_bool nvme_cqe_valid(struct sfx_queue *q, xt_u16 head, xt_u16 phase)
{
	return (sfx_le16_to_cpu(q->cqes[head].status) & 1) == phase;
}

/*
 * Called with local interrupts disabled and the q_lock held.
 * May not sleep.
 */
void *free_cmdid(struct sfx_queue *nvmeq, int cmdid, sfx_completion_fn *fn)
{
	void *ctx;
	struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
#ifdef USE_KTIME_ALL
	struct sfx_dev *dev = nvmeq->dev;
	xt_u64 rtt;
#endif

	if (cmdid >= nvmeq->q_depth || !info[cmdid].fn) {
		sfx_pr_err("%s: %s, cmdid %u > q_depth %u || !info[].fn %p\n", __FUNCTION__, nvmeq->dev->name,
			   cmdid, nvmeq->q_depth, info[cmdid].fn);
		if (fn)
			*fn = special_completion;
		return CMD_CTX_INVALID;
	}
#ifdef USE_KTIME_ALL
	info[cmdid].cts = sfx_ktime_get();
	rtt = sfx_ktime_to_ns(info[cmdid].cts) - sfx_ktime_to_ns(info[cmdid].sts);
	if (rtt >= RTT_THRESHOLD) {
		sfx_pr_info("%s: %s q[%u] rtt 0x%lx Too large\n", __FUNCTION__, dev->name, nvmeq->qid, rtt);
	}
	nvmeq->q_stats.lat_rtt += rtt;
#endif
	if (fn)
		*fn = info[cmdid].fn;
	ctx = info[cmdid].ctx;
	info[cmdid].fn = special_completion;
	info[cmdid].ctx = CMD_CTX_COMPLETED;
	clear_bit(cmdid, nvmeq->cmdid_data);
	return ctx;
}

int sfx_process_cq(void *ctx, int lock_need, xt_u32 cmpl_target)
{
	struct sfx_queue *nvmeq = ctx;
	struct sfx_dev *dev = nvmeq->dev;
	xt_u16 head, phase;
	unsigned long flag;
	xt_u32 cmpl_cmd = 0;
#ifdef SFXDRIVER_DEBUG
	short d = 0;
#endif
	if (lock_need) {
		sfx_spin_lock_irqsave(&nvmeq->q_lock, flag);
		nvmeq->q_stats.poll_total++;
	}

	head = nvmeq->cq_head;
	phase = nvmeq->cq_phase;

	/* Read CQE phase bit (validity) before the rest of the structure.
     * The phase bit is the highest address and the CQE read will happen
     * on most platforms from lower to upper addresses and will be done
     * by multiple non-atomic loads.
     * If the structure is updated by PCI during the reads from the processor,
     * the processor may get a corrupted copy.
     * Ref. ticket# 326.
   */
	while (nvme_cqe_valid(nvmeq, head, phase)) {
		void *ctx;
		sfx_completion_fn fn;

		struct nvme_completion cqe = nvmeq->cqes[head];

#if (HOT_READ_PERF || HOT_WRITE_PERF)
		if (cqe.sq_id >= NON_IO_QUEUE && dev->ftl_mq_ctx.ioq_config) {
			xt_u8 io_cmd = (sfx_qid_is_wrq(cqe.sq_id, dev->ftl_mq_ctx.ioq_config) ||
					sfx_qid_is_rdq(cqe.sq_id, dev->ftl_mq_ctx.ioq_config));
			if (io_cmd) {
				struct sfx_cmd_info *info = sfx_cmd_info(nvmeq);
				struct async_io_cmd_info *cmdinfo = info[cqe.command_id].ctx;
				if (cmdinfo->iod) {
					cmdinfo->iod->irq_time = sfx_ktime_get();
#if (READ_HW_LAT)
					cmdinfo->iod->hw_dbell_tcnt =
						fis_indirect_read32(dev, dev->bar, DBELL_TCNT_ADDR);
					cmdinfo->iod->hw_cpl_tcnt =
						fis_indirect_read32(dev, dev->bar, CPL_TCNT_ADDR);
					fis_indirect_write32(dev, dev->bar, TCNT_CTL_ADDR, 0);
					fis_indirect_write32(dev, dev->bar, TCNT_CTL_ADDR, 1);
#endif
				}
			}
		}
#endif

		nvmeq->q_stats.cq_counter++;
		if (lock_need) {
			nvmeq->q_stats.poll_counter++;
		} else if (cmpl_target == 0xffffffff) {
			nvmeq->q_stats.polling_counter++;
		}
		nvmeq->sq_head = sfx_le16_to_cpu(cqe.sq_head);
		if ((++head) == nvmeq->q_depth) {
			head = 0;
			phase = !phase;
		}

		ctx = free_cmdid(nvmeq, cqe.command_id, &fn);

		fn(nvmeq, ctx, &cqe);

		dev->sfx_stats.cq_counter[nvmeq->qid]++;

		if (cqe_single_process) {
			break;
		}
		if (lock_need && ((++cmpl_cmd) == cmpl_target)) {
			break;
		}
	}
#ifdef SFXDRIVER_DEBUG
	d = head - nvmeq->cq_head;
	if (d > 0) {
		PR_INFO("qid=%d %d processed, phase %u/%u\n", nvmeq->qid, d, nvmeq->cq_phase, phase);
	}
#endif

	/* If the controller ignores the cq head doorbell and continuously
     * writes to the queue, it is theoretically possible to wrap around
     * the queue twice and mistakenly return IRQ_NONE.  Linux only
     * requires that 0.1% of your interrupts are handled, so this isn't
     * a big problem.
     */
	if (head == nvmeq->cq_head && phase == nvmeq->cq_phase) {
		if (lock_need) {
			sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flag);
		}
		return 0;
	}

	sfx_writel(head, (xt_u32 *)nvmeq->q_db + nvmeq->dev->db_stride);
	nvmeq->cq_head = head;
	nvmeq->cq_phase = phase;
	nvmeq->cqe_seen = 1;
	if (lock_need) {
		sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flag);
	}
	return 1;
}
EXPORT_SYMBOL(sfx_process_cq); //todo

static void sfx_abort_command(struct sfx_queue *nvmeq, int cmdid)
{
	sfx_spin_lock_irq(&nvmeq->q_lock);
	cancel_cmdid(nvmeq, cmdid, NULL);
	sfx_spin_unlock_irq(&nvmeq->q_lock);
}

static void sfx_del_queue_end(struct sfx_queue *nvmeq)
{
	struct sfx_delq_ctx *dq = nvmeq->cmdinfo.ctx;

	sfx_pr_info("%s: %s, nvmeq[%u] call sfx_clear_queue+sfx_put_dq\n", __FUNCTION__, nvmeq->dev->name,
		    nvmeq->qid);
	sfx_clear_queue(nvmeq);
	sfx_put_dq(dq);
}

void sfx_del_queue_start(struct sfx_work_struct *work)
{
	struct sfx_queue *nvmeq = container_of(work, struct sfx_queue, cmdinfo.work);
	if (sfx_delete_sq(nvmeq)) {
		sfx_pr_info("%s: %s, nvmeq[%u] sfx_delete_sq failed, call sfx_del_queu_end\n", __FUNCTION__,
			    nvmeq->dev->name, nvmeq->qid);
		sfx_del_queue_end(nvmeq);
	}
}

/*
 * Returns 0 on success. If the result is negative, it's a Linux error
 * code; If the result is positive, it's an NVM Express status code
 */
int sfx_submit_sync_cmd(struct sfx_dev *dev, int q_idx, struct nvme_command *cmd, xt_u32 *result,
			xt_u64 timeout)
{
	int cmdid, ret;
	struct sync_cmd_info cmdinfo;
	struct sfx_queue *nvmeq;
	unsigned i = 0;

#ifdef USE_KTIME_CTX
	cmdinfo.opcode = cmd->common.opcode;
	cmdinfo.its = sfx_ktime_get();
#endif
	nvmeq = lock_nvmeq(dev, q_idx);

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, q_idx);
		return -ENODEV;
	}

	cmdinfo.task = sfx_get_current();
	cmdinfo.status = -EINTR;

	cmdid = alloc_cmdid(nvmeq, &cmdinfo, sync_completion, timeout);

	if (cmdid < 0) {
		unlock_nvmeq(nvmeq);
		return cmdid;
	}
	cmd->common.command_id = cmdid;

	sfx_set_current_state(TASK_KILLABLE);
#ifdef USE_KTIME_CTX
	cmdinfo.smt = sfx_ktime_get();
#endif
	ret = sfx_submit_cmd(nvmeq, cmd);
	if (ret) {
		free_cmdid(nvmeq, cmdid, NULL);
		unlock_nvmeq(nvmeq);
		sfx_set_current_state(TASK_RUNNING);
		return ret;
	}
	unlock_nvmeq(nvmeq);
	sfx_schedule_timeout(timeout);

	if (cmdinfo.status == -EINTR) {
		if (cmd->rw.opcode == sfx_cmd_nand_reset) {
			sfx_pr_info("%s: %s, sfx_cmd_nand_reset timeout, i %d\n", __FUNCTION__, dev->name, i);
			while (i < 3) {
				/* either wake_up_process() or more than 3 loops can break us */
				sfx_schedule_timeout(timeout);
				i++;
				if (cmdinfo.status == -EINTR)
					continue;
				else
					break;
			}
			sfx_pr_info("%s: %s, sfx_cmd_nand_reset break, i %d status %d\n", __FUNCTION__,
				    dev->name, i, cmdinfo.status);
			if (i == 3 || cmdinfo.status == -EINTR)
				return -EINTR;
		}
		sfx_pr_info("%s: %s, q[%u], opcode 0x%x -EINTR\n", __FUNCTION__, dev->name, nvmeq->qid,
			    cmd->rw.opcode);
		nvmeq = lock_nvmeq(dev, q_idx);
		if (nvmeq) {
			sfx_abort_command(nvmeq, cmdid);
			unlock_nvmeq(nvmeq);
		}
		return -EINTR;
	}

	if (result)
		*result = cmdinfo.result;

	dev->sfx_stats.cpl_counter[q_idx]++;
	nvmeq->q_stats.cpl_counter++;

	return cmdinfo.status;
}

static void async_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe)
{
	struct async_cmd_info *cmdinfo = ctx;

#ifdef USE_KTIME_CTX
	cmdinfo->irq = sfx_ktime_get();
	cmdinfo->latency = sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its);
	_sfx_statistics_async(nvmeq, cmdinfo);
#endif
	cmdinfo->result = sfx_le32_to_cpup(&cqe->result);
	//    cmdinfo->lba = sfx_le32_to_cpup(&cqe->lba);
	cmdinfo->ext_result = sfx_le32_to_cpup(&cqe->ext_result);
	cmdinfo->status = sfx_le16_to_cpup(&cqe->status) >> 1;
	sfx_queue_work(cmdinfo->worker, &cmdinfo->work);
}

static int sfx_submit_async_cmd(struct sfx_queue *nvmeq, struct nvme_command *cmd,
				struct async_cmd_info *cmdinfo, unsigned timeout)
{
	int cmdid, rtn;

#ifdef USE_KTIME_CTX
	cmdinfo->opcode = cmd->common.opcode;
	cmdinfo->its = sfx_ktime_get();
#endif
	cmdid = alloc_cmdid_killable(nvmeq, cmdinfo, async_completion, timeout);
	if (cmdid < 0) {
		sfx_pr_err("%s: q[%u] cmdid %d < 0\n", __FUNCTION__, nvmeq->qid, cmdid);
		return cmdid;
	}
	cmdinfo->status = -EINTR;
	cmd->common.command_id = cmdid;
#ifdef USE_KTIME_CTX
	cmdinfo->smt = sfx_ktime_get();
#endif
	rtn = sfx_submit_cmd(nvmeq, cmd);
	if (rtn) {
		sfx_pr_err("%s: q[%u] sfx_submit_cmd cmdid %d failed, %d returned\n", __FUNCTION__,
			   nvmeq->qid, cmdid, rtn);
		cancel_cmdid(nvmeq, cmdid, NULL);
	}
	return rtn;
}

static int sfx_submit_admin_cmd_async(struct sfx_dev *dev, struct nvme_command *cmd,
				      struct async_cmd_info *cmdinfo)
{
	return sfx_submit_async_cmd(raw_nvmeq(dev, 0), cmd, cmdinfo, SFX_ADMIN_TIMEOUT);
}

int adapter_async_del_queue(struct sfx_queue *nvmeq, xt_u8 opcode, sfx_work_func_t fn)
{
	struct nvme_command c;

	sfx_memset(&c, 0, sizeof(c));
	c.delete_queue.opcode = opcode;
	c.delete_queue.qid = sfx_cpu_to_le16(nvmeq->qid);
	sfx_bd_prepare_work(&nvmeq->cmdinfo.work, fn);
	return sfx_submit_admin_cmd_async(nvmeq->dev, &c, &nvmeq->cmdinfo);
}
#if (HOT_WRITE_PERF)
void _sfx_rd_statistics(struct sfx_dev *dev, xt_u8 qid, struct sfx_iod *iod);
#endif

static void async_simple_completion(struct sfx_queue *nvmeq, void *ctx, struct nvme_completion *cqe)
{
	struct sfx_dev *dev = nvmeq->dev;
	sfx_nvme_cmpl *nvme_cmpl = (sfx_nvme_cmpl *)cqe;

	struct async_io_cmd_info *cmdinfo = ctx;
	unsigned long flag = 0;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
	sfx_ktime_t cb_rtn_time;
	xt_u8 io_cmd = 0;
#endif

#ifdef USE_KTIME_CTX
	cmdinfo->irq = sfx_ktime_get();
	cmdinfo->latency = cmdinfo->queue_cmd_info->ext_result =
		sfx_ktime_to_ns(cmdinfo->irq) - sfx_ktime_to_ns(cmdinfo->its);
	_sfx_statistics_async_simple(nvmeq, cmdinfo);
#endif
	if (cmdinfo->fake_result) { /* error injection */
		cmdinfo->result &= ~RESULT_ERR_CHAN_MASK;
		nvme_cmpl->result |= cmdinfo->fake_result & RESULT_ERR_CHAN_MASK;
	}

#ifndef USE_CCS_NID
	if (!nvmeq->qid) {
		if (cqe->command_id < HOT_IO_QD) {
			sfx_pr_err("%s: inconsistent cmdid %u < HOT_IO_QD for nvmeq0 completion\n",
				   __FUNCTION__, cqe->command_id);
			BUG();
		}
		cqe->command_id -= HOT_IO_QD;
		sfx_pr_err("%s: cmdid %u for nvmeq0 completion\n", __FUNCTION__, cqe->command_id);
	}
#endif
	if (nvmeq->cmpl_cb) {
#if (HOT_READ_PERF || HOT_WRITE_PERF)
		if (cqe->sq_id >= NON_IO_QUEUE && dev->ftl_mq_ctx.ioq_config) {
			io_cmd = (sfx_qid_is_wrq(cqe->sq_id, dev->ftl_mq_ctx.ioq_config) ||
				  sfx_qid_is_rdq(cqe->sq_id, dev->ftl_mq_ctx.ioq_config));
			if (io_cmd && cmdinfo->iod) {
				cmdinfo->iod->ftl_cb_smt_time = sfx_ktime_get();
			}
		}
#endif
#ifndef USE_CCS_NID
		cqe->command_id = cmdinfo->apptag;
#endif
		nvmeq->q_stats.cpl_counter++;
		nvmeq->cmpl_cb(&dev->ftl_mq_ctx.ftl_ctx, (void *)cqe);
#if (HOT_READ_PERF || HOT_WRITE_PERF)
		cb_rtn_time = sfx_ktime_get();
		if (cqe->sq_id >= NON_IO_QUEUE && dev->ftl_mq_ctx.ioq_config) {
			if (io_cmd && cmdinfo->iod) {
				cmdinfo->iod->ftl_cb_rtn_time = cb_rtn_time;
				_sfx_rd_statistics(dev, cqe->sq_id, cmdinfo->iod);
			}
		}
#endif
		// free iod
		if (cmdinfo->iod) {
			if (sfx_is_token_addr(cmdinfo->addr) || cmdinfo->from_kernel) {
				sfx_unmap_user_pages_only(dev, cmdinfo->opcode & 1, cmdinfo->iod);
			} else {
				sfx_unmap_user_pages(dev, cmdinfo->opcode & 1, cmdinfo->iod);
			}
			sfx_try_to_cleanup_pages_context(dev, cmdinfo->iod);
			sfx_free_iod(dev, cmdinfo->iod);
		}
		sfx_spin_lock_irqsave(&nvmeq->list_lock, flag);
		dev->sfx_stats.cpl_counter[cqe->sq_id]++;
		if (sfx_list_next(cmdinfo->node) != LIST_POISON1) {
			sfx_list_del(&cmdinfo->node);
		} else {
			PR_INFO("%s, Warning runaway node!!!! op:%03x nid=%d\n", dev->name, cmdinfo->opcode,
				cmdinfo->apptag);
		}
		sfx_list_add_tail(&cmdinfo->node, &nvmeq->free_list);
#if (HOT_READ_PERF || HOT_WRITE_PERF)
		{
			if (cqe->sq_id >= NON_IO_QUEUE && dev->ftl_mq_ctx.ioq_config) {
				if (io_cmd) {
					SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
					sfx_nvmeq =
						((dev->ftl_mq_ctx.drvg_ctx)[cqe->sq_id]).sfx_nvme_cmd_queue;
					if (sfx_qid_is_rdq(cqe->sq_id, dev->ftl_mq_ctx.ioq_config)) {
						sfx_nvmeq->hot_rd_drv_cmd_cb2cmpl_lat +=
							(sfx_ktime_to_ns(sfx_ktime_get()) -
							 sfx_ktime_to_ns(cb_rtn_time));
						if (sfx_ktime_to_ns(sfx_ktime_get()) -
							    sfx_ktime_to_ns(cb_rtn_time) >=
						    LONG_LAT_TARGET) {
							sfx_pr_info(
								"%s %d: %s, driver process after ftl callback takes"
								" too long %llu\n",
								__FUNCTION__, __LINE__, dev->name,
								(sfx_ktime_to_ns(sfx_ktime_get()) -
								 sfx_ktime_to_ns(cb_rtn_time)) /
									1000);
						}
					} else if (sfx_qid_is_wrq(cqe->sq_id, dev->ftl_mq_ctx.ioq_config)) {
						sfx_nvmeq->hot_wr_drv_cmd_cb2cmpl_lat +=
							(sfx_ktime_to_ns(sfx_ktime_get()) -
							 sfx_ktime_to_ns(cb_rtn_time));
					}
				}
			}
		}
#endif
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flag);
		return;
	}

	cmdinfo->result = cmdinfo->queue_cmd_info->result = sfx_le32_to_cpup(&cqe->result);
	cmdinfo->ext_result = cmdinfo->queue_cmd_info->ext_result = sfx_le32_to_cpup(&cqe->ext_result);
	cmdinfo->sqid = sfx_le16_to_cpup(&cqe->sq_id);
	if (cmdinfo->fake_result) { /* error injection */
		cmdinfo->result &= ~0xf;
		cmdinfo->result |= cmdinfo->fake_result & 0xf;
	}
	cmdinfo->queue_cmd_info->status = sfx_le16_to_cpup(&cqe->status) >> 1;

	if (cmdinfo->opcode == 0xf0 && ((cqe->result & 0xFF) != 0xe0)) { //erase return FFE0
		dev->sfx_cntrs.erase_error_counter++;
	}

	sfx_spin_lock_irqsave(&nvmeq->list_lock, flag);
	if (sfx_list_next(cmdinfo->node) != LIST_POISON1) {
		sfx_list_del(&cmdinfo->node);
	} else {
		PR_INFO("%s, Warning runaway node!!!! op:%03x nid=%d\n", dev->name, cmdinfo->opcode,
			cmdinfo->apptag);
	}
	sfx_list_add_tail(&cmdinfo->node, &nvmeq->cq_list);
	sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flag);
}

/*
 * Async_IO, No worker thread
 */
static int sfx_submit_async_cmd_simple(struct sfx_queue *nvmeq, struct nvme_command *cmd,
				       struct async_io_cmd_info *cmdinfo, unsigned timeout)
{
	int cmdid;

#ifdef USE_CCS_NID
	cmdid = alloc_cmdid_simple(nvmeq, cmdinfo, async_simple_completion, timeout);
#else
	cmdid = alloc_cmdid_killable(nvmeq, cmdinfo, async_simple_completion, timeout);
#endif
	if (cmdid < 0)
		return cmdid;
	cmdinfo->queue_cmd_info->status = -EINTR;
	cmdinfo->cmdid = cmdid;
	cmd->common.command_id = cmdid;
#ifdef USE_KTIME_CTX
	cmdinfo->smt = sfx_ktime_get();
#endif
	return sfx_submit_cmd(nvmeq, cmd);
}

int sfx_submit_nvme_io(struct sfx_fd *fd, struct sfx_userio_cmd *io, sfx_bool sync, sfx_bool from_kernel)
{
	struct sfx_dev *dev = fd->dev;
	unsigned long flags = 0;
	struct sfx_queue *nvmeq;
	struct async_io_cmd_info *cmdinfo = NULL;

	struct nvme_command c;
	unsigned length;
	int status, ret = 0;
	struct sfx_iod *iod = NULL;
	unsigned q_idx = 2;
	xt_u32 result;
	xt_u64 extended_ctrl;
	xt_u32 fake_result;
#ifdef DMATEST
	sfx__le64 *a_test;
	sfx_dma_addr_t dma_test;
#endif
#ifdef USE_KTIME_CTX
	sfx_ktime_t init_time = sfx_ktime_get();
#endif

	// 4K-bytes, TODO: (io->nblocks + 1) << ns->lba_shift;
	length = (io->nblocks + 1) << 12;

	q_idx = io->qid;

#ifdef DMATEST
	if (!(a_test = (sfx__le64 *)sfx_dma_alloc(dev, 256, &dma_test))) {
		sfx_pr_info("%s:%d %s, sfx_dam_alloc 256 failed\n", __FUNCTION__, __LINE__, dev->name);
	} else {
		sfx_pr_info("%s:%d %s, sfx_dam_alloc 256 return %p/%p, free it\n", __FUNCTION__, __LINE__,
			    dev->name, a_test, dma_test);
		sfx_dma_free(dev, 256, a_test, dma_test);
	}
#endif
	switch (io->opcode) {
	case nvme_cmd_write:
	case nvme_cmd_read:
		if (io->opcode == nvme_cmd_read) {
			dev->sfx_cntrs.read_counter += (io->nblocks + 1);
		}
		if (io->addr == NULL) {
			if (((io->slba >> 56) & 0x7) == 3 &&
			    io->opcode == nvme_cmd_write) { //Parity write command
				iod = NULL;
				break;
			}
			sfx_pr_err("%s:%d %s, cmd address failed, opcode=%d nid=%d io->addr=%p, length=%d\n",
				   __FUNCTION__, __LINE__, dev->name, io->opcode, io->apptag, io->addr,
				   length);
			BUG();
			return PTR_ERR(iod);
		}

#if FTL_PERF_DEBUG
		if ((io->qid >= NON_IO_QUEUE) && (io->opcode == nvme_cmd_read)) {
			struct nvme_completion cqe = { 0 };
			struct sfx_queue q = raw_nvmeq(dev, io->qid);
			cqe.sq_id = io->qid;
			cqe.command_id = io->apptag;
			if (q->cmpl_cb) {
				q->cmpl_cb(&dev->ftl_mq_ctx.ftl_ctx, (void *)(&cqe));
				return 0;
			}
		}
#endif

		sfx_assert(length <= MAX_IO_LENGTH);
		if (length > MAX_IO_LENGTH) {
			sfx_pr_err("%s: %s, error, IO size(%d) too big: not supported.\n", __FUNCTION__,
				   dev->name, length);
			return -ENOMEM;
		}

		if (sync) {
			iod = sfx_alloc_iod(0, length, GFP_ATOMIC);
			if (iod == NULL) {
				sfx_pr_err("%s: %s, error, out of memory!\n", __FUNCTION__, dev->name);
				return -ENOMEM;
			}
		} else {
			nvmeq = lock_nvmeq(dev, q_idx);
			if (!nvmeq) {
				sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, q_idx);
				return -ENODEV;
			}

			sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
			if (unlikely(sfx_list_empty(&nvmeq->free_list))) {
				sfx_pr_err("%s: %s, out out ASYNC_IO entry, FIXME!!!!!\n", __FUNCTION__,
					   dev->name);
				sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
				unlock_nvmeq(nvmeq);
				return -ENOMEM;
			}
			cmdinfo = sfx_list_first_entry(&nvmeq->free_list, struct async_io_cmd_info, node);
			sfx_list_del(&cmdinfo->node);
			sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

			unlock_nvmeq(nvmeq);

			iod = &cmdinfo->cmd_iod;
			if (!iod->prp_dma) {
				iod->npages = -1; /* if static_alloc npages = 0 */
			}
			iod->static_alloc = 1;
			iod->offset = offsetof(struct sfx_iod, prp_array);
			iod->length = length;
			iod->nents = 0;
			iod->first_dma = 0ULL;
			iod->start_time = jiffies;
			iod->private = iod;
		}

		if (!sfx_is_token_addr(io->addr)) {
			if (from_kernel) {
				iod = sfx_map_kernel_pages_ex(dev, io->opcode & 1, (unsigned long)io->addr,
							      length, iod);
			} else {
				iod = sfx_map_user_pages_ex(dev, io->opcode & 1, (unsigned long)io->addr,
							    length, iod);
			}
		} else {
			iod = sfx_map_user_pages_post_ex(dev, io->opcode & 1, (unsigned long)io->addr, length,
							 iod);
		}
		if (IS_ERR(iod)) {
			sfx_pr_err("%s:%d %s, map_*_pages failed, opcode=%d nid=%d io->addr=%p, length=%d\n",
				   __FUNCTION__, __LINE__, dev->name, io->opcode, io->apptag, io->addr,
				   length);
			return PTR_ERR(iod);
		}
#if (HOT_READ_PERF || HOT_WRITE_PERF)
		iod->init_time = sfx_ktime_get();
#endif
		break;
	case sfx_cmd_admin_async:
	case sfx_cmd_buf2nand:
	case sfx_cmd_nand2buf:
		//  case sfx_cmd_erase:
	case sfx_cmd_nand_reset:
	case sfx_cmd_dceread:
	case sfx_cmd_loopback:
	case sfx_cmd_barrier:
		iod = NULL;
		break;
	default:
		sfx_pr_err("%s:%d %s, Unknown message type: %x\n", __FUNCTION__, __LINE__, dev->name,
			   io->opcode);
		return -EINVAL;
	}
#ifdef DMATEST
	if (!(a_test = (sfx__le64 *)sfx_dma_alloc(dev, 512, &dma_test))) {
		sfx_pr_info("%s:%d sfx_dam_alloc 512 failed\n", __FUNCTION__, __LINE__);
	} else {
		sfx_pr_info("%s:%d sfx_dam_alloc 512 return %p/%p, free it\n", __FUNCTION__, __LINE__, a_test,
			    dma_test);
		sfx_dma_free(dev, 256, a_test, dma_test);
	}
#endif
	sfx_memset(&c, 0, sizeof(c));
	// nand2buf prp for r2c
	if (io->opcode == sfx_cmd_nand2buf) {
		c.rw.prp1 = io->prp1;
	}

	c.rw.opcode = io->opcode;
	c.rw.flags = io->flags;
	c.rw.nsid = sfx_cpu_to_le32(0 /*ns->ns_id*/);
	c.rw.metadata = sfx_cpu_to_le64(io->metadata);

	//TODO: Should be PBA + SFX Flags, 64bits
	c.rw.slba = sfx_cpu_to_le64(io->slba);

	c.rw.length = sfx_cpu_to_le16(io->nblocks);
	c.rw.control = sfx_cpu_to_le16(io->control);
	c.rw.dsmgmt = sfx_cpu_to_le32(io->dsmgmt);
	c.rw.reftag = sfx_cpu_to_le32(io->reftag);
	c.rw.apptag = sfx_cpu_to_le16(io->apptag);
	c.rw.appmask = sfx_cpu_to_le16(io->appmask);
	extended_ctrl = io->extended_ctrl;
	c.rw.rsvd2 = sfx_cpu_to_le64(extended_ctrl << 32);

	if (iod) {
		length = sfx_setup_prps(dev, iod, length, from_kernel ? GFP_ATOMIC : GFP_KERNEL);
		c.rw.prp1 = sfx_cpu_to_le64(sfx_sg_dma_address(iod->sg));
		c.rw.prp2 = sfx_cpu_to_le64(iod->first_dma);
	}
	/* Inject error, potentially */
	fake_result = sfx_get_fakeresult(dev, io, &ret);
	// fake_result = 0;
	if (ret) {
		return ret;
	}
	status = 0;

	if (length != (io->nblocks + 1) << 12 /*ns->lba_shift*/) {
		sfx_pr_err("%s:%d %s, unaligned length! length=%d, io->nblocks=%d\n", __FUNCTION__, __LINE__,
			   dev->name, length, io->nblocks);

		status = -ENOMEM;
	} else {
		if (sync) {
			status = sfx_submit_sync_cmd(dev, q_idx, &c, &result, NVME_IO_TIMEOUT);
		} else {
			nvmeq = lock_nvmeq(dev, q_idx);
			if (!nvmeq) {
				sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, q_idx);
				status = -ENODEV;
			} else {
				// 1. Get one free entry
				if (unlikely(sfx_list_empty(&nvmeq->free_list))) {
					sfx_pr_err("%s: %s, out out ASYNC_IO entry, FIXME!!!!!\n",
						   __FUNCTION__, dev->name);
				}

				sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
				if (cmdinfo == NULL) {
					cmdinfo = sfx_list_first_entry(&nvmeq->free_list,
								       struct async_io_cmd_info, node);
					sfx_list_del(&cmdinfo->node);
				}

				// 2. Setup
#ifdef USE_KTIME_CTX
				cmdinfo->its = init_time;
#endif
				cmdinfo->apptag = c.rw.apptag;
				cmdinfo->queue_cmd_info = &nvmeq->cmdinfo;
				cmdinfo->iod = iod;
				cmdinfo->addr = io->addr; // For unmap
				cmdinfo->opcode = (io->opcode);
				cmdinfo->owner = fd;
				cmdinfo->from_kernel = from_kernel;
#ifdef CMD_COMB
				if (io->opcode == sfx_cmd_read) {
					sfx_memcpy(cmdinfo->fids, io->fids,
						   MAX_COMBINED_FCMD * sizeof(xt_u16));
					cmdinfo->nr_fcmd = io->nr_fcmd;
				}
#endif

				cmdinfo->fake_result = fake_result;

				// For performance debug, complete request right away
				if ((dev->sfx_cntrs.debug_flag == 66) && (io->opcode == sfx_cmd_read)) {
					cmdinfo->ext_result = io->slba;
					sfx_pr_info(
						"%s: %s, ??? debug_flag==66 add qid %u node %d cpu %d opcode 0x%x\n",
						__FUNCTION__, dev->name, q_idx,
						dev_to_node(&dev->pci_dev->dev), smp_processor_id(),
						cmdinfo->opcode);
					sfx_list_add_tail(&cmdinfo->node, &nvmeq->cq_list);
					sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
					unlock_nvmeq(nvmeq);
					return status;
				}

				// 3. add it to submit queue
				sfx_list_add_tail(&cmdinfo->node, &nvmeq->sq_list);
				sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

				// 4. submit async_cmd
				status = sfx_submit_async_cmd_simple(nvmeq, &c, cmdinfo, NVME_IO_TIMEOUT);
				unlock_nvmeq(nvmeq);
				return status;
			}
		}
	}

	if (iod) {
		if (sfx_is_token_addr(io->addr) || from_kernel) {
			sfx_unmap_user_pages_only(dev, io->opcode & 1, iod);
		} else {
			sfx_unmap_user_pages(dev, io->opcode & 1, iod);
		}
		sfx_free_iod(dev, iod);
	}

	if (fake_result) {
		/* error injection */
		result &= ~0xf;
		result |= fake_result & 0xf;
	}

	io->dsmgmt = result;
	io->reftag = status;

	return status;
}
EXPORT_SYMBOL(sfx_submit_nvme_io);

int sfx_submit_admin_cmd(struct sfx_dev *dev, struct nvme_command *cmd, xt_u32 *result)
{
	return sfx_submit_sync_cmd(dev, 0, cmd, result, SFX_ADMIN_TIMEOUT);
}

/**
 * sfx_submit_cmd() - Copy a command into a queue and ring the doorbell
 * @nvmeq: The queue to use
 * @cmd: The command to send
 *
 * Safe to use from interrupt context
 */
int sfx_submit_cmd(struct sfx_queue *nvmeq, struct nvme_command *cmd)
{
	struct sfx_dev *dev = nvmeq->dev;
	unsigned long flags = 0;
	xt_u16 tail;
#if DRIVER_PRINT_NVME_CMD
	int i;
	unsigned int *p;
#endif
#if (HOT_READ_PERF || HOT_WRITE_PERF)
	int cmdid;
	struct sfx_cmd_info *info;
#else
#ifdef USE_KTIME_ALL
	int cmdid;
	struct sfx_cmd_info *info;
#endif
#endif

#if (HOT_READ_PERF || HOT_WRITE_PERF)
	cmdid = cmd->common.command_id;
	info = sfx_cmd_info(nvmeq);
#else
#ifdef USE_KTIME_ALL
	cmdid = cmd->common.command_id;
	info = sfx_cmd_info(nvmeq);
#endif
#endif
	sfx_spin_lock_irqsave(&nvmeq->q_lock, flags);
	if (nvmeq->q_suspended) {
		sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flags);
		sfx_pr_info("%s: %s, sfx_submit q[%u] op %u cmdid %u returning EBUSY, suspended\n",
			    __FUNCTION__, dev->name, nvmeq->qid, cmd->common.opcode, cmd->common.command_id);
		return -EBUSY;
	}
#if DRIVER_PRINT_NVME_CMD
	sfx_pr_info("%s: q[%u] op 0x%x cmdid %u\n", __FUNCTION__, nvmeq->qid, cmd->common.opcode,
		    cmd->common.command_id);
	p = (unsigned int *)cmd;
	for (i = 0; i < 16; i++) {
		if (i == 15) {
			(*p) = 1;
		}
		sfx_pr_info("%08x ", *p);
		p++;
	}
	sfx_pr_info("\n");
#endif

	tail = nvmeq->sq_tail;
	sfx_memcpy(&nvmeq->sq_cmds[tail], cmd, sizeof(*cmd));
	if (++tail == nvmeq->q_depth)
		tail = 0;
	sfx_writel(tail, (xt_u32 *)nvmeq->q_db);

#if (HOT_READ_PERF || HOT_WRITE_PERF)
	if (nvmeq->qid >= NON_IO_QUEUE && dev->ftl_mq_ctx.ioq_config) {
		xt_u8 io_cmd = (sfx_qid_is_wrq(nvmeq->qid, dev->ftl_mq_ctx.ioq_config) ||
				sfx_qid_is_rdq(nvmeq->qid, dev->ftl_mq_ctx.ioq_config));
		if (io_cmd) {
			struct async_io_cmd_info *cmdinfo = info[cmdid].ctx;
			if (cmdinfo->iod) {
				cmdinfo->iod->smt_time = sfx_ktime_get();
			}
		}
	}
#endif
#ifdef USE_KTIME_ALL
	info[cmdid].sts = sfx_ktime_get();
#endif

	nvmeq->sq_tail = tail;

	dev->sfx_stats.sq_counter[nvmeq->qid]++;
	nvmeq->q_stats.sq_counter++;

	sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flags);

	return 0;
}

sfx_irqreturn_t sfx_irq(int irq, void *data)
{
	sfx_irqreturn_t result;
	struct sfx_queue *nvmeq = data;
	struct sfx_dev *dev = nvmeq->dev;

	if (dev->device_gone)
		return IRQ_NONE;

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfx_ktime_t start_time = sfx_ktime_get();
	sfx_ktime_t end_time;
#endif
	sfx_spin_lock(&nvmeq->q_lock);

	dev->sfx_cntrs.irq_counter++;
	dev->sfx_cntrs.irq_total++;
	nvmeq->q_stats.irq_counter_total++;

	sfx_atomic_inc(&dev->ftl_mq_ctx.osd_irq);
	sfx_process_cq(nvmeq, 0, 0);
	sfx_atomic_dec(&dev->ftl_mq_ctx.osd_irq);

	if (!nvmeq->cqe_seen) {
		dev->sfx_cntrs.irq_counter--;
		result = IRQ_NONE;
	} else {
		nvmeq->q_stats.irq_counter++;
		result = IRQ_HANDLED;
	}

	// result = nvmeq->cqe_seen ? IRQ_HANDLED : IRQ_NONE;
	nvmeq->cqe_seen = 0;
	sfx_spin_unlock(&nvmeq->q_lock);
#if HOT_READ_PERF || HOT_WRITE_PERF
	if (sfx_atomic64_read(&dev->ftl_mq_ctx.max_irq_time) <
	    sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(start_time)) {
		sfx_atomic64_set(&dev->ftl_mq_ctx.max_irq_time,
				 sfx_ktime_to_ns(sfx_ktime_get()) - sfx_ktime_to_ns(start_time));
	}
	end_time = sfx_ktime_get();
	sfx_atomic64_inc(&dev->ftl_mq_ctx.num_irq);
	if (sfx_ktime_to_ns(end_time) - sfx_ktime_to_ns(start_time) > 100000) {
		sfx_atomic64_inc(&dev->ftl_mq_ctx.num_irq_100);
	}
#endif
	return result;
}

static int adapter_delete_queue(struct sfx_dev *dev, xt_u8 opcode, xt_u16 id)
{
	int status;
	struct nvme_command c;

	sfx_memset(&c, 0, sizeof(c));
	c.delete_queue.opcode = opcode;
	c.delete_queue.qid = sfx_cpu_to_le16(id);

	status = sfx_submit_admin_cmd(dev, &c, NULL);
	if (status)
		return -EIO;
	return 0;
}

void sfx_clear_queue(struct sfx_queue *nvmeq)
{
#ifdef SFXDRIVER_DEBUG
	if (NULL != nvmeq) {
		PR_INFO("qid[%u]\n", nvmeq->qid);
	}
#endif

	if (nvmeq->dev->ftl_mq_ctx.ftl_ctx.device_ready == 2) {
		sfx_pr_info("%s: %s, BLK FTL Freeze detected\n", __func__, nvmeq->dev->name);
		return;
	}

	if (sfx_readl(&nvmeq->dev->bar->csts) == -1) {
		sfx_pr_info("%s: %s, csts == -1\n", __func__, nvmeq->dev->name);
		return;
	}

	sfx_spin_lock_irq(&nvmeq->q_lock);
	sfx_process_cq(nvmeq, 0, 0);
	sfx_cancel_ios(nvmeq, false);
	sfx_spin_unlock_irq(&nvmeq->q_lock);
}

int adapter_delete_cq(struct sfx_dev *dev, xt_u16 cqid)
{
	return adapter_delete_queue(dev, nvme_admin_delete_cq, cqid);
}

int adapter_delete_sq(struct sfx_dev *dev, xt_u16 sqid)
{
	return adapter_delete_queue(dev, nvme_admin_delete_sq, sqid);
}

void sfx_disable_queue(struct sfx_dev *dev, int qid)
{
	struct sfx_queue *nvmeq = raw_nvmeq(dev, qid);

	if (!nvmeq) {
		sfx_pr_err("%s: %s !nvmeq for qid=%u, return\n", __FUNCTION__, dev->name, qid);
		return;
	}
	if (sfx_suspend_queue(nvmeq)) {
		sfx_pr_err("%s: %s sfx_suspend_queue(qid=%u) failed, return\n", __FUNCTION__, dev->name, qid);
		return;
	}

	/*
     * Don't tell the adapter to delete the admin queue.
     * Don't tell a removed adapter to delete IO queues.
     */
	if (qid && sfx_readl(&dev->bar->csts) != -1 && sfx_readl(&dev->bar->csts) != 0) {
		adapter_delete_sq(dev, qid);
		adapter_delete_cq(dev, qid);
	}
	sfx_clear_queue(nvmeq);
#ifdef SFXDRIVER_DEBUG
	PR_INFO("Disable nvme queue id=%u\n", qid);
#endif
}

static int adapter_alloc_cq(struct sfx_dev *dev, xt_u16 qid, struct sfx_queue *nvmeq)
{
	int status;
	struct nvme_command c;
	int flags = NVME_QUEUE_PHYS_CONTIG | NVME_CQ_IRQ_ENABLED;

	sfx_memset(&c, 0, sizeof(c));
	c.create_cq.opcode = nvme_admin_create_cq;
	c.create_cq.prp1 = sfx_cpu_to_le64(nvmeq->cq_dma_addr);
	c.create_cq.cqid = sfx_cpu_to_le16(qid);
	c.create_cq.qsize = sfx_cpu_to_le16(nvmeq->q_depth - 1);
	c.create_cq.cq_flags = sfx_cpu_to_le16(flags);
	c.create_cq.irq_vector = sfx_cpu_to_le16(nvmeq->cq_vector);

	status = sfx_submit_admin_cmd(dev, &c, NULL);

	if (status) {
		sfx_pr_err("%s: %s, failed, return -EIO\n", __FUNCTION__, nvmeq->dev->name);
		return -EIO;
	}

	return 0;
}

static int adapter_alloc_sq(struct sfx_dev *dev, xt_u16 qid, struct sfx_queue *nvmeq, xt_u8 q_type,
			    xt_u8 stream_id)
{
	int status;
	struct nvme_command c;
	int flags = NVME_QUEUE_PHYS_CONTIG | NVME_SQ_PRIO_MEDIUM | (q_type << 8) | (stream_id << 12);

	sfx_memset(&c, 0, sizeof(c));
	c.create_sq.opcode = nvme_admin_create_sq;
	c.create_sq.prp1 = sfx_cpu_to_le64(nvmeq->sq_dma_addr);
	c.create_sq.sqid = sfx_cpu_to_le16(qid);
	c.create_sq.qsize = sfx_cpu_to_le16(nvmeq->q_depth - 1);
	c.create_sq.sq_flags = sfx_cpu_to_le16(flags);
	c.create_sq.cqid = sfx_cpu_to_le16(qid);

	status = sfx_submit_admin_cmd(dev, &c, NULL);
	if (status) {
		sfx_pr_err("%s: %s, failed, return -EIO\n", __FUNCTION__, dev->name);
		return -EIO;
	}
	return 0;
}

static void sfx_destroy_hw_io_queue(struct sfx_queue *nvmeq, int qid)
{
	sfx_assert(nvmeq && nvmeq->dev);

	adapter_delete_sq(nvmeq->dev, qid);
	adapter_delete_cq(nvmeq->dev, qid);
}

static int sfx_create_hw_io_queue(struct sfx_queue *nvmeq, int qid, xt_u8 qtype, xt_u8 stream_id)
{
	struct sfx_dev *dev = nvmeq->dev;
	int result;

	result = adapter_alloc_cq(dev, qid, nvmeq);
	if (result < 0)
		return result;

	result = adapter_alloc_sq(dev, qid, nvmeq, qtype, stream_id);
	if (result < 0) {
		adapter_delete_cq(dev, qid);
	}

	return result;
}

static int sfx_create_queue(struct sfx_queue *nvmeq, int qid)
{
	struct sfx_dev *dev = nvmeq->dev;
	int result;

	if ((result = sfx_create_hw_io_queue(raw_nvmeq(dev, qid), qid, 8, 0)) <
	    0) { // HELEN: hard code to erase queue type for now
		sfx_pr_err("%s: %s, creating hw io queue [%u] failed\n", __FUNCTION__, dev->name, qid);
		return result;
	} else
		sfx_pr_err("%s: %s, hw io queue[%u] created\n", __FUNCTION__, dev->name, qid);

	result = queue_request_irq(dev, nvmeq, nvmeq->irqname);
	if (result < 0) {
		sfx_pr_err("%s: %s, !!! q[%u] queue_request_irq fail\n", __FUNCTION__, dev->name, nvmeq->qid);
		goto release_qs;
	}

	sfx_spin_lock_irq(&nvmeq->q_lock);
	sfx_init_queue(nvmeq, qid);
	sfx_spin_unlock_irq(&nvmeq->q_lock);

	sfx_pr_info("%s: %s, q[%d]=0x%p succees\n", __FUNCTION__, dev->name, nvmeq->qid, nvmeq);
	return result;

release_qs:
	adapter_delete_sq(dev, qid);
	adapter_delete_cq(dev, qid);
	return result;
}

void sfx_create_io_queues(struct sfx_dev *dev)
{
	unsigned i, max;

	max = min(dev->max_qid, sfx_num_online_cpus());
	sfx_pr_info("%s: %s, 1 max %u count q/ioq %u/%u\n", __FUNCTION__, dev->name, max, dev->queue_count,
		    dev->ioqueue_count);
	for (i = dev->queue_count; i <= max; i++) {
		/* should not assign 0 to q other than adminq */
		/* each q should have its own cq_vector as index into dev->entry */
		/* if msix_disable, all entry[x] should be assigned to pdev->irq */
		int vec = msix_disable ? 0 : i;
		if (!sfx_alloc_queue(dev, i, dev->q_depth, vec, NULL, 0xFFFFFFFF))
			break;
	}

	max = min(dev->queue_count - 1, sfx_num_online_cpus());
	sfx_pr_info("%s: %s, 2 max %u onlineq %u count q/ioq %u/%u\n", __FUNCTION__, dev->name, max,
		    dev->online_queues, dev->queue_count, dev->ioqueue_count);
	for (i = dev->online_queues; i <= max; i++)
		if (sfx_create_queue(raw_nvmeq(dev, i), i))
			break;
}

static void sfx_del_sq_work_handler(struct sfx_work_struct *work)
{
	struct sfx_queue *nvmeq = container_of(work, struct sfx_queue, cmdinfo.work);
	int status = nvmeq->cmdinfo.status;

	if (!status)
		status = sfx_delete_cq(nvmeq);
	if (status) {
		sfx_pr_info("%s: %s, nvmeq[%u] sfx_delete_cq failed, call sfx_del_queu_end\n", __FUNCTION__,
			    nvmeq->dev->name, nvmeq->qid);
		sfx_del_queue_end(nvmeq);
	}
}

int sfx_delete_sq(struct sfx_queue *nvmeq)
{
	return adapter_async_del_queue(nvmeq, nvme_admin_delete_sq, sfx_del_sq_work_handler);
}

static void sfx_del_cq_work_handler(struct sfx_work_struct *work)
{
	struct sfx_queue *nvmeq = container_of(work, struct sfx_queue, cmdinfo.work);
	sfx_pr_info("%s: %s, nvmeq[%u] call sfx_del_queu_end\n", __FUNCTION__, nvmeq->dev->name, nvmeq->qid);
	sfx_del_queue_end(nvmeq);
}

int sfx_delete_cq(struct sfx_queue *nvmeq)
{
	return adapter_async_del_queue(nvmeq, nvme_admin_delete_cq, sfx_del_cq_work_handler);
}

int sfx_shutdown_ctrl(struct sfx_dev *dev)
{
	xt_u32 cc;

	cc = (sfx_readl(&dev->bar->cc) & ~NVME_CC_SHN_MASK) | NVME_CC_SHN_NORMAL;
	sfx_writel(cc, &dev->bar->cc);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: NVME_CC_SHN_NORMAL cc: 0x%08x\n", __FUNCTION__, cc);
#endif

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s done\n", __FUNCTION__, dev->name);
#endif
	return 0;
}

void sfx_compressionq_throttle(void *sfx_driver_handle, int base_qid, int write_val)
{
	struct sfx_dev *dev = sfx_driver_handle;
	xt_u32 i, addr = (NVME_HW_QSIZE_BASE + base_qid * 4);

	/* programme throttle registers for nvme queues allocated for compression engines
     * each engine uses two queues
     */
	for (i = 0; i < MAX_NUM_COMP_ENG; i++) {
		fis_indirect_write32(dev, dev->bar, addr,
				     write_val); // write queue buffer shared with ec, total 16
		addr += 8;
		sfx_msleep(1);
	}
}
EXPORT_SYMBOL(sfx_compressionq_throttle);

void sfx_comp_readq_throttle(void *sfx_driver_handle, int base_qid, int write_val)
{
	struct sfx_dev *dev = sfx_driver_handle;
	xt_u32 i, addr = (NVME_HW_QSIZE_BASE + 4 +
			  base_qid * 4); /* +4: skipping write queue threshold register */

	/* programme throttle registers for nvme read queues allocated for compression engines
     * each engine uses two queues
     */
	for (i = 0; i < MAX_NUM_COMP_ENG; i++) {
		fis_indirect_write32(dev, dev->bar, addr,
				     write_val); // read queue
		addr += 8;
		sfx_msleep(1);
	}
}
EXPORT_SYMBOL(sfx_comp_readq_throttle);

void sfx_ecq_throttle(void *sfx_driver_handle, int base_qid, int write_val)
{
	struct sfx_dev *dev = sfx_driver_handle;
	xt_u32 addr = (NVME_HW_QSIZE_BASE + base_qid * 4);

	/* programme throttle registers for nvme queues allocated for ec engines */
	fis_indirect_write32(dev, dev->bar, addr,
			     write_val); // write queue buffer shared with compression, total 16
	addr += 4;
	sfx_msleep(1);
	fis_indirect_write32(dev, dev->bar, addr,
			     READ_FIFO_DEFAULT); // read queue
	addr += 4;
	sfx_msleep(1);
}
EXPORT_SYMBOL(sfx_ecq_throttle);

void *sfx_alloc_nvmeq(void *sfx_driver_handle, struct sfx_driver_nvmeq_ctx *init_ctx, ftl_cmpl_cb cb)
{
	struct sfx_dev *dev = sfx_driver_handle;
	struct sfx_queue *q;
	xt_u8 qid = init_ctx->qid;
	xt_u8 q_type = init_ctx->queue_type;
	xt_u8 stream_id = init_ctx->stream_id;
	struct cpumask *m = init_ctx->cpumask;
	xt_u8 flag_last = init_ctx->flag_last;
	int ret, vector = 0;
#ifdef MQ_IRQSHARED
	int cpu = 0, cpucnt;
#endif

	BUG_ON(!dev);
	BUG_ON(!dev->queues[0]);
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: => %s count q/ioq %u/%u qid %u q_type %u stream_id %u cpumask %*pb\n", __FUNCTION__,
		    dev->name, dev->queue_count, dev->ioqueue_count, qid, q_type, stream_id,
		    cpumask_pr_args(m));
#endif

	if ((q = lock_nvmeq(dev, qid))) {
		sfx_pr_err("%s: %s, ??? allocate q[%u]:%p already exist\n", __FUNCTION__, dev->name, qid, q);
		unlock_nvmeq(q);
		return q;
	}
	/* vector decides which msix entry this queue will attach to */
	/* +1 because adminq takes msix_entry[0] */
#ifdef MQ_IRQSHARED
	if (m) {
		if ((cpucnt = cpumask_weight(m)) > 1) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
			sfx_pr_err("%s: WARNING %d cpus set in cpumask IRQ %*pb\n", __FUNCTION__, cpucnt,
				   cpumask_pr_args(m));
#endif
		}
		if (!cpumask_equal(dev->msix_requested, m)) {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
			sfx_pr_info("%s: =====DEBUG cpumask m %*pb != msix_requested %*pb\n", __FUNCTION__,
				    cpumask_pr_args(m), cpumask_pr_args(dev->msix_requested));
#endif
		} else {
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
			sfx_pr_info("%s: =====DEBUG cpumask m==msix_requested %*pb Nothing to do\n",
				    __FUNCTION__, cpumask_pr_args(dev->msix_requested));
#endif
		}

		for_each_cpu (cpu, m) {
			vector = cpu;
			if (cpumask_test_and_set_cpu(cpu, dev->msix_requested))
				sfx_pr_info("%s: %s, Resetting cpu %d for q[%u] on msix_requested\n",
					    __FUNCTION__, dev, cpu->name, qid);
			else
				sfx_pr_info("%s: %s, Firstime setting cpu %d for q[%u] on msix_requested\n",
					    __FUNCTION__, dev->name, cpu, qid);
			/* take the first one */
			break;
		}
	}
#else
	vector = qid;
#endif
	if (!sfx_alloc_queue(dev, qid, dev->q_depth, vector, cb, init_ctx->numa_node)) {
		sfx_pr_err("%s: %s, allocate q[%u] failed\n", __FUNCTION__, dev->name, qid);
		return NULL;
	}
	if (sfx_create_hw_io_queue(raw_nvmeq(dev, qid), qid, q_type, stream_id)) {
		sfx_pr_err("%s: %s, create hw io q[%u] failed\n", __FUNCTION__, dev->name, qid);
		goto sfx_alloc_nvmeq_free_nvmeq;
	}
	q = raw_nvmeq(dev, qid);
	q->q_type = q_type;
#ifdef SFXDRIVER_DEBUG
	sfx_pr_info("%s: => q[%u]:%p created\n", __FUNCTION__, qid, q);
#endif
	if (m) {
		cpumask_copy(q->cpu_mask, m);
	} else {
		cpumask_clear(q->cpu_mask);
	}
	if (flag_last) {
		BUG_ON(dev->online_queues != 1);
		if ((ret = sfx_assign_interrupts(dev))) {
			sfx_pr_err("%s: %s, sfx_assign_interrupts failed, %d returned\n", __FUNCTION__,
				   dev->name, ret);
			goto sfx_alloc_nvmeq_destroy_hw_io_queue;
		} else {
			sfx_pr_info("%s: %s, sfx_assign_interrupts succeeded\n", __FUNCTION__, dev->name);
		}
	}
	return q;

sfx_alloc_nvmeq_destroy_hw_io_queue:
	sfx_destroy_hw_io_queue(raw_nvmeq(dev, qid), qid);

sfx_alloc_nvmeq_free_nvmeq:
	sfx_free_queue_common(raw_nvmeq(dev, qid));
	dev->queue_count--;

	return NULL;
}
EXPORT_SYMBOL(sfx_alloc_nvmeq);

void sfx_dev_info(struct sfx_dev *dev)
{
	sfx_pr_info("%s: dev 0x%p\n", __FUNCTION__, dev);
	sfx_pr_info("    BAR:     0x%p\n", dev->bar);
	sfx_pr_info("    vs:      0x%08x\n", sfx_readl(&dev->bar->vs));
	sfx_pr_info("    csts:    0x%08x\n", sfx_readl(&dev->bar->csts));
	sfx_pr_info("    cc:      0x%08x\n", sfx_readl(&dev->bar->cc));
	sfx_pr_info("    aqa:     0x%08x\n", sfx_readl(&dev->bar->aqa));
	sfx_pr_info("    cap:     0x%016llx\n",
		    (long long unsigned int)sfx_le64_to_cpu(sfx_readq(&dev->bar->cap)));
	sfx_pr_info("    intms:   0x%08x\n", sfx_readl(&dev->bar->intms));
	sfx_pr_info("    intmc:   0x%08x\n", sfx_readl(&dev->bar->intmc));
	sfx_pr_info("    asq:     0x%016llx\n",
		    (long long unsigned int)sfx_le64_to_cpu(sfx_readq(&dev->bar->asq)));
	sfx_pr_info("    acq:     0x%016llx\n",
		    (long long unsigned int)sfx_le64_to_cpu(sfx_readq(&dev->bar->acq)));
	sfx_pr_info("    q_depth: 0x%08x\n", dev->q_depth);
	sfx_pr_info("    db_str:  0x%08x\n", dev->db_stride);
	sfx_pr_info("    dbs:     0x%p\n", (void *)dev->dbs);
}

xt_u32 check_device_gone(struct sfx_dev *dev)
{
	if (sfx_readl(&dev->bar->csts) == -1 || sfx_atomic_read(&dev->ftl_mq_ctx.vir_surprise_remove)) {
		if (!dev->device_gone) {
			dev->device_gone = 1;
			sfx_pr_info("%s: %s, device [%d] gone. dev->bar->csts %xh\n", __FUNCTION__, dev->name,
				    dev->instance, dev->bar->csts);

			/* if blk ftl not loaded yet */
			if (!dev->ftl_mq_ctx.ftl_ctx.blk_ftl_ctx)
				return NO_BLK_FTL;
		}
		return 1;
	} else {
		return 0;
	}
}

inline xt_u32 fis_direct_read32(void *bar, xt_u32 addr)
{
	return sfx_readl(bar + addr);
}

xt_u32 fis_indirect_read32(struct sfx_dev *dev, void *bar, xt_u32 addr)
{
	xt_u32 data;

	if (dev->device_gone)
		return -1;

	if (addr < 0x8000) { /* below 32k is ours */
		data = fis_direct_read32(bar, addr);
		if (data == -1) {
			check_device_gone(dev);
		}
		return data;
	}

	sfx_spin_lock(&dev->indirect_reg_lock);

	sfx_writel(addr, bar + 0x4000);
	data = sfx_readl(bar + 0x4008);

	sfx_spin_unlock(&dev->indirect_reg_lock);

	if (data == -1) {
		check_device_gone(dev);
	}
	return data;
}

void fis_indirect_write32(struct sfx_dev *dev, void *bar, xt_u32 addr, xt_u32 value)
{
	if (dev->device_gone)
		return;

	sfx_spin_lock(&dev->indirect_reg_lock);

	sfx_writel(addr, bar + 0x4000);
	sfx_writel(value, bar + 0x4004);

	sfx_spin_unlock(&dev->indirect_reg_lock);
}

void ccs_clean_nvme_sq(struct sfx_dev *dev, struct sfx_driver *drv)
{
	int qid;
	xt_u32 processed = 0;
	xt_u64 timeout = 0;
	xt_u32 old_osd_req_num = sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num);

	while (sfx_atomic_read(&dev->ftl_mq_ctx.osd_irq))
		sfx_usleep(10);

	/* while loop in cleaning ccs nvme queue, until no oustanding:
	 * 1. hot IO, 2. read disturb, 3. error handling left
	 */
	while (sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num) || sfx_atomic_read(&dev->ftl_mq_ctx.osd_rd) ||
	       sfx_atomic_read(&dev->ftl_mq_ctx.osd_eh)) {
		for (qid = 1; qid < dev->queue_count; qid++) {
			struct sfx_queue *nvmeq = raw_nvmeq(dev, qid);

			if (!sfx_list_empty(&nvmeq->sq_list)) {
				struct async_io_cmd_info *cmdinfo, *next;
				unsigned long flags;
#if SURPRISE_REMOVE_DEBUG
				sfx_pr_info("%s: %s, q[%u](%p) is not empty!\n", __FUNCTION__,
					    nvmeq->dev->name, nvmeq->qid, nvmeq);
#endif
				sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
				sfx_list_for_each_entry_safe(cmdinfo, next, &nvmeq->sq_list, node)
				{
					void *ctx;
					sfx_completion_fn fn;
					struct nvme_completion cqe;

					sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
					ctx = free_cmdid(nvmeq, cmdinfo->cmdid, &fn);
					cqe.command_id = cmdinfo->cmdid;
					cqe.sq_id = qid;
					cqe.status = INVALID_16BIT;
					fn(nvmeq, ctx, &cqe);
					++processed;
					sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
				}
				sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
			}
		}

		while (old_osd_req_num == sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num) &&
		       !sfx_atomic_read(&dev->ftl_mq_ctx.osd_rd) &&
		       !sfx_atomic_read(&dev->ftl_mq_ctx.osd_eh)) {
			sfx_usleep(1000);
			timeout++;
			if (timeout == 5000) {
				// after 5s if there are still requests outstanding
				// call drv->check_osd_req(&dev->ftl_mq_ctx) to force clean
				goto out;
			}
		}
		timeout = 0;
		old_osd_req_num = sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num);
		sfx_udelay(100);
	}
out:
	sfx_pr_info("SR->%s completed: processed %d commands, outstanding %d requests.\n", __FUNCTION__,
		    processed, sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num));

	if (sfx_atomic_read(&dev->ftl_mq_ctx.osd_req_num))
		drv->check_osd_req(&dev->ftl_mq_ctx);

	sfx_atomic_set(&dev->ftl_mq_ctx.surprise_remove_done, 1);
}

void sfx_free_queue_common(struct sfx_queue *nvmeq)
{
	int i;

	sfx_spin_lock_irq(&nvmeq->q_lock);

	// TODO: Add completion/cleanup here.
	if (!sfx_list_empty(&nvmeq->sq_list)) {
		sfx_pr_err("%s: %s, q[%u] %p Async_IO, submission queue is not empty!!!!\n", __FUNCTION__,
			   nvmeq->dev->name, nvmeq->qid, nvmeq);
	}
	if (!sfx_list_empty(&nvmeq->cq_list)) {
		sfx_pr_err("%s: %s, q[%u] %p Async_IO, completion queue is not empty!!!!\n", __FUNCTION__,
			   nvmeq->dev->name, nvmeq->qid, nvmeq);
	}

	sfx_spin_unlock_irq(&nvmeq->q_lock);

	for (i = 0; i < sizeof(nvmeq->iod_pool) / sizeof(struct async_io_cmd_info); i++) {
		sfx_free_prps(nvmeq->dev, &nvmeq->iod_pool[i]);
#ifdef SG_PREALLOC
		sfx_free_sgarray(nvmeq->dev, &nvmeq->iod_pool[i]);
#endif
	}

	sfx_dma_free_coherent(nvmeq->dev, CQ_SIZE(nvmeq->q_depth), (void *)nvmeq->cqes, nvmeq->cq_dma_addr);
	sfx_dma_free_coherent(nvmeq->dev, SQ_SIZE(nvmeq->q_depth), nvmeq->sq_cmds, nvmeq->sq_dma_addr);
	if (nvmeq->qid)
		sfx_free_cpumask_var(nvmeq->cpu_mask);

	sfx_destroy_spinlock(&nvmeq->q_lock);
	sfx_destroy_spinlock(&nvmeq->list_lock);

	sfx_kfree(nvmeq);
}

void sfx_free_queue(struct sfx_rcu_head *r)
{
	struct sfx_queue *nvmeq = container_of(r, struct sfx_queue, r_head);

	sfx_free_queue_common(nvmeq);
}

void sfx_free_queues(struct sfx_dev *dev, int lowest)
{
	int i;

	for (i = dev->queue_count - 1; i >= lowest; i--) {
		struct sfx_queue *nvmeq = raw_nvmeq(dev, i);
		sfx_rcu_assign_pointer(dev->queues[i], NULL);
		if (nvmeq->qid && !sfx_cpumask_empty(nvmeq->cpu_mask))
			dev->ioqueue_count--;
		sfx_call_rcu(&nvmeq->r_head, sfx_free_queue);
		dev->queue_count--;
	}
}

int sfx_nand_pba_reset(struct sfx_dev *dev, xt_u64 pba, xt_u32 *rp)
{
	struct nvme_command c;
	int status;
	xt_u32 result = 0;

	sfx_memset(&c, 0, sizeof(c));
	c.rw.opcode = sfx_cmd_nand_reset;
	//    c.rw.slba = ((ch << CHANNEL_OFFSET) | (ce << CE_OFFSET)) & 0xFFFFFFFF;
	c.rw.slba = pba;
	status = sfx_submit_sync_cmd(dev, 0, &c, &result, SFX_ADMIN_TIMEOUT);

	*rp = result;
	return status;
}

static int match_probe_done_list(struct sfx_driver *driver, struct sfx_dev *device)
{
	ftl_mq_ctx *mq_ctx = NULL;

	sfx_spin_lock(&driver->probe_list_lock);
	sfx_list_for_each_entry(mq_ctx, &driver->probe_done_list, probe_on)
	{
		if (mq_ctx == &device->ftl_mq_ctx) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: device %s found on probe_done_list of driver %s\n", __FUNCTION__,
				    device->devfname, driver->name);
#endif
			sfx_spin_unlock(&driver->probe_list_lock);
			return 1;
		}
	}
	sfx_spin_unlock(&driver->probe_list_lock);
	return 0;
}

static int match_probe_ing_list(struct sfx_driver *driver, struct sfx_dev *device)
{
	ftl_mq_ctx *mq_ctx = NULL;

	sfx_spin_lock(&driver->probe_list_lock);
	sfx_list_for_each_entry(mq_ctx, &driver->probe_ing_list, probe_on)
	{
		if (mq_ctx == &device->ftl_mq_ctx) {
			sfx_spin_unlock(&driver->probe_list_lock);
			return 1;
		}
	}
	sfx_spin_unlock(&driver->probe_list_lock);
	return 0;
}

#ifdef SFXDRIVER_PROBELIST_DEBUG
static int match_probe_fail_list(struct sfx_driver *driver, struct sfx_dev *device)
{
	ftl_mq_ctx *mq_ctx = NULL;

	sfx_spin_lock(&driver->probe_list_lock);
	sfx_list_for_each_entry(mq_ctx, &driver->probe_fail_list, probe_on)
	{
		if (mq_ctx == &device->ftl_mq_ctx) {
			sfx_spin_unlock(&driver->probe_list_lock);
			return 1;
		}
	}
	sfx_spin_unlock(&driver->probe_list_lock);
	return 0;
}

static int match_probe_pre_list(struct sfx_driver *driver, struct sfx_dev *device)
{
	ftl_mq_ctx *mq_ctx = NULL;

	sfx_spin_lock(&driver->probe_list_lock);
	sfx_list_for_each_entry(mq_ctx, &driver->probe_pre_list, probe_on)
	{
		if (mq_ctx == &device->ftl_mq_ctx) {
			sfx_pr_info("%s: device %s found on probe_pre_list of driver %s\n", __FUNCTION__,
				    device->devfname, driver->name);
			sfx_spin_unlock(&driver->probe_list_lock);
			return 1;
		}
	}
	sfx_spin_unlock(&driver->probe_list_lock);
	return 0;
}
#endif

#define PRINT_CNT 15

static int wait_probe_finish(struct sfx_driver *drv, struct sfx_dev *dev)
{
	int secs = 0;

	while (match_probe_ing_list(drv, dev)) {
		if ((secs % PRINT_CNT) == 0)
			sfx_pr_info("%s: %s is on probe_ing_list, %d secs passed\n", __FUNCTION__, dev->name,
				    secs);
		sfx_msleep(1000);
		secs++;
	}
	if (match_probe_done_list(drv, dev)) {
		//sfx_pr_info("%s: %s on probe_done_list\n", __FUNCTION__, dev->devfname);
		return 0;
	} else {
#ifdef SFXDRIVER_PROBELIST_DEBUG
		if (match_probe_fail_list(drv, dev))
			sfx_pr_info("%s: device %s found on probe_fail_list\n", __FUNCTION__, dev->name);
		else if (match_probe_pre_list(drv, dev))
			sfx_pr_info("%s: device %s found on probe_pre_list\n", __FUNCTION__, dev->name);
		else
			sfx_pr_info("%s: device %s not found on any list\n", __FUNCTION__, dev->name);
#endif
		return 1;
	}
}

static void remove_device_per_driver(struct sfx_driver *drv, struct sfx_dev *dev,
				     int (*fn_rm)(ftl_mq_ctx *mq_ctx))
{
	if (wait_probe_finish(drv, dev)) {
		sfx_spin_lock(&drv->probe_list_lock);
		sfx_list_del(&dev->ftl_mq_ctx.probe_on);
		sfx_spin_unlock(&drv->probe_list_lock);
		return;
	}
	(*fn_rm)(&dev->ftl_mq_ctx);
	sfx_spin_lock(&drv->probe_list_lock);
#ifdef SFX_LINUX
	/*format remove while reset remove, fn_rm will blocking, so the 2nd remove can be just skip*/
	if (dev->ftl_mq_ctx.probe_on.prev != LIST_POISON2 && dev->ftl_mq_ctx.probe_on.next != LIST_POISON1)
#endif
		sfx_list_del(&dev->ftl_mq_ctx.probe_on);
	sfx_spin_unlock(&drv->probe_list_lock);
}

void sfx_driver_remove(struct sfx_dev *sdev)
{
	struct sfx_driver *driver = NULL;

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s entered\n", __FUNCTION__, sdev->name);
#endif
	while (!sfx_write_trylock(&driver_list_lock)) {
		sfx_usleep(10);
	}
	if (!sfx_list_empty(&driver_list)) {
		sfx_list_for_each_entry(driver, &driver_list, node)
		{
			if (driver->remove) {
				sfx_pr_info("%s: %s, remove device %s per driver %s\n", __FUNCTION__,
					    sdev->name, sdev->devfname, driver->name);
				remove_device_per_driver(driver, sdev, driver->remove);
			}
		}
	}
	sfx_write_unlock(&driver_list_lock);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s exit\n", __FUNCTION__, sdev->name);
#else
	sfx_pr_info("%s: %s done\n", __FUNCTION__, sdev->name);
#endif
	return;
}

void sfx_driver_shutdown(struct sfx_dev *sdev)
{
	struct sfx_driver *driver = NULL;

	while (!sfx_write_trylock(&driver_list_lock)) {
		sfx_usleep(10);
	}

	if (!sfx_list_empty(&driver_list)) {
		sfx_list_for_each_entry(driver, &driver_list, node)
		{
			if (driver->shutdown) {
				sfx_pr_info("%s: %s, shutdown device %s per driver %s\n", __FUNCTION__,
					    sdev->name, sdev->devfname, driver->name);
				remove_device_per_driver(driver, sdev, driver->shutdown);
			}
		}
	} else
		sfx_pr_info("%s: %s, empty driver_list!\n", __FUNCTION__, sdev->name);
	sfx_write_unlock(&driver_list_lock);
}

int sfx_make_bd_parameter(struct sfx_dev *dev)
{
	if (!dev->sfx_bd_param) {
		dev->sfx_bd_param = sfx_kzalloc(sizeof(bd_param_t), GFP_KERNEL);
		if (!dev->sfx_bd_param) {
			sfx_pr_info("%s: %s, Unknown mem addr !!!\n", __FUNCTION__, dev->name);
			// F_LEAVE;
			return -ENOMEM;
		}
	}
	(dev->sfx_bd_param)->dev_id = dev->instance;
	(dev->sfx_bd_param)->intf_ver = 1;
	(dev->sfx_bd_param)->goldimg = dev->goldimg;
	(dev->sfx_bd_param)->sn_start_addr = dev->sn_start_addr;
	if (dev->sfx_bd_heap1 || dev->sfx_bd_heap2) {
		(dev->sfx_bd_param)->heapid1 = dev->sfx_bd_heap1;
		(dev->sfx_bd_param)->heapid2 = dev->sfx_bd_heap2;
		(dev->sfx_bd_param)->heapsz1 = dev->sfx_bd_heap1_size;
		(dev->sfx_bd_param)->heapsz2 = dev->sfx_bd_heap2_size;
	}
	/* set driver_handle for blk_ftl to call sfx_alloc_nvmeq */
	dev->ftl_mq_ctx.driver_handle = dev;
#ifdef SFX_LINUX
#if ENABLE_VDEV
	dev->ftl_mq_ctx.pdev1 = dev->block_kobj;
#endif
	dev->ftl_mq_ctx.pdev = &dev->pci_dev->dev;
#endif
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: %s, Set driver handle %p, ftl ctx %p %p goldimg %u clean %d\n", __FUNCTION__,
		    dev->name, dev->ftl_mq_ctx.driver_handle, &dev->ftl_mq_ctx, &dev->ftl_mq_ctx.ftl_ctx,
		    dev->goldimg, dev->to_clean);
#endif
	if (*dev->opn) {
		strncpy((dev->sfx_bd_param)->opn, dev->opn, sizeof((dev->sfx_bd_param)->opn));
#ifdef SFXDRIVER_DEBUG
		sfx_pr_info("%s: %s, set OPN \"%s\"\n", __FUNCTION__, dev->name, dev->opn);
#endif
	}
	if (*dev->serial) {
		strncpy((dev->sfx_bd_param)->sn, dev->serial, sizeof((dev->sfx_bd_param)->sn));
#ifdef SFXDRIVER_DEBUG
		sfx_pr_info("%s: %s, set SN \"%s\"\n", __FUNCTION__, dev->name, dev->serial);
#endif
	}
	if (*dev->firmware_rev) {
		strncpy((dev->sfx_bd_param)->firmware_rev, dev->firmware_rev,
			sizeof((dev->sfx_bd_param)->firmware_rev));
#ifdef SFXDRIVER_DEBUG
		sfx_pr_info("%s: %s, set REV \"%s\"\n", __FUNCTION__, dev->name,
			    (dev->sfx_bd_param)->firmware_rev);
#endif
	}
	sfx_pr_info("%s: %s, card clean=0x%x comp_only=0x%x\n", __FUNCTION__, dev->name, dev->to_clean,
		    dev->comp_only);
	(dev->sfx_bd_param)->clean = dev->to_clean;
	(dev->sfx_bd_param)->comp_only = dev->comp_only;

	return 0;
}

int sfx_driver_probe(struct sfx_driver *sdrv, struct sfx_dev *sdev)
{
	struct sfx_driver *driver = sdrv;
	int ret = 0;

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: entered, sdrv %p %s ftl_mq_ctx %p\n", __FUNCTION__, sdrv, sdev->name,
		    &sdev->ftl_mq_ctx);
#endif
	sfx_make_bd_parameter(sdev);
	sfx_pr_info("%s: call probe(%s) for driver %s, numa id %u\n", __FUNCTION__, sdev->name, driver->name,
		    sdev->numa_node);
	if ((ret = driver->probe(sdev->devfname, sdev->numa_node, sdev->sfx_bd_param, &sdev->ftl_mq_ctx))) {
		sfx_pr_err("%s: %s, driver->probe failed, &dev->ftl_mq_ctx %p ret %d\n", __FUNCTION__,
			   sdev->name, &sdev->ftl_mq_ctx, ret);
	} else {
		sfx_pr_info("%s: %s, driver->probe succeeded, &dev->ftl_mq_ctx %p\n", __FUNCTION__,
			    sdev->name, &sdev->ftl_mq_ctx);
	}
	sdev->to_clean = 0;
	//sfx_pr_info("%s: %s reset card clean\n", __FUNCTION__, sdev->name);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: exit\n", __FUNCTION__);
#endif
	return ret;
}

void sfx_driver_cleanup(void)
{
	struct sfx_driver *driver = NULL, *next = NULL;

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: enter\n", __FUNCTION__);
#endif
	while (!sfx_write_trylock(&driver_list_lock)) {
		sfx_usleep(10);
	}

	if (!sfx_list_empty(&driver_list)) {
		sfx_pr_info("%s: drver_list is not empty!\n", __FUNCTION__);
		sfx_list_for_each_entry_safe(driver, next, &driver_list, node) sfx_list_del(&driver->node);
	}
	sfx_write_unlock(&driver_list_lock);
#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: exit\n", __FUNCTION__);
#endif
	return;
}

struct sfx_driver *sfx_driver_find(const char *name)
{
	struct sfx_driver *driver = NULL, *my_sdriver = NULL;

	sfx_read_lock(&driver_list_lock);
	sfx_list_for_each_entry(driver, &driver_list, node)
	{
		if (driver && !strcmp(name, driver->name)) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: found active driver %s=%p\n", __FUNCTION__, name, driver);
#endif
			my_sdriver = driver;
		}
	}
	sfx_read_unlock(&driver_list_lock);

	return (struct sfx_driver *)my_sdriver;
}

#define NORWSZ 128
#define PROBECNT_HDR 0x5afec0de

int write_nor_sw_probecnt(struct sfx_dev *dev, xt_u32 value)
{
	int i, err = 0;
	void *tmp_mem;
	xt_u32 *tmp;
	xt_u32 offset;
	struct nor_sw_probe probe = { 0, 0, 0, 0 };

	if (!(tmp_mem = sfx_malloc(BYTE_PER_SUBSECTOR))) {
		sfx_pr_err("%s: %s, sfx_malloc 4K failed\n", __FUNCTION__, dev->name);
		return -ENOMEM;
	}
	sfx_memset(tmp_mem, 0, BYTE_PER_SUBSECTOR);
	offset = dev->nor_sw;
	tmp = (xt_u32 *)tmp_mem;
	/* read 4k */
	for (i = 0; i < BYTE_PER_SUBSECTOR / NORWSZ; i++) {
		if (sfxdriver_nor_flash_read(dev, offset, NORWSZ, tmp)) {
			sfx_pr_err("%s: %s, Read 128b from nor failed i %d\n", __FUNCTION__, dev->name, i);
			sfx_mfree(tmp_mem);
			return -EIO;
		}
		offset += NORWSZ;
		tmp += NORWSZ / 4;
	}
	/* erase 4k */
	if (sfxdriver_norsw_erase_data(dev, 0, BYTE_PER_SUBSECTOR)) {
		sfx_pr_err("%s: %s, sfxdriver_spi_erase_daa() failed", __FUNCTION__, dev->name);
		sfx_mfree(tmp_mem);
		return -EIO;
	}
	tmp = (xt_u32 *)tmp_mem;
	probe.hdr = PROBECNT_HDR;
	probe.count = value;
	probe.sum = nor_sw_probe_checksum_comp(&probe);
#ifdef SFXDRIVER_NOR_DEBUG
	sfx_pr_info("%s: %s probe %08x %08x %08x %08x write\n", __FUNCTION__, dev->name, probe.hdr,
		    probe.count, probe.rsv, probe.sum);
#endif
	sfx_memcpy(tmp, &probe, sizeof(struct nor_sw_probe));
	offset = dev->nor_sw;
	/* write and verify 4k */
#ifdef SFXDRIVER_NOR_DEBUG
	sfx_pr_info("%s: %s, === value %x *tmp %x\n", __FUNCTION__, dev->name, value, *tmp);
#endif
	for (i = 0; i < BYTE_PER_SUBSECTOR / NORWSZ && !err; i++) {
		xt_u32 rbuf[NORWSZ >> 2];

		if (sfxdriver_spi_write_data(dev, offset, NORWSZ, tmp)) {
			sfx_pr_err("%s: %s, sfxdriver_spi_write_data failed i %d", __FUNCTION__, dev->name,
				   i);
			err = -EIO;
		} else {
			if (sfxdriver_nor_flash_read(dev, offset, NORWSZ, rbuf)) {
				sfx_pr_err("%s: %s, ReadBack failed\n", __FUNCTION__, dev->name);
				err = -EIO;
			} else {
				{
					int j;
					char *wp = (char *)tmp;
					char *rp = (char *)rbuf;
					for (j = 0; j < NORWSZ; wp++, rp++, j++) {
						if (*wp != *rp) {
							sfx_pr_info(
								"%s: Compare failed at offset %x j %d, wp 0x%02x rp 0x%02x\n",
								__FUNCTION__, offset, j, *wp, *rp);
							err = -EIO;
							break;
#ifdef SFXDRIVER_NOR_DEBUG
						} else {
							printk("%2x ", *rp);
#endif
						}
					}
				}
			}
		}
		offset += NORWSZ;
		tmp += NORWSZ / 4;
	}
	sfx_mfree(tmp_mem);
	return err;
}

int sfx_probecnt_update(struct sfx_dev *sdev, probecnt_ope_t ope, int val)
{
	xt_u32 blk_probe = 0;
	if (!sdev || ope >= PROBE_INVALID) {
		sfx_pr_err("%s: %s, Invalid Param\n", __FUNCTION__, sdev->name);
		return -EINVAL;
	}
	if (sfxdriver_spi_init(sdev)) {
		sfx_pr_err("%s: %s, sfxdriver_spi_init() failed, return -EFAULT\n", __FUNCTION__, sdev->name);
		return -EFAULT;
	}

	switch (ope) {
	case PROBE_ADD:
		if (nor_sw_probecnt_read(sdev, &blk_probe)) {
			sfx_pr_err("%s/%d: %s, nor_sw_probecnt_read failed, %08x, keep probing\n",
				   __FUNCTION__, __LINE__, sdev->name, blk_probe);
		}
		if (blk_probe != 0xffffffff && blk_probe != SW_PROBECNT_READ_RD_ERR &&
		    blk_probe != SW_PROBECNT_READ_SUM_ERR) {
			blk_probe += val;
		} else {
			sfx_pr_err("%s/%d:, Invalid blk_probe 0x%x, reset to 0\n", __func__, __LINE__,
				   blk_probe);
			blk_probe = 0;
		}
		break;

	case PROBE_CLR:
		blk_probe = 0;
		break;

	default:
		sfx_pr_err("%s: %s, Invalid Ope %d\n", __FUNCTION__, sdev->name, ope);
		sfxdriver_spi_exit(sdev);
		return -EFAULT;
	}

	/*update to nor flash*/
	if (write_nor_sw_probecnt(sdev, blk_probe)) {
		sfxdriver_spi_exit(sdev);
		sfx_pr_err("%s/%d: %s, write_nor_sw_probecnt failed\n", __FUNCTION__, __LINE__, sdev->name);
		return -EFAULT;
	} else {
		if (nor_sw_probecnt_read(sdev, &sdev->probe_cnt)) {
			sfx_pr_err("%s/%d: %s, nor_sw_probecnt_read failed, NOTE: keep probing\n",
				   __FUNCTION__, __LINE__, sdev->name);
		}
	}
	sfxdriver_spi_exit(sdev);
	sfx_pr_info("%s: update probe_cnt to %d\n", sdev->name, blk_probe);
	return blk_probe;
}

/**
 * @brief if blt_assert occur, inc probe_cnt by 5
 *
 * @param sdev
 */
void sfx_assert_probecnt(void *arg)
{
	struct sfx_dev *sdev = (struct sfx_dev *)arg;
	/*
	 * sdev->probe_cnt only clear to 0 after post probe executed which means probe successfully.
	 * Only inc the probe_cnt by 5 if assert triggered during probe period
	 * */
	if (sdev->probe_cnt != 0) {
		sfx_probecnt_update(sdev, PROBE_ADD, PROBE_ASSERT_INC);
	}
}
EXPORT_SYMBOL(sfx_assert_probecnt);

int sfx_pre_probe(struct sfx_dev *device)
{
	struct sfx_dev *sdev = device;
	int probe_cnt = 0;

	if (!sdev->force_probe && !sdev->to_clean) {
		probe_cnt = sfx_probecnt_update(sdev, PROBE_ADD, 1);
		if (probe_cnt < 0) {
			return -EFAULT;
		} else if (probe_cnt >= sdev->probe_cnt_limit) {
			sfx_pr_err(
				"%s: %s, nor_flash_read %d > probe_cnt_limit 0x%x from nor_sw, will not call blk driver's probe\n",
				__FUNCTION__, sdev->name, probe_cnt, sdev->probe_cnt_limit);
			return -ENODEV;
		}
	} /*else {
		sfx_pr_info("%s: %s, force_probe %d or to_clean %d\n", __FUNCTION__, sdev->name,
			    sdev->force_probe, sdev->to_clean);
	}*/

	return 0;
}

void sfx_post_probe(struct sfx_dev *device)
{
	struct sfx_dev *sdev = device;
	sfx_probecnt_update(sdev, PROBE_CLR, 0);
}

static int do_bd_probe(struct sfx_driver *drv, struct sfx_dev *sdev)
{
	int rtn = 0;
	/*Ali Requirement, if goldimg detected, disable blk dev*/
	if (sdev->goldimg) {
		sfx_pr_info("%s:%s GoldImg detected, skip bd probe\n", __FUNCTION__, &sdev->name);
		return -ENODEV;
	}

	sfx_spin_lock(&drv->probe_list_lock);
	sfx_list_add_tail(&sdev->ftl_mq_ctx.probe_on, &drv->probe_pre_list);
	sfx_spin_unlock(&drv->probe_list_lock);

	if ((rtn = sfx_pre_probe(sdev))) {
		sfx_pr_err("%s: %s sfx_pre_probe() failed %d returned\n", __FUNCTION__, sdev->name, rtn);
		return rtn;
	}

	sfx_spin_lock(&drv->probe_list_lock);
	sfx_list_del(&sdev->ftl_mq_ctx.probe_on);
	sfx_list_add_tail(&sdev->ftl_mq_ctx.probe_on, &drv->probe_ing_list);
	sfx_spin_unlock(&drv->probe_list_lock);

	if (drv->probe) {
		if ((rtn = sfx_driver_probe(drv, sdev))) {
			sfx_pr_err("%s: %s sfx_driver_probe() failed %d returned\n", __FUNCTION__, sdev->name,
				   rtn);
			sfx_spin_lock(&drv->probe_list_lock);
			sfx_list_del(&sdev->ftl_mq_ctx.probe_on);
			sfx_list_add_tail(&sdev->ftl_mq_ctx.probe_on, &drv->probe_fail_list);
			sfx_spin_unlock(&drv->probe_list_lock);
		} else {
			sfx_spin_lock(&drv->probe_list_lock);
			sfx_list_del(&sdev->ftl_mq_ctx.probe_on);
			sfx_list_add_tail(&sdev->ftl_mq_ctx.probe_on, &drv->probe_done_list);
			sfx_spin_unlock(&drv->probe_list_lock);
		}
	}

	if (!rtn)
		sfx_post_probe(sdev);

	if (sfx_atomic_read(&bd_probe_cnt))
		sfx_atomic_dec(&bd_probe_cnt);

	/*if (!sfx_atomic_read(&bd_probe_cnt))
		sfx_pr_info("%s: %s, sfx_driver_probe all done\n", __FUNCTION__, sdev->name);*/

	if (sdev->force_probe) {
		//sfx_pr_info("%s: %s, force_probe = 0, One shot only\n", __FUNCTION__, sdev->name);
		sdev->force_probe = 0;
	}

	return 0;
}

static int bd_probe_thread(void *arg)
{
	struct bd_probe *bprobe = (struct bd_probe *)arg;
	struct sfx_driver *drv;
	struct sfx_dev *sdev;
	int rtn = 0;

	drv = bprobe->drv;
	sdev = bprobe->dev;
	sfx_kfree(bprobe);
	rtn = do_bd_probe(drv, sdev);
	return rtn;
}

static int sfx_driver_probe_thread(void *arg)
{
	struct sfx_driver *drv = arg;
	struct sfx_dev *sdev;
	struct bd_probe *bprobe = NULL;
	sfx_thread_t probe_thread;
	int i = 0;
	char tname[32];

	sfx_write_lock(&driver_list_lock);
	sfx_list_add_tail(&drv->node, &driver_list);
	sfx_write_unlock(&driver_list_lock);
	//sfx_pr_info("%s: driver %s=0x%p added to driver list\n", __FUNCTION__, drv->name, drv);

	if (!drv->probe) {
		sfx_pr_err("%s: driver %s has no probe routine, return\n", __FUNCTION__, drv->name);
		return 0;
	}

	sfx_read_lock(&dev_list_lock);
	if (!sfx_list_empty(&dev_list)) {
		sfx_list_for_each_entry(sdev, &dev_list, node)
		{
			bprobe = sfx_kzalloc(sizeof(struct bd_probe), GFP_KERNEL);
			if (bprobe) {
				bprobe->dev = sdev;
				bprobe->drv = drv;
				sfx_snprintf(tname, 32, "sfx_bd_probe_%d", i);
				i++;
				if (IS_ERR((void *)(unsigned long)sfx_thread_create(
					    &probe_thread, bd_probe_thread, bprobe, tname))) {
					sfx_pr_err("%s: %s, Failed to start bd_probe_thread\n", __FUNCTION__,
						   sdev->name);
				}
			} else {
				sfx_pr_err("%s: cannot allocate bd_probe struct for %s\n", __FUNCTION__,
					   sdev->name);
			}
		}
	}
	sfx_read_unlock(&dev_list_lock);
	return 0;
}

int sfx_dev_probe_thread(void *arg)
{
	struct sfx_dev *dev = (struct sfx_dev *)arg;
	struct sfx_driver *driver = NULL;
	int rtn = 0;

	sfx_read_lock(&driver_list_lock);
	sfx_list_for_each_entry(driver, &driver_list, node)
	{
		sfx_pr_info("%s: %s driver %s probe device: %s\n", __FUNCTION__, dev->name, driver->name);
		rtn = do_bd_probe(driver, dev);
	}
	sfx_read_unlock(&driver_list_lock);

	/* set pattern for power failure event checking */
	fis_indirect_write32(dev, dev->bar, SCRATCH_HI, SCRATCH_HI_PF_PATTERN);

	if (sfxdriver_spi_init(dev)) {
		sfx_pr_err("%s: %s, sfxdriver_spi_init() failed", __FUNCTION__, dev->name);
	} else {
		nor_sw_probecnt_read(dev, &dev->probe_cnt);
		sfxdriver_spi_exit(dev);
	}

	return rtn;
}

int sfx_register_driver(struct sfx_driver *drv)
{
	struct sfx_driver *sdrv = NULL;
	sfx_thread_t probe_thread;

	if (in_crashdump) {
		sfx_pr_err("%s: in crashdump kernel, don't probe block driver\n", __FUNCTION__);
		return -EINVAL;
	}

	if (!drv) {
		sfx_pr_err("%s: NULL driver, return\n", __FUNCTION__);
		return -EINVAL;
	}
	if ((sdrv = sfx_driver_find(drv->name))) {
		sfx_pr_err("Error: driver %s=%p is already registered, return\n", drv->name, sdrv);
		return -EBUSY;
	}

	if (IS_ERR((void *)(unsigned long)sfx_thread_create(&probe_thread, sfx_driver_probe_thread, drv,
							    "sfx_drv_probe"))) {
		sfx_pr_err("%s: Failed to start sfx_driver_probe\n", __FUNCTION__);
		return -EINVAL;
	} else {
		return 0;
	}
}
EXPORT_SYMBOL(sfx_register_driver);

void sfx_wait_probe_finish(struct sfx_driver *drv)
{
	struct sfx_driver *sdrv = NULL;
	struct sfx_dev *dev = NULL;

	if (!drv) {
		sfx_pr_err("%s: NULL driver, nothing to do, return\n", __FUNCTION__);
		return;
	}
	if (!(sdrv = sfx_driver_find(drv->name))) {
		sfx_pr_info("Error: driver %s is not registered.\n", drv->name);
		return;
	}

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, &dev_list, node)
	{
		wait_probe_finish(drv, dev);
	}
	sfx_read_unlock(&dev_list_lock);
}
EXPORT_SYMBOL(sfx_wait_probe_finish);

int sfx_unregister_driver(struct sfx_driver *drv)
{
	struct sfx_driver *sdrv = NULL;
	struct sfx_dev *dev = NULL, *next = NULL;
	ftl_mq_ctx *mq_ctx = NULL;

	if (!drv) {
		sfx_pr_err("%s: NULL driver, nothing to do, return\n", __FUNCTION__);
		return -EINVAL;
	}
	if (!(sdrv = sfx_driver_find(drv->name))) {
		sfx_pr_info("Error: driver %s is not registered.\n", drv->name);
		return -EBUSY;
	}

	if (sdrv->remove) {
		sfx_read_lock(&dev_list_lock);
		sfx_list_for_each_entry(dev, &dev_list, node)
		{
			sfx_pr_info("%s: remove device %s per driver %s\n", __FUNCTION__, dev->devfname,
				    sdrv->name);
			remove_device_per_driver(sdrv, dev, sdrv->remove);
		}
		sfx_read_unlock(&dev_list_lock);
	} else {
		sfx_pr_info("%s: driver %s has no fuction remove initialized\n", __FUNCTION__, drv->name);
	}

	sfx_spin_lock(&drv->probe_list_lock);
	if (!sfx_list_empty(&sdrv->probe_done_list)) {
		sfx_pr_err("%s: driver %s probe_done_list is not empty!\n", __FUNCTION__, drv->name);
		sfx_list_for_each_entry(mq_ctx, &sdrv->probe_done_list, probe_on)
		{
			sfx_pr_info("%s: mq_ctx(%p)\n", __FUNCTION__, mq_ctx);
		}
		BUG();
	}
	sfx_spin_unlock(&drv->probe_list_lock);

	while (!sfx_write_trylock(&driver_list_lock)) {
		sfx_usleep(10);
	}
	sfx_list_del(&sdrv->node);
	sfx_write_unlock(&driver_list_lock);
	//sfx_pr_info("%s: driver %s(%p) unregistered\n", __FUNCTION__, sdrv->name, sdrv);
	in_hotreset = 1;
	sfx_read_lock(&dev_list_lock);
	if (!sfx_list_empty(&dev_list)) {
		sfx_list_for_each_entry_safe(dev, next, &dev_list, node)
		{
			xt_u32 nvme_cmd_cnt, nvme_cpl_cnt, nvme_int_cnt;

			nvme_cmd_cnt = fis_indirect_read32(dev, dev->bar, NVME_CMD_CNT);
			nvme_cpl_cnt = fis_indirect_read32(dev, dev->bar, NVME_CPL_CNT);
			nvme_int_cnt = fis_indirect_read32(dev, dev->bar, NVME_INT_CNT);

			dev->fail_flg = 0;
			/*sfx_pr_info("%s: %s hw cmd_cnt %u cpl_cnt %u int_cnt %u\n", __FUNCTION__,
				    dev->devfname, nvme_cmd_cnt, nvme_cpl_cnt, nvme_int_cnt);*/
			if (nvme_cmd_cnt != nvme_cpl_cnt) {
				sfx_pr_info(
					"%s: %s hw cmd_cnt != cpl_cnt, hotreset to flush dangling commands\n",
					__FUNCTION__, dev->devfname);
				/* per HW, do heavy-handed reset here to clear HW state
                 * this is to workaround block driver only unload/load hang problem
                 */
				sfx_dev_hotreset(dev);
			}
		}
	}
	sfx_read_unlock(&dev_list_lock);

	/*move fail device to fail list*/
	sfx_write_lock(&dev_list_lock);
	if (!sfx_list_empty(&dev_list)) {
		sfx_list_for_each_entry(dev, &dev_list, node)
		{
			if (dev->fail_flg) {
				sfx_list_del(&dev->node);
				sfx_list_add_tail(&dev->node, &fail_list);
				sfx_pr_info("%s: %s, put on fail_list\n", __FUNCTION__, dev->name);
			}
		}
	}
	sfx_write_unlock(&dev_list_lock);
	in_hotreset = 0;
	return 0;
}
EXPORT_SYMBOL(sfx_unregister_driver);

#define sfx_seq_wapper_printf(m, format, args...)            \
	do {                                                 \
		if (m) {                                     \
			sfx_seq_printf((m), format, ##args); \
		} else {                                     \
			sfx_pr_info(format, ##args);         \
		}                                            \
	} while (0)

int sfx_proc_stats_show_f(struct sfx_seq_file *m, void *v, struct sfx_list_head *dl)
{
	struct sfx_list_head *dev_list = dl;
	struct sfx_dev *dev;
	int i;

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, dev_list, node)
	{
		sfx_seq_wapper_printf(m, "version=%s, dev[%d]: %p\n", SFX_SW_VERSION, dev->instance, dev);

		for (i = 0; i < dev->queue_count; i++) {
			struct sfx_queue *q = lock_nvmeq(dev, i);

			if (q) {
				sfx_seq_wapper_printf(
					m,
					"S[%d]:%-12llu IRQ[%d]:%-12llu IRQ_T[%d]:%-12llu C[%d]:%-12llu CB/Completion[%d]:%-12llu "
					"P[%d]:%-12llu PT[%d]:%-12llu PP[%d]:%-12llu PPT[%d]:%-12llu\n",
					i, (long long unsigned int)q->q_stats.sq_counter, i,
					(long long unsigned int)q->q_stats.irq_counter, i,
					(long long unsigned int)q->q_stats.irq_counter_total, i,
					(long long unsigned int)q->q_stats.cq_counter, i,
					(long long unsigned int)q->q_stats.cpl_counter, i,
					(long long unsigned int)q->q_stats.poll_counter, i,
					(long long unsigned int)q->q_stats.poll_total, i,
					(long long unsigned int)q->q_stats.polling_counter, i,
					(long long unsigned int)q->q_stats.polling_total);
				unlock_nvmeq(q);
			} else {
				sfx_seq_wapper_printf(m, "q[%d] NON-EXIST\n", i);
			}
		}
#ifdef USE_KTIME_ALL
		for (i = 0; i < dev->queue_count; i++) {
			struct sfx_queue *q = lock_nvmeq(dev, i);
			sfx_seq_wapper_printf(m, "lat_rtt[%d]:%-12llu\n", i,
					      q->q_stats.lat_rtt / q->q_stats.cq_counter);
			unlock_nvmeq(q);
		}
#endif
#ifdef USE_KTIME_CTX
		sfx_seq_wapper_printf(m, "============================================Latency start\n");
		for (i = 0; i < dev->queue_count; i++) {
			struct sfx_queue *q = lock_nvmeq(dev, i);

			if (q) {
				if (q->q_stats.cq_counter > 0) {
					if (i == 0) {
						sfx_seq_wapper_printf(
							m,
							"nandreset_rtt[%d]:%-12llu nandreset_smt[%d]:%-12llu nandreset_max[%d]:%-12llu "
							"aes_rtt[%d]:%-12llu aes_smt[%d]:%-12llu aes_max[%d]:%-12llu "
							"identify_rtt[%d]:%-12llu identify_smt[%d]:%-12llu identify_max[%d]:%-12llu "
							"getfeature_rtt[%d]:%-12llu getfeature_smt[%d]:%-12llu getfeature_max[%d]:%-12llu "
							"setfeature_rtt[%d]:%-12llu setfeature_smt[%d]:%-12llu setfeature_max[%d]:%-12llu "
							"delcq_rtt[%d]:%-12llu delcq_smt[%d]:%-12llu delcq_max[%d]:%-12llu "
							"delsq_rtt[%d]:%-12llu delsq_smt[%d]:%-12llu delsq_max[%d]:%-12llu "
							"other_rtt[%d]:%-12llu other_smt[%d]:%-12llu other_max[%d]:%-12llu\n",
							i,
							q->q_stats.lat_s.nandreset_cnt > 0 ?
								q->q_stats.lat_s.nandreset_rtt /
									q->q_stats.lat_s.nandreset_cnt :
								0,
							i,
							q->q_stats.lat_s.nandreset_cnt > 0 ?
								q->q_stats.lat_s.nandreset_smt /
									q->q_stats.lat_s.nandreset_cnt :
								0,
							i, q->q_stats.lat_s.nandreset_max, i,
							q->q_stats.lat_s.aes_cnt > 0 ?
								q->q_stats.lat_s.aes_rtt /
									q->q_stats.lat_s.aes_cnt :
								0,
							i,
							q->q_stats.lat_s.aes_cnt > 0 ?
								q->q_stats.lat_s.aes_smt /
									q->q_stats.lat_s.aes_cnt :
								0,
							i, q->q_stats.lat_s.aes_max, i,
							q->q_stats.lat_s.ai_cnt > 0 ?
								q->q_stats.lat_s.ai_rtt /
									q->q_stats.lat_s.ai_cnt :
								0,
							i,
							q->q_stats.lat_s.ai_cnt > 0 ?
								q->q_stats.lat_s.ai_smt /
									q->q_stats.lat_s.ai_cnt :
								0,
							i, q->q_stats.lat_s.ai_max, i,
							q->q_stats.lat_s.gf_cnt > 0 ?
								q->q_stats.lat_s.gf_rtt /
									q->q_stats.lat_s.gf_cnt :
								0,
							i,
							q->q_stats.lat_s.gf_cnt > 0 ?
								q->q_stats.lat_s.gf_smt /
									q->q_stats.lat_s.gf_cnt :
								0,
							i, q->q_stats.lat_s.gf_max, i,
							q->q_stats.lat_s.sf_cnt > 0 ?
								q->q_stats.lat_s.gf_rtt /
									q->q_stats.lat_s.sf_cnt :
								0,
							i,
							q->q_stats.lat_s.sf_cnt > 0 ?
								q->q_stats.lat_s.gf_smt /
									q->q_stats.lat_s.sf_cnt :
								0,
							i, q->q_stats.lat_s.sf_max, i,
							q->q_stats.lat_s.dcq_cnt > 0 ?
								q->q_stats.lat_s.dcq_rtt /
									q->q_stats.lat_s.dcq_cnt :
								0,
							i,
							q->q_stats.lat_s.dcq_cnt > 0 ?
								q->q_stats.lat_s.dcq_smt /
									q->q_stats.lat_s.dcq_cnt :
								0,
							i, q->q_stats.lat_s.dcq_max, i,
							q->q_stats.lat_s.dsq_cnt > 0 ?
								q->q_stats.lat_s.dsq_rtt /
									q->q_stats.lat_s.dsq_cnt :
								0,
							i,
							q->q_stats.lat_s.dsq_cnt > 0 ?
								q->q_stats.lat_s.dsq_smt /
									q->q_stats.lat_s.dsq_cnt :
								0,
							i, q->q_stats.lat_s.dsq_max, i,
							q->q_stats.lat_s.other_cnt > 0 ?
								q->q_stats.lat_s.other_rtt /
									q->q_stats.lat_s.other_cnt :
								0,
							i,
							q->q_stats.lat_s.other_cnt > 0 ?
								q->q_stats.lat_s.other_smt /
									q->q_stats.lat_s.other_cnt :
								0,
							i, q->q_stats.lat_s.other_max);
					} else {
						sfx_seq_wapper_printf(
							m,
							"wr_rtt[%d]:%-12llu wr_smt[%d]:%-12llu wr_max[%d]:%-12llu "
							"rd_rtt[%d]:%-12llu rd_smt[%d]:%-12llu rd_max[%d]:%-12llu "
							"other_asyncio_rtt[%d]:%-12llu other_asyncio_smt[%d]:%-12llu other_asyncio_max[%d]:%-12llu\n",
							i,
							q->q_stats.lat_s.wr_cnt > 0 ?
								q->q_stats.lat_s.wr_rtt /
									q->q_stats.lat_s.wr_cnt :
								0,
							i,
							q->q_stats.lat_s.wr_cnt > 0 ?
								q->q_stats.lat_s.wr_smt /
									q->q_stats.lat_s.wr_cnt :
								0,
							i, q->q_stats.lat_s.wr_max, i,
							q->q_stats.lat_s.rd_cnt > 0 ?
								q->q_stats.lat_s.rd_rtt /
									q->q_stats.lat_s.rd_cnt :
								0,
							i,
							q->q_stats.lat_s.rd_cnt > 0 ?
								q->q_stats.lat_s.rd_smt /
									q->q_stats.lat_s.rd_cnt :
								0,
							i, q->q_stats.lat_s.rd_max, i,
							q->q_stats.lat_s.other_asyncio_cnt > 0 ?
								q->q_stats.lat_s.other_asyncio_rtt /
									q->q_stats.lat_s.other_asyncio_cnt :
								0,
							i,
							q->q_stats.lat_s.other_asyncio_cnt > 0 ?
								q->q_stats.lat_s.other_asyncio_smt /
									q->q_stats.lat_s.other_asyncio_cnt :
								0,
							i, q->q_stats.lat_s.other_asyncio_max);
					}
				} else {
					sfx_seq_wapper_printf(m, "q[%d] has %llu completion\n", i,
							      q->q_stats.cq_counter);
				}
				unlock_nvmeq(q);
			} else {
				sfx_seq_wapper_printf(m, "q[%d] NON-EXIST\n", i);
			}
		}
		sfx_seq_wapper_printf(m, "============================================Latency end\n");
#endif

		sfx_seq_wapper_printf(m, "Irq:%d/%u Polling %d/%u\n", dev->sfx_cntrs.irq_counter,
				      dev->sfx_cntrs.irq_total, dev->sfx_cntrs.polling_counter,
				      dev->sfx_cntrs.polling_total);

		sfx_seq_wapper_printf(m, "Umem Locked:%u unlocked:%u (%u) %u/%u\n",
				      sfx_get_page_ctr_val(dev, SFX_COUNTER_LOCKED),
				      sfx_get_page_ctr_val(dev, SFX_COUNTER_UNLOCKED),
				      sfx_get_page_ctr_val(dev, 2), dev->sfx_cntrs.local_locked_pages,
				      dev->sfx_cntrs.local_unlocked_pages);

		sfx_seq_wapper_printf(m, "Check_calls:%d\n", dev->sfx_stats.check_counter);
		sfx_seq_wapper_printf(m, "Erase Error count:%d\n", dev->sfx_cntrs.erase_error_counter);

		sfx_seq_wapper_printf(m, "Read pages:%lld\n",
				      (long long unsigned int)dev->sfx_cntrs.read_counter);

		sfx_seq_wapper_printf(m, "OPN:%s\n", dev->opn);
		sfx_seq_wapper_printf(m, "Serial number:%s sfx%d\n", dev->serial, dev->instance);
	}
	sfx_read_unlock(&dev_list_lock);

	return 0;
}

int sfx_proc_stats_show(struct sfx_seq_file *m, void *v)
{
	sfx_proc_stats_show_f(m, v, &dev_list);
	sfx_proc_stats_show_f(m, v, &fail_list);
	return 0;
}

int sfx_proc_hw_qlists_show_f(struct sfx_seq_file *m, void *v, struct sfx_list_head *dl)
{
	struct sfx_list_head *dev_list = dl;
	struct sfx_dev *dev;

	struct sfx_queue *nvmeq;
	int i, j;

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, dev_list, node)
	{
		sfx_seq_wapper_printf(m, "dev[%d]: %p queue_count %u\n", dev->instance, dev,
				      dev->queue_count);

		for (i = 0; i < dev->queue_count; i++) {
			xt_u16 head, phase, tail;
			volatile struct nvme_completion *cqe;
			struct nvme_command *sqe;

			nvmeq = lock_nvmeq(dev, i);
			if (nvmeq) {
				head = nvmeq->cq_head;
				phase = nvmeq->cq_phase;
				tail = nvmeq->sq_tail;
				sfx_seq_wapper_printf(
					m,
					"q[%d] cq_head 0x%x cq_phase 0x%x sq_tail 0x%x csts 0x%08x cqes %p 0x%016llx seqs %p 0x%016llx\n",
					nvmeq->qid, head, phase, tail, sfx_readl(&dev->bar->csts),
					nvmeq->cqes, nvmeq->cq_dma_addr, nvmeq->sq_cmds, nvmeq->sq_dma_addr);
				sfx_seq_wapper_printf(
					m,
					"cqe list: result, ext_result, sq_head, sq_id, command_id, status\n");
				cqe = &nvmeq->cqes[0];
				for (j = 0; j < nvmeq->q_depth; j++) {
					//  sfx_seq_wapper_printf(m, "\t  cqe[%d] 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n", j, cqe->result, cqe->lba, cqe->sq_head, cqe->sq_id, cqe->command_id, cqe->status);
					sfx_seq_wapper_printf(m,
							      "\t  cqe[%d] 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n",
							      j, cqe->result, cqe->ext_result, cqe->sq_head,
							      cqe->sq_id, cqe->command_id, cqe->status);
					cqe++;
				}

				sfx_seq_wapper_printf(m, "sqe list: nid opcode flags command_id\n");
				sqe = &nvmeq->sq_cmds[0];
				for (j = 0; j < nvmeq->q_depth; j++) {
					sfx_seq_wapper_printf(m, "\t  sqe[%d] 0x%x 0x%x 0x%x 0x%x\n", j,
							      sqe->rw.apptag, sqe->common.opcode,
							      sqe->common.flags, sqe->common.command_id);
					sqe++;
				}
				unlock_nvmeq(nvmeq);
			} else {
				sfx_seq_wapper_printf(m, "q[%d] NON-EXIST\n", i);
			}
		}
	}
	sfx_read_unlock(&dev_list_lock);

	return 0;
}

int sfx_proc_hw_qlists_show(struct sfx_seq_file *m, void *v)
{
	sfx_proc_hw_qlists_show_f(m, v, &dev_list);
	sfx_proc_hw_qlists_show_f(m, v, &fail_list);
	return 0;
}

#define sfx_seq_wapper_printf2(m, format, args...)             \
	do {                                                   \
		if (m) {                                       \
			sfx_seq_printf(m, format, ##args);     \
		} else {                                       \
			sfx_pr_info_no_prefix(format, ##args); \
		}                                              \
	} while (0)

void qe_print(struct sfx_seq_file *m, void *qe, unsigned long size, int depth, char *qs)
{
	xt_u32 *p;
	int cnt;
	int i, j;

	cnt = size >> 2;
	sfx_seq_wapper_printf(m, "%s list: an entry contains %lu bytes\n", qs, size);
	for (i = 0; i < depth; i++) {
		p = (xt_u32 *)qe;
		for (j = 0; j < cnt; j++) {
			if (!j) {
				sfx_seq_wapper_printf2(m, "\t  %s[%d] %08x ", qs, i, *p++);
			} else if (j == cnt - 1) {
				sfx_seq_wapper_printf2(m, "%08x", *p);
				sfx_seq_wapper_printf2(m, "\n");
			} else {
				sfx_seq_wapper_printf2(m, "%08x ", *p++);
			}
		}
		qe += size;
	}
}

int sfx_proc_cmdraw_qlists_show_f(struct sfx_seq_file *m, void *v, struct sfx_list_head *dl)
{
	struct sfx_list_head *dev_list = dl;
	struct sfx_dev *dev;

	struct sfx_queue *nvmeq;
	int i;

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, dev_list, node)
	{
		sfx_seq_wapper_printf(m, "dev[%d]: %p queue_count %u\n", dev->instance, dev,
				      dev->queue_count);

		for (i = 0; i < dev->queue_count; i++) {
			xt_u16 head, phase, tail;
			nvmeq = lock_nvmeq(dev, i);
			if (nvmeq) {
				head = nvmeq->cq_head;
				phase = nvmeq->cq_phase;
				tail = nvmeq->sq_tail;
				sfx_seq_wapper_printf(
					m, "q[%d] cq_head 0x%x cq_phase 0x%x sq_tail 0x%x csts 0x%08x\n",
					nvmeq->qid, head, phase, tail, sfx_readl(&dev->bar->csts));

				qe_print(m, (void *)&nvmeq->cqes[0], sizeof(struct nvme_completion),
					 nvmeq->q_depth, "cqe");
				qe_print(m, (void *)&nvmeq->sq_cmds[0], sizeof(struct nvme_command),
					 nvmeq->q_depth, "sqe");
				unlock_nvmeq(nvmeq);
			} else {
				sfx_seq_wapper_printf(m, "q[%d] NON-EXIST\n", i);
			}
		}
	}
	sfx_read_unlock(&dev_list_lock);

	return 0;
}

int sfx_proc_cmdraw_qlists_show(struct sfx_seq_file *m, void *v)
{
	sfx_proc_cmdraw_qlists_show_f(m, v, &dev_list);
	sfx_proc_cmdraw_qlists_show_f(m, v, &fail_list);
	return 0;
}

void sfx_dev_list_remove(struct sfx_dev *dev)
{
	if (!dev) {
		sfx_pr_err("%s: !dev, return\n", __FUNCTION__);
		return;
	}

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: dev=%p\n", __FUNCTION__, dev);
#endif

	sfx_write_lock(&dev_list_lock);
	sfx_list_del_init(&dev->node);
	sfx_write_unlock(&dev_list_lock);

#ifdef SFXDRIVER_BASE_DEBUG
	sfx_pr_info("%s: list_del_init()'ed\n", __FUNCTION__);
#endif

	if (!sfx_atomic_read(&s_dev_cnt)) {
		sfx_pr_err("%s: %s Unexpected s_dev_cnt = 0\n", __FUNCTION__, dev->name);
	} else {
		sfx_atomic_dec(&s_dev_cnt);
#ifdef SFXDRIVER_BASE_DEBUG
		sfx_pr_info("%s: %s done s_dev_cnt = %d\n", __FUNCTION__, dev->name,
			    sfx_atomic_read(&s_dev_cnt));
#endif
	}
}

struct sfx_iod *sfx_alloc_iod(unsigned nseg, unsigned nbytes, sfx_gfp_t gfp)
{
	struct sfx_iod *iod = sfx_kzalloc(sizeof(struct sfx_iod), gfp);

	if (iod) {
		iod->offset = offsetof(struct sfx_iod, prp_array);
		iod->npages = -1;
		iod->length = nbytes;
		iod->nents = 0;
		iod->first_dma = 0ULL;
		iod->start_time = jiffies;
		iod->private = iod;
	}

	return iod;
}

int sfx_get_matched_sdev_fd(int minor, struct sfx_dev *idev, struct sfx_fd **ifd)
{
	struct sfx_dev *dev = NULL;
	int ret = 0;

	*ifd = NULL;
	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, &dev_list, node)
	{
		if ((dev->instance == minor) && (idev ? dev == idev : 1)) {
			if (!sfx_fd_init(ifd, dev)) {
				if (*ifd)
					ret = 1;
			}
			break;
		}
	}
	sfx_read_unlock(&dev_list_lock);
	return ret;
}
EXPORT_SYMBOL(sfx_get_matched_sdev_fd);

int sfx_kernel_get_feature(struct sfx_fd *fd, xt_u16 op, xt_u32 *data, xt_u8 len)
{
	switch (op) {
	case FEAT_OP_OPN:
		sfx_pr_info("%s: sizeof(*data) %u  sizeof(data) %u len %u\n", __FUNCTION__, sizeof(*data),
			    sizeof(data), len);
		strncpy((char *)data, (char *)fd->dev->opn, len);
		break;
	case FEAT_OP_CARD_INFO: {
#if ENABLE_GC_TRIGGER_FASTER
		sfx_board_nand_type *tmp = (sfx_board_nand_type *)data;
#endif
		memcpy((void *)data, (void *)&fd->dev->card_info,
		       sizeof(fd->dev->card_info) < len ? sizeof(fd->dev->card_info) : len);
#if ENABLE_GC_TRIGGER_FASTER
		tmp->num_blk = 48;
#endif
#ifdef SFXDRIVER_DEBUG
		print_card_info((sfx_board_nand_type *)data);
#endif
		break;
	}
	default:
		sfx_pr_info("%s: opcode=0x%x not supported\n", __FUNCTION__, op);
		return -EINVAL;
	}
	return 0;
}
EXPORT_SYMBOL(sfx_kernel_get_feature);

int sfx_kernel_capacitor_handle(struct sfx_fd *fd, xt_u32 op, xt_u32 para)
{
	return sfx_capacitor_handle(fd->dev, op, para);
}
EXPORT_SYMBOL(sfx_kernel_capacitor_handle);

xt_u32 sfx_kernel_read_power(struct sfx_fd *fd)
{
	return sfx_read_power(fd->dev);
}
EXPORT_SYMBOL(sfx_kernel_read_power);

int sfx_user_get_freeslot_kernel_api(struct sfx_fd *fd, xt_u32 *nfslotp)
{
	return sfx_get_free_slot(fd->dev, nfslotp);
}
EXPORT_SYMBOL(sfx_user_get_freeslot_kernel_api);

void sfx_length_one_token_api(struct sfx_fd *fd, void *mem_struct)
{
	struct sfx_tk_spl_cmd *mem = (struct sfx_tk_spl_cmd *)mem_struct;
	sfx_length_one_sgl(fd->dev, mem->addr, mem->list, mem->length, mem->mask, mem->prd_buff);
}
EXPORT_SYMBOL(sfx_length_one_token_api);

int sfx_split_token_kernel_api(struct sfx_fd *fd, void *mem_struct)
{
	struct sfx_tk_spl_cmd *mem = (struct sfx_tk_spl_cmd *)mem_struct;
	int len = 0;

	if (sfx_is_token_addr(mem->addr)) {
		if (mem->length > 4)
			len = 8;
		else
			len = 4;
	} else {
		len = mem->length;
	}
	if (sfx_create_sgl(fd, mem->addr, mem->list, mem->length, mem->mask, mem->prd_buff,
			   (void **)&mem->token_addr, sfx_true) == NO_ERROR) {
		return 0;
	} else {
		return -1;
	}
}
EXPORT_SYMBOL(sfx_split_token_kernel_api);

int sfx_split_token_release_kernel_api(struct sfx_fd *fd, void *token)
{
	int count = 0;

	if ((count = sfx_delete_sgl(fd, token)) > 0) {
		return 0;
	} else {
		return -1;
	}
}
EXPORT_SYMBOL(sfx_split_token_release_kernel_api);

int sfx_set_pagelist_kernel_api(struct sfx_fd *fd, void **list, void **token, unsigned count, int type,
				int offset)
{
	xt_u32 pgcnt = 0;

	if ((pgcnt = sfx_set_pagelist(fd, (sfx_page **)list, token, count, type, offset)) == count) {
		return 0;
	} else {
		return -1;
	}
}
EXPORT_SYMBOL(sfx_set_pagelist_kernel_api);

int sfx_lock_user_pages_kernel_api(struct sfx_fd *fd, void *mem_struct)
{
	struct sfx_mem_cmd *mem = mem_struct;

	/* So far, no body calls us */
	mem->token_addr = sfx_map_user_pages_simple(fd, (unsigned long)mem->addr, mem->length);

	if (sfx_is_token_addr(mem->token_addr)) {
		return 0;
	} else {
		return -1;
	}
}
EXPORT_SYMBOL(sfx_lock_user_pages_kernel_api);

int sfx_unlock_user_pages_kernel_api(struct sfx_fd *fd, void *mem_struct)
{
	struct sfx_mem_cmd *mem = mem_struct;
	int token = 0;
	long count = 0;

	/* So far, no body calls us */
	if (sfx_is_token_addr(mem->token_addr)) {
		token = (((unsigned long)mem->token_addr) >> 32) & 0xFFFF;
		count = sfx_unmap_user_pages_simple(fd, &fd->dev->page_mgr.pages_list[token]);
		/* BUG or counter returned */
		return 0;
	} else {
		sfx_pr_err("%s: %s, Not token addr!!!\n", __FUNCTION__, fd->dev->name);
		sfx_dump_stack();
		return -1;
	}
}
EXPORT_SYMBOL(sfx_unlock_user_pages_kernel_api);

int sfx_user_check_q_status(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	sfx_check_status_cmd_t *ps = &fd->_status;
	struct sfx_list_head cmdinfo_list;
	struct sfx_list_head cmdinfo_free_list;
	int sts_cnt = 0, status = 0;
	xt_u16 qid = (xt_u16)ps->status;

	// Check cq_list for each queue, free iod and put entry back to free_list
	ps->cq_len = 0;

	dev->sfx_stats.check_counter++;

	{
		struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);
		struct async_io_cmd_info *cmdinfo, *next;
		unsigned long flags = 0;

		if (!nvmeq) {
			sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
			status = -ENODEV;
			return status;
		}
		SFX_INIT_LIST_HEAD(&cmdinfo_list);
		SFX_INIT_LIST_HEAD(&cmdinfo_free_list);

		sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
		if (sfx_list_empty(&nvmeq->cq_list)) {
			sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
			unlock_nvmeq(nvmeq);
			return status;
		}

		sfx_list_for_each_entry_safe(cmdinfo, next, &nvmeq->cq_list, node)
		{
			if (cmdinfo->owner == fd) {
				sfx_list_del(&cmdinfo->node);
				sfx_list_add_tail(&cmdinfo->node, &cmdinfo_list);
				sts_cnt++;
				dev->sfx_stats.cpl_counter[qid]++;
				nvmeq->q_stats.cpl_counter++;
				if (sts_cnt >= STATUS_Q_DEPTH) {
					break;
				}
			}
		}
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

		sfx_list_for_each_entry_safe(cmdinfo, next, &cmdinfo_list, node)
		{
			ps->cpl[ps->cq_len].op_code = cmdinfo->opcode;
			ps->cpl[ps->cq_len].result = cmdinfo->result;
			ps->cpl[ps->cq_len].ext_result = cmdinfo->ext_result;
			ps->cpl[ps->cq_len].nid = cmdinfo->apptag;
#ifdef USE_KTIME_CTX
			ps->cpl[ps->cq_len].latency = cmdinfo->latency;
#endif
			ps->cq_len++;
#ifdef CMD_COMB
			if (cmdinfo->opcode == sfx_cmd_read) {
				sfx_memcpy(ps->cpl[ps->cq_len].fids, cmdinfo->fids,
					   MAX_COMBINED_FCMD * sizeof(xt_u16));
				ps->cpl[ps->cq_len].nr_fcmd = cmdinfo->nr_fcmd;
				ps->cpl[ps->cq_len].comb_token = cmdinfo->addr;
			}
#endif
			// free iod
			if (cmdinfo->iod) {
				if (sfx_is_token_addr(cmdinfo->addr) || cmdinfo->from_kernel) {
					sfx_unmap_user_pages_only(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				} else {
					sfx_unmap_user_pages(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				}
				sfx_try_to_cleanup_pages_context(dev, cmdinfo->iod);
				sfx_free_iod(dev, cmdinfo->iod);
			}
			sfx_list_add_tail(&cmdinfo->node, &cmdinfo_free_list);
		}
		if (sts_cnt != ps->cq_len) {
			sfx_pr_info(
				"%s: %s, ??? cpu %d q[%u] %p sts_cnt %d, != ps->cq_len %d cntrs %llu/%llu/%llu/%llu/%llu\n",
				__FUNCTION__, dev->name, smp_processor_id(), qid, nvmeq, sts_cnt, ps->cq_len,
				nvmeq->q_stats.sq_counter, nvmeq->q_stats.irq_counter,
				nvmeq->q_stats.irq_counter_total, nvmeq->q_stats.cq_counter,
				nvmeq->q_stats.cpl_counter);
			BUG();
		}

		// put back to free_list
		sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
		sfx_list_splice_tail(&cmdinfo_free_list, &nvmeq->free_list);
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

		unlock_nvmeq(nvmeq);
	}
	return status;
}

int sfx_user_check_status(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	int i;
	//sfx_check_status_cmd_t _status;
	sfx_check_status_cmd_t *ps = &fd->_status;
	struct sfx_list_head cmdinfo_list;
	struct sfx_list_head cmdinfo_free_list;
	int sts_cnt = 0, status = 0;

	// Check cq_list for each queue, free iod and put entry back to free_list
	ps->cq_len = 0;

	dev->sfx_stats.check_counter++;

	for (i = 0; i < dev->queue_count; i++) {
		struct sfx_queue *nvmeq = lock_nvmeq(dev, i);
		struct async_io_cmd_info *cmdinfo, *next;
		unsigned long flags = 0;

		if (!nvmeq) {
			sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, i);
			status = -ENODEV;
			break;
		}
		SFX_INIT_LIST_HEAD(&cmdinfo_list);
		SFX_INIT_LIST_HEAD(&cmdinfo_free_list);

		sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);

		if (sfx_list_empty(&nvmeq->cq_list)) {
			sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
			unlock_nvmeq(nvmeq);
			continue;
		}

		sfx_list_for_each_entry_safe(cmdinfo, next, &nvmeq->cq_list, node)
		{
			if (cmdinfo->owner == fd) {
				sfx_list_del(&cmdinfo->node);
				sfx_list_add_tail(&cmdinfo->node, &cmdinfo_list);
				sts_cnt++;
				dev->sfx_stats.cpl_counter[i]++;
				nvmeq->q_stats.cpl_counter++;
				if (sts_cnt >= STATUS_Q_DEPTH) {
					break;
				}
			}
		}
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

		sfx_list_for_each_entry_safe(cmdinfo, next, &cmdinfo_list, node)
		{
			ps->cpl[ps->cq_len].op_code = cmdinfo->opcode;
			ps->cpl[ps->cq_len].result = cmdinfo->result;
			ps->cpl[ps->cq_len].ext_result = cmdinfo->ext_result;
			ps->cpl[ps->cq_len].nid = cmdinfo->apptag;
#ifdef USE_KTIME_CTX
			ps->cpl[ps->cq_len].latency = cmdinfo->latency;
#endif
			ps->cq_len++;
#ifdef CMD_COMB
			if (cmdinfo->opcode == sfx_cmd_read) {
				sfx_memcpy(ps->cpl[ps->cq_len].fids, cmdinfo->fids,
					   MAX_COMBINED_FCMD * sizeof(xt_u16));
				ps->cpl[ps->cq_len].nr_fcmd = cmdinfo->nr_fcmd;
				ps->cpl[ps->cq_len].comb_token = cmdinfo->addr;
			}
#endif
			// free iod
			if (cmdinfo->iod) {
				if (sfx_is_token_addr(cmdinfo->addr) || cmdinfo->from_kernel) {
					sfx_unmap_user_pages_only(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				} else {
					sfx_unmap_user_pages(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				}
				sfx_try_to_cleanup_pages_context(dev, cmdinfo->iod);
				sfx_free_iod(dev, cmdinfo->iod);
			}
			sfx_list_add_tail(&cmdinfo->node, &cmdinfo_free_list);
		}
		if (sts_cnt != ps->cq_len) {
			sfx_pr_info(
				"%s: %s, ??? cpu %d q[%u] %p sts_cnt %d, != ps->cq_len %d cntrs %llu/%llu/%llu/%llu/%llu\n",
				__FUNCTION__, dev->name, smp_processor_id(), i, nvmeq, sts_cnt, ps->cq_len,
				nvmeq->q_stats.sq_counter, nvmeq->q_stats.irq_counter,
				nvmeq->q_stats.irq_counter_total, nvmeq->q_stats.cq_counter,
				nvmeq->q_stats.cpl_counter);
			BUG();
		}

		// put back to free_list
		sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);
		sfx_list_splice_tail(&cmdinfo_free_list, &nvmeq->free_list);
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);

		unlock_nvmeq(nvmeq);

		if (sts_cnt >= STATUS_Q_DEPTH) {
			break;
		}
	}

	return status;
}

#ifdef USE_KTIME_CTX
int sfx_user_get_qstats(struct sfx_fd *fd)
{
	int i;
	struct sfx_dev *dev = fd->dev;
	sfx_get_qstats_cmd_t *qs = &fd->_qstats;

	for (i = 0; i < dev->queue_count && i < NUM_MAXQ; i++) {
		struct sfx_queue *nvmeq = lock_nvmeq(dev, i);

		memcpy(&qs->q_stats[qs->qcnt], &nvmeq->q_stats.lat_s, sizeof(SFX_NVME_QSTATS));
		qs->qcnt++;

		unlock_nvmeq(nvmeq);
	}
	return 0;
}
#endif

int sfx_kernel_check_status(struct sfx_fd *fd, void *status_struct)
{
	int ret;

	if ((ret = sfx_user_check_status(fd))) {
		return ret;
	}

	memcpy(status_struct, &fd->_status, sizeof(sfx_check_status_cmd_t));

	return 0;
}
EXPORT_SYMBOL(sfx_kernel_check_status);

int sfx_kernel_check_q_status(struct sfx_fd *fd, void *status_struct)
{
	int ret;

	if ((ret = sfx_user_check_q_status(fd))) {
		return ret;
	}

	memcpy(status_struct, &fd->_status, sizeof(sfx_check_status_cmd_t));

	return 0;
}
EXPORT_SYMBOL(sfx_kernel_check_q_status);

#ifdef USE_KTIME_CTX
int sfx_kernel_get_qstats(struct sfx_fd *fd, void *qstats_struct)
{
	int ret;

	if ((ret = sfx_user_get_qstats(fd))) {
		return ret;
	}

	memcpy(qstats_struct, &fd->_qstats, sizeof(sfx_get_qstats_cmd_t));

	return 0;
}
EXPORT_SYMBOL(sfx_kernel_get_qstats);
#endif

xt_u32 get_pci_bar_csts(struct sfx_dev *dev)
{
	return sfx_readl(&dev->bar->csts);
}

xt_u32 sfx_get_pci_bar_cts_api(struct sfx_fd *fd)
{
	struct sfx_dev *dev = fd->dev;
	return get_pci_bar_csts(dev);
}
EXPORT_SYMBOL(sfx_get_pci_bar_cts_api);

xt_u32 sfx_indirect_read32(struct sfx_fd *fd, xt_u32 addr)
{
	struct sfx_dev *dev = fd->dev;
	return fis_indirect_read32(dev, dev->bar, addr);
}
EXPORT_SYMBOL(sfx_indirect_read32);

void sfx_indirect_write32(struct sfx_fd *fd, xt_u32 addr, xt_u32 value)
{
	struct sfx_dev *dev = fd->dev;
	fis_indirect_write32(dev, dev->bar, addr, value);
}
EXPORT_SYMBOL(sfx_indirect_write32);

xt_u32 sfx_get_pglist_entry_nr(void)
{
	return MAX_SLOTS;
}
EXPORT_SYMBOL(sfx_get_pglist_entry_nr);

/* adapted from ccs_reg_put ()*/
#define PRINTCNT_IN_ONELINE 16

int ccs_reg_dump(struct sfx_dev *dev, void *ibuf, void *ibuf_end)
{
	char *p, *p1;
	xt_u32 addr = 0, val;
	char mode, reg[64], tmp;
	int rc = 0;
	char pbuf[256];
	char lbuf[16];

	p = ibuf;
	sfx_memset(pbuf, 0, sizeof(pbuf));
	sfx_memset(lbuf, 0, sizeof(lbuf));
	while (*p) {
		p1 = p;
		while (p1 < (char *)ibuf_end && *p1 != '\n')
			p1++;
		if (p1 == (char *)ibuf_end) {
			sfx_pr_err(
				"%s: %s, corrupted or incomplete input, ibuf %p p1=ibuf_end %p p %p *p %c *p1 %c\n",
				__FUNCTION__, dev->name, ibuf, ibuf_end, p, *p, *p1);
			return 1;
		}
		tmp = *p1; // save original content
		*p1 = '\0';
		if ((sscanf(p, "0x%x %c 0x%x %s", &addr, &mode, &val, reg)) == 4) {
			if (mode != 'w') {
				sfx_pr_err("%s: %s, bad format: %s\n", __FUNCTION__, dev->name, p);
				return 2;
			}
			fis_indirect_write32(dev, dev->bar, addr, val);
		} else if ((sscanf(p, "0x%x %c %s", &addr, &mode, reg)) == 3) {
			if (mode != 'r') {
				sfx_pr_err("%s: %s, bad format: %s\n", __FUNCTION__, dev->name, p);
				return 3;
			}
			val = fis_indirect_read32(dev, dev->bar, addr);
			sfx_snprintf(lbuf, 16, "%8x", val);
			rc++;
			if (rc && !(rc % PRINTCNT_IN_ONELINE)) {
				sfx_strncat(lbuf, "\n", 1);
				sfx_strncat(pbuf, lbuf, sizeof(lbuf));
				sfx_pr_info("%s\n", pbuf);
				sfx_memset(pbuf, 0, sizeof(pbuf));
			} else {
				sfx_strncat(lbuf, " ", 1);
				sfx_strncat(pbuf, lbuf, sizeof(lbuf));
			}
		} else {
			sfx_pr_err("%s: %s, unsupported format: %s\n", __FUNCTION__, dev->name, p);
			return 4;
		}
		p += strlen(p) + 1;
		*p1 = tmp; // restore original content
	}
	if (rc && (rc % PRINTCNT_IN_ONELINE)) {
		/* sfx_writelog(SFX_LOG_REG, "last pbuf[%d]: %s\n", strlen(pbuf), pbuf); */
		if (pbuf[strlen(pbuf) - 1] == ' ') {
			/* sfx_writelog(SFX_LOG_REG, "remove pbuf last space\n"); */
			pbuf[strlen(pbuf) - 1] = '\0';
		}
		sfx_pr_info("%s\n", pbuf);
	}
	return 0;
}

/**get submission nvmeq head */
xt_u32 sfx_kernel_get_nvmeq_head(struct sfx_fd *fd, xt_u32 qid)
{
	xt_u32 head;
	struct sfx_dev *dev = fd->dev;
	struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
		return 0xffffffff;
	}
	head = nvmeq->sq_head;
	unlock_nvmeq(nvmeq);
	return head;
}
EXPORT_SYMBOL(sfx_kernel_get_nvmeq_head);

/**get submission nvmeq tail */
xt_u32 sfx_kernel_get_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid)
{
	xt_u32 tail;
	struct sfx_dev *dev = fd->dev;
	struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
		return 0xffffffff;
	}
	tail = nvmeq->sq_tail;
	unlock_nvmeq(nvmeq);
	return tail;
}
EXPORT_SYMBOL(sfx_kernel_get_nvmeq_tail);

/**get submission nvmeq depth */
xt_u32 sfx_kernel_get_nvmeq_depth(struct sfx_fd *fd, xt_u32 qid)
{
	xt_u32 depth;
	struct sfx_dev *dev = fd->dev;
	struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
		return 0xffffffff;
	}
	depth = nvmeq->q_depth;
	unlock_nvmeq(nvmeq);
	return depth;
}
EXPORT_SYMBOL(sfx_kernel_get_nvmeq_depth);

/**set submission nvmeq tail, return error code if it failed */
int sfx_kernel_set_nvmeq_tail(struct sfx_fd *fd, xt_u32 qid, xt_u32 tail)
{
	struct sfx_dev *dev = fd->dev;
	struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);
	unsigned long flags = 0;

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
		return -ENODEV;
	}
	sfx_spin_lock_irqsave(&nvmeq->q_lock, flags);
	if (nvmeq->q_suspended) {
		sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flags);
		sfx_pr_err("%s: %s, !!!!!!!! q[%u] update tail %u suspended, return -EBUSY\n", __FUNCTION__,
			   dev->name, nvmeq->qid, tail);
		return -EBUSY;
	}
	if (tail >= nvmeq->q_depth) {
		sfx_pr_err("%s: %s, !!!!!!!! q[%u] update invalid tail %u\n", __FUNCTION__, dev->name,
			   nvmeq->qid, tail);
		return -EINVAL;
	}
	/* no command to send, just update door bell */
	sfx_writel(tail, (xt_u32 *)nvmeq->q_db);
	nvmeq->sq_tail = tail;
	sfx_spin_unlock_irqrestore(&nvmeq->q_lock, flags);
	unlock_nvmeq(nvmeq);
	return 0;
}
EXPORT_SYMBOL(sfx_kernel_set_nvmeq_tail);

int sfx_kernel_nvmeq_reset(struct sfx_fd *fd, xt_u32 qid)
{
	struct sfx_dev *dev = fd->dev;
	struct sfx_queue *nvmeq = lock_nvmeq(dev, qid);
	int id_cnt = 0, cmd_cnt = 0;
	int rtn = 0;

	if (!nvmeq) {
		sfx_pr_info("%s/%d: NULL q[%d]\n", __FUNCTION__, __LINE__, qid);
		return ENODEV;
	}
	sfx_pr_info("%s: %s, reset sq[%u]\n", __FUNCTION__, dev->name, qid);
	id_cnt = sfx_clear_cmdids(nvmeq);
	sfx_pr_info("%s: %s, %d command_id was cleared!\n", __FUNCTION__, dev->name, id_cnt);
	if (!sfx_list_empty(&nvmeq->cq_list)) {
		sfx_pr_err("%s: %s, cq[%u] is not empty!\n", __FUNCTION__, dev->name, qid);
		rtn = EBUSY;
	}
	if (!sfx_list_empty(&nvmeq->sq_list)) {
		struct async_io_cmd_info *cmdinfo, *next;
		unsigned long flags;

		sfx_pr_info("%s: %s, sq[%u] is not empty, clean up!\n", __FUNCTION__, dev->name, qid);
		sfx_spin_lock_irqsave(&nvmeq->list_lock, flags);

		sfx_list_for_each_entry_safe(cmdinfo, next, &nvmeq->sq_list, node)
		{
			sfx_list_del(&cmdinfo->node);
			// free iod
			if (cmdinfo->iod) {
				if (sfx_is_token_addr(cmdinfo->addr) || cmdinfo->from_kernel) {
					sfx_unmap_user_pages_only(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				} else {
					sfx_unmap_user_pages(dev, cmdinfo->opcode & 1, cmdinfo->iod);
				}
				sfx_try_to_cleanup_pages_context(dev, cmdinfo->iod);
				sfx_free_iod(dev, cmdinfo->iod);
			}
			sfx_list_add_tail(&cmdinfo->node, &nvmeq->free_list);
			cmd_cnt++;
		}
		sfx_spin_unlock_irqrestore(&nvmeq->list_lock, flags);
	} else {
		sfx_pr_info("%s: %s, sq[%u] is empty! Nothing to do\n", __FUNCTION__, dev->name, qid);
		rtn = EINVAL;
	}
	sfx_pr_info("%s: %s, %d async_io_commands are freed\n", __FUNCTION__, dev->name, cmd_cnt);
	if (id_cnt != cmd_cnt) {
		sfx_pr_info("%s: %s, !!!!!!!!!!!!!!! id_cnt %d != cmd_cnt %d\n", __FUNCTION__, dev->name,
			    id_cnt, cmd_cnt);
		rtn = EINVAL;
	}
	sfx_memset(&nvmeq->q_stats, 0, sizeof(nvmeq->q_stats));
	sfx_pr_info("%s: %s, q[%d]=0x%p sq_head 0x%x tail 0x%x cq_head 0x%x cq_phase 0x%x success\n",
		    __FUNCTION__, dev->name, nvmeq->qid, nvmeq, nvmeq->sq_head, nvmeq->sq_tail,
		    nvmeq->cq_head, nvmeq->cq_phase);
	unlock_nvmeq(nvmeq);
	return rtn;
}
EXPORT_SYMBOL(sfx_kernel_nvmeq_reset);

#if ERROR_INJECTION_TEST
static int sfx_errinj_addlist_obj(struct sfx_dev *dev, struct sfx_errorinject_obj object)
{
	struct sfx_errorinject_obj *listobj;
	unsigned long flag;

	listobj = sfx_kzalloc(sizeof(struct sfx_errorinject_obj), GFP_KERNEL);
	if (!listobj) {
		return -ENOMEM;
	}
	listobj->pba = object.pba;
	listobj->blk = object.blk;
	listobj->page = object.page;
	listobj->attempt = object.attempt;
	sfx_spin_lock_irqsave(&dev->errobj_lock, flag);
	sfx_list_add_tail(&listobj->list, &dev->errobj_list);
	sfx_spin_unlock_irqrestore(&dev->errobj_lock, flag);
	return 0;
}
#endif

/* Check if an error is to be injected at this PBA and opcode, and
 * if so, return the injected error code. Return 0 if nothing is
 * to be injected
 */
#if ERROR_INJECTION_TEST
xt_u32 sfx_get_fakeresult(struct sfx_dev *dev, struct sfx_userio_cmd *io, int *ret)
{
	struct sfx_errinj_listelem *curr;
	struct sfx_errorinject_obj *retrieved, obj;
	struct sfx_errorinject_cmd cmd;
	int magic_key;
	xt_u64 pba;
	xt_u32 res = 0;
	xt_u8 opcode, read_buff_status, low_plane;
	long nowtime;
	unsigned long inject_flag, obj_flag;

	if (!dev->inject_active) {
		// bypass spinlock thing to improve performance
		return 0;
	}

	sfx_spin_lock_irqsave(&dev->inject_lock, inject_flag);
	sfx_list_for_each_entry(curr, &dev->inject_list, list)
	{
		/* Protect against removal; if it isn't allowed,
         * remove the copy */
		cmd = curr->cmd;
		pba = io->slba & 0xFFFFFFFFF;
		opcode = (xt_u8)(io->opcode & 0xFF);
		nowtime = jiffies / SFX_HZ;
		if (cmd.enable_random) {
			int got = 0;

			obj.pba = pba;
			obj.blk = ((pba >> dev->card_info.hw_off_blk) & dev->card_info.hw_mask_blk);
			if ((dev->card_info.nand_type == TSB_BICS) &&
			    (pba & (1 << dev->card_info.hw_off_blkh))) {
				obj.blk |= (1 << dev->card_info.hw_off_blkh);
			}
			obj.page = ((pba >> dev->card_info.hw_off_pg) & dev->card_info.hw_mask_pg);
			obj.attempt = 0;

			// if pba has block 0, don't inject error
			if (obj.blk == 0x0) {
				goto fake_exit;
			}
			if ((cmd.opcode == opcode) && (cmd.opcode == 0x02)) {
				// get read from buffer status from io->slba bit 44
				read_buff_status = ((xt_u64)(io->slba) & 0x100000000000) >> 43;

				// get low_plane status from io->extended_ctrl bits 16 ~ 19
				low_plane = ((xt_u32)(io->extended_ctrl) & 0xF0000) >> 15;

				// if pba has read_from_buff status bit,
				// or detect invalid data from low plane, don't inject error
				if ((read_buff_status == 1) || (low_plane == 0xF)) {
					goto fake_exit;
				}
				sfx_spin_lock_irqsave(&dev->errobj_lock, obj_flag);
				sfx_list_for_each_entry(retrieved, &dev->errobj_list, list)
				{
					got = 1;
					retrieved->attempt += 1;
					// if pba is already marked as error, just return error
					if ((retrieved->pba == pba)) {
						sfx_spin_unlock_irqrestore(&dev->errobj_lock, obj_flag);
						sfx_pr_info(
							"%s, EHANDLE:inject to same pba=%llx retrived_pba=%llx err=%xh, cmd.opcode=%d opcode=%d\n",
							dev->name, pba, retrieved->pba, cmd.fake_results,
							cmd.opcode, opcode);
						dev->last_time = jiffies / SFX_HZ;
						res = cmd.fake_results;
						goto fake_exit;
					}
					// if pba is different but has the same blk and page; then return 0 since don't want to inject there
					if ((retrieved->blk == obj.blk) && (retrieved->page == obj.page)) {
						sfx_spin_unlock_irqrestore(&dev->errobj_lock, obj_flag);
						goto fake_exit;
					}
					// release error pba when it reaches SFX_INJECT_ATTEMPT threshold
					if ((nowtime - dev->last_time) >
					    10) { //retrieved->attempt >= SFX_INJECT_ATTEMPT) {  // inject same pba error for 10 seconds
						sfx_pr_info(
							"%s, EHANDLE:remove same pba=%llx retrived_pba=%llx err=%xh, cmd.opcode=%d opcode=%d\n",
							dev->name, pba, retrieved->pba, cmd.fake_results,
							cmd.opcode, opcode);
						sfx_list_del(&retrieved->list);
						sfx_spin_unlock_irqrestore(&dev->errobj_lock, obj_flag);
						sfx_kfree(retrieved);
						goto fake_exit;
					}
				}
				sfx_spin_unlock_irqrestore(&dev->errobj_lock, obj_flag);
			}
			if (((nowtime - dev->last_time) > SFX_INJECT_COUNTER) && (cmd.opcode == opcode) &&
			    got == 0) {
				// add new error pba to list
				if ((*ret = sfx_errinj_addlist_obj(dev, obj))) {
					sfx_pr_err(
						"%s, Out of memory when locating memory for error injection\n",
						dev->name);
				}
				sfx_get_random_bytes(&magic_key, sizeof(magic_key));
				//curr->cmd.counter = (magic_key & 0xFFFFFFFF) % SFX_INJECT_COUNTER;
				sfx_pr_info("%s, EHANDLE:inject err=%xh, pba=%llx cmd.opcode=%d opcode=%d\n",
					    dev->name, cmd.fake_results, pba, cmd.opcode, opcode);
				dev->last_time =
					jiffies / SFX_HZ; // - (magic_key & 0xFFFFFFFF) % SFX_INJECT_COUNTER;
				res = cmd.fake_results;
				goto fake_exit;
			}
		} else {
			if (cmd.opcode == opcode && ((cmd.mask & cmd.pba) == (cmd.mask & pba)) &&
			    ((nowtime - dev->last_time) < SFX_INJECT_COUNTER)) {
				sfx_pr_info(
					"%s, EHANDLE:non random inject err=%d, pba=%llx cmd.opcode=%d opcode=%d\n",
					dev->name, cmd.fake_results, pba, cmd.opcode, opcode);
				dev->last_time = jiffies / SFX_HZ;
				res = cmd.fake_results;
				goto fake_exit;
			}
		}
	}
fake_exit:
	sfx_spin_unlock_irqrestore(&dev->inject_lock, inject_flag);

	return res;
}
#endif

/* Destroy the error injection list, such as on device removal */
void sfx_remove_injection(struct sfx_dev *dev)
{
	struct sfx_errinj_listelem *curr, *dummy;
	struct sfx_errorinject_obj *retrieved, *temp;

	sfx_list_for_each_entry_safe(curr, dummy, &dev->inject_list, list)
	{
		sfx_kfree(curr);
	}
	sfx_list_for_each_entry_safe(retrieved, temp, &dev->errobj_list, list)
	{
		sfx_kfree(retrieved);
	}
	dev->inject_active = 0;
}

int match_dev_list(struct sfx_dev *device)
{
	struct sfx_dev *dev = NULL;

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, &dev_list, node)
	{
		if (dev == device) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: device %s found on dev_list\n", __FUNCTION__, device->name);
#endif
			sfx_read_unlock(&dev_list_lock);
			return 1;
		}
	}
	sfx_read_unlock(&dev_list_lock);
	return 0;
}

int match_fail_list(struct sfx_dev *device)
{
	struct sfx_dev *dev = NULL;

	sfx_read_lock(&dev_list_lock);
	sfx_list_for_each_entry(dev, &fail_list, node)
	{
		if (dev == device) {
#ifdef SFXDRIVER_BASE_DEBUG
			sfx_pr_info("%s: device %s found on fail_list\n", __FUNCTION__, device->name);
#endif
			sfx_read_unlock(&dev_list_lock);
			return 1;
		}
	}
	sfx_read_unlock(&dev_list_lock);
	return 0;
}
