/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_driver_fops.c
 * ---------------------------------------------------------------------------
 */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/fs.h>
#include <linux/kdev_t.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/types.h>
#include <linux/version.h>
#include "sfx_driver.h"

/* These functions are yet to be implemented */
#define sfx_error_detected NULL
#define sfx_dump_registers NULL
#define sfx_link_reset NULL
#define sfx_slot_reset NULL
#define sfx_error_resume NULL

#define SFX_DEVICE_ID 0x0001

static SIMPLE_DEV_PM_OPS(sfx_dev_pm_ops, sfx_suspend, sfx_resume);

static struct pci_error_handlers sfx_err_handler = {
	.error_detected = sfx_error_detected,
	.mmio_enabled = sfx_dump_registers,
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 11, 0)
	.link_reset = sfx_link_reset,
#endif
	.slot_reset = sfx_slot_reset,
	.resume = sfx_error_resume,
};

static const struct pci_device_id sfx_id_table[] = { { PCI_VDEVICE(SFX, SFX_DEVICE_ID) },
						     {
							     0,
						     } };
MODULE_DEVICE_TABLE(pci, sfx_id_table);

struct pci_driver sfx_driver = {
    .name           = KBUILD_MODNAME,
    .id_table       = sfx_id_table,
    .probe          = sfx_probe,
    .remove         = sfx_remove,
    .shutdown       = sfx_shutdown,
    .driver         = {
        .pm         = &sfx_dev_pm_ops,
    },
    .err_handler    = &sfx_err_handler,
};

const struct file_operations sfx_dev_fops = { .owner = THIS_MODULE,
					      .open = sfx_dev_open,
					      .release = sfx_dev_release,
					      .unlocked_ioctl = sfx_dev_ioctl,
					      .compat_ioctl = sfx_dev_ioctl };

static int __init sfx_dev_init(void)
{
	sfx_pr_info("%s: SFX_SW_VERSION %s\n", __FUNCTION__, SFX_SW_VERSION);
	return _sfx_dev_init();
}
static void __exit sfx_dev_exit(void)
{
	_sfx_dev_exit();
}
module_init(sfx_dev_init);
module_exit(sfx_dev_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("ScaleFlux Device Driver Module");
/* SFX_SW_VERSION is dynamically defined in version_tmp.h */
MODULE_VERSION(SFX_SW_VERSION);
