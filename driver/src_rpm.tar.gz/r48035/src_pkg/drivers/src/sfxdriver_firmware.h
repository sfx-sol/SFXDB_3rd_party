// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfxdriver_firmware.h
//
// ---------------------------------------------------------------------------

#ifndef __SFXDRIVER_FIRMWARE_H__
#define __SFXDRIVER_FIRMWARE_H__

#include "sfx_api.h"
#include "sfx_types.h"
#include "sfxdriver_common.h"
#include "sfxdriver_spi_common.h"

int sfx_unlock_fw(struct sfx_dev *dev);
void sfx_lock_fw(struct sfx_dev *dev);
int sfx_download_fw(struct sfx_dev *dev, xt_u32 offset_in, xt_u32 xfer_len, void *ibuf);
int sfx_verify_fw(struct sfx_dev *dev, xt_u32 offset_in, xt_u32 xfer_len, void *wbufp);
int sfx_nvme_download_fw(struct sfx_dev *dev, void *addr, xt_u32 offset, int data_len);
void sfx_init_fw(struct sfx_dev *dev);
#endif
