// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_api.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_API_H__
#define __SFX_API_H__

#include "sfx.h"

typedef struct
{
    xt_u16  nid;
    xt_u8   op; // 0: For Read, 1: For Write
    xt_u8   session_id;
    xt_u8 key[32];
    xt_u8 iv[16];
    xt_u32  result;
} __attribute__((packed)) SFX_AES_CONFIG_CMD ;

typedef struct
{
    xt_u16  nid;
    xt_u16  channel_number;
    xt_u16  ce_number;
} SFX_NAND_RESET_CMD;

typedef struct sfx_userio_cmd
{
    xt_u8    opcode;
    xt_u8    flags;
    xt_u16   control;
    xt_u16   nblocks;
    xt_u8    qid;
    xt_u8    rsvd;
    xt_u64   metadata;
    void *   addr;
    xt_u64   slba;
    xt_u32   dsmgmt;
    xt_u32   reftag;
    xt_u16   apptag;
    xt_u16   appmask;
    xt_u32   extended_ctrl;
    xt_u64   prp1;
    xt_u16   fids[MAX_COMBINED_FCMD];
    xt_u16   nr_fcmd;
} sfx_userio_cmd_t;

typedef struct sfx_errorinject_cmd
{
    xt_u32  opcode;
    xt_u32  pba;
    xt_u32  mask;
    xt_u32  counter;
    xt_u32  fake_results;
    xt_u8   enable_random;
} sfx_errorinject_cmd_t;

typedef struct sfx_q_info
{
    xt_u8    qid;
    xt_u8    q_type;
    xt_u8    stream_id;
    unsigned long mask;
    xt_u8     flag;
} sfx_q_info_t;

/* DEV_NAME is used by services/sfx_api/src/sfx_user_print.c,
 * It should be designated by process id instead of NUM_DRIVE
 */
#define DEV_NAME                        "sfx"
#define MODEL_DEV_NAME                  "sfxModel"
#define ERR_MASK                        0xF // check completion message error field
#define sfx_is_token_addr(vaddr)        (((((unsigned long)(vaddr)) >> 48) & (0xFFFF)) == 0x4B1D)
#define sfx_token2idx(token)            ((((unsigned long)(token)) >> 32) & (0xFFFF))
#define REG_DCE_FEATURE                 (0x00100000+0x00000054)

xt_32 sfx_config_aes(union handle *hand, SFX_AES_CONFIG_CMD *cmd);
xt_32 sfx_nand_reset(union handle *hand, SFX_NAND_RESET_CMD *cmd);

int sfx_lock_mem(union handle *hand, xt_u32 *vaddr, xt_u32 length, xt_u32 **paddr);
int sfx_unlock_mem(union handle *hand, xt_u32 *paddr);
void sfx_length_one_token(union handle *hand, xt_u32 *vaddr, xt_u32 offset, xt_u32 length, xt_u8 *mask, void *prd_buff);
int sfx_split_token(union handle *hand, xt_u32 *vaddr, xt_u32 *list, xt_u32 length, xt_u8 *mask, void *prd_buff, xt_u32 **paddr);
int sfx_split_token_release(union handle *hand, void *token);
xt_32 sfx_card_init(union handle *hand);

/* Helper functions to print from model using the same code as the sfx_api */
void sfx_fill_and_print_helper(union handle *hand, SFX_NVME_IO_CMD *nvmeCmd);
void sfx_print_completion(union handle *hand, SFX_NVME_CMD_RESULT *res);

/* Model-only functions */
xt_32 sfx_get_put_header(union handle *hand, xt_u32 *paddr, xt_u32 offs, xt_u32 chunks[2], xt_u32 isPut);
xt_32 sfx_user_set_pagelist(union handle *hand, void **list, void **token, unsigned count, int type, int offset);
xt_32 sfx_get_free_slot_cnt(union handle *hand, xt_u32 *cntp);

xt_u32 sfx_get_pci_bar_csts(union handle *hand);
void sfx_reg_write(union handle *hand, xt_u32 addr, xt_u32 value);
xt_32 sfx_reg_read(union handle *hand, xt_u32 addr);
xt_32 sfx_load_bd_param(union handle *hand, bd_param_t *param);
int sfx_capacitor_issue(union handle *hand, xt_u32 op, xt_u32 para);
xt_u32 sfx_read_power_consumption(union handle *hand);
xt_32 sfx_get_card_feature(union handle *hand, xt_u16 feat_op, xt_u32 *feat_data, xt_u8 len);
xt_32 sfx_create_nvmeq(union handle *hand, xt_u8 qid, xt_u8 q_type, xt_u8 stream_id, unsigned long mask, xt_u8 flag);
xt_32 sfx_delete_nvmeq(union handle *hand, xt_u8 qid);

/* Need to call this before register reads, but the other functions
 * call it internally */
int sfx_base_init(void);

/* User mode only */
xt_32 sfx_inject_error(union handle *hand, struct sfx_errorinject_cmd *cmd);

/**get submission nvmeq head */
xt_u32 sfx_get_nvmeq_head(union handle *hand, xt_u32 qid);
/**get submission nvmeq tail */
xt_u32 sfx_get_nvmeq_tail(union handle *hand, xt_u32 qid);
/**get submission nvmeq depth */
xt_u32 sfx_get_nvmeq_depth(union handle *hand, xt_u32 qid);
/**set submission nvmeq tail, return error code if it failed */
int sfx_set_nvmeq_tail(union handle *hand, xt_u32 qid, xt_u32 tail);
int sfx_nvmeq_reset(union handle *hand, xt_u32 qid);

xt_u32 sfx_spi_init(union handle *hand);
xt_u32 sfx_spi_init_read_only(union handle *hand);
xt_u32 spi_write_data(union handle *hand, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data);
xt_u32 sfx_nor_flash_read(union handle *hand, xt_u32 start_addr, xt_u32 len, xt_u32 *datao);
xt_u32 spi_erase_data(union handle *hand, xt_u32 start_addr, xt_u32 len);
xt_u32 sfx_spi_read_nor_did(union handle *hand, xt_u32 len, xt_u32 *datao);
void sfx_spi_exit(union handle *hand);
void sfx_vu_get_feat_data(union handle *hand, xt_u32 *feat_data);

#endif // __SFX_API_H__
