// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_linux_funcs.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_LINUX_FUNCS_H__
#define __SFX_LINUX_FUNCS_H__

#include <linux/random.h>
#include "sfx_gendefs.h"

// The LINUX_VERSION_PARTSx macro may be used as input to printf(..., 4, 9, 75);
#define LINUX_VERSION_PART1                 ((LINUX_VERSION_CODE >> 16) & 0xff)
#define LINUX_VERSION_PART2                 ((LINUX_VERSION_CODE >> 8) & 0xff)
#define LINUX_VERSION_PART3                 ((LINUX_VERSION_CODE & 0xff))

#define MEASURE_FUNC_TIME                   0

#define SG_PREALLOC
#define SFX_DEFINE_SPINLOCK                 DEFINE_SPINLOCK
#define sfx_false                           false
#define sfx_true                            true
#define sfx__le64                           __le64
#define sfx__le32                           __le32
#define sfx__le16                           __le16
#define SFX_ERR_ENOMEM                      -ENOMEM
#define SFX_PAGE_SHIFT                      PAGE_SHIFT
#define sfx_kmem_cache_create(s,sz,n,f)     linux_kmem_cache_create((s), (sz), (n), (SLAB_RECLAIM_ACCOUNT | SLAB_MEM_SPREAD), (f))
#define sfx_kmem_cache_create_orig          linux_kmem_cache_create
#define sfx_kmem_cache_create_wrapper       linux_kmem_cache_create_wrapper
#define sfx_kmem_cache_alloc                linux_kmem_cache_alloc
#define sfx_kmem_cache_alloc_wrapper        linux_kmem_cache_alloc_wrapper
#define sfx_kmem_cache_free                 linux_kmem_cache_free
#define sfx_kmem_cache_free_wrapper         linux_kmem_cache_free_wrapper
#define sfx_kmem_cache_destroy              linux_kmem_cache_destroy
#define sfx_alloc_page                      linux_alloc_page
#define sfx_tv_sec                          tv_sec
#define sfx_tv_usec                         tv_usec
#define sfx_sys_tz_adj                      sys_tz.tz_minuteswest
#define SFX_GFP_KERNEL                      GFP_KERNEL
#define SFX_GFP_ATOMIC                      GFP_ATOMIC
#define sfx_cpu_online_mask                 linux_cpu_online_mask()
#define SFX_GFP_NOIO                        GFP_NOIO
#define sfx_cpu_possible_mask               linux_cpu_possible_mask()
#define sfx_for_each_cpu(cpu, mask)         for ((cpu) = -1; (cpu) = sfx_cpumask_next((cpu), (mask)), (cpu) < sfx_nr_cpu_ids();)
#define sfx_for_each_online_cpu(cpu)        sfx_for_each_cpu((cpu), sfx_cpu_online_mask)
#define sfx_for_each_possible_cpu(cpu)      sfx_for_each_cpu((cpu), sfx_cpu_possible_mask)
#define sfx_num_possible_cpus               num_possible_cpus
#define sfx_init_waitqueue_head             linux_init_waitqueue_head
#define sfx_init_waitqueue_entry            init_waitqueue_entry
#define sfx_bio_list_init                   bio_list_init
#define sfx_wake_up_interruptible           linux_wake_up_interruptible
#define sfx_wake_up                         linux_wake_up
#define sfx_num_online_nodes                linux_num_online_nodes
#define sfx_destroy_spinlock(x)
#define sfx_isalnum                         isalnum

// list - struct name, for-each and expressions that cannot be wrapped under linux
#define SFX_LIST_HEAD                       LIST_HEAD
#define sfx_list_head                       list_head
#define sfx_list_entry                      list_entry
#define sfx_list_first_entry                list_first_entry
#define sfx_list_for_each_entry             list_for_each_entry
#define sfx_list_for_each_entry_safe        list_for_each_entry_safe
#define sfx_list_next(node)                 (node).next
#define sfx_list_prev(node)                 (node).prev
#define sfx_list_next_next(node)            ((node).next)->next
// list - functions that should be wrapped
#define SFX_INIT_LIST_HEAD                  linux_INIT_LIST_HEAD
#define sfx_list_add_tail                   linux_list_add_tail
#define sfx_list_del                        linux_list_del
#define sfx_list_del_init                   linux_list_del_init
#define sfx_list_empty                      linux_list_empty
#define sfx_list_splice_tail                linux_list_splice_tail
#define sfx_bio_list_empty                  bio_list_empty
#define MEM_BOUND_CHK

#ifdef MEM_BOUND_CHK
#ifdef __KERNEL__
#define MEM_CHK(off, len, cap)              if ((off) + (len) > (cap)) BUG();
#else
#include <assert.h>
#define MEM_CHK(off, len, cap)              if ((off) + (len) > (cap)) assert(0);
#endif
#else
#define MEM_CHK(off, len, cap)
#endif

struct sfx_mul_drv_s;

#ifdef __KERNEL__

//=============================================================================
// Kernel Space
//=============================================================================

#include <linux/workqueue.h>
#include <asm/uaccess.h>

#ifndef __SFX_KERNEL__
#define __SFX_KERNEL__
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,32)
#ifndef __percpu
#define __percpu
#endif
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,32)
#define SFX_ALIGN_NODEMASK_TO_NUMA_ID       (1)
#else
#define SFX_ALIGN_NODEMASK_TO_NUMA_ID       (0)
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
#define __rcu
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,34)
#define for_each_set_bit(bit, addr, size)   for ((bit) = find_first_bit((addr), (size)); \
                                                 (bit) < (size); \
                                                 (bit) = find_next_bit((addr), (size), (bit) + 1))
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
#define sfx_bd_create_work_queue(wq_name)   sfxdriver_alloc_workqueue((wq_name));
#else
#define sfx_bd_create_work_queue(wq_name)   sfxdriver_create_workqueue((const char *)(wq_name))
#endif

#define sfx_ioq_type                        unsigned short __percpu

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,39)
int kstrtoull(const char *s, unsigned int base, unsigned long long *res);
int kstrtoul(const char *s, unsigned int base, unsigned long *res);
int kstrtou8(const char *s, unsigned int base, u8 *res);
int kstrtou32(const char *s, unsigned int base, u32 *res);
#endif

#ifdef DEBUG
#define CCS_INFO(fmt,...)                   SFX_PRINTF("%s: " fmt, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, ts.tv_nsec / 1000, __FUNCTION__, ##__VA_ARGS__);
#define CCS_ERROR(fmt,...)                  SFX_PRINTF("ERROR:%s: " fmt, __FUNCTION__, ##__VA_ARGS__)
#else
#define CCS_INFO(fmt,...)
#define CCS_ERROR(fmt,...)
#endif // DEBUG

#define SFX_PAGE_SIZE                       PAGE_SIZE
#define SFX_HZ                              linux_get_hz()
#define sfx_miscdev                         miscdev
#define sfx_readl                           readl
#define sfx_writel                          writel
#define sfx_readq                           readq
#define sfx_writeq                          writeq
#define sfx_time_after                      time_after
#define sfx_mdelay                          mdelay
#ifdef USE_SGELEM
typedef struct scatterlist                  sfx_scatterlist;
#else
#define sfx_scatterlist                     scatterlist
#endif
// CLOCK_MONOTONIC_RAW is defined in all of the kernels we support
#define SFX_CLOCK_DEFAULT                   CLOCK_MONOTONIC_RAW
#define sfx_allow_signal                    allow_signal
#define sfx_cpu_to_le16                     cpu_to_le16
#define sfx_cpu_to_le32                     cpu_to_le32
#define sfx_cpu_to_le64                     cpu_to_le64
#define sfx_le64_to_cpu                     le64_to_cpu
#define sfx_le32_to_cpup                    le32_to_cpup
#define sfx_le16_to_cpup                    le16_to_cpup
#define sfx_le16_to_cpu                     le16_to_cpu

#define sfx_alloc_percpu(t)                 linux_alloc_percpu(sizeof(t), __alignof__(t))
#define sfx_free_percpu                     linux_free_percpu
#define sfx_get_cpu_ptr_to_die_busy         linux_get_cpu_ptr_to_die_busy
#define sfx_per_cpu_ptr_to_die_busy         linux_per_cpu_ptr_to_die_busy
#define sfx_get_cpu_ptr_to_xt_32            linux_get_cpu_ptr_to_xt_32
#define sfx_per_cpu_ptr_to_xt_32            linux_per_cpu_ptr_to_xt_32
#define sfx_get_cpu_ptr_to_xt_64            linux_get_cpu_ptr_to_xt_64
#define sfx_per_cpu_ptr_to_xt_64            linux_per_cpu_ptr_to_xt_64

#define sfx_put_cpu_ptr(x)                  linux_put_cpu_ptr((void *)x)

//#define sfx_get_cpuid                     linux_smp_processor_id
#define sfx_cpu_to_node                     linux_cpu_to_node
#define sfx_iomem                           unsigned char __iomem *
#define sfx_rcu_head                        rcu_head
#define sfx__acquires                       __acquires
#define sfx__releases                       __releases
#define sfx_rcu_assign_pointer              rcu_assign_pointer
#define sfx_call_rcu                        call_rcu
#define sfx_msix_entry                      struct msix_entry
#define sfx_pci_enable_msix_range           pci_enable_msix_range
#define sfx_free_irq                        free_irq
#define sfx_irq_set_affinity_hint           irq_set_affinity_hint
#define sfx_local_irq_save                  linux_local_irq_save
#define sfx_local_irq_restore               linux_local_irq_restore
#define sfx_local_irq_disable_ex()
#define sfx_local_irq_enable_ex()
#define sfx_local_irq_disable               linux_local_irq_disable
#define sfx_local_irq_enable                linux_local_irq_enable
#define sfx_irqs_disabled()                 linux_irqs_disabled()
#define sfx_irq_count                       linux_irq_count
#define sfx_preempt_count                   linux_preempt_count
#define sfx_dma_pool                        dma_pool
#define sfx_sg_dma_len                      sg_dma_len
#define sfx_sg_dma_address                  sg_dma_address
#define sfx_ktime_get                       linux_ktime_get
#define sfx_ktime_to_ns                     ktime_to_ns
#define sfx_ktime_to_us                     ktime_to_us
#define sfx_atomic_set                      atomic_set
#define sfx_atomic_dec                      atomic_dec
#define sfx_atomic_sub                      atomic_sub
#define sfx_atomic_read                     atomic_read
#define sfx_atomic_inc                      atomic_inc
#define sfx_atomic_add                      atomic_add
#define sfx_atomic_inc_return               atomic_inc_return
#define sfx_atomic_sub_return               atomic_sub_return
#define sfx_atomic_add_unless               atomic_add_unless
#if (GCC_VERSION < 40700)
#define sfx_atomic_test_and_set(x, y)       __sync_lock_test_and_set((int *)(x), (y))
#else
#define sfx_atomic_test_and_set             __atomic_test_and_set
#endif
#define sfx_atomic64_set                    atomic64_set
#define sfx_atomic64_dec                    atomic64_dec
#define sfx_atomic64_inc                    atomic64_inc
#define sfx_atomic64_add                    atomic64_add
#define sfx_atomic64_inc_return             atomic64_inc_return
#define sfx_atomic64_sub                    atomic64_sub
#define sfx_atomic64_read                   atomic64_read
#define sfx_atomic_dec_and_test             atomic_dec_and_test
#define sfx_atomic_sub_and_test             atomic_sub_and_test
#define sfx_atomic_add_return               atomic_add_return
#define sfx_cmpxchg                         linux_cmpxchg_xt_u32
#define sfx_os_mb()                         mb()
#define sfx_module_param(name, type, val)   module_param(name, type, val)
#define sfx_cpumask_empty                   cpumask_empty
#define sfx_cpumask_or                      cpumask_or
#define sfx_cpumask_full                    linux_cpumask_full
#define sfx_cpumask_equal                   linux_cpumask_equal
#define sfx_cpumask_clear                   linux_cpumask_clear
#define sfx_cpumask_copy                    linux_cpumask_copy
#define sfx_cpumask_set_cpu                 linux_cpumask_set_cpu
#define sfx_cpumask_test_cpu                linux_cpumask_test_cpu
#define sfx_cpumask_setall                  linux_cpumask_setall
#define sfx_zalloc_cpumask_ptr              linux_zalloc_cpumask_struct_ptr
#define sfx_zalloc_cpumask_var              zalloc_cpumask_var
#define sfx_alloc_cpumask_var               linux_alloc_cpumask_var
#define sfx_free_cpumask_var                linux_free_cpumask_var
#define sfx_cpumask_first(srcp)             linux_cpumask_first(srcp)
#define sfx_cpumask_of_node                 linux_cpumask_of_node
#define sfx_cpumask_of                      sfxdriver_cpumask_of
#define sfx_cpumask_clear_cpu               linux_cpumask_clear_cpu
#define sfx_set_cpus_allowed_ptr            linux_set_cpus_allowed_ptr
#define sfx_cpumask_pr_args                 cpumask_pr_args
#define sfx_cpu_data                        cpu_data
#define sfx_get_ds()                        linux_get_ds()
#define sfx_get_fs()                        linux_get_fs()
#define sfx_set_fs(fs)                      linux_set_fs(fs)
#define sfx_vfs_write(f, d, s, o)           linux_vfs_write(f, d, s, o)
#define sfx_set_device_ro                   linux_set_device_ro
#define sfx_bdev_read_only                  linux_bdev_read_only

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,0,0)
// From linux 4.0.0 <linux/cpumask.h>
/**
 * cpumask_pr_args - printf args to output a cpumask
 * @maskp: cpumask to be printed
 *
 * Can be used to provide arguments for '%*pb[l]' when printing a cpumask.
 */
#define cpumask_pr_args(maskp)              nr_cpu_ids, cpumask_bits(maskp)
#endif // LINUX_VERSION_CODE < KERNEL_VERSION(4,0,0)

#define sfx__rcu                            __rcu
#define sfx__iomem                          __iomem
#define sfx__user                           __user
#define sfx_kref                            kref
#define sfx_dev_warn                        dev_warn
#define sfx_miscdevice                      miscdevice
#define sfx_pci_dev                         pci_dev
#define sfx_notifier_block                  notifier_block
#define sfx_kobject                         kobject
#define SFX_DEFINE_MUTEX(name)              DEFINE_MUTEX(name)
#define sfx_crash(condition)                BUG_ON(!(condition))
#define sfx_assert(condition)               if (!(condition)) { while(1) { sfx_schedule(); } }

#define sfx_work_struct                     work_struct
#define sfx_bd_prepare_work(work, fn)       do { (work)->func = (fn); } while (0)
#define sfx_bd_init_work(work, n, func)     linux_bd_init_work(work, n, func)
#define sfx_bd_queue_work_on_cpu(q, w, c)   linux_queue_work_on((c), ((struct workqueue_struct *)(q)), (w))
#define sfx_destroy_workqueue               sfxdriver_destroy_workqueue
#define sfx_queue_work                      queue_work
#define sfx_get_work_container(w,ctx,c,wrk) ((ctx) = container_of((w), struct ftl_ctx, wrk[(c)]))

#define SFX_PRINTF                          sfx_printk
#define sfx_pr_info(fmt, ...)               sfx_printk(KERN_INFO "SFXPK:" fmt, ##__VA_ARGS__)
#define sfx_pr_info_no_prefix(fmt, ...)     sfx_printk(KERN_INFO fmt, ##__VA_ARGS__)
#define sfx_pr_err(fmt, ...)                sfx_printk(KERN_ERR "SFXPK:" fmt, ##__VA_ARGS__)
#define sfx_pr_emr(fmt, ...)                sfx_printk(KERN_EMERG "SFXPK:" fmt, ##__VA_ARGS__)
#define SFX_INFO(fmt,...)                   sfx_pr_info("%s: " fmt, __FUNCTION__, ##__VA_ARGS__)
#define SFX_ERROR(fmt,...)                  sfx_pr_err("%s: " fmt, __FUNCTION__, ##__VA_ARGS__)
#define sfx_kmalloc                         linux_kmalloc
#define sfx_mutex_lock(mutex)               linux_mutex_lock(mutex)
#define sfx_mutex_unlock(mutex)             linux_mutex_unlock(mutex)
#define sfx_mutex_init(mutex)               linux_mutex_init(mutex)
#define linux_mutex_init(mutex)             __linux_mutex_init((mutex), #mutex)
#define MAX_MUTEX_STRUCT_SIZE               64
#define sfx_mutex_destroy(mutex)            linux_mutex_destroy(mutex)
#define sfx_get_current                     linux_get_current
#define sfx_get_single_job_pid()            linux_get_single_job_pid()

#define SFX_MSLEEP(ms)                      msleep(ms)
#define sfx_spin_lock_irqsave(lock, flags)  linux_spin_lock_irqsave((lock), &(flags))
#define sfx_spin_unlock_irqrestore          linux_spin_unlock_irqrestore
#define sfx_destroy_spinlock(x)
#define sfx_alloc_pages_handle(ord)         alloc_pages(SFX_GFP_NOIO, (ord))
#define sfx_alloc_pages_address             sfx_alloc_pages

#define sfx_get_random_bytes                get_random_bytes

#define init_per_cpu(percpu_value)          do { \
                                                xt_u32 cpu_iter; \
                                                (percpu_value) = sfx_alloc_percpu(xt_u32); \
                                                sfx_for_each_online_cpu(cpu_iter) { \
                                                    *sfx_per_cpu_ptr_to_xt_32((percpu_value), cpu_iter) = 0; \
                                                } \
                                            } while (0)

#define init_per_cpu64(percpu_value)        do { \
                                                xt_u32 cpu_iter; \
                                                (percpu_value) = sfx_alloc_percpu(xt_u64); \
                                                sfx_for_each_online_cpu(cpu_iter) { \
                                                    *sfx_per_cpu_ptr_to_xt_64((percpu_value), cpu_iter) = 0; \
                                                } \
                                            } while (0)

#define reset_per_cpu64(percpu_value)       do { \
                                                xt_u32 cpu_iter; \
                                                sfx_for_each_online_cpu(cpu_iter) { \
                                                    *sfx_per_cpu_ptr_to_xt_64((percpu_value), cpu_iter) = 0; \
                                                } \
                                            } while (0)

#define free_per_cpu(percpu_value)          sfx_free_percpu(percpu_value)

#define add_per_cpu(percpu_value, add_val)  do { \
                                                xt_u32 *temp = sfx_get_cpu_ptr_to_xt_32(percpu_value); \
                                                *temp += (add_val); \
                                                sfx_put_cpu_ptr(percpu_value); \
                                            } while (0)

#define add_per_cpu64(percpu_value, add_val) do { \
                                                xt_u64 *temp = sfx_get_cpu_ptr_to_xt_64(percpu_value); \
                                                *temp += (add_val); \
                                                sfx_put_cpu_ptr(percpu_value); \
                                            } while (0)

#define sum_per_cpu(percpu_value, sum)      do { \
                                                xt_u32 cpu_iter; \
                                                *(sum) = 0; \
                                                sfx_for_each_online_cpu(cpu_iter) { \
                                                    *(sum) += *sfx_per_cpu_ptr_to_xt_32((percpu_value), cpu_iter); \
                                                } \
                                            } while (0)

#define sum_per_cpu64(percpu_value, sum)    do { \
                                                xt_u32 cpu_iter; \
                                                *(sum) = 0; \
                                                sfx_for_each_online_cpu(cpu_iter) { \
                                                    *(sum) += *sfx_per_cpu_ptr_to_xt_64((percpu_value), cpu_iter); \
                                                } \
                                            } while (0)

#ifdef USE_KTIME_CTX
#define NUM_MAXQ                            16
#endif

typedef atomic64_t                          sfx_atomic64_t;
typedef atomic_t                            sfx_atomic_t;
typedef struct bio                          sfx_bio;
typedef struct gendisk                      sfx_gendisk;
typedef struct request                      sfx_bio_request;
typedef struct block_device                 sfx_block_device;
typedef struct request_queue                sfx_request_queue;
typedef struct kmem_cache                   sfx_kmem_cache;
typedef struct page                         sfx_page;
typedef struct device                       sfx_device;
typedef struct timeval                      sfx_timeval;
typedef size_t                              sfx_size_t;
typedef irqreturn_t                         sfx_irqreturn_t;
typedef dma_addr_t                          sfx_dma_addr_t;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0)
typedef wait_queue_t                        sfx_wait_queue_t;
#else
typedef wait_queue_entry_t                  sfx_wait_queue_t;
#endif
typedef bool                                sfx_bool;
typedef pid_t                               sfx_pid_t;
typedef s8                                  xt_8;
typedef s16                                 xt_16;
typedef s32                                 xt_32;
typedef s64                                 xt_64;
typedef u8                                  xt_u8;
typedef u16                                 xt_u16;
typedef u32                                 xt_u32;
typedef u64                                 xt_u64;
typedef rwlock_t                            sfx_rwlock_t;
typedef ktime_t                             sfx_ktime_t;
typedef int                                 sfx_stdsize_t; // May not need if valloc is changed
typedef unsigned long                       sfx_useconds_t;
typedef ssize_t                             sfx_ssize_t;
typedef gfp_t                               sfx_gfp_t;
typedef struct task_struct                  *sfx_thread_t;
typedef wait_queue_head_t                   sfx_wait_queue_head_t;
typedef struct bio_list                     sfx_bio_list;
typedef struct cpumask                      sfx_cpumask_t;
typedef struct cpumask                      *sfx_cpumask_ptr;
#ifdef CONFIG_CPUMASK_OFFSTACK
typedef struct cpumask                      *sfx_cpumask_var_t;
#else
typedef struct cpumask                      sfx_cpumask_var_t[1];
#endif
typedef struct workqueue_struct             *sfx_workqueue_struct;
// Sometimes we use work_func_t regardless OS version. Have to define them separately
typedef work_func_t                         sfx_work_func_t;
typedef struct workqueue_struct             sfx_worker_t;

typedef spinlock_t                          sfx_spinlock_t;
typedef struct cpuinfo_x86                  sfx_cpuinfo_x86;
// It is necessary to have consistent size of spinlock_t for Source RPM prebuilt libs.
CC_ASSERT(sizeof(sfx_spinlock_t) == 4);

// ---------------------------------------------------------------------------
// The following segment of macros and typedef are designed to ensure the
// flash_mgr_t struct is of constant size regardless whether it is built on
// host from linux 2.6.0 to 4.20.0 and beyond.  This is necessary so that the
// linux-vesion-independent libraries may be created for the Source RPM package.
// ---------------------------------------------------------------------------
typedef struct tasklet_struct               sfx_tasklet_struct;
#define sfx_tasklet_init                    linux_tasklet_init
#define sfx_tasklet_schedule                linux_tasklet_schedule
// In Linux 4.20.0, sizeof(struct tasklet_struct) = 40, which is the max size for now.
// It may need to be adjusted when porting to new linux releases/versions.
#define MAX_TASKLET_STRUCT_SIZE             (40)
// Please use this sfx_mdrv accessor macro to access the mq_tag_set member.
#define sfx_fmp_tasklet(fmp, member)        ((struct tasklet_struct *)(void *)(&(fmp)->member))
struct sfx_tasklet_struct
{
    xt_u64 ___pad___[MAX_TASKLET_STRUCT_SIZE / sizeof(xt_u64)];
};
// Check to ensure the reserved space is sufficient for all Linux versions.
CC_ASSERT(sizeof(struct tasklet_struct) <= sizeof(struct sfx_tasklet_struct));

#ifndef SECTOR_SHIFT
#define SECTOR_SHIFT                        9
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,16,0)
#define SFX_KV_REQ_ATOM_STARTED             0x01  /* REQ_ATOM_STARTED */
#define SFX_KV_REQ_ATOM_COMPLETE            0x02  /* REQ_ATOM_POLL_SLEPT */
#else
#include <linux/blk-mq.h>
#define atomic_flags                        gstate
#define SFX_MQ_RQ_COMPLETE                  2
#define SFX_MQ_RQ_STATE_BITS                2
#define SFX_MQ_RQ_STATE_MASK                ((1 << SFX_MQ_RQ_STATE_BITS) - 1)
#endif

int sfx_spin_lock_init(sfx_spinlock_t *lock);
int sfx_spin_lock(sfx_spinlock_t *lock);
int sfx_spin_lock_irq(sfx_spinlock_t *lock);
int sfx_spin_lock_irq(sfx_spinlock_t *lock);
int sfx_spin_lock_irq(sfx_spinlock_t *lock);
int sfx_spin_unlock_irq(sfx_spinlock_t *lock);
int sfx_spin_unlock(sfx_spinlock_t *lock);
int sfx_read_lock(sfx_rwlock_t *lock);
int sfx_read_trylock(sfx_rwlock_t *lock);
int sfx_read_unlock(sfx_rwlock_t *lock);
int sfx_write_lock(sfx_rwlock_t *lock);
int sfx_write_trylock(sfx_rwlock_t *lock);
int sfx_write_unlock(sfx_rwlock_t *lock);

void *sfx_alloc_pages(int order);
void *sfx_alloc_pages_node(int order, int nid);
sfx_thread_t sfx_thread_create(sfx_thread_t *thread, int (*thread_routine)(void *), void *data, const char *name);
sfx_thread_t sfx_thread_create_on_node(sfx_thread_t *thread, int (*thread_routine)(void *), void *data, int node, const char *name);
void sfx_set_user_nice(sfx_thread_t p, long nice);
int sfx_printk(char* format, ...);
int sfx_vprintk(const char *fmt, va_list args);

void sfx_kv_set_rq_start(sfx_bio_request *sfxrq);
sfx_bool sfx_kv_check_rq_done(sfx_bio_request *sfxrq);
void sfx_kv_set_rq_done(sfx_bio_request *sfxrq);
void sfx_queue_flag_set(unsigned int flag, sfx_request_queue *q);
void sfx_queue_flag_set_unlocked(unsigned int flag, sfx_request_queue *q);
void sfx_queue_flag_clear_unlocked(unsigned int flag, sfx_request_queue *q);
int sfx_blk_queue_stopped(sfx_request_queue *q);

void linux_tasklet_init(struct tasklet_struct *t, void (*func)(unsigned long), unsigned long data);
void linux_tasklet_schedule(struct tasklet_struct *t);

void sfx_reset(void *dev);
xt_u8 sfx_1byte_set_by_cas(xt_u8 * addr, xt_u8 old_val, xt_u8 new_val);

xt_u32 sfx_4byte_set_by_cas(xt_u32 *addr, xt_u32 old_val, xt_u32 new_val);

#else

//=============================================================================
// User Space (not __KERNEL__)
//=============================================================================

#define SFX_PAGE_SIZE                       4096
#define sfx_atomic_read(p)                  (*(p))
#define sfx_atomic_set(p, n)                (*(p) = (n))
#define sfx_atomic_add(n, p)                (*(p) = *(p) + (n))
#define sfx_atomic_sub(n, p)                (*(p) = *(p) - (n))
#define sfx_atomic_dec(p)                   ((*p)--)
#define sfx_atomic_inc(p)                   ((*p)++)
#define sfx_atomic64_read(p)                (*(p))
#define sfx_atomic64_dec(p)                 ((*p)--)
#define sfx_atomic64_inc(p)                 ((*p)++)
#define sfx_atomic64_set(p, n)              (*(p) = (n))
#define sfx_atomic64_add(n, p)              (*(p) = *(p) + (n))
#define sfx_atomic64_sub(n, p)              (*(p) = *(p) - (n))
#define sfx_atomic_inc_return(p)            ((*p)++)
#define sfx_atomic64_inc_return(p)          ((*p)++)
#define sfx_atomic_add_return(n, p)         (*(p) = *(p) + (n))
#define sfx_atomic_test_and_set(p, n)       (*(p) = (n))
#define sfx_cmpxchg(p, o, n)                (*(p) = (n))
#define sfx_thread_wait_event_timeout(...)

typedef unsigned int                        sfx_atomic_t;
typedef unsigned long                       sfx_atomic64_t;
#define sfx_bool                            _Bool

#define SECTOR_SHIFT                        9

#endif // __KERNEL__

// event - only referred in sfxdriver.ko
#define sfx_wake_up_process                 wake_up_process
#define sfx_set_current_state               set_current_state
#define sfx_schedule_timeout                schedule_timeout

//printf
#define sfx_snprintf                        snprintf
#define sfx_sprintf                         sprintf
#define sfx_vscnprintf                      vscnprintf

#define sfx_put_page                        put_page
#define sfx_virt_to_page(x, y)              linux_virt_to_page(x)
#define sfx_page_address                    linux_page_address
#define sfx_copy_from_user                  linux_copy_from_user
#define sfx_copy_to_user                    linux_copy_to_user
#define sfx_kcalloc                         linux_kcalloc
#define sfx_kzalloc                         linux_kzalloc
#define sfx_kzalloc_node0                   linux_kzalloc_node

//proc
#define sfx_seq_file                        seq_file
#define sfx_seq_printf                      seq_printf

#define sfx_kthread_should_stop(thread)     linux_kthread_should_stop()
#define sfx_kthread_stop(sfx_thread)        do { \
                                                if (SFX_THRD_STOPPED > sfx_atomic_read(&(sfx_thread).state) && \
                                                        SFX_THRD_NONE < sfx_atomic_read(&(sfx_thread).state)) { \
                                                    linux_kthread_stop((sfx_thread).thread); \
                                                } \
                                            } while(0)
#define sfx_kthread_wait_exited(thread_ptr) do { \
                                                sfx_kthread_stop(*(thread_ptr)); \
                                                sfx_atomic_set(&(thread_ptr)->state, SFX_THRD_PARKING); \
                                                sfx_complete(&(thread_ptr)->parked); \
                                                sfx_wait_for_completion(&(thread_ptr)->exited); \
                                            } while(0)

#define sfx_kthread_stop_log(sfx_thread)    linux_kthread_stop((sfx_thread).log_thread)
#define sfx_do_exit(p)                      sfxdriver_do_exit((long)(p))
#define sfx_completion                      completion
#define sfx_complete                        linux_complete
#define sfx_init_completion                 linux_init_completion
#define sfx_wait_for_completion             linux_wait_for_completion
#define sfx_wait_for_completion_timeout     linux_wait_for_completion_timeout
#define sfx_wait_for_completion_interruptible   linux_wait_for_completion_interruptible

#define sfx_blk_end_request_all             blk_end_request_all
#define sfx_blk_cleanup_queue               blk_cleanup_queue
#define sfx_blk_stop_queue                  blk_stop_queue
#define sfx_blk_start_queue                 blk_start_queue

#define sfx_rq_data_dir(req)                linux_get_rq_data_dir_from_request(req)
#define sfx_rq_for_each_bio(_bio, rq)       if (sfx_get_req_bio(rq)) \
                                                for ((_bio) = sfx_get_req_bio(rq); \
                                                    (_bio); \
                                                    (_bio) = sfx_get_bio_bi_next(_bio))
#define sfx_req2bv(r, p, n, s)              linux_req2bv((r), &(p), &(n), &(s))
#define sfx_bvec(bio)                       linux_get_bio_bio_vec(bio)
#define sfx_bvec_off(bio)                   linux_get_bio_biovec_bv_offset(bio)
#define sfx_bvec_len(bio)                   linux_get_bio_biovec_bv_len(bio)
#define sfx_bvcnt(bio)                      linux_get_bio_bi_vcnt(bio)
#define sfx_bflag(bio)                      linux_get_bio_bi_flags(bio)
#define sfx_bio_end_sector(bio)             linux_get_bio_end_sector(bio)
#define sfx_bsec(bio)                       linux_get_bio_bi_sector(bio)
#define sfx_bsz(bio)                        linux_get_bio_bi_size(bio)
#define sfx_set_bsec(bio, lba)              linux_set_bio_bi_sector(bio, lba)
#define sfx_inc_bsz(bio, inc)               linux_inc_bio_bi_size(bio, inc)
#define sfx_get_bvec(bio, idx)              linux_get_bio_iovec_idx_postinc((bio), (idx))
#define sfx_bio_offset(bio)                 linux_get_bio_offset(bio)
#define UNALIGN_BIO(bio)                    linux_is_unaligned_bio(bio)
#define OFF_SECT_MAPPING_UNIT(bio)          (sfx_bsec(bio) % (1 << MAPPING_UNIT_TO_SECTOR_SHIFT))
#define GET_END_SECTOR_INDEX(bio)           (sfx_bsec(bio) + (sfx_bsz(bio) >> SECTOR_SHIFT) - 1)
#define sfx_get_dsm_pages(req)              linux_get_dsm_pages(req)

//-----------------------------------------------------------------------------
// Please do NOT use the macro below in pre-built ftl and blk_ftl libraries.
//-----------------------------------------------------------------------------
#define sfx_bio_for_each_segment            bio_for_each_segment

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
//-----------------------------------------------------------------------------
// Please do NOT use the macros below in pre-built ftl and blk_ftl libraries.
//-----------------------------------------------------------------------------
#define sfx_bio_rw                          bio_rw
#define sfx_brw(bio)                        ((bio)->bi_rw)
#else
//-----------------------------------------------------------------------------
// Please do NOT use the macros below in pre-built ftl and blk_ftl libraries.
//-----------------------------------------------------------------------------
#define sfx_bio_rw                          bio_op
#define sfx_brw(bio)                        ((bio)->bi_opf)
#endif // LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,14,0)
//-----------------------------------------------------------------------------
// Please do NOT use the macros below in pre-built ftl and blk_ftl libraries.
//-----------------------------------------------------------------------------
#define sfx_bveclen(v)                      (v->bv_len)
#define sfx_bvecpage(v)                     (v->bv_page)
#define sfx_bvecoff(v)                      (v->bv_offset)
#define sfx_bvec_iter                       xt_u32
#define sfx_bio_vec                         struct bio_vec *
#define sfx_bvec_kmap_irq                   bvec_kmap_irq
#define sfx_next_bvec(bio, idx_bvec, bvec_iter, bvec)   sfx_get_bvec(bio, idx_bvec)
#else
//-----------------------------------------------------------------------------
// Please do NOT use the macros below in pre-built ftl and blk_ftl libraries.
//-----------------------------------------------------------------------------
#define sfx_bveclen(v)                      ((v).bv_len)
#define sfx_bvecpage(v)                     ((v).bv_page)
#define sfx_bvecoff(v)                      ((v).bv_offset)
#define sfx_bvec_iter                       struct bvec_iter
#define sfx_bio_vec                         struct bio_vec
#define sfx_bvec_kmap_irq(b, f)             bvec_kmap_irq(&(b), (f))
#define sfx_bio_advance_iter                bio_advance_iter
#define sfx_bio_iter_iovec                  bio_iter_iovec
#define sfx_next_bvec(bio, idx_bvec, bvec_iter, bvec)   \
    linux_get_advance_iter_iovec((bio), (idx_bvec), (bvec_iter), (bvec))
#endif // LINUX_VERSION_CODE < KERNEL_VERSION(3,14,0)

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
#define SFX_REQ_WRITE                       REQ_WRITE
#define SFX_REQ_DISCARD                     REQ_DISCARD
#else
#define SFX_REQ_WRITE                       REQ_OP_WRITE
#define SFX_REQ_DISCARD                     REQ_OP_DISCARD
#endif

#define SFX_WRITE                           WRITE
#define SFX_READ                            READ
#define SFX_READA                           READA
#define SFX_BLKFLSBUF                       BLKFLSBUF
#define SFX_BLKROSET                        BLKROSET
#define sfx_bug                             BUG
#define sfx_bug_on                          BUG_ON
#define sfx_smp_mb                          smp_mb
#define sfx_free_pages_handle               __free_pages
#define sfx_free_pages_address              sfx_free_pages
#define sfx_bd_add_init                     sfx_linux_bd_add
#define sfx_bd_free                         sfx_bd_free_linux
#define sfx_thread_pid(ptask)               linux_get_thread_pid(ptask)
#define sfx_bio_page_buf_init_once          bio_page_buf_init_once_linux
#define sfx_alloc_mappages_node(m,o,n)      sfx_alloc_pages_node((o), (n))
#define sfx_free_mappages(m,p,o)            sfx_free_pages((p), (o))
#define sfx_init_flat_map                   init_flat_map
#define release_flat_map                    release_flat_map_linux
#define memset_flat_map                     memset_flat_map_linux

//only for esx, not used in linux: try not to do this if possible
typedef char                                sfx_heap_id;

char *sfx_strcpy(char *destination, const char *source);
void memset_flat_map_linux(void *map_array, void *mdrv);
void *init_flat_map(void *sfx_mdrv);
void release_flat_map_linux(void *map_array, void *sfx_mdrv);

#ifdef __KERNEL__

// <lnux/list.h>
// all are static inline functions
void linux_INIT_LIST_HEAD(struct list_head *list);
void linux_list_add_tail(struct list_head *new, struct list_head *head);
void linux_list_del(struct list_head *entry);
void linux_list_del_init(struct list_head *entry);
int  linux_list_empty(const struct list_head *head);
void linux_list_splice_tail(struct list_head *list, struct list_head *head);

// asmlinkage void schedule(void);
// <linux/sched.h>
void sfx_schedule(void);

// bool kthread_should_stop(void);
// <linux/kthread.h>
bool sfx_capable(int cap);

// void dump_stack(void)
// <linux/printk.h>
void sfx_dump_stack(void);

// void kfree(const void *);
// <linux/slab.h>
void sfx_kfree(const void *p_mem);

// void *vmalloc(unsigned long size);
// void vfree(const void *addr);
// <linux/vmalloc.h>
void *sfx_vmalloc(unsigned long size);
void sfx_vfree(const void *addr);

// millisecond sleep
// void msleep(unsigned int msecs);
// <inux/delay.h>
void sfx_msleep(unsigned int msecs);

// void do_gettimeofday(struct timeval *tv);
// <linux/timekeeping.h>
void sfx_do_gettimeofday(struct timeval *tv);

// struct file *filp_open(const char *filename, int flags, int mode);
// int filp_close(struct file *filp, fl_owner_t id);
// loff_t vfs_llseek(struct file *file, loff_t offset, int origin);
// <linux/fs.h>
struct file *sfx_filp_open(const char *filename, int flags, int mode);
int sfx_filp_close(struct file *filp, fl_owner_t id);
loff_t sfx_vfs_llseek(struct file *filp, loff_t offset, int origin);

// <linux/timekeeping.h>
ktime_t linux_ktime_get(void);

// bool kthread_should_stop(void);
// <linux/kthread.h>
bool linux_kthread_should_stop(void);

// int kthread_stop(struct task_struct *k);
// <linux/kthread.h>
int linux_kthread_stop(struct task_struct *k);

// void complete(struct completion *);
// <linux/completion.h>
void linux_complete(struct completion *p_comp);

// static inline void init_completion(struct completion *x)
// <linux/completion.h>
void linux_init_completion(struct completion *p_comp);

// void wait_for_completion(struct completion *);
// <linux/completion.h>
void linux_wait_for_completion(struct completion *p_comp);

// unsigned long wait_for_completion_timeout(struct completion *x unsigned long timeout);
// <linux/completion.h>
unsigned long linux_wait_for_completion_timeout(struct completion *p_comp, unsigned long timeout);

// int wait_for_completion_interruptible(struct completion *x);
// <linux/completion.h>
int linux_wait_for_completion_interruptible(struct completion *p_comp);

//-----------------------------------------------------------------------------
// !!! Wrappers below CANNOT be turned off !!!
// Some of the reasons why this is...
// - function args changed; but function name stayed the same
// - static inline functions contains local/static vars and/or other kernel macros
//-----------------------------------------------------------------------------

typedef union
{
    struct mutex mutex;
    xt_u8 max_size_of_mutex[MAX_MUTEX_STRUCT_SIZE];
} sfx_mutex_t;
// With all the kernel debug config enabled, mutex struct could get to 64 bytes
// amongst 2.6.32, 3.10.0, and 4.4.0; so we have to make sure we give it room.
CC_ASSERT(sizeof(struct mutex) <= MAX_MUTEX_STRUCT_SIZE);

void __linux_mutex_init(sfx_mutex_t *mutex, const char *mutex_name);
void linux_mutex_destroy(sfx_mutex_t *mutex);
void linux_mutex_lock(sfx_mutex_t *mutex);
void linux_mutex_unlock(sfx_mutex_t *mutex);

// static inline long copy_from_user(void *to, const void __user * from, unsigned long n)
// static inline long copy_to_user(void __user *to, const void *from, unsigned long n)
// <asm-generic/uaccess.h>
unsigned long linux_copy_from_user(void *to, const void __user *from, unsigned long n);
unsigned long linux_copy_to_user(void __user *to, const void *from, unsigned long n);

/* Kernel only function; originally stubbed to allow for differences between
 * 3.10 and 3.16 kernel. The arg "cond" is a callback to calculate the condition,
 * taking "data" as an argument, unlike the original function which takes the
 * condition itself
 */
typedef int (*cond_func)(void *);
void sfx_thread_wait_event_interruptible(sfx_wait_queue_head_t *wq, cond_func cond, void *data);
void sfx_thread_wait_event_timeout(sfx_wait_queue_head_t *wq, cond_func cond, void *p_data, long timeout);

// #define wake_up_interruptible(x)         __wake_up(x, TASK_INTERRUPTIBLE, 1, NULL)
// <linux/wait.h>
void linux_wake_up_interruptible(wait_queue_head_t *q);
void linux_wake_up(wait_queue_head_t *q);
// 2.6.32
// <linux/workqueue.h>
// #define INIT_WORK(_work, _func)  do {
//      (_work)->data = (atomic_long_t) WORK_DATA_INIT();
//      INIT_LIST_HEAD(&(_work)->entry);
//      PREPARE_WORK((_work), (_func));
//  } while (0)
//
// 4.13.0
// <linux/workqueue.h>
// #define __INIT_WORK(_work, _func, _onstack)  do {
//      __init_work((_work), _onstack);
//      (_work)->data = (atomic_long_t) WORK_DATA_INIT();
//      INIT_LIST_HEAD(&(_work)->entry);
//      (_work)->func = (_func);
//  } while (0)
// #define INIT_WORK(_work, _func)  __INIT_WORK((_work), (_func), 0)
//
void linux_bd_init_work(struct sfx_work_struct *work, xt_u32 cpu_id, sfx_work_func_t func);

// <linux/workqueue.h>
// extern int queue_work_on(int cpu, struct workqueue_struct *wq, struct work_struct *work);
//
bool linux_queue_work_on(int cpu, struct workqueue_struct *wq, struct sfx_work_struct *work);

// #define spin_lock_irqsave(lock, flags)   do { raw_spin_lock_irqsave(spinlock_check(lock), flags); } while (0)
// <linux/spinlock.h>
void linux_spin_lock_irqsave(sfx_spinlock_t *lock, unsigned long *flag);

// This static inline function, so we need to wrap them in a function.
// static __always_inline void spin_unlock_irqrestore(spinlock_t *lock, unsigned long flags)
// {
//  raw_spin_unlock_irqrestore(&lock->rlock, flags);
// }
// <linux/spinlock.h>
void linux_spin_unlock_irqrestore(sfx_spinlock_t *lock, unsigned long flags);

// These are all macros, so we need to wrap them in a function.
// #define local_irq_save(flags)    do { raw_local_irq_save(flags); trace_hardirqs_off(); } while (0)
// <asm-generic/irqflags.h>
void linux_local_irq_save(unsigned long flags);
void linux_local_irq_restore(unsigned long flags);
void linux_local_irq_disable(void);
void linux_local_irq_enable(void);

// #ifdef CONFIG_TRACE_IRQFLAGS_SUPPORT
// #define irqs_disabled()  ({ unsigned long _flags; raw_local_save_flags(_flags); raw_irqs_disabled_flags(_flags); })
// #else
// #define irqs_disabled()   raw_irqs_disabled()
// #endif
// <linux/irqflags.h>
int linux_irqs_disabled(void);

// linux 2.6.32
// #define smp_processor_id() raw_smp_processor_id()
// #define raw_smp_processor_id() (percpu_read(cpu_number))
// <x86/include/asm/smp.h>
// linux 4.4.0
// #define smp_processor_id() raw_smp_processor_id()
// #define raw_smp_processor_id() (this_cpu_read(cpu_number))
// <x86/include/asm/smp.h>
int linux_smp_processor_id(void);

// 4.4.0
// static inline int cpu_to_node(int cpu) { return per_cpu(numa_node, cpu); }
// <linux/topology.h>
// 2.6.32
// static inline int cpu_to_node(int cpu) { return per_cpu(x86_cpu_to_node_map, cpu); }
// <asm/topology.h>
int linux_cpu_to_node(int cpu);

// #define num_online_nodes()   num_node_state(N_ONLINE)
// <linux/nodemask.h>
int linux_num_online_nodes(void);

// 4.9.75
// #define cpu_possible_mask ((const struct cpumask *)&__cpu_possible_mask)
// #define cpu_online_mask   ((const struct cpumask *)&__cpu_online_mask)
// 4.4.0
// const struct cpumask *const cpu_possible_mask = to_cpumask(cpu_possible_bits);
// const struct cpumask *const cpu_online_mask = to_cpumask(cpu_online_bits);
// static inline unsigned int cpumask_next(int n, const struct cpumask *srcp)
// <linux/cpumask.h>
const struct cpumask *linux_cpu_online_mask(void);
const struct cpumask *linux_cpu_possible_mask(void);
int sfx_nr_cpu_ids(void);
unsigned int sfx_cpumask_next(int n, const struct cpumask *srcp);

// indirect caller of __bitmap_weight() function
// #define num_online_cpus()    cpumask_weight(cpu_online_mask)
// <linux/cpumask.h>
#define sfx_num_online_cpus                 linux_num_online_cpus
unsigned int linux_num_online_cpus(void);

// cpumask_first - get the first cpu in a cpumask
// Returns >= nr_cpu_ids if no cpus set.
// <linux/cpumask.h>
unsigned int linux_cpumask_first(const struct cpumask *srcp);

// indirect ref to the exported node_to_cpumask_map[] array
// static inline const struct cpumask *cpumask_of_node(int node);
// <asm/topology.h>
const struct cpumask *linux_cpumask_of_node(int node);

// >= 4.2.0
// Just use cpumask_of(cpu)
// 2.6.32 to 4.1.0
// #define topology_thread_cpumask(cpu)     (per_cpu(cpu_sibling_map, cpu))
// <asm/topology.h>
const struct cpumask *sfx_topology_thread_cpumask(unsigned int cpu);

// static inline void cpumask_clear_cpu(int cpu, struct cpumask *dstp)
// static inline void cpumask_clear(struct cpumask *dstp)
// static inline void cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp)
// static inline int cpumask_test_cpu(int cpu, const struct cpumask *cpumask)
// <linux/cpumask.h>
void linux_cpumask_clear_cpu(int cpu, struct cpumask *dstp);
void linux_cpumask_clear(struct cpumask *dstp);
void linux_cpumask_copy(struct cpumask *dstp, const struct cpumask *srcp);
bool linux_cpumask_full(const struct cpumask *srcp);
bool linux_cpumask_equal(const struct cpumask *src1p,
                const struct cpumask *src2p);
void linux_cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp);
int linux_cpumask_test_cpu(int cpu, const struct cpumask *cpumask);
void linux_cpumask_setall(struct cpumask *dstp);

// static inline int set_cpus_allowed_ptr(struct task_struct *p, const struct cpumask *new_mask)
// <inux/sched.h>
int linux_set_cpus_allowed_ptr(struct task_struct *p, const struct cpumask *new_mask);

// 4.4.0
// #define alloc_percpu(type)   (typeof(type) __percpu *)__alloc_percpu(sizeof(type), __alignof__(type))
// void __percpu *__alloc_percpu(size_t size, size_t align);
// 2.6.32
// #define alloc_percpu(type)   (type *)__alloc_percpu(sizeof(type), __alignof__(type))
// static inline void *__alloc_percpu(size_t size, size_t align)
void __percpu *linux_alloc_percpu(size_t size, size_t align);
void linux_free_percpu(void __percpu *__pdata);

// #define get_cpu_ptr(var) ({ preempt_disable(); this_cpu_ptr(var); })
// #define put_cpu_ptr(var) do { (void)(var); preempt_enable(); } while (0)
// <linux/percpu-defs.h>
struct die_busy_s;
struct hot_rd_s;
struct die_busy_s *linux_get_cpu_ptr_to_die_busy(struct die_busy_s *pdb);
xt_32 *linux_get_cpu_ptr_to_xt_32(xt_32 *pdb);
xt_64 *linux_get_cpu_ptr_to_xt_64(xt_64 *pdb);
void linux_put_cpu_ptr(void *ptr);

// > 2.6.32
// #define per_cpu_ptr(ptr, cpu) ({ __verify_pcpu_ptr(ptr); SHIFT_PERCPU_PTR((ptr), per_cpu_offset((cpu))); })
// <linux/percpu-defs.h>
// <= 2.6.32
// #define per_cpu_ptr(ptr, cpu) ({ struct percpu_data *__p = __percpu_disguise(ptr); (__typeof__(ptr))__p->ptrs[(cpu)]; })
// <linux/percpu.h>
struct die_busy_s *linux_per_cpu_ptr_to_die_busy(struct die_busy_s *pdb, xt_32 cpu_iter);
xt_32 *linux_per_cpu_ptr_to_xt_32(xt_32 *px32, xt_32 cpu_iter);
xt_64 *linux_per_cpu_ptr_to_xt_64(xt_64 *px64, xt_32 cpu_iter);

// static inline void *page_address(const struct page *page);
// <linux/mm.h>
void *linux_page_address(const struct page *page);

// static __always_inline void *kmalloc(size_t size, gfp_t flags)
// <linux/slab.h>
void *linux_kmalloc(size_t size, gfp_t flags);

// static inline void *kcalloc(size_t n, size_t size, gfp_t flags)
// <linux/slab.h>
void *linux_kcalloc(size_t n, size_t size, gfp_t flags);

// static inline void *kzalloc(size_t size, gfp_t flags);
// <linux/slab.h>
void *linux_kzalloc(size_t size, gfp_t flags);

// static inline void *kzalloc_node(size_t size, gfp_t flags, int node) { return kmalloc_node(size, flags | __GFP_ZERO, node); }
// <linux/slab.h>
void *linux_kzalloc_node(size_t size, gfp_t flags, int node);

// #define alloc_page(gfp_mask) alloc_pages(gfp_mask, 0)
// <linux/gfp.h>
struct page *linux_alloc_page(gfp_t gfp_mask);

// bool alloc_cpumask_var(cpumask_var_t *mask, gfp_t flags);
// void free_cpumask_var(cpumask_var_t mask);
// <linux/cpumask.h>
bool linux_alloc_cpumask_var(cpumask_var_t *mask, gfp_t flags);
void linux_free_cpumask_var(cpumask_var_t mask);
bool linux_zalloc_cpumask_struct_ptr(struct cpumask **mask, gfp_t flags);

// <  3.3.0 #define init_waitqueue_head(q)  do { static struct lock_class_key __key; __init_waitqueue_head((q), &__key);} while (0)
// >= 3.3.0 #define init_waitqueue_head(q)  do { static struct lock_class_key __key; __init_waitqueue_head((q), #q, &__key);} while (0)
// <linux/wait.h>
void linux_init_waitqueue_head(wait_queue_head_t *q);

//  DECLARE_PER_CPU(struct task_struct *, current_task);
// < 3.5.0
//  static __always_inline struct task_struct *get_current(void)
//  {
//      return percpu_read_stable(current_task);
//  }
// >= 3.5.0
//  static __always_inline struct task_struct *get_current(void)
//  {
//      return this_cpu_read_stable(current_task);
//  }
//  #define current get_current()
// <asm/current.h>
struct task_struct *linux_get_current(void);
xt_u32 linux_get_single_job_pid(void);

//  < 3.9.0
//  <asm/page.h>
//  #define virt_to_page(kaddr) pfn_to_page(__pa(kaddr) >> PAGE_SHIFT)
//  #define __pa(x)         __phys_addr((unsigned long)(x))
//  <asm/page_64_types.h>
//  extern unsigned long __phys_addr(unsigned long);
//
//  >= 3.9.0
//  <asm/page.h>
//  #define virt_to_page(kaddr) pfn_to_page(__pa(kaddr) >> PAGE_SHIFT)
//  #define __pa(x)         __phys_addr((unsigned long)(x))
//  <asm/page_64.h>
//  #define __phys_addr(x)      __phys_addr_nodebug(x)
//  static inline unsigned long __phys_addr_nodebug(unsigned long x)
//  {
//      unsigned long y = x - __START_KERNEL_map;
//      /* use the carry flag to determine if x was < __START_KERNEL_map */
//      x = y + ((x > y) ? phys_base : (__START_KERNEL_map - PAGE_OFFSET));
//      return x;
//  }
struct page *linux_virt_to_page(void *pp);

// void do_gettimeofday(struct timeval *tv);
// <linux/time.h>
void linux_get_ts_and_tz(uint16_t *tz, uint64_t *ts);

// #undef HZ
// #define HZ               CONFIG_HZ   /* Internal kernel timer frequency */
// #define USER_HZ          100         /* some user interfaces are */
// #define CLOCKS_PER_SEC   (USER_HZ)   /* in "ticks" like times() */
// <asm-generic/param.h>
unsigned long linux_get_hz(void);

// #define cmpxchg_local(ptr, o, n) ({ ((__typeof__(*(ptr)))__cmpxchg_local_generic((ptr), (unsigned long)(o), (unsigned long)(n), sizeof(*(ptr)))); })
// #define cmpxchg(ptr, o, n)   cmpxchg_local((ptr), (o), (n))
// <asm-generic/cmpxchg-local.h>
xt_32 linux_cmpxchg_xt_u32(xt_32 *ptr, xt_32 old, xt_32 new);

// 4.13.0
// static __always_inline int preempt_count(void) { return raw_cpu_read_4(__preempt_count) & ~PREEMPT_NEED_RESCHED; }
// 4.4.0
// static __always_inline int preempt_count(void) { return raw_cpu_read_4(__preempt_count) & ~PREEMPT_NEED_RESCHED; }
// 3.10.0
// #define preempt_count()  (current_thread_info()->preempt_count)
// 2.6.32
// #define preempt_count()  (current_thread_info()->preempt_count)
xt_u32 linux_preempt_count(void);

// #define irq_count()  (preempt_count() & (HARDIRQ_MASK | SOFTIRQ_MASK | NMI_MASK))
// <linux/preempt.h>
xt_u32 linux_irq_count(void);

// <asm/uaccess.h> < 4.14.0
// #define get_ds() (KERNEL_DS)
// #define get_fs() (current->thread.addr_limit)
// #define set_fs(x)    (current->thread.addr_limit = (x))
//
// <asm/uaccess.h> >= 4.14.0
// #define get_ds() (KERNEL_DS)
// #define get_fs() (current->thread.addr_limit)
// static inline void set_fs(mm_segment_t fs)
// {
//      current->thread.addr_limit = fs;
//      /* On user-mode return, check fs is correct */
//      set_thread_flag(TIF_FSCHECK);
// }
mm_segment_t linux_get_ds(void);
mm_segment_t linux_get_fs(void);
void linux_set_fs(mm_segment_t fs);

// <linux/fs.h> >= 4.14.0
// ssize_t kernel_write(struct file *, const char *, size_t, loff_t *);
// <linux/fs.h> < 4.14.0
// ssize_t vfs_write(struct file *, const char __user *, size_t, loff_t *);
ssize_t linux_vfs_write(struct file *, const char *, size_t, loff_t *);

void linux_set_device_ro(sfx_gendisk *bd_disk, xt_8 read_only_mode);
int linux_bdev_read_only(sfx_gendisk *bd_disk);
// <linux/interrupt.h>
// static inline void tasklet_schedule(struct tasklet_struct *t);
// extern void tasklet_init(struct tasklet_struct *t, void (*func)(unsigned long), unsigned long data);
void linux_tasklet_schedule(struct tasklet_struct *t);
void linux_tasklet_init(struct tasklet_struct *t, void (*func)(unsigned long), unsigned long data);

struct kmem_cache *linux_kmem_cache_create(const char *name, size_t size, size_t align, unsigned long flags, void (*ctor)(void *));
struct kmem_cache *linux_kmem_cache_create_wrapper(const char *pname, xt_u32 size);

void *linux_kmem_cache_alloc(struct kmem_cache *cachep, gfp_t flags);
void *linux_kmem_cache_alloc_wrapper(void *sid);

void linux_kmem_cache_free(struct kmem_cache *cachep, void *objp);
void linux_kmem_cache_free_wrapper(void *ptr);

void linux_kmem_cache_destroy(void *ptr);

xt_u64 linux_get_bio_bi_sector(struct bio *bio);
void   linux_set_bio_bi_sector(struct bio *bio, xt_u64 lba);
xt_u32 linux_get_bio_bi_size(struct bio *bio);
void   linux_inc_bio_bi_size(struct bio *bio, xt_u32 inc);
xt_u32 linux_get_bio_bi_vcnt(struct bio *bio);
xt_u32 linux_get_bio_bi_flags(struct bio *bio);
struct bio_vec *linux_get_bio_bio_vec(struct bio *bio);
xt_u32 linux_get_bio_biovec_bv_offset(struct bio *bio);
struct bio_vec *linux_get_bio_iovec_idx_postinc(struct bio *bio, xt_u32 *idx);
struct bio_vec *linux_get_advance_iter_iovec(struct bio *bio, xt_u32 *idx_bvec, sfx_bvec_iter *bvec_iter, struct bio_vec *bvec);
xt_u32 linux_get_bio_biovec_bv_len(struct bio *bio);
xt_u32 linux_get_bio_offset(struct bio *bio);
xt_u32 linux_is_unaligned_bio(struct bio *bio);
pid_t linux_get_thread_pid(struct task_struct *ptask);
int linux_get_rq_data_dir_from_request(struct request *req);

void sfx_init_bvec_iter(sfx_bio *bio, sfx_bvec_iter *bvec_iter, struct bio_vec *bvec);

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

#ifdef RHEL_RELEASE_CODE
#if (RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,4))
void sfxdriver_blk_mq_freeze_queue_start(void *q);
#endif
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,18,0))
void sfxdriver_blk_mq_freeze_queue_start(void *q);
#endif
#endif

#ifdef RHEL_RELEASE_CODE
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,4)
void sfxdriver_blk_mq_unfreeze_queue(void *q);
#endif
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,18,0)
void sfxdriver_blk_mq_unfreeze_queue(void *q);
#endif
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,10,0)
#ifdef RHEL_RELEASE_CODE
#if RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,4)
void sfxdriver_blk_mq_cancel_requeue_work(void *q);
#endif
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,19,0)
void sfxdriver_blk_mq_cancel_requeue_work(void *q);
#endif
#endif
#endif

#endif // (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_SQ_BIO)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,14,0))
void sfxdriver_part_round_stats(void *q, int cpu, void *part);
#else
void sfxdriver_part_round_stats(int cpu, void *part);
#endif
#endif

void sfxdriver_schedule_hrtimeout(ktime_t *expires, const enum hrtimer_mode mode);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,39)
struct workqueue_struct *sfxdriver_alloc_workqueue(char *qname);
#else
struct workqueue_struct *sfxdriver_create_workqueue(const char *qname);
#endif

const struct cpumask *sfxdriver_cpumask_of(unsigned int cpu);
ktime_t          sfxdriver_ktime_get(void);
struct device   *sfxdriver_device_create(struct class *class, struct device *parent, dev_t devno, void *drv, char *devname);
void             sfxdriver_device_destroy(struct class *class, dev_t devno);
void __percpu   *sfxdriver_alloc_percpu(size_t size, size_t align);
void             sfxdriver_free_percpu(void __percpu *__pdata);
int              sfxdriver_kobject_init_and_add(struct kobject *kobj, struct kobj_type *ktype, struct kobject *kparent, const char *fmt, char *name);
int              sfxdriver_sysfs_create_link(struct kobject * kobj, struct kobject * target, const char * name);
void             sfxdriver_sysfs_remove_link(struct kobject * kobj,const char * name);
int              sfxdriver_set_cpus_allowed_ptr(struct task_struct *tp, const struct cpumask *mask);
void             sfxdriver_destroy_workqueue(sfx_worker_t *worker);
void             sfxdriver_do_exit(long ecode);
int              sfxdriver_sysfs_create_file(struct kobject *dev_kobj, const struct attribute *attr);
xt_32            sfxdriver_sysfs_create_group(struct kobject *dev_kobj, const struct attribute_group *group);
void             sfxdriver_sysfs_remove_group(struct kobject *dev_kobj, const struct attribute_group *group);
void             sfxdriver_sched_setscheduler(void *thread);
void             sfxdriver_class_destroy(struct class *class);
struct class    *sfxdriver_class_create(void *module, char *name);
int              sfxdriver_get_user_pages_fast(xt_u64 addr, xt_u32 count, xt_u8 is_write, struct page **pages);
bool             sfxdriver_queue_work_on(int cpu, void *wq, void *work);
void             sfxdriver_smp_call_function_single_async(xt_u32 cpuid, void *func);
void             sfxdriver_blk_mq_freeze_queue(void *q);
void             sfxdriver_blk_mq_unfreeze_queue(void *q);

//#define USE_KTIME_CTX
#ifdef USE_KTIME_CTX
#define NUM_MAXQ 16
#endif

#endif // __KERNEL__

#endif // __SFX_LINUX_FUNCS_H__
