// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : linklist.h
//
// ---------------------------------------------------------------------------

#ifndef __LINKLIST_H__
#define __LINKLIST_H__

#include "osal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* The queue (qid) of link list is empty */
static inline xt_u8 ll_is_empty(com_linklist_t *ll, xt_u16 qid)
{
    sfx_assert(qid <= ll->l_wqnum);
    return (ll->que[qid].head == INVALID_16BIT);
}

/* The free queue of link list is empty, i.e. usage of link list is full */
static inline xt_u8 ll_is_full(com_linklist_t *ll)
{
    return (ll->que[ll->l_wqnum].head == INVALID_16BIT);  // free queue is empty
}

/* The free queue of link list is almost empty, i.e. avail cnt is less than threshold */
static inline xt_u8 ll_is_almost_full(com_linklist_t *ll, xt_u16 threshold)
{
    return (ll->que[ll->l_wqnum].cnt < threshold);
}

/* The free queue of link list is full, i.e. entire link list is idle */
static inline xt_u8 ll_is_idle(com_linklist_t *ll)
{
    return (ll->que[ll->l_wqnum].cnt == ll->l_size);
}

static inline xt_u16 ll_outstanding_size(com_linklist_t *ll)
{
    return (ll->l_size - ll->que[ll->l_wqnum].cnt);
}

/* The free count of link list */
static inline xt_u16 ll_free_count(com_linklist_t *ll)
{
    return (ll->que[ll->l_wqnum].cnt);
}

/* Pop -- pop out one command from head of link list (qid) */
static inline xt_u16 ll_pop(com_linklist_t *ll, xt_u16 qid)
{
    xt_u16 lid;

    if (ll_is_empty(ll, qid)) {
        return INVALID_16BIT;
    }

    lid = ll->que[qid].head;
    ll->que[qid].head = ll->l_elems[lid].next;
    ll->l_elems[lid].next = INVALID_16BIT;
    ll->que[qid].cnt--;

    return lid;
}

/* Get -- get free emlement from head of free link list*/
static inline xt_u16 ll_get(com_linklist_t* ll)
{
    return ll_pop(ll, ll->l_wqnum);
}

/* Add element (lid) to the tail of queue (qid) */
static inline void ll_add(com_linklist_t *ll, xt_u16 lid, xt_u16 qid)
{
    sfx_assert(qid <= ll->l_wqnum);

    if (ll_is_empty(ll, qid)) {  // This is the first command
        ll->que[qid].head = lid;
    }
    else {
        xt_u16 tail = (ll->que[qid].tail);
        ll->l_elems[tail].next = lid;
    }
    ll->que[qid].tail = lid;    // this command will be the tail.
    ll->l_elems[lid].next = INVALID_16BIT;
    ll->que[qid].cnt++;
}

/* Release -- Release one command (lid) to tail of free link list */
static inline void ll_release(com_linklist_t *ll, xt_u16 lid)
{
    sfx_assert(ll_free_count(ll) < ll->l_size); // maybe called in callback function, cannot use assert.
    sfx_assert(lid != INVALID_16BIT);
    ll_add(ll, lid, ll->l_wqnum);
}

/* Queue Size -- return queue size of link list (qid) */
static inline xt_u16 ll_que_size(com_linklist_t *ll, xt_u16 qid)
{
    return ll->que[qid].cnt;
}

/* Peek -- peek next command of link list (qid, lid) */
static inline xt_u16 ll_peek(com_linklist_t *ll, xt_u16 qid, xt_u16 lid)
{
    if (lid == INVALID_16BIT) {
        return ll->que[qid].head;
    }
    return ll->l_elems[lid].next;
}

/* PeekTail -- peek tail command of link list (qid) */
static inline xt_u16 ll_peek_tail(com_linklist_t *ll, xt_u16 qid)
{
    if (ll_is_empty(ll, qid)) {
        return INVALID_16BIT;
    }
    return ll->que[qid].tail;
}

/* PeekN -- peek nth command of link list (qid) */
static inline xt_u16 ll_peekN(com_linklist_t *ll, xt_u16 qid, xt_u16 n)
{
    xt_u16 lid;

    lid = ll->que[qid].head;
    while (lid != INVALID_16BIT && n > 0) {
        lid = ll->l_elems[lid].next;
        n--;
    }
    return lid;
}

static inline void ll_init_single(com_linklist_t *ll, com_queue_t *que, queue_elem_t *elems, xt_u16 size, xt_u16 wqnum)
{
    xt_u16 i;

    ll->l_size = size;
    ll->l_elems = elems;
    ll->l_wqnum = wqnum - 1;
    ll->que = que;

    for (i = 0; i < wqnum; i++) {
        ll->que[i].head = INVALID_16BIT;
        ll->que[i].tail = INVALID_16BIT;
        ll->que[i].cnt = 0;
        ll->que[i].group_cnt = 0;
    }

    for (i = 0; i < size; i++) {
        // add all into free que
        ll_add(ll, i, ll->l_wqnum - 1);
    }
}

static inline void ll_init(com_linklist_t *ll, com_queue_t *que, queue_elem_t *elems, xt_u16 size, xt_u16 wqnum)
{
    xt_u16 i;

    ll->l_size = size;
    ll->l_elems = elems;
    ll->l_wqnum = wqnum - 1;
    ll->que = que;

    for (i = 0; i < wqnum; i++) {
        ll->que[i].head = INVALID_16BIT;
        ll->que[i].tail = INVALID_16BIT;
        ll->que[i].cnt = 0;
        ll->que[i].group_cnt = 0;
    }

    for (i = 0; i < size; i++) {
        // add all into free que
        ll_add(ll, i, ll->l_wqnum);
    }
}

#ifdef __cplusplus
}
#endif

#endif // __LINKLIST_H__
