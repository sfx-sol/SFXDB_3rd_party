// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_os_headers_linux.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_OS_HEADERS_LINUX_H__
#define __SFX_OS_HEADERS_LINUX_H__

#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)

#include <linux/types.h>
#include <linux/version.h>
#include <asm-generic/ioctl.h>

#ifdef __KERNEL__

#include <linux/init.h>
#include <linux/major.h>
#include <linux/bio.h>
#include <linux/highmem.h>
#include <linux/hdreg.h>
#include <linux/blkpg.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <asm/uaccess.h>
#include <asm/unistd.h>
#include <asm/atomic.h>
#include <linux/lockdep.h>
#include <linux/percpu.h>
#include <linux/pci.h>
#include <linux/blkdev.h>
#include <linux/fs.h>
#include <linux/kref.h>
#include <linux/kthread.h>
#include <linux/preempt.h>
#include <linux/string.h>
#include <linux/spinlock.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/mm.h>
#include <linux/bitops.h>
#include <linux/miscdevice.h>
#include <linux/interrupt.h>
#include <linux/genhd.h>
#include <scsi/sg.h>
#include <linux/sched.h>
#include <linux/signal.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,6,0))
#include <linux/kern_levels.h>
#endif

#include <asm/bug.h>
#include <linux/workqueue.h>
#include <linux/mutex.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0)
    #ifdef SFX_BLK_QUEUE_TYPE
    #if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
        #include <linux/blk-mq.h>
    #endif
    #endif
    #if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,9,0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(4,10,0))
        int blk_mq_map_queues(struct blk_mq_tag_set *set);
    #endif
#endif // LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0)

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/ctype.h>
#include <linux/kobject.h>  // for goldimg_kobj

#endif // __KERNEL__

#include "sfx_linux_funcs.h"

#endif // __SFX_OS_HEADERS_LINUX_H__
