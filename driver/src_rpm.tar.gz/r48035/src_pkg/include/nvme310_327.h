/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * Definitions for the NVM Express interface
 * Copyright (c) 2011-2014, Intel Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : nvme310_327.h
 * ---------------------------------------------------------------------------
 */

#ifndef __NVME310_327_H__
#define __NVME310_327_H__

#include "uapi_nvme.h"

struct nvme_bar
{
    xt_u64  cap;    /* Controller Capabilities */
    xt_u32  vs;     /* Version */
    xt_u32  intms;  /* Interrupt Mask Set */
    xt_u32  intmc;  /* Interrupt Mask Clear */
    xt_u32  cc;     /* Controller Configuration */
    xt_u32  rsvd1;  /* Reserved */
    xt_u32  csts;   /* Controller Status */
    xt_u32  rsvd2;  /* Reserved */
    xt_u32  aqa;    /* Admin Queue Attributes */
    xt_u64  asq;    /* Admin SQ Base Address */
    xt_u64  acq;    /* Admin CQ Base Address */
};

#define NVME_CAP_MQES(cap)      ((cap) & 0xffff)
#define NVME_CAP_TIMEOUT(cap)   (((cap) >> 24) & 0xff)
#define NVME_CAP_STRIDE(cap)    (((cap) >> 32) & 0xf)
#define NVME_CAP_MPSMIN(cap)    (((cap) >> 48) & 0xf)
#define NVME_CAP_MPSMAX(cap)    (((cap) >> 52) & 0xf)

enum
{
    NVME_CC_ENABLE          = 1 << 0,
    NVME_CC_CSS_NVM         = 0 << 4,
    NVME_CC_MPS_SHIFT       = 7,
    NVME_CC_ARB_RR          = 0 << 11,
    NVME_CC_ARB_WRRU        = 1 << 11,
    NVME_CC_ARB_VS          = 7 << 11,
    NVME_CC_SHN_NONE        = 0 << 14,
    NVME_CC_SHN_NORMAL      = 1 << 14,
    NVME_CC_SHN_ABRUPT      = 2 << 14,
    NVME_CC_SHN_MASK        = 3 << 14,
    NVME_CC_IOSQES          = 6 << 16,
    NVME_CC_IOCQES          = 4 << 20,
    NVME_CSTS_RDY           = 1 << 0,
    NVME_CSTS_CFS           = 1 << 1,
    NVME_CSTS_SHST_NORMAL   = 0 << 2,
    NVME_CSTS_SHST_OCCUR    = 1 << 2,
    NVME_CSTS_SHST_CMPLT    = 2 << 2,
    NVME_CSTS_SHST_MASK     = 3 << 2,
};

extern unsigned char nvme_io_timeout;
#define NVME_IO_TIMEOUT    (nvme_io_timeout * SFX_HZ)

#endif // __NVME310_327_H__
