// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_gendefs.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_GENDEFS_H__
#define __SFX_GENDEFS_H__

// Use the GCC_VERSION macro below for testing gcc version.
// For example, for gcc version > 4.7.0:  #if (GCC_VERSION > 40700)
#define GCC_VERSION                         (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)

#ifdef UNUSED
// Use existing predefined UNUSEd MACRO
#elif defined(__GNUC__)
#define UNUSED(x)                           x __attribute__((unused))
#else
#define UNUSED(x)                           x
#endif

#define CC_CONCAT(X, Y)                     X##Y
// expand args before concatenating
#define CC_CONCAT_EXPAND(X, Y)              CC_CONCAT(X, Y)
#define CC_EXPAND(X, Y)                     X Y

/*
 * Throw a compile-time assert (i.e. gcc error) based on compile-time constant expression.
 * Use this macro to find bugs during the build and avoid costly execution time asserts.
 */
#ifdef __COUNTER__
#define CC_ASSERT(const_expr)               ;enum { CC_CONCAT_EXPAND(_cc_assert_, __COUNTER__) = 1/(int)(!!(const_expr)) }
#else
// This can't be used twice on the same line so ensure if using in headers
// that the headers are not included twice (by wrapping in #ifndef...#endif)
// Note it doesn't cause an issue when used on same line of separate modules
// compiled with gcc -combine -fwhole-program.
#define CC_ASSERT(const_expr)               ;enum { CC_CONCAT_EXPAND(_cc_assert_, __LINE__) = 1/(int)(!!(const_expr)) }
#endif // __COUNTER__

/*
 * The following macro generates a compile time integer constant which is the
 * number of entries in the array/table macro argument.
 */
#define NUM_OF_ARRAY_ENTRIES(arrayvar)      ((sizeof(arrayvar) / sizeof(arrayvar[0])))

#define IS_POWER_OF_2(n)                    (0 == ((n) & ((n) - 1)))

#define INVALID_CODE                        (0xFFFFFFFF)
#define INVALID_LS_ADDR                     (0xFFFFFF)
#define INVALID_16BIT                       (0xFFFF)
#define INVALID_8BIT                        (0xFF)

#define CCS_KEY_LEN                         (256 / 8)
#define CCS_IV_LEN                          (128 / 8)

#endif // __SFX_GENDEFS_H__
