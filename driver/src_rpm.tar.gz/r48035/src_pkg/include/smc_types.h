/**
 * @author lhfcws
 * @create_date 2019-09-29
 */

#ifndef __SMARTSCAN_TYPES_H__
#define __SMARTSCAN_TYPES_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum smc_db_type {
  DEFAULT = 0,
  MYSQL8 = 1
} smc_db_type;

// Limit smc_data_type into a uint8_t
typedef enum smc_data_type {
  SMC_DTYPE_DECIMAL, // = 0 , deprecated, see SMC_DTYPE_NEWDECIMAL
  SMC_DTYPE_TINY = 1,
  SMC_DTYPE_SHORT = 2, // 2 byte int16
  SMC_DTYPE_LONG = 3, // 4 byte int32
  SMC_DTYPE_FLOAT = 4, // 4 byte
  SMC_DTYPE_DOUBLE = 5, // 8 byte
  SMC_DTYPE_NULL = 6,
  SMC_DTYPE_TIMESTAMP = 7, // deprecated, see SMC_DTYPE_TIMESTAMP2
  SMC_DTYPE_LONGLONG = 8, // 8 byte int64
  SMC_DTYPE_INT24 = 9, // 3 byte int24
  SMC_DTYPE_DATE = 10, // deprecated, see SMC_DTYPE_NEWDATE
  SMC_DTYPE_TIME = 11, // deprecated, see SMC_DTYPE_TIME2
  SMC_DTYPE_DATETIME = 12, // deprecated, see SMC_DTYPE_DATETIME2
  SMC_DTYPE_YEAR = 13,
  SMC_DTYPE_NEWDATE = 14,
  SMC_DTYPE_VARCHAR = 15,
  SMC_DTYPE_BIT = 16,
  SMC_DTYPE_TIMESTAMP2 = 17,
  SMC_DTYPE_DATETIME2 = 18,
  SMC_DTYPE_TIME2 = 19,

  SMC_DTYPE_JSON = 245,
  SMC_DTYPE_NEWDECIMAL = 246,
  SMC_DTYPE_ENUM = 247,
  SMC_DTYPE_SET = 248,
  SMC_DTYPE_TINY_BLOB = 249,
  SMC_DTYPE_MEDIUM_BLOB = 250,
  SMC_DTYPE_LONG_BLOB = 251,
  SMC_DTYPE_BLOB = 252,
  SMC_DTYPE_VAR_STRING = 253,
  SMC_DTYPE_STRING = 254,
  SMC_DTYPE_GEOMETRY = 255
} smc_data_type;


// >row_filter = sub_filter1 and sub_filter2 and sub_filter3 and ... and sub_filterN
/*
                 +-------------+-------------+       +-------------+
                 | sub_filter1 | sub_filter2 |  ...  | sub_filterN |
                 +-------------+-------------+       +-------------+
                              /               \
                            /                     \
                         /                              \
                      /                                       \
                    /                                               \
                   +-------------------------------------------------+
                   |   op   |          params of sub_filter          |
                   +-------------------------------------------------+
                   |<  1B  >|  param1    |  param2   |    param3     |

                     41[NUL]  colid(2B)
                     42[!NUL] colid(2B)
                     1[ =]   colid(2B)   colid(2B)
                     2[<=>]   colid(2B)   colid(2B)
                     3[!=]   colid(2B)   colid(2B)
                     4[ >]   colid(2B)   colid(2B)
                     5[>=]   colid(2B)   colid(2B)
                     6[ <]   colid(2B)   colid(2B)
                     7[<=]   colid(2B)   colid(2B)
                     21[ =]   colid(2B)   len(2B)     bytes...(len)
                     22[<=>]   colid(2B)   len(2B)     bytes...(len)
                    23[!=]   colid(2B)   len(2B)     bytes...(len)
                    24[ >]   colid(2B)   len(2B)     bytes...(len)
                    25[>=]   colid(2B)   len(2B)     bytes...(len)
                    26[ <]   colid(2B)   len(2B)     bytes...(len)
                    27[<=]   colid(2B)   len(2B)     bytes...(len)
                    43[LIKE] colid(2B)   len(2B)     bytes...(len)
                    44[!LIKE]colid(2B)   len(2B)     bytes...(len)
                    45[IN] colid(2B)   const_type(1B)  const_size(2B)  len1(2B)    bytes1...(len1)  len2(2B)  bytes2...(len2) ...
 =====================================================================================*/

typedef enum smc_filter_op {
  // 0 is reserved as zero value
  EQ_COL      = 1,
  FEQ_COL     = 2,
  NE_COL      = 3,
  GT_COL      = 4,
  GTE_COL     = 5,
  LT_COL      = 6,
  LTE_COL     = 7,
  // EQ_VAL will be used as a more general equal operator in smart_scan codes,
  // so as other XX_VAL as follows.
  EQ_VAL      = 21,
  FEQ_VAL     = 22,
  NE_VAL      = 23,
  GT_VAL      = 24,
  GTE_VAL     = 25,
  LT_VAL      = 26,
  LTE_VAL     = 27,

  ISNULL      = 41,
  IS_NOT_NULL = 42,
  LIKE        = 43,
  NOT_LIKE    = 44,
  IN          = 45,

  AND         = 250,
  OR          = 251
} smc_filter_op;

#ifdef __cplusplus
}
#endif

#endif // __SMARTSCAN_TYPES_H__
