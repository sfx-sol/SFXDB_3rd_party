// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : ccs_api.h
//
// ---------------------------------------------------------------------------

#ifndef __CCS_API_H__
#define __CCS_API_H__

#include "sfx_types.h"
#include "sfx.h"
#include "row2col_fpga.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CCS_API                             "0.05"

#define ERROR_BAD_CCS_MINOR_NUMBER          ((xt_u16)-1)
#define PARITY_RATIO                        (32)
#define PF_DATA_PBA_NUM_ALLOCATE            32

#if ENABLE_GC_TRIGGER_FASTER
#define L2P_MAX_CH_ALLOCATE                 1 // blocks num to store l2p table
#else
#define L2P_MAX_CH_ALLOCATE                 4 // blocks num to store l2p table
#endif
#define L2P_MAX_CH_MICRON                   1 // blocks num to store l2p table
#define NAND_PARAM_DEBUG                    0

#if ENABLE_GC_TRIGGER_FASTER
#define CFG_FREE_BLOCK_FIFO_SIZE            (4)
#else
#define CFG_FREE_BLOCK_FIFO_SIZE            (ccp->cf.free_block_fifo_size)
#endif
#define CFG_FREE_BLOCK_FIFO_SIZE_MICRON     (6)     //CFG_FREE_BLOCK_FIFO_SIZE
#define CFG_FREE_BLOCK_FIFO_SIZE_ALLOCATE   (20)    //CFG_FREE_BLOCK_FIFO_SIZE

#define CFG_TOTAL_RECYCLE_BUF_SIZE          (2 * CFG_RECYCLE_BUF_SIZE)

#define CFG_CMD_CHUNK_SIZE                  (ccp->cf.page_data_unit)
#define CFG_CMD_CHUNK_SIZE_ALLOCATE         24

#define CFG_FAST_RECYCLE_BLOCK_FIFO_SIZE_MICRON (CFG_FREE_BLOCK_FIFO_SIZE_MICRON)
#define CFG_FAST_RECYCLE_BLOCK_FIFO_SIZE_ALLOCATE (20)
#define CFG_FAST_RECYCLE_BLOCK_FIFO_SIZE        (ccp->cf.free_block_fifo_size)

#define CFG_RECOVERY_BLOCK_FIFO_SIZE_MICRON     (CFG_FREE_BLOCK_FIFO_SIZE_MICRON)
#define CFG_RECOVERY_BLOCK_FIFO_SIZE_ALLOCATE   (20)
#define CFG_RECOVERY_BLOCK_FIFO_SIZE        (ccp->cf.free_block_fifo_size)

#define CFG_CMD_CHUNCK_SIZE                 (ccp->cf.page_data_unit)
#define CP_PAGE_READ_CNT                    (ccp->cf.page_data_unit / CFG_CP_CMD_SIZE)

#define SDP_AES_ENABLE_BIT                  (0)
#define SDP_COMRESSION_ENABLE_BIT           (1)
#define SDP_STRIP_ENABLE_BIT                (2)

#define SDP_AES_ENABLE                      (1 << SDP_AES_ENABLE_BIT)
#define SDP_COMPRESSION_ENABLE              (1 << SDP_COMRESSION_ENABLE_BIT)
#define SDP_STRIPE_ENABLE                   (1 << SDP_STRIP_ENABLE_BIT)

#define SDP_SRC_ENCRYPTED                   (SDP_AES_ENABLE)
#define SDP_SRC_COMPRESSED                  (SDP_COMPRESSION_ENABLE)
#define SDP_SRC_STRIPED                     (SDP_STRIPE_ENABLE)

#define SDP_DST_ENCRYPTED                   (SDP_SRC_ENCRYPTED  << 16)
#define SDP_DST_COMPRESSED                  (SDP_SRC_COMPRESSED << 16)
#define SDP_DST_STRIPED                     (SDP_SRC_STRIPED    << 16)

#define MAX_EC_CCSCMDS                      (8)
#define FEAT_LEN                            (64)
#define FUSE_CONT                           (1)
#define FUSE_CMPL                           (0)
#define CCS_DEVID_INVALID                   (0xFF)

#define CCS_CLIENT_MAX_CID_SLOTS            256
#define CCS_IOCTL_REQUEST                   _IOWR('S', 0x10, ccs_message_t)
#define CCS_IOCTL_MASK_OUT_LEN_BITS(req)    ((req) & 0xFFFF)
#define CCS_CLIENT_SID_MAX_SLOTS            (64)

/*
 * Layout for 4 bytes in bit is as follow:
 * bit 31:    a = atomic group flag
 * bit 10-30: o = offset, for first 4KB in mem_id, o = stream
 * bit 0-9:   m = mem_id
 * aooo oooo oooo oooo oooo oomm mmmm mmmm
 */
#define MIM_MAX_MEM_ID_NUMBER               (4096)
#define PF_RSVD_MID                         (ccp->cf.nand_type == TSB_BICS ? (0xfff):(0x3ff))
#define MID_MASK                            ((ccp->cf.nand_type ==TSB_BICS)?(0x00000fff):(0x000003ff))//(0x00000fff)
#define ATOMIC_WR_FLAG_BIT                  (31)	//only use 1 bit, last bit
#define MID_OFF                             ((ccp->cf.nand_type ==TSB_BICS)?(12):(10))//(12)
#define TRIMT_OFF                           (MID_OFF)
#define TRIMT_MASK                          (0x3)
#define TRIML_OFF                           (MID_OFF + 2)
#define TRIML_MASK                          (0x7FFF)
#define OFFSET_MASK                         ((ccp->cf.nand_type == TSB_BICS) ? (0x7FFFF) : (0x1FFFFF))
#define COMPOSE_MID(mid, off)               ((xt_u32)(((mid) & (MID_MASK)) | (((off) & OFFSET_MASK) << (MID_OFF))))
#define COMPOSE_ATOMIC_GROUP(val, flag)     ((xt_u32)((val) & ~((1) << (ATOMIC_WR_FLAG_BIT))) | \
                                             (xt_u32)((((flag) & 1) << (ATOMIC_WR_FLAG_BIT))))
#define PARSE_GET_OFF(fmid)                 (((fmid) >> (MID_OFF)) & OFFSET_MASK)
#define PARSE_GET_MID(val)                  ((val) & (MID_MASK))
#define PARSE_GET_ATOMIC_GROUP(fmid)        (((fmid) >> (ATOMIC_WR_FLAG_BIT)) & 1)

#define MID_MASK_BLKFTL                     ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? (0x00000fff) : (0x000003ff))
#define MID_OFF_BLKFTL                      ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? (12) : (10))
#define TRIMT_OFF_BLKFTL                    (MID_OFF_BLKFTL)
#define TRIMT_MASK_BLKFTL                   (0x3)
#define TRIML_OFF_BLKFTL                    (MID_OFF_BLKFTL + 2)
#define TRIML_MASK_BLKFTL                   (0x7FFF)
#define PARSE_GET_MID_BLKFTL(val)           ((val) & (MID_MASK_BLKFTL))
#define APPEND_PAGE_BUFFER_SIZE             (36)

enum
{
    VU_ERR_READ_INJECT = 1,
    VU_ERR_WRITE_INJECT = 2,
    VU_ERR_ERASE_INJECT = 4,
    VU_ERR_MISMATCH_INJECT = 8,
    VU_ERR_MODE_TIMEOUT = 1,
    VU_ERR_MODE_ECC     = 2,
    VU_ERR_MODE_NAND_STATUS = 3,
    VU_ERR_INJECT_MAX_CNT = 400,
};

#ifdef __KERNEL__

#ifdef SFX_LINUX
typedef struct die_busy_s
{
    xt_32 array[256];
} sfx_die_busy_t;
#endif

struct id_item
{
    int id;
    struct sfx_list_head q;
    unsigned int minor;
    unsigned int major;
};

long ccs_conn_ioctl(struct id_item *item, unsigned int cmd, unsigned long arg);
void print_error(char *fmt, ...);
int sfd_dbgmsg_1(int err_code, xt_u8 devId, xt_u8 module, xt_u8 severity, char *fmt, ...);
int sfx_dbgmsg(xt_u8 devId, xt_u8 module, xt_u8 severity, char *fmt, ...);

#define sfd_dbgmsg(devId,mod,sev,fmt, ...)  sfd_dbgmsg_1(0, (devId), (mod), (sev), fmt, ##__VA_ARGS__)
/* helper macros for fewer parameters, the caller must have ccp->ccs_devID */
#define PR_ERR(err_code, fmt, ...)          sfd_dbgmsg_1((err_code), ccp->ccs_devID, CCS_SYS, PL_ERR, fmt, ##__VA_ARGS__)
#define PR_WRN(err_code, fmt, ...)          sfd_dbgmsg_1((err_code), ccp->ccs_devID, CCS_SYS, PL_WRN, fmt, ##__VA_ARGS__)
#define PR_NOT(fmt, ...)                    sfd_dbgmsg(ccp->ccs_devID, CCS_SYS, PL_NOT, fmt, ##__VA_ARGS__)
#define PR_INF(fmt, ...)                    sfd_dbgmsg(ccp->ccs_devID, CCS_SYS, PL_INF, fmt, ##__VA_ARGS__)

#endif // __KERNEL__

typedef enum
{
    FORM_Cheetah = 0,
    FORM_PUMA,
    FORM_LYNX
} SFX_CARD_FORM_FACTOR;

typedef struct
{
    // define an EC session.
    xt_u32  sdp_flag;
    xt_u16  keyid;
    xt_u8   ec_mode;        // EC algorithm ID: 0 for (6, 3) algorithm; TBD for others.
    xt_u8   status;         // 0: Idle; 1: Active.
    xt_u8   block_size;     // data block size, default is 0:64KB.
    xt_u16  cmds_cid[MAX_EC_CCSCMDS]; // CMD IDS of the latest EC operation.
    xt_u16  cmds_status[MAX_EC_CCSCMDS];
    xt_u8   cmd_pos;        // relative position of the latest CCS CMD submitted.
    xt_u32* host_addr;      // host addresses of the latest EC operation.
    xt_u64  time_stamp;
} EC_SESSION_STRUCT;

typedef struct
{
    xt_u8 streamID;
} ccs_attr;

typedef struct
{
    xt_u32 length;
    xt_u32 available_length;
    xt_u32 mid_sp;
    xt_u8 streamID;
    xt_u8 seal_flag;
} ccs_stats;

typedef struct
{
    xt_u64 start_pba;
    xt_u32 cur_wr_pba;
} __attribute__((packed)) nand_blk_info;

/*
 * ccs_message_t aligned with message_t
 */
typedef struct
{
    int msg_id; /* Internal use */
    int token;  /* Internal use */
    xt_u32 sequence;
    xt_u32 client_cid;
    xt_u32 length;
    xt_u32 result;
    xt_u32 async;
    xt_u8 ccs_dev_id;   /* use this one. ccs_devID in each param will be retired */

    union {
        struct {

            /* Output */
            xt_u32 mid;  //[Reference] Copy required
            xt_u8  stream;
        } ccs_param_AllocateMem;

        struct {
            /* Input */
            xt_u32 memSize;

            /* Output */
            xt_u32 mid;  //[Reference] Copy required
        } ccs_param_AllocateMemSize;

        struct {
            /* Input */

            /* Output */
            xt_u32 size;  //[Reference] Copy required
        } ccs_param_GetCardSize;

        struct {
            /* Input */
            xt_u32 memID;
            xt_u32* host_addr; //[Virtual Addreess] Coversion required
            xt_u32 append_size;
            xt_u32 sdp;
            xt_u16 keyid;

            /* Output */
            xt_u16 cid; //[Reference] Copy required
        } ccs_param_AppendMem_Async;

        struct {
            /* Input */
            xt_u32 memID;
            xt_u32* host_addr; //[Virtual Addreess] Coversion required
            xt_u32 append_size;
            xt_u32 sdp;
            xt_u16 keyid;

            /* Output */
            xt_u32 wlen; //[Reference] Copy required
        } ccs_param_AppendMem;

        struct {
            /* Input */
            /* Output */
            xt_u8 result[CCS_CLIENT_MAX_CID_SLOTS];

            /*
             * Note:
             * ret_len field is needed for compression, but the field size increase needs to be within
             * the message size limitation, which is defined as CCS_MSG_MAX_DATA_SIZE in ipc_api.h
             */
            xt_u32 ret_len[CCS_CLIENT_MAX_CID_SLOTS];

            /*
             * TODO: currently using fixed-size message, to save space, skip ret_len here
             * revisit this issue in phase 1.1.
             * xt_u32 ret_len[256]; //[Reference] Copy required
             */
        } ccs_param_GetCCSCmdStatus;

        struct {
            /* Input */
            xt_u32 memID;

        } ccs_param_SealMem;

        struct {
            /* Input */
            xt_u32 memId;
        } ccs_param_DeallocateMem;

        struct {
            /* Input */
            xt_u32 memId;
            xt_u32 length;
        } ccs_param_TrimMem;

        struct {
            /* Input */
            xt_u32 memID;
            xt_u32* host_addr;          //[Virtual Addreess] Coversion required
            xt_u32 offset;
            xt_u32 length;
            xt_u32 sdp;
            xt_u16 keyid;

            /* Output */
            xt_u32 rlen;                //[Reference] Copy required
        } ccs_param_ReadMem;

        struct {
            /* Input */
            xt_u32 memID;
            xt_u32* host_addr;          //[Virtual Addreess] Coversion required
            xt_u32 offset;
            xt_u32 length;
            xt_u32 sdp;
            xt_u16 keyid;

            //Ouptut
            xt_u16 cid;                 // [Reference] Copy required
        } ccs_param_ReadMem_Async;

         struct {
            /* Input */
            CCS_KEY_STRUCT key;

            /* Output */
            xt_u16  keyid;              // [Reference] Copy required
        } ccs_param_SetKey;

        struct {
            /* Input */
            xt_u16 keyid;
        } ccs_param_ReleaseKey;

        struct {
            /* Input */
            EC_SESSION_STRUCT ec_session;

            /* Output */
            xt_u8  ecSessionID;         // [Reference] Copy required
        } ccs_param_InitECSession;

        struct {
            /* Input */
            xt_u8   ecSessionID;
            xt_u32* host_addr;

            /* Output */
            xt_u16 cid;                 // [Reference] Copy required
        } ccs_param_AppendECData_Async;

        struct {
            /* Input */
            xt_u8 ecSessionID;

            /* Output */
            xt_u16 cid;                 // [Reference] Copy required
        } ccs_param_ComputeECParity_Async;

        struct {
            /* Input */
            xt_u8  ecSessionID;
            xt_u32 *host_addr_list[4];

            /* Output */
            xt_u16 cid;                 // [Reference] Copy required
        } ccs_param_GetECParity_Async;

        struct {
            /* Input */
            xt_u8 ecSessionID;
        } ccs_param_endECSession;

        struct {
            // Input
            xt_u32 option;
        } ccs_param_DeleteAllData;

        struct {
            // Input
            xt_u32 memID;
            ccs_attr attr;
        } ccs_param_SetAttributes;

        struct {
            // Input
            xt_u32 memID;

            // Output
            ccs_stats stat;             // [Reference] Copy required
        } ccs_param_GetStats;

        struct {
            // Input
            xt_u32 memID;
            xt_u32 parity_sizes[4];
        } ccs_param_CCS_GetParitySizes;

        struct {
            xt_u16 FEAT_OP;
            xt_u32 feat_data[FEAT_LEN / sizeof(xt_u32)]; //[Virtual Addreess] Coversion required
            xt_u32 length;
        } ccs_param_get_feature;

        /*
         * Compression related function parameters. Also including ccs_param_GetCCSCmdStatus
         */
        struct {
            /* Input */
            xt_u32 para_0;
            xt_u32 para_1;
            xt_u32 para_2;
            xt_u32 para_3;
            xt_u16 sid;                 // [Reference] Copy required
        } ccs_param_Comp_Open_Session;
        struct {
            /* Input */
            xt_u8   ccs_dev_cnt ;        // [Reference] Copy required
        }ccs_param_Get_Dev_Count;

        struct {
            /* Input */
            xt_u32 rt_status;            // [Reference] Copy required
        } ccs_param_Comp_Get_Runtime_Status;

        struct {
            /* Input */
            xt_u16 sid;
        } ccs_param_Comp_Close_Session;

        struct {
            /* Input */
            xt_u32* host_addr;
            xt_u32  length;
            xt_u16  fuse_flag;
            xt_u16  sid;
        } ccs_param_Comp_Append_Data_Async;

        struct {
            /* Input */
            xt_u32* host_addr;
            xt_u32  length;
            xt_u16  fuse_flag;
            xt_u16  sid;
        } ccs_param_Comp_Get_Data_Async;

        struct {
            /* Input */
            xt_u32* append_addr;
            xt_u32  append_length;
            xt_u32* get_addr;
            xt_u32  get_length;
            xt_u16  fuse_flag;
            xt_u16  sid;
        } ccs_param_Comp_Append_Get_Data_Async;

        struct {
            /* Input */
            xt_u32 para_0;
            xt_u32 para_1;
            xt_u32 para_2;
            xt_u32 para_3;
            xt_u16 sid;                 // [Reference] Copy required
        }ccs_param_EC_Open_Session;
        struct {
            xt_u32 rt_status;            // [Reference] Copy required
        }ccs_param_EC_Get_Runtime_Status;
        struct {
            xt_u16 sid;
        } ccs_param_EC_Close_Session;
        struct {
            xt_u32* host_addr;
            xt_u32  length;
            xt_u16  fuse_flag;
            xt_u16  sid;
        } ccs_param_EC_Append_Data_Async;
        struct {
            /* Input */
            xt_u32* host_addr;
            xt_u32  length;
            xt_u16  fuse_flag;
            xt_u16  sid;
        } ccs_param_EC_Get_Data_Async;
/*
        struct {
            xt_u64 page_read_cnt;
            xt_u64 byte_retn_cnt;
            xt_u64 total_col_read_cnt;
            xt_u64 total_blk_cnt;
            xt_u64 total_fpga_cmd_cnt;
            xt_u32 util;
        } ccs_param_R2C_Moniter;

        struct {
            xt_u8  session_idle;
        } ccs_param_R2C_Session_Idle;

        struct {
            xt_u8  schema_id;
            xt_u8  rw;
            xt_u16 ncol;
            xt_u32 col_type[R2C_MAX_COL];
            xt_u32 nblk;
            xt_u8  cond_num;
            xt_u8  filter_buf[(5+R2C_MAX_COND_CONST_LEN)*R2C_MAX_COND_NUM+1];
        } ccs_param_R2C_Col_Schema;

        struct {
            xt_u8  schema_id;
            xt_u16 ncol;
            xt_u8  col_vld[R2C_MAX_COL/8];
            xt_u64 meta;
            xt_u32 seq_id_used;
            xt_u8  is_sync;
            xt_u64 user_buf;
            xt_u64 sid;
            xt_u16 session_lock;
        } ccs_param_R2C_Open_Session;

        struct {
            xt_u8 schema_id;
            xt_u16 ncol;
            xt_u16 sid;
            xt_u8  fuse_nvme_read;
            xt_u32 *nvme_read_buf;
            xt_u32 nvme_read_length;
            xt_u8  fuse_dce;
            xt_u32 dce_offset;
            xt_u32 dce_length;
            xt_u8  fuse_n2b;
            xt_u32 page_start;
            xt_u32 page_end;
            xt_u32 offset_start;
            xt_u32 offset_end;
            xt_u64 aux;
            xt_u8  is_sync;
            r2cStatus send_cmd_status;
        } ccs_param_R2C_Send_Cmd;

        // Use separate struct for R2C
        struct {
            xt_u64 sid;
            xt_u64 ret_len;
            xt_u64 user_buf;
        } ccs_param_R2C_Query_Status;

        struct {
            xt_u16 sid;
            xt_u64 retn_length;
        } ccs_param_R2C_Close_Session;
*/
        struct {
            xt_u32 start;
            xt_u32 end;
            xt_u16 pba_list_size;
            xt_u64 pba_list[R2C_MAX_PBA_LIST_SIZE];
            xt_u8  pba_mask[R2C_MAX_PBA_LIST_SIZE];
            xt_u8  pba_page[R2C_MAX_PBA_LIST_SIZE];
        } ccs_param_R2C_LBA_PBA;

        struct {
            xt_u16  sid;
        } ccs_param_Get_Session_Status;

        struct {
            /* Input */
        } ccs_param_Abort_Cmd;

        struct {
            /* Input */
        } ccs_param_IdentifyDevice;

        struct {
            /* Input */
        } ccs_param_SnapshotTables;

        struct {
            char    dev_name[256];
        } ccs_param_Open_ccs_dev;

        struct {
            xt_u32  *vaddr;
            xt_u32  count;
            xt_u32  *paddr;
        } ccs_param_LockMem;

        struct {
            xt_u32  *paddr;
        } ccs_param_UnlockMem;

    } params;

} ccs_message_t;

typedef struct
{
    xt_u32 errtype;
    xt_u64 hw_pba;
    xt_u64 mask;
    xt_u32 enable;
    xt_u32 is_hw;
    xt_u32 errmode;
} __attribute__((packed)) vu_error_inject_element_t;

typedef struct
{
    xt_u32 read_err_inject_cnt;
    xt_u32 write_err_inject_cnt;
    xt_u32 erase_err_inject_cnt;
    xt_u32 mismatch_err_inject_cnt;
    vu_error_inject_element_t errlist[VU_ERR_INJECT_MAX_CNT];
} vu_error_inject_t;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  sid;
    xt_u64 key_meta;
    xt_u64 val_meta;
    xt_u32 ncol;
    xt_u8  col_vld[64/8];
    xt_u8  val_col_map[64/8];
    xt_u32 col_type[64];
    xt_u32 nblk;
    xt_u8  cond_num;
    xt_u8  filter_buf[MAX_ROW_FILTER_LEN];
} rc_message_64_col_schema;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  sid;
    xt_u64 key_meta;
    xt_u64 val_meta;
    xt_u32 ncol;
    xt_u8  col_vld[128/8];
    xt_u8  val_col_map[128/8];
    xt_u32 col_type[128];
    xt_u32 nblk;
    xt_u8  cond_num;
    xt_u8  filter_buf[MAX_ROW_FILTER_LEN];
} rc_message_128_col_schema;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  sid;
    xt_u64 key_meta;
    xt_u64 val_meta;
    xt_u32 ncol;
    xt_u8  col_vld[256/8];
    xt_u8  val_col_map[256/8];
    xt_u32 col_type[256];
    xt_u32 nblk;
    xt_u8  cond_num;
    xt_u8  filter_buf[MAX_ROW_FILTER_LEN];
} rc_message_256_col_schema;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  sid;
    xt_u64 key_meta;
    xt_u64 val_meta;
    xt_u32 ncol;
    xt_u8  col_vld[512/8];
    xt_u8  val_col_map[512/8];
    xt_u32 col_type[512];
    xt_u32 nblk;
    xt_u8  cond_num;
    xt_u8  filter_buf[MAX_ROW_FILTER_LEN];
} rc_message_512_col_schema;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  sid;
    xt_u64 key_meta;
    xt_u64 val_meta;
    xt_u32 ncol;
    xt_u8  col_vld[1024/8];
    xt_u8  val_col_map[1024/8];
    xt_u32 col_type[1024];
    xt_u32 nblk;
    xt_u8  cond_num;
    xt_u8  filter_buf[MAX_ROW_FILTER_LEN];
} rc_message_1024_col_schema;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    xt_u8  is_sync;
    xt_u32 seq_id_used;
    xt_u64 user_buf;
    xt_u64 sid;
    r2cStatus    result;
} rc_message_open_session;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u8  schema_id;
    xt_u16 ncol;
    xt_u16 sid;
    xt_u8  fuse_nvme_read;
    xt_u32 *nvme_read_buf;
    xt_u32 nvme_read_length;
    xt_u8  fuse_dce;
    xt_u32 dce_offset;
    xt_u32 dce_length;
    xt_u8  fuse_n2b;
    xt_u32 page_start;
    xt_u32 page_end;
    xt_u32 offset_start;
    xt_u32 offset_end;
    xt_u64 aux;
    xt_u8  is_sync;
    r2cStatus send_cmd_status;
} rc_message_send_cmd;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    r2cStatus    result;
    xt_u64 sid;
    xt_u64 ret_len;
    xt_u64 user_buf;
} rc_message_query_status;

typedef struct
{
    int    msg_id;
    xt_u8  ccs_dev_id;
    xt_u16 sid_cnt;
    r2cStatus    result_array[R2C_MAX_SESSION];
    xt_u64 sid_time_array[R2C_MAX_SESSION];
    xt_u64 ret_len_array[R2C_MAX_SESSION];
    xt_u64 user_buf_array[R2C_MAX_SESSION];
} rc_message_query_status_group;

#define RC_OPEN_SESSION_REQUEST       _IOWR('Z', 0xF0, rc_message_open_session)
#define RC_64_COL_SCHEMA_REQUEST      _IOWR('Z', 0xF1, rc_message_64_col_schema)
#define RC_128_COL_SCHEMA_REQUEST     _IOWR('Z', 0xF2, rc_message_128_col_schema)
#define RC_256_COL_SCHEMA_REQUEST     _IOWR('Z', 0xF3, rc_message_256_col_schema)
#define RC_512_COL_SCHEMA_REQUEST     _IOWR('Z', 0xF4, rc_message_512_col_schema)
#define RC_1024_COL_SCHEMA_REQUEST    _IOWR('Z', 0xF5, rc_message_1024_col_schema)
#define RC_SEND_CMD_REQUEST           _IOWR('Z', 0xF6, rc_message_send_cmd)
#define RC_QUERY_STATUS_REQUEST       _IOWR('Z', 0xF7, rc_message_query_status)
#define RC_QUERY_STATUS_GROUP_REQUEST _IOWR('Z', 0xF8, rc_message_query_status_group)

typedef struct
{
    xt_u8  dev_id;
    xt_u8  schema_id;
    xt_u16 sid;
    xt_u8  fuse;
    xt_u32 page_start;
    xt_u32 page_end;
    xt_u32 offset_start;
    xt_u32 offset_end;
    xt_u8  background;
    xt_u64 aux;
} r2c_cb_context;

typedef struct
{
    xt_u8  dev_id;
    xt_u32 start;
    xt_u32 end;
    xt_u16 pba_list_size;
    xt_u64 *pba_list;
    xt_u8  *pba_mask;
    xt_u8  *pba_page;
} r2c_lba_pba_cb_context;
// exported for validation purpose
// otherwise, those code would be at log.h or scheduler.h
typedef enum
{
    DISABLE,
    SETUP_PRESCALE_L,
    SETUP_PRESCALE_H,
    SETUP_ENABLE,
    WR_ADDR_H,
    WR_ADDR_H_T,
    WR_ADDR_H_ACK_WAIT,
    WR_ADDR_H_ACKED,
    WR_ADDR_L,
    WR_ADDR_L_T,
    WR_ADDR_L_ACK_WAIT,
    WR_ADDR_L_ACKED,
    RD_ADDR_H,
    RD_ADDR_H_T,
    RD_ADDR_H_ACK_WAIT,
    RD_ADDR_H_ACKED,
    RD_DATA_H_T,
    RD_DATA_H_ACK_WAIT,
    RD_DATA_H_ACKED,
    RD_DATA_H,
    RD_DATA_L_T,
    RD_DATA_L_ACK_WAIT,
    RD_DATA_L_ACKED,
    RD_DATA_L,
    STOP,
    CLEAR_T,
    CLEAR_ACK_WAIT,
    CLEAR_ACKED,
} old_i2c_state_e;

typedef struct
{
    xt_u32 sensor_value;
    old_i2c_state_e i2c_state;
    xt_u32 ack_retry_cnt;
    xt_u32 read_first;
    xt_u32 read_second;
} old_i2c_sensor_status_t;

typedef enum
{
    I2C_IDLE,
    I2C_SOFT_RST,
    I2C_INIT,
    I2C_INIT_ACK_WAIT,
    I2C_INIT_ACKED,
    I2C_RD_CMD,
    I2C_RD_DATA_ACK_WAIT,
    I2C_RD_DATA_ACKED,
} i2c_state_e;

typedef struct
{
    xt_u32 sensor_value;
    i2c_state_e i2c_state;
    xt_u32 ack_retry_cnt;
    xt_u32 i2c_rst_cnt;
    xt_u32 read_data;
} i2c_sensor_status_t;

typedef enum
{
    EH_NO_ERROR,
    EH_ERR_READ,
    EH_ERR_WRITE,
    EH_ERR_ERASE,
} eh_err_type_e;


typedef struct
{
    void *sfx_mdrv;
    xt_u32 mid;
    xt_u32 offset;
    xt_u32 remain_len;
    xt_u32 parity_gp_sz;
    eh_err_type_e err_type;
} error_info_ctx;

typedef struct
{
    void *sfx_mdrv;
    xt_u32 mid;
    xt_u32 start_offset;
    xt_u32 end_offset;
    xt_u32 horzntl_offset[NO_OF_HORZONTAL_4KB ];
    xt_u32 super_page_size;  // delta
    blk_ftl_read_distb_element_t *elem;
} read_distb_info;

typedef enum
{
    TEMP_SENSOR_7000 = 0x7000,
    TEMP_SENSOR_7100 = 0x7100,
    TEMP_SENSOR_4800 = 0x4800,
    TEMP_SENSOR_4900 = 0x4900,  //puma board
    TEMP_SENSOR_4a00 = 0x4a00,  //lynx board
    TEMP_SENSOR_4b00 = 0x4b00,
    CURRENT_SENSOR_0928 = 0x0928,
} hw_sensor_e;

typedef struct
{
    xt_u32  mid;           // ccs mid
    xt_u32  avail_space;   // available space left in the block bounded to the mid
    xt_u32  appendpoint;   // valid data length of mid
    xt_u8   status;        // 0: open mid, 1: sealed mid, 3: free mid
    xt_u8   stream;        // stream type, only valid for open mid 1 = hot, >= 6 is cold
    xt_u32  avail_space_last;
} ccs_mid;

typedef struct read_callback_entry_s
{
    //sfxError    status;
    sfx_atomic_t status;
    xt_u32      lba;
    xt_u32      id;
    xt_u32      mem_id;
    xt_u32      mim_mem_id;
    xt_u32      offset;
    xt_u32      index;
    xt_u32      curren_lba;
    xt_u32      lba_count;
    void        *prd_buff;
    void        *pbuff;
    void        *gc;
    xt_u16      cid;
    xt_u16      size;
    xt_u32      map_log_index;  //index for the current map-log within memid
    xt_u32      need_compact;
    //sfx_mul_drv *sfx_mdrv;
    void *sfx_mdrv;
    void        *token;         // used for freeing up the token
    ccs_mid     ccs_mid_table;
} read_callback_entry_t;

struct lba_list_ctx
{
    xt_u32 lba;             /* current lba */
    xt_u32 nr_seg_proc;     /* processed segment */
    xt_u32 nr_lba_proc;     /* processed lba nr */
    xt_u32 nr_seg_lba_proc; /* processed lba nr in current segment */
    sfx_lba_list *lba_list;
};

#define UINT_512B_FLAG (0x8000000000000000)//use bit63 for compatiablity check
typedef struct sfx_blk_log
{
    sfx_atomic64_t data_units_rd;
    sfx_atomic64_t data_units_wr;
    sfx_atomic64_t host_read_cmds;
    sfx_atomic64_t host_write_cmds;
} sfx_blk_log;

typedef struct sfx_percpu_blk_log
{
#ifdef SFX_LINUX
#ifdef __SFX_KERNEL__
    xt_u64  __percpu    *data_units_rd;
    xt_u64  __percpu    *data_units_wr;
    xt_u64  __percpu    *host_read_cmds;
    xt_u64  __percpu    *host_write_cmds;
#else
    xt_u64  *data_units_rd;
    xt_u64  *data_units_wr;
    xt_u64  *host_read_cmds;
    xt_u64  *host_write_cmds;
#endif
#endif
} sfx_percpu_blk_log;

typedef enum
{
    DT_USER           = 0,
    DT_P2L            = 1,
    DT_XOR            = 2,
    DT_GARBAGE        = 3,
    DT_EMPTY          = 4,
    DT_BB             = 5,
    DT_SYSTEM         = 6,
    DT_FOOTER         = 7,
    DT_HEADER         = 8,
    DT_L2P            = 9,
    DT_INVALID_USER   = 0xA,
    DT_DUMMY          = 0XB,
    DT_MASTER_TABLE   = 0XC,
    DT_CHECK_POINT    = 0XD,
    DT_UNKNOWN_TYPE   = 0XE,
    DT_COUNT,

} sfx_data_type;

typedef struct _temp_setting
{
    xt_u32 nand_temp_thrd;
    xt_u32 fpga_temp_thrd;
    xt_u32 nand_current_temp;
    xt_u32 fpga_current_temp;
} vu_temp_setting_t;

// utility function
#ifdef __GNUC__
/*
 * GNU has a highly optimized built-in function that returns the msb position.
 * This GNU built-in, called __builtin_clz(), will use, if possible, a single
 * HW instruction to find the msb position for CPU's like x86, ARM, MIPS, etc.
 *
 * Here is the list of GNU's extension to the standard C built-in functions:
 *   https://gcc.gnu.org/onlinedocs/gcc-7.2.0/gcc/Other-Builtins.html
 *   https://gcc.gnu.org/onlinedocs/gcc-4.8.4/gcc/X86-Built-in-Functions.html
 */
#define find_cont_bits(x)       ((xt_u32)((x) < 2 ? 0 : ((31 - __builtin_clz(x)) + (0 != ((x) & ((x) - 1))))))
#else
static inline xt_u32 find_cont_bits(xt_u32 x)
{
    xt_u32 orig_x = x;
    xt_u32 i = 0;
    while (x >>= 1) {
        ++i;
    }
    return (orig_x > (1 << i)) ? (i + 1) : i;
}
#endif // __GNUC__

// Multi-driver API for blk ftl
void ccs_blk_ftl_get_capacity(xt_u8 ccs_devID, xt_u32 *feat_data);
void set_css_atomic_write_group(xt_u32 dev_id, xt_u32 flag);
sfxError CCS_Open_ccs_dev(char *dev_name, xt_u8 *ccs_devID, xt_u32 nid, ftl_global_ctx *ftl_global_ctx, ccs_thread_register cb);
void sfx_nand_log_init(xt_u8 sfx_dev_id);
void sfx_nand_log_exit(xt_u8 sfx_dev_id, xt_u8 from_assert_exit);

void InitializeTable(void);
//Multi-driver API
void CCS_InitializeTable(xt_u8 ccs_devID);

void InitializeTableBase(void); /* Version of InitializeTable that doesn't add signal handlers */
//Multi-driver API

/* return card ready or not ready information */
sfxError IdentifyDevice(void);
//Multi-driver API
sfxError CCS_IdentifyDevice(xt_u8 ccs_devID);

void DestroyTable(void);
void ccs_destroy_table(xt_u8 ccs_devID);
void ccs_set_surprising_remove(xt_u8 ccs_devID);
void ccs_set_flag_dev_freeze(xt_u8 ccs_devID);
xt_u32 ccs_get_inflight_cb_cnt(xt_u8 ccs_devID);
//Multi-driver API
void CCS_DestroyTable(xt_u8 ccs_devID);

void SnapshotTables(void);
//Multi_driver
void CCS_SnapshotTables(xt_u8 ccs_devID);

void ccs_internal_status(void);
//Multi_driver
void ccs_set_non_gc_stream(xt_u8 ccs_devID, xt_u8 val);
void CCS_Internal_status(xt_u8 ccs_devID);
void ccs_inject_messages(xt_u8 ccs_devID, const xt_u8 *str);

int ccs_cmpl_driver_cb(void *ctx, void *cqe);
int sfx_mdrv_empty_query(void *ptr);
int comp_cmpl_driver_cb(void *ctx, void *cqe);
int ec_cmpl_driver_cb(void *ctx, void *cqe);
//change number of read per die
void ccs_set_num_read_per_die(xt_u8 ccs_devID, xt_u32 val);
void ccs_set_irq_coal(xt_u8 ccs_devID, xt_u32 val);
xt_u32 ccs_get_irq_coal(xt_u8 ccs_devID);
//enable/disable hw command scheduler
void ccs_set_hw_cmd_sched(xt_u8 ccs_devID, xt_u32 val);
void ccs_get_nand_type(xt_u8 ccs_devID, xt_u32 *nand_type);
xt_u32 ccs_get_hw_cmd_sched(xt_u8 ccs_devID);
//get die number
xt_u32 ccs_get_die_cnt(xt_u8 ccs_devID);
//Change to Aerospike mode
xt_u32 ccs_actmode_config(xt_u8 ccs_devID, xt_u8 set);

void reg_u2_config(xt_u8 ccs_devID, xt_u8 val);

void ccs_erase_point_config(xt_u8 ccs_devID, xt_u8 p0, xt_u8 p1, xt_u8 clear);

void ccs_get_ctx(xt_u8 ccs_devID);

//Multi-driver API for blk ftl
void ccs_dump_nvme_q(xt_u8 ccs_devID, xt_u8 op_code);

//Multi-driver API for blk ftl
void ccs_dump_app_q(xt_u8 ccs_devID, xt_u8 op_code);

void DumpWS(void);
//Multi-driver API for blk ftl
void CCS_DumpWS(xt_u8 ccs_devID);

void DumpMap(void);
//Multi-driver API for blk ftl
void CCS_DumpMap(xt_u8 ccs_devID);

void DumpSBlock(void);
//Multi-driver API for blk ftl
void CCS_DumpSBlock(xt_u8 ccs_devID);

//print histogram of FPGA temperature
void ccs_dump_temperature(xt_u8  ccs_devID);

xt_u64 ccs_rd_debug_func(xt_u8 ccs_devID, xt_u8 op);

void DumpNvme(void);
//Multi-driver API for blk ftl
void CCS_DumpNvme(xt_u8 ccs_devID);

void CCS_PerfDebug(xt_u8 ccs_devID);
/* Return the card capacity in CCS blocks */

/* Trigger crash at location loc */
void CCS_crash_trigger(xt_u8 ccs_devID, xt_u32 loc);

void CCS_trigger_checkpoint(xt_u8 ccs_devID);

/* Set ccs thread to be realtime thread*/
void CCS_set_ccs_cmd_sched_realtime(xt_u8 ccs_devID);
/*
 * set fpga temp trigger threshold for temp throttling
 */
void ccs_set_fpga_temp_thrd(xt_u8 ccs_devID, xt_u32 loc);
/*
 * set fpga temp trigger threshold for temp throttling
 */
void ccs_set_nand_temp_thrd(xt_u8 ccs_devID, xt_u32 val);

/*
 * get temp threshold for temp throttling by sensor id
 */
xt_u32 ccs_get_temp_thrd(xt_u8 ccs_devID, xt_u8 sensor_id);

/*
 * get default temp threshold for temp throttling by sensor id
 */
xt_u32 ccs_get_temp_default_thrd(xt_u8 ccs_devID, xt_u8 sensor_id);

xt_u32 ccs_get_temp_sensor_num(void);

/*
 * set temp threshold for temp throttling by sensor id
 */
void ccs_set_temp_thrd(xt_u8 ccs_devID, xt_u16 temp_thrd, xt_u8 sensor_id);

/*
 * set power mode to control power consumption on board
 */
void ccs_set_power_mode(xt_u8 ccs_devID, xt_u32 mode);
void *ccs_get_ccp(xt_u8 ccs_devID);

/*
 * set parallel erase num
 */
void ccs_set_erase_num(xt_u8 ccs_devID, xt_u32 num);

/*
 * set/get module debug level
 */
xt_u8 ccs_get_debug_level(xt_u8 ccs_devID, xt_u8 module);
void ccs_set_debug_level(xt_u8 ccs_devID, xt_u8 module, xt_u8 level);
void ccs_set_debug_level_all(xt_u8 ccs_devID, xt_u8 mode);

xt_u32 CCS_GetCardSize(xt_u8 ccs_devID);

/* Return the maximum number of sessions allowed */
unsigned int GetMaxSessions(void);                        //TBD

// return memID
sfxError AllocateMem(xt_u32 *mid);
//Multi-driver API
sfxError CCS_AllocateMem(xt_u8 ccs_devID, xt_u32 *mid);

sfxError AllocateMemType(xt_u32 *mid, xt_u8 stream);
//Multi-driver API
sfxError CCS_AllocateMemType(xt_u8 ccs_devID, xt_u32 *mid, xt_u8 stream);

// return memID

sfxError AllocateMemSize(xt_u32 memSize, xt_u32 *mid); //may not be used any more

/* AppendMem() function - Asynchronous mode.
    Submit command only, and caller shall check the completion later on.
    function return *cid, which will be used to check command completion status.
   Return:
    0: command return with no error
    none-0: defined in sfxError enum
*/
sfxError CCS_AppendMem_Async(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 append_size, xt_u32 sdp, xt_u16 keyid, xt_u16 *cid);

sfxError CCS_AppendMem_Async_callback(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 append_size,
        xt_u32 qid, xt_u32 nvm, ccs_callback_t cb, void *context, xt_u16 *cid, void *lba_list);
/* AppendMem() function - Synchronous mode
    The function wait until command is completed.
   Return written size (*wlen) in device.
    w/o compression: it should be same as append size
    with compression: it is the data size written in device (after compression)
    error: INVALID_CODE
*/
sfxError CCS_AppendMem(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 append_size, xt_u32 sdp, xt_u16 keyid, xt_u32 *wlen);

/*  Get pending command[cid] completion status
    return *com_len: command return length
    Function return *cmd_status:
        0: command is completed successfully
        1: command is still pending.
        ERROR_XXXX: command is failed with error.
    Note the cid is released after this function is called.
*/
//Multi-driver API
sfxError CCS_GetCCSCmdStatus(xt_u8 ccs_devID, xt_u16 cid, xt_u32 *ret_len);

// Seal the memID -- close the memID and release write session. It's like file close
sfxError CCS_SealMem(xt_u8 ccs_devID, xt_u32 memID);
sfxError ccs_sealMem_mode(xt_u8 ccs_devID, xt_u32 memID, xt_u16 mode_type);

// Deallocate memory ID request from different callers.
//  Return:
//      Fail: defined in sfxError enum
//      Success: 0
//Multi-driver API
sfxError CCS_DeallocateMem(xt_u8 ccs_devID, xt_u32 memId);

// Trim memory ID for specific length (count from backward). The length has to be 32KB aligned
//  Return:
//      Fail: defined in sfxError enum
//      Success: 0
//Multi-driver API
sfxError CCS_TrimMem(xt_u8 ccs_devID, xt_u32 memId, xt_u32 length);

/*  Read API from the device
    Return read length (*rlen) from device if successful.
*/

/* ReadMem() function - Asynchronous mode.
    Submit command only, and caller shall check the completion later on.
    function return *cid, which will be used to check command completion status.
   Return:
    0: command is success
    none-0: defined in sfxError enum
*/
sfxError CCS_ReadMem(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 offset, xt_u32 length, xt_u32 sdp, xt_u16 keyid, xt_u32 *rlen);

sfxError CCS_ReadMem_Async(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 offset, xt_u32 length, xt_u32 sdp, xt_u16 keyid, xt_u16 *cid);

sfxError CCS_ReadMem_Async_callback(xt_u8 ccs_devID, xt_u32 memID,
    xt_u32* host_addr, xt_u32 offset, xt_u32 length, xt_u32 cpuid, xt_u16 keyid,
    ccs_callback_t cb, void *context, xt_u16 *cid, xt_u32 lba, xt_u16 read_mask,
    xt_u32 pba_base, xt_u32 merge_rd_en, xt_u32 lba_seq_off);

sfxError prepare_hot_and_cold_read(xt_u8 ccs_devID, css_io_ctx *ctx, xt_u16 *cid);

xt_u64  CCS_Obtain_PBA(xt_u8 ccs_devID, xt_u32 memID, xt_u32 offset);
xt_u32 CCS_obtain_software_pba(xt_u8 ccs_devID, xt_u32 memID, xt_u32 offset, xt_u32 *valid);

xt_u64 CCS_Convert_mid_to_PBA(xt_u8 ccs_devID, xt_u32 memID, xt_u32 offset, xt_u32 is_sw_pba);

xt_u32 get_rrb_strip_pba_list(xt_u32 deviceId, xt_u32 pba, xt_u64 *pba_list);
xt_u32 get_rrb_xor_pba(xt_u32 deviceId, xt_u32 pba);

xt_u64 blk_ftl_xlat_lba2pba(void *sfx_mdrv, xt_u32 lba);
/* Abort_Cmd() function - Abort submitted and not finished command
 * Return:
 * 0: abort success
 * none-0: defined in sfxError enum
 */
//Multi-driver API
sfxError CCS_Abort_Cmd(xt_u8 ccs_devID, xt_u16 cid);

/*  API to set the key table
    Function will allocate one entry(keyid) from key table, and save the key structure in key table. Function returns *keyid.
*/

sfxError SetKey(CCS_KEY_STRUCT* key, xt_u16* keyid);
//Multi-driver API
//not supported

/*  API to release the keyid from key table */
sfxError ReleaseKey(xt_u16 keyid);
//Multi-driver API
//not supported

/* Erasure coding API - InitECSession
   - To create an erasure coding (EC) operating session. The particular EC parameters are specified by "ec_session":
   - If the function is completed successfully, it will return a session ID pointed by "ecSessionID".
*/
sfxError InitECSession(xt_u8* ecSessionID, EC_SESSION_STRUCT* ec_session);
/* Erasure coding API - AppendECData_Async
   - To send a 64KB data to the shared buffer of Arundina card for erasure coding operation.
   - The data to be sent is specified by "host_addr".
   - The associated EC session ID is specified by "ecSessionID", which dictates the particular EC algorithm to be used,
     e.g. (6, 3) algorithm.
   - The function will return a command ID pointed by "cid". This allows the application to check its completion status
     with "GetCCSCmdStatus".
*/
//Multi-driver API
sfxError CCS_InitECSession(xt_u8 ccs_devID, xt_u8* ecSessionID, EC_SESSION_STRUCT* ec_session);

sfxError AppendECData_Async(xt_u8 ecSessionID, xt_u32* host_addr, xt_u16* cid);
/* Erasure coding API - ComputeECParity_Async
   - To compute all the parity data based on the data sent by the preceding AppendECData operations. Each parity block
     has a size of 64KB.
   - The associated EC session ID is specified by "ecSessionID", which dictates the particular EC algorithm to be used,
     e.g. (6, 3) algorithm.
   - The function will return a commmand ID pointed by "cid". This allows the application to check its completion status
     with "GetCCSCmdStatus".
*/
//Multi-driver API
sfxError CCS_AppendECData_Async(xt_u8 ccs_devID, xt_u8 ecSessionID, xt_u32* host_addr, xt_u16* cid);

sfxError ComputeECParity_Async(xt_u8 ecSessionID, xt_u16* cid);
/* Erasure coding API - GetECParity_Async
   - To read back all the parity data to the host memory starting at addresses specified by "host_addr_list".
   - The associated EC session ID is specified by "ecSessionID".
   - The function will return a command ID pointed by "cid". This allows the application to check its completion status
     with "GetCCSCmdStatus".
*/
//Multi-driver API
sfxError CCS_ComputeECParity_Async(xt_u8 ccs_devID, xt_u8 ecSessionID, xt_u16* cid);

sfxError GetECParity_Async(xt_u8 ecSessionID, xt_u32** host_addr_list, xt_u16* cid);
/* Erasure coding API - endECSession
   - To end an erasure coding (EC) operating session specified by "ecSessionID".
*/

//Multi-driver API
sfxError CCS_GetECParity_Async(xt_u8 ccs_devID, xt_u8 ecSessionID, xt_u32** host_addr_list, xt_u16* cid);

sfxError endECSession(xt_u8 ecSessionID);
//Multi-driver API
sfxError CCS_endECSession(xt_u8 ccs_devID, xt_u8 ecSessionID);

/* Delete all memID on CCS
   option = 0 : the data only but not reset the block structure
          = 1 : delete the data, and also clear the block structure to recover system from failure
 */
//void DeleteAllData(xt_u32 option);
//Multi-driver API
void CCS_DeleteAllData(xt_u8 ccs_devID, xt_u32 option);
void blk_get_padding_data_space(xt_u8 ccs_devID, xt_u32 memid, xt_u32 *avail_len);

/* Set Attributes for specific memID
 */
sfxError SetAttributes(xt_u32 memID, ccs_attr *attr);
//Multi-driver API
//not supported

/* Get statistics for specific memID
 */
//sfxError GetStats(xt_u32 memID, ccs_stats *stat);
//Multi-driver API
sfxError CCS_GetStats(xt_u8 ccs_devID, xt_u32 memID, ccs_stats *stat);

/* get parity group size for blk_ftl
 */
sfxError CCS_GetParitySizes(xt_u8 ccs_devID,xt_u32 memID, xt_u32 *parity_sizes);

/*
 * reallocate buff2nand cmd trace after power failure. It is avtived by blk ftl
 */
void ccs_reactive_gc_trace(xt_u8 ccs_devID, xt_u32 mid);

// ----wear leveling -----------------
void   ccs_pick_wl_candidates(xt_u8 ccs_devID, xt_u32 *wl_hot_candidate, xt_u32 *wl_cold_candidate);
xt_u32 get_wl_max_threshold(xt_u8 ccs_devID);
xt_u32 get_wl_min_threshold(xt_u8 ccs_devID);
xt_u32 get_stream_count(xt_u8 ccs_devID);
xt_u8  obtain_wl_threshold(xt_u8 ccs_devID);
void   ccs_set_wl_status(xt_u8 ccs_devID, xt_u8 value);
xt_u8  ccs_get_wl_status(xt_u8 ccs_devID);
void   ccs_disable_wl_hot(xt_u8 ccs_devID);
void   ccs_disable_wl_cold(xt_u8 ccs_devID);
xt_u32 ccs_wl_fifo_size(xt_u8 ccs_devId);
void   ccs_set_wl_peh_block(xt_u8 ccs_devId, xt_u32 hot_blk);
void   ccs_set_wl_pel_block(xt_u8 ccs_devId, xt_u32 cold_blk);
void   ccs_sort_blk_by_pe_count(xt_u8 ccs_devID, xt_u32 *result, xt_u32 *valid_len, xt_u8 wl_type);
xt_u32 ccs_xlate_blk2ccsmemid(xt_u8 ccs_devId, xt_u32 blk);
xt_u32 ccs_xlate_ccsmemid2blk(xt_u8 ccs_devId, xt_u32 memid);
void   print_wl_info(xt_u8 devId);
void   set_wl_target_endurance(xt_u8 devId, xt_u32 value);
void   set_wl_default_threshold(xt_u8 devId, xt_u32 value);
void   set_wl_default_gap(xt_u8 devId, xt_u32 value);
void   stop_wl(xt_u8 devId);
void   set_wear_leveling_opt(xt_u8 devId, xt_u8 option);
xt_u8  get_wear_leveling_opt(xt_u8 devId);
void   trigger_wl_early(xt_u8 devId, xt_u8 option);
xt_u8  is_wl_trigger_early(xt_u8 devId);
xt_u8  is_memid_a_good_wl_peh_candidate(xt_u8 devId, xt_u32 ccs_memid);
/*
 *  Get feature with specific feature command
 */
void ccs_secure_erase_change_seal_flag(xt_u8 ccs_devID, xt_u32 memID);
xt_u32 return_se_check_point_flag(xt_u8 ccs_devID);
void reset_se_check_point_flag(xt_u8 ccs_devID);

//Multi-driver API
sfxError CCS_get_feature(xt_u8 ccs_devID, xt_u16 FEAT_OP, xt_u32* host_addr);

//for master table read, write and erase
sfxError blk_ftl_cp_wr_fcmd_submit(xt_u8 ccs_devID, xt_u32 *addr, xt_u32 pba, xt_u32 len,
        xt_u32 cp_or_jnl, xt_u8 bypass_pcie, xt_u16 ssid,
        ccs_callback_t callback, void *context);
xt_u32 blk_ftl_direct_read(xt_u8 ccs_devID, xt_u32* rbuf, xt_u32 pba, xt_u32 length, xt_u32 raid_mode,
        xt_u16 buf_id, ccs_callback_t cb, xt_u32 cp, void *context);
sfxError blk_ftl_erase_single_block(xt_u8 ccs_devID, xt_u32 pba, ccs_callback_t call_back, void *context);

xt_32 blk_ftl_read_mid_offset(xt_u8 ccs_devID, xt_u32 mid);
void blk_ftl_get_sblock_pg_num(xt_u8 ccs_devID, xt_u32 *blk_num, xt_u32 *pg_num, xt_u32 *total_grown_bbd);
void ccp_checker_dummy(xt_u8 ccs_devID, xt_u32 m_num);
xt_u8 ccs_check_prog_status(xt_u8 ccs_devID, xt_u32 mid, xt_u32 *offset);
xt_u32 ccs_next_sw_page(xt_u32 devId, xt_u32 swpba);

// secure erase, setting/resetting flag
void blk_ftl_se_in_progress(xt_u8 ccs_devID, xt_u8 value);
void blk_ftl_stop_ccs_internal(xt_u8 ccs_devID, xt_u8 value);
sfxError blk_ftl_secure_erase(xt_u8 ccs_devID);
void blk_ftl_wait_to_finish_outstanding_cmds(xt_u8 ccs_devID, xt_u32 allow_one_buf2nand_for_gc);
void ccs_get_invalid_prd_buff(xt_u8 ccs_devID, void **prd_buff);
/*
 * CCS Compression Client API
 */
sfxError ccs_comp_mgr_open_session(xt_u8 ccs_dev_id, xt_u16 *sid, xt_u32 p0, xt_u32 p1, xt_u32 p2, xt_u32 p3);
sfxError ccs_comp_mgr_close_session(xt_u8 ccs_dev_id, xt_u16 sid);
sfxError ccs_comp_mgr_append_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf, xt_u32 len, xt_u16 flag);
sfxError ccs_comp_mgr_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf, xt_u32 len, xt_u16 flag);
sfxError ccs_comp_mgr_append_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32* append_buf, xt_u32 append_length, xt_u32 *get_buf,  xt_u32 get_length, xt_u16 flag);
sfxError ccs_get_runtime_status(xt_u8 ccs_dev_id, xt_u32 *rt_status);
sfxError ccs_get_cmd_status(xt_u8 ccs_dev_id, xt_u16 cid, xt_u32 *len);
sfxError ccs_ni_get_dev_count(xt_u8 ccs_dev_id, xt_u8 *cdev_cnt);

void ccs_update_param(xt_u8 ccs_dev_id, xt_u8 option, xt_u32 value);
int get_lbamismatch_log(xt_u8 ccs_devId, void *smart_log_out);
int get_nvme_smart_log(xt_u8 ccs_devId, void **smart_log_out);
int get_intel_nvme_smart_log(xt_u8 ccs_devId, void *smart_log_out);
xt_u32 ccs_get_log(xt_u8 ccs_devId, xt_u8 option, xt_u32 cdw11, void *addr, xt_u32 len);
int ccs_unlock_fw(xt_u8 ccs_devId);
void ccs_lock_fw(xt_u8 ccs_devId);
int ccs_download_fw(xt_u8 ccs_devId, xt_u32 offset_in, xt_u32 xfer_len, void *ibuf);
int ccs_verify_fw(xt_u8 ccs_devId, xt_u32 offset_in, xt_u32 xfer_len, void *wbufp);
int ccs_reg_put(xt_u8 ccs_devID, void *regmem, void *regmem_end, void *ibuf, void *ibuf_end);
/*
 * CCS Compression Native API
 */
sfxError ccs_ni_comp_open_session(xt_u8 ccs_dev_id, xt_u16 *sid, xt_u32 p0, xt_u32 p1, xt_u32 p2, xt_u32 p3);
sfxError ccs_ni_comp_close_session(xt_u8 ccs_dev_id, xt_u16 sid);
sfxError ccs_ni_comp_append_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf, xt_u32 len, xt_u16 flag);
sfxError ccs_ni_comp_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf,  xt_u32 len, xt_u16 flag);
sfxError ccs_ni_comp_get_runtime_status(xt_u8 ccs_dev_id, xt_u32 *rt_status);
sfxError ccs_ni_comp_append_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *abuf, xt_u32 alen, xt_u32 *gbuf, xt_u32 glen, xt_u16 flag);
sfxError ccs_ni_comp_get_cmd_status(xt_u8 ccs_dev_id, xt_u16 cid, xt_u32 *len);

/*
 * CCS EC Native API
 */
sfxError ccs_ni_ec_open_session(xt_u8 ccs_dev_id, xt_u16 *sid, xt_u32 p0, xt_u32 p1, xt_u32 p2, xt_u32 p3);
sfxError ccs_ni_ec_close_session(xt_u8 ccs_dev_id, xt_u16 sid);
sfxError ccs_ni_ec_append_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *abuf, xt_u32 alen, xt_u32 *gbuf, xt_u32 glen, xt_u16 flag);
sfxError ccs_ni_ec_get_cmd_status(xt_u8 ccs_dev_id, xt_u16 cid, xt_u32 *len);
sfxError ccs_ni_ec_get_runtime_status(xt_u8 ccs_dev_id, xt_u32 *rt_status);

// R2C Related
int rc_client_call(int msg_id, void *msg, xt_u8 dev_id);
void record_multi_drv(xt_u8 ccs_dev_id, void *p);
void* get_multi_drv(xt_u8 ccs_dev_id);

typedef sfxError (*r2c_read_cb)(void *, void *);
void register_r2c_cb(xt_u8 ccs_dev_id, r2c_read_cb cb, r2c_read_cb lba_pba_cb);
xt_u32 get_r2c_n2b_qid(xt_u8 ccs_dev_id, xt_u16 sid);
int r2c_cmpl_driver_cb(void *ctx, void *cqe);

r2cStatus ccs_ni_r2c_col_schema(xt_u8 dev_id, xt_u8 sid, xt_u64 key_meta,
                 xt_u64 val_meta, xt_u32 ncol, xt_u8 *col_vld, xt_u8 *val_col_map,
                 xt_u32 *col_type, xt_u32 nblk, xt_u8 cond_num, xt_u8 *filter_buf);
r2cStatus ccs_ni_r2c_open_session(xt_u8 ccs_dev_id, xt_u32 seq_id_used,
                 xt_u8 is_sync, xt_u64 user_buf, xt_u64 *sid);
sfxError ccs_ni_r2c_close_session(xt_u8 ccs_dev_id, xt_u16 sid, xt_u64 *retn_len);
r2cStatus ccs_ni_r2c_send_cmd(xt_u8 dev_id, xt_u8 schema_id, xt_u16 ncol, xt_u16 sid,
                  xt_u8 fuse_nvme_read, xt_u32 *nvme_read_buf, xt_u32 nvme_read_length,
                  xt_u8 fuse_dce, xt_u32 dce_offset, xt_u32 dce_length, xt_u8 fuse_n2b,
                  xt_u32 page_start, xt_u32 page_end, xt_u32 offset_start_aligned,
                  xt_u32 offset_end_aligned, xt_u64 *aux, xt_u8 is_sync, r2cStatus send_cmd_status);
r2cStatus ccs_ni_r2c_query_status(xt_u8 dev_id, xt_u64 sid, xt_u64 *user_buf, xt_u64 *ret_len);

sfxError CCS_R2C_ReadMem_Async_callback(xt_u8 ccs_devID, xt_u32 memID, xt_u32 offset,
                  xt_u32 length, xt_u32 qid, xt_u16 keyid, ccs_callback_t cb,
                  void *context, xt_u16 sid, xt_u8 fuse, xt_u64 aux, xt_u16 *cid,
                  xt_u32 lba, xt_u16 read_mask, xt_u32 pba_base, xt_u32 merge_rd_en,
                  xt_u32 lba_seq_off);

sfxError CCS_R2C_LBA_PBA_Async_callback(xt_u8 ccs_devID, xt_u32 memID, xt_u32 offset,
                  xt_u32 length, xt_u32 qid, xt_u16 keyid, ccs_callback_t cb,
                  void *context, xt_u16 sid, xt_u8 fuse, xt_u64 aux, xt_u16 *cid,
                  xt_u32 lba, void *condtext_fill);

//ACT queue number statistics
xt_u32 ccs_get_act_num(xt_u8 ccs_devId);
xt_u32 ccs_get_act_op_num(xt_u8 ccs_devId, xt_u8 opcode);
xt_u32 ccs_get_cmp_act_num(xt_u8 ccs_devId);
xt_u32 ccs_get_non_cmp_act_num(xt_u8 ccs_devId);

// turn off/on adaptive read
void ccs_flip_adaptive_read(xt_u8 devId);

void stop_wl(xt_u8 devId);

sfxError get_FPGA_temp(union handle *dev_handle, xt_u32 *feat_data);
int sfx_capacitor_issue(union handle *hand, xt_u32 op, xt_u32 para);
xt_u32 sfx_read_power_consumption(union handle *hand);
sfxError old_read_sensor_scaled(xt_u8 ccs_devID, union handle *dev_handle, hw_sensor_e sensor_sel, old_i2c_sensor_status_t *stat, xt_u32 power_factor, xt_u32 *feat_data);
sfxError read_sensor_scaled(xt_u8 ccs_devID, union handle *dev_handle, hw_sensor_e sensor_sel, i2c_sensor_status_t *stat, xt_u32 power_factor, xt_u32 *feat_data);
void qual_error_cnt_trigger_end(xt_u8 ccs_devID);
void qual_error_cnt_trigger_start(xt_u8 ccs_devID);
sfxError set_unsafe_shutdown(xt_u8 devId, xt_u32 pf_count);
sfxError set_ps_cnt(xt_u8 devId, xt_u32 ps_cnt, xt_u32 pf_count);
sfxError CCS_get_feature(xt_u8 ccs_devID, xt_u16 FEAT_OP, xt_u32 *feat_data);
void ccs_reset_log(xt_u8 ccs_devId);
void ccs_reg_read_distb_cb(xt_u8 ccs_devID, ccs_callback_t cb, read_distb_info *read_distb_cntx);
void ccs_read_distb_init_ready(xt_u8 ccs_devID);
void ccs_reg_err_handler_cb(xt_u8 ccs_devID, ccs_callback_t cb, error_info_ctx *err_ctx);
int get_next_lba(struct lba_list_ctx *lba_list_ctx, xt_u32 off);
void ccs_get_mid_list(xt_u8 ccs_devID, ccs_mid *mid_list, xt_u32 *length);
xt_u8 ccs_sync_info_with_ftl(xt_u8 ccs_devID, xt_u32 ccs_mem_id, xt_u32 blk_ftl_ap, xt_u32 required_size);
xt_u8 ccs_mid_can_be_early_sealed(xt_u8 ccs_devID, xt_u32 ccs_mem_id, eh_err_type_e error_type, xt_u32 *final_pba, xt_u32 *new_total_aval_len);

void ccs_sync_info_with_ftl_done(xt_u8 ccs_devID, xt_u32 stream);
xt_u8 ccs_handle_err_partial_flag(xt_u8 ccs_devID, xt_u32 ccs_mem_id, xt_u8 is_clear, xt_u8* pf_flag);

xt_u32 fm_get_mirror_pba(xt_u8 ccs_dev_id, xt_u32 pba);
sfxError sfx_blk_assert(void *sfx_mul_drv, xt_u64 cond);
xt_u8 ccs_get_dev_id_by_ctrlr(void *ccs_ctrlr);
void set_ccs_private_data(xt_u8 ccs_devID, void *sfx_mdrv, struct sfx_blk_ftl_thread *thread,
        sfx_thread_pool *thrd_pool, sfx_mdrv_state_machine_func sfx_mdrv_state_machine);
void set_ccs_assert_handle(xt_u8 ccs_devID, SFX_ASSERT_HANDLE_ACTION action);
int assert_from_ccs(xt_u8 ccs_devID);
void freeze_ccs(xt_u8 ccs_devID);
void signal_scheduler_thread_stop(xt_u8 ccs_devID);
void ccs_set_blk_smart_log(xt_u8 ccs_devID, sfx_blk_log *io_smart_log, sfx_percpu_blk_log *percpu_log);
void ccs_set_read_distb_values(xt_u8 ccs_devID, xt_u32 val);
sfxError css_append_metadata_Async_callback(xt_u8 ccs_devID, xt_u32 memID, xt_u32* host_addr, xt_u32 append_size,
                                      xt_u8 fuse, ccs_callback_t cb, void *context, void *lbactx);
sfxError sfx_pu_init_dev_parameter(xt_u8 ccs_devID, struct sfx_pu_res_manager *pu_res_mgr);
int css_hotwr_smt(void *data);
int CSS_CompressStat(xt_u8 css_devID, char *buf);
xt_u8 ccs_is_data_loss_mode(xt_u8 devId);
void ccs_set_data_loss_mode(xt_u8 devId);
void ccs_reset_data_loss_mode(xt_u8 devId);
void ccs_set_media_err(xt_u8 devId, xt_u8 value);
void ccs_start_checkpoint(xt_u8 devId);
void ccs_wait_checkpoint_write_done(xt_u8 devId);
xt_u32 ccs_is_nonassert_readonly(xt_u8 devId);
void ccs_clear_read_only_signal(xt_u8 devId);
void ccs_enter_readonly_mode(xt_u8 devId);
void ccs_update_lbamismatch_log(xt_u8 devId, xt_u32 lba);
xt_u32 add_and_return_ele_num(xt_u8 devId, xt_u32 cnt);

int set_blk_ftl_config_params(void *sfx_mdriv);
int update_drive_size(void *sfx_mdriv, xt_u32 is_factory_init);
void print_debug_drive_size(void *sfx_mdriv);
void ccs_security_erase_reset_bf2n(xt_u8 ccs_devID);
void ccs_security_erase_reset_cmd_queue(xt_u8 ccs_devID);
void ccs_security_reset_scheduler_state(xt_u8 ccs_devID);
xt_u32 get_super_block_of_pba(xt_u8 devId, xt_u32 pba);
xt_u32 get_block_entity_of_pba(xt_u8 devId, xt_u32 pba);

sfxError ccs_ec_open_session(xt_u8 ccs_dev_id, xt_u16 *sid, xt_u32 p0, xt_u32 p1, xt_u32 p2, xt_u32 p3);
sfxError ccs_ec_close_session(xt_u8 ccs_dev_id, xt_u16 sid);
sfxError ccs_ec_append_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf, xt_u32 len, xt_u16 flag);
sfxError ccs_ec_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32 *buf,  xt_u32 len, xt_u16 flag);
sfxError ccs_ec_get_runtime_status(xt_u8 ccs_dev_id, xt_u32 *rt_status);
sfxError ccs_ec_mgr_append_get_data_async(xt_u8 ccs_dev_id, xt_u16 sid, xt_u16 *cid, xt_u32* append_buf, xt_u32 append_length, xt_u32 *get_buf,  xt_u32 get_length, xt_u16 flag);
sfxError ccs_ec_get_cmd_status(xt_u8 ccs_dev_id, xt_u16 cid, xt_u32 *ret_len);
int CSS_DCEStat(xt_u8 css_devID, char *buf);

#ifdef ENABLE_KMEM_CACHE
void *kmem_valloc(xt_u32 dev_id, unsigned int size);
void *kmem_malloc(xt_u32 dev_id, int size);
void  kmem_mfree(void *ptr);
int   kmem_free(void *ptr);
#else
#define kmem_valloc(dev_id, size)           sfx_valloc(size)
#define kmem_malloc(dev_id, size)           sfx_malloc(size)
#define kmem_mfree(ptr)                     sfx_mfree(ptr)
#define kmem_free(ptr)                      sfx_free(ptr)
#endif

void init_memory_module(xt_u32 dev_id);
void destroy_memory_module(void *pkmem_mgr_in, xt_u32 dev_id);
xt_u32 kmem_is_ready(xt_u32 dev_id);
xt_u32 kmem_free_check(xt_u32 dev_id, void *ptr);
xt_u32 kmem_mfree_check(xt_u32 dev_id, void *ptr);
sfxError CCS_LockMem(xt_u8 ccs_devID, xt_u32 *vaddr, xt_u32 length, xt_u32 **paddr);
sfxError CCS_UnlockMem(xt_u8 ccs_devID, xt_u32 *paddr);
void mdata_get_reverse_lba(void *sfx_mdriv, xt_u32 mim_mem_id, xt_u32 offset);
xt_u32 ccs_multi_stream_mode(xt_u32 ccs_devID);
xt_u32 get_first_mid_of_block(xt_u8 devId, xt_u32 block);
xt_u32 get_last_mid_of_stream(xt_u8 devId, xt_u32 stream);
xt_u32 get_stream_from_mid(xt_u8 devId, xt_u32 mid);

xt_u32 get_status_of_block(xt_u8 devId, xt_u32 block);

sfx_data_type block_status2_data_type(xt_u32 block_status);

xt_u32 get_erase_count_of_block(xt_u8 devId, xt_u32 block);
sfxError set_erase_count_of_block(xt_u8 devId, xt_u32 block, xt_u32 erase_count);
xt_u32 get_read_count_of_block(xt_u8 devId, xt_u32 block_entity, xt_u32 block);
sfxError set_read_count_of_block(xt_u8 devId, xt_u32 block_entity, xt_u32 block, xt_u32 read_count);
sfxError mark_bb(xt_u8 devId, xt_u64 pba);
xt_u64 vu_mark_bb(xt_u8 devId, xt_u64 pba);

sfxError get_bb_table(xt_u8 devId, xt_u64 *table_address);
sfxError get_mfbb_table(xt_u8 devId, xt_u64 *table_address);

xt_u8 check_pba_is_bb(xt_u8 devId, xt_u64 pba);
xt_u32 ccs_can_stop_gc_for_gsd(xt_u32 devId);
xt_u32 ccs_get_bad_blk_num(xt_u32 devId, xt_u8 isGrownBB);
void geometry_collect_nand_info(xt_u32 devId, void *geometry);
xt_u32 get_last_pba(xt_u32 devId, xt_u32 sblock, xt_u32 ch, xt_u32 ce, xt_u32 lun, xt_u32 plane);
void get_next_prog_pba(xt_u32 devId, xt_u32 sblock, void *next_pba_info, xt_u32 mode);
void get_pba_layout(xt_u32 devId, xt_u64 pba, void *pba_layoutbuf);
xt_u32 combine_pba(xt_u32 devId, xt_u32 ch, xt_u32 ce, xt_u32 lun, xt_u32 plane, xt_u32 blk, xt_u32 page, xt_u32 offset);
xt_u32 is_swpba_valid(xt_u32 devId, xt_u64 pba);
void get_nand_cfg(xt_u32 devId, void *nand_cfg);
xt_u32 get_page_type(xt_u32 devId, xt_u32 page, void *page_type);
xt_u32 get_block_type(xt_u32 devId, xt_u32 block);
xt_u32 get_bad_block_of_sblock(xt_u32 devId, xt_u64 pba, xt_u64 *table_address);
xt_u32 get_retired_bb_threshold_of_sblock(xt_u32 devId);
xt_u32 ccs_vu_inject_err_hw(xt_u32 devId, vu_error_inject_element_t *ele);
xt_u32 ccs_vu_inject_error(xt_u32 devId, vu_error_inject_element_t *ele);
xt_u32 get_cp_info(xt_u8 devId, xt_u64* databuf);
xt_u64 ccs_convert_pba(xt_u32 devId, xt_u32 pba_type, xt_u64 pba);
sfxError get_nandlog_cur_pos(xt_u32 devId, xt_u8 file_id, xt_u32 *paddr);
xt_u32 decode_nand_log_one_page(xt_u8 *data_buf, xt_u32 buf_size, xt_u8 *output);
xt_u32 get_nandlog_4k_page_num(xt_u32 devId, xt_u32 *cur_pos);
xt_u32 get_nandlog_blk_info(xt_u8 sfx_dev_id, xt_u8 *buf);
sfxError ccs_vu_erase_sblock(xt_u32 devId, xt_u64 pba);
void set_read_mode(xt_u32 devId, xt_u32 mode);
xt_u32 double_program_one_chunk_data(xt_u32 devId, xt_u32 pba);
sfxError ccs_vu_get_free_block(xt_u32 devId, void *buf);
xt_32 vu_calculate_padding_size(xt_u32 devId, xt_u32 sw_pba);
xt_u32 vu_get_last_finished_sw_pba(xt_u32 devId, xt_u32 stream);
sfxError ccs_vu_get_temeperature(xt_u8 ccs_devID, vu_temp_setting_t *ptemp);
sfxError ccs_vu_set_temeperature_thrd(xt_u8 ccs_devID, xt_u32 nand_thrd, xt_u32 fpga_thrd);
sfxError ccs_vu_set_temeperature(xt_u8 devId, xt_u32 set_flag, xt_u32 temp_val);
xt_u32 get_read_disturb_threshold_of_block(xt_u8 devId, xt_u32 block);
xt_u32 is_css_gsd(xt_u32 dev_id);
sfxError ccs_vu_get_wl_blocks(xt_u32 devId, void *buf);
sfxError ccs_vu_set_wl_blocks_hot_cold(xt_u32 devId, xt_u32 blk, xt_u32 type);
sfxError ccs_vu_set_capacitor_threshold(xt_u32 devId, xt_u32 threshold, xt_u32 interval);
sfxError ccs_vu_get_capacitor_threshold(xt_u32 devId, xt_u32 *threshold, xt_u32 *interval);
sfxError ccs_vu_set_tbw_endurance(xt_u32 devId, xt_u32 threshold);
xt_u32 ccs_vu_get_tbw_endurance(xt_u32 devId);
sfxError ccs_vu_set_available_spare(xt_u32 devId, xt_u32 set_flag, xt_u32 available_spare_val);
xt_u32 get_recent_hotcnt_of_block(xt_u8 devId, xt_u32 block);
xt_u32 set_recent_hotcnt_of_block(xt_u8 devId, xt_u32 block,xt_u32 rhc);
void check_barrier_cmd_bg(xt_u32 dev_id, xt_u32 mid, xt_u32 offset);
void buf2nand_cmd_thrd_stop(xt_u32 dev_id);
xt_u32 next_pg_offset(xt_u8 ccs_devID, xt_u32 mid, xt_u32 pre_offset);
sfxError ccs_vu_set_scrub_read_mode(xt_u32 devId, xt_u32 scrub_test_mode);
sfxError vu_get_scrub_rc_table(xt_u8 devId, xt_u32 buf_id, xt_u64 *data_buf, xt_u32 *total_nr_pages);
sfxError vu_get_scrub_mid_seq(xt_u8 devId, xt_u32 idx, xt_u32 *data_buf, xt_u32 *total_nr_pages);

sfxError CCS_Get_Onetime_Rd_Range(xt_u8 ccs_devID, xt_u32 mem_id,
    xt_u32 offset, xt_u16 *left_off, xt_u16 *right_off, xt_u32 *pba_base,
    xt_u16 *up_plane_off);
sfxError vu_get_scrub_cur_info(xt_u8 devId, void *rs_info);
sfxError vu_get_scrub_next_info(xt_u8 devId, xt_u32 mem_id, xt_u32 offset, void *rs_info);
sfxError vu_get_ali_scrub_info(xt_u8 devId, void *scrub_info);
sfxError vu_get_tt_credit(xt_u8 devId, void *tt_credit);
void ccs_clear_all_injected_error(xt_u32 devId);
void ccs_print_sblock(xt_u8 devId);

xt_u32 get_nvme_queue_write_reqs_num(xt_u8 ccs_devID);
int seu_crc_error_update(union handle *dev_handle, xt_u32 *seu_crc_error);
void ccs_blk_pe_min_max_avg(xt_u8 ccs_devId, xt_u16 *min, xt_u16 *max, xt_u16 *avg);

#ifdef __cplusplus
}
#endif

#endif // __CCS_API_H__
