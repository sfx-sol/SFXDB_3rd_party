// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_smc_proto.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_SMC_PROTO_H__
#define __SFX_SMC_PROTO_H__

#include <stdint.h>
#include <sys/uio.h>

#ifdef __cplusplus
extern "C" {
#endif

// Used in async mode
#define DEV_SMART_SCAN_CMD_SEND_COMPLETED               (0)

// Errors even CPU cannot deal with
// Error range: -1001 ~ -1099
#define DEV_SMART_SCAN_ERR_RESULT_LEN_TOO_SMALL         (-1001)
#define DEV_SMART_SCAN_ERR_DEVICE_NOT_FOUND             (-1002)
#define DEV_SMART_SCAN_ERR_INPUT_ILLEGAL                (-1003)
#define DEV_SMART_SCAN_ERR_BAD_BLOCK_CRC                (-1004)

// Errors CPU could try another once
// Error range: -1101 ~ -1199
#define DEV_SMART_SCAN_ERR_NOT_SUPPORT                  (-1101)
#define DEV_SMART_SCAN_ERR_ECC_FAILED                   (-1102)
#define DEV_SMART_SCAN_ERR_KEY_OVERFLOW                 (-1103)
#define DEV_SMART_SCAN_ERR_ROW_OVERFLOW                 (-1104)
#define DEV_SMART_SCAN_ERR_COLUMN_TOO_MANY              (-1105)
#define DEV_SMART_SCAN_ERR_BLOCK_TOO_MANY               (-1106)
#define DEV_SMART_SCAN_ERR_BLOCK_TOTAL_SIZE_TOO_LARGE   (-1107)
#define DEV_SMART_SCAN_ERR_RESOURCE_UNAVAILABLE         (-1108)
#define DEV_SMART_SCAN_ERR_DECOMPRESS_FAILED            (-1109)
#define DEV_SMART_SCAN_ERR_OTHER_HW_LIMIT               (-1110)
#define DEV_SMART_SCAN_ERR_HANG                         (-1111)
#define DEV_SMART_SCAN_ERR_UNKNOWN                      (-1112)

// Intermediate state used in async mode
#define DEV_SMART_SCAN_PENDING                          (-1201)

typedef struct sfx_smc_slice {
  const char* data = 0x0;
  size_t len = 0;
} sfx_smc_slice;

/**
 * A row will be stored as a key-value in rocksdb.
 *
 * The value part of a row should be like:
 *
 *                | (n + 7) / 8 bytes |
 * +--------------+-------------------+-------------+--------------+-----...----+-------------+
 * |     header   |    null bitmap    |    col 1    |    col 2     |     ...    |    col n    |
 * +--------------+-------------------+-------------+--------------+-----...----+-------------+
 *                                   /               \                         /               \
 *                                  /                 \                       /                 \
 *                                 +-------------------+                     +-------+-----------+
 *                                 |      data         |                     |  len  |    data   |
 *                                 +-------------------+                     +-------+-----------+
 *                                 (fixed length column)                    (variable length column)
 *
 * null bitmap (uint8[]):
 *              col i is null if ((bitmap[(i/8)] >> (i % 8)) & 1) == 1
 *              each column use 1 bit, so null bitmap's length: (n + 7) / 8
 *
 * ----------------------------------
 * For either a key schema or a value schema:
 *
 *  meta:       size of header bytes in the front of a row (a key or a value)
 *  col_num:    number of columns of a row (a key or a value), not the whole table field num.
 *  col_lengths:  length=col_num. types for each column(uint32_t array)
 *              col_length format is: high_2_bits | low_30_bits
 *              high_2_bits indicates fixed_length(0x00) or
 *              variable length (0x01) low_30_bits indicates the real column length in bytes
 *  data_types: length=col_num.
 *              The lower byte is enum_fields_type to indicate data type;
 *              the higher byte is an unsigned tag to indicate if this is an unsigned type.
 *              @see IsUnsigned() in types.h
 *  collations: length=col_num. collation for string field, empty for other fields.
 *  padding: padding flags.  false for NO PAD (0x0), true for PAD SPACE 0x20.
 *
 *  // Only for Primary key
 *  tbl_field_num: the whole table field num, including key and value fields.
 *  mapping: length=tbl_field_num. table col id -> filter col index mapping, -1 if empty.
 *  rev_mapping: length=tbl_field_num. filter col index -> table col id mapping, -1 if empty.
 *
 *  // Only for Secondary key
 *  nullable: indicate each key part if it is nullable. Nullable key part contains one byte tag.
 *
 *  ATTENTION: colid in col_filter and row_filter is the table col id, not the filter index id.
 *  @TODO SecondaryKey support
 *
 *  known as `smc_row_format` previously
 *  @see tools/key_schema.tpl tools/value_schema.tpl for schema example
 *  @TODO The build logic of smc_schema is too fuzzy, maybe we need a builder.
 */
struct sfx_smc_schema {
  /// if it is key, then id & 0x3fff means the index id in the table.
  /// 0x8000 means is_value, 0x4000 means is_pk
  uint16_t id = 0;

  /// actually is meta_length, buy maybe change its meaning in the future.
  uint32_t meta = 0;
  /// value schema col num, not the whole table col num.  Including pk part in SK format.
  uint16_t col_num = 0;
  uint8_t db_type = 1; /* default smc_db_type::MYSQL8*/

  /// known as `col_types` previously
  uint32_t* col_lengths = 0x0;
  /// for mysql and default, refer to mysql::enum_field_types
  /// extend one byte for unsigned flag 0x80
  uint16_t* data_types = 0x0;

  /// MySQL doesn't organize collation/charset well, so we use raw string for collation recognition here.
  /// It seems that PGSQL is also use raw name of collation with a different system from MySQL.
  /// collation is bound to compare logic. Empty for non-string field.
  /// if field collation is not set,
  /// then outer engine may need to check table/database collation and fill it here.
  sfx_smc_slice* collations = 0x0;
  /// false for NO PAD (0x0), true for PAD SPACE 0x20
  bool* padding = 0x0;

  /// === Only for PrimaryIndex
  uint16_t tbl_field_num = 0;
  /// tbl id -> filter schema id
  uint16_t* mapping = 0x0;
  /// filter schema id -> tbl id
  uint16_t* rev_mapping = 0x0;

  /// === Only for SecondaryIndex
  /// length=col_num . to indicate if a part of sk is nullable.
  /// If a col is defined by `c1 INT NOT NULL`, it isn't nullable,
  ///   otherwise nullable without `NOT NULL` syntax.
  /// nullable col on key in SK format has a 1-byte tag to indicate if it is null.
  /// 00 NULL, 01 not null.
  bool* nullable = 0x0;
};

/// >row_filter = sub_filter1 and sub_filter2 and sub_filter3 and ... and sub_filterN
/**
 *                +-------------+-------------+       +-------------+
 *                | sub_filter1 | sub_filter2 |  ...  | sub_filterN |
 *                +-------------+-------------+       +-------------+
 *                             /               \
 *                           /                     \
 *                        /                              \
 *                     /                                       \
 *                   /                                               \
 *                  +-------------------------------------------------+
 *                  |   op   |          params of sub_filter          |
 *                  +-------------------------------------------------+
 *                  |<  1B  >|  param1    |  param2   |    param3     |
                     41[NUL]  colid(2B)
                     42[!NUL] colid(2B)
                     1[ =]    colid(2B)   colid(2B)
                     2[<=>]   colid(2B)   colid(2B)
                     3[!=]    colid(2B)   colid(2B)
                     4[ >]    colid(2B)   colid(2B)
                     5[>=]    colid(2B)   colid(2B)
                     6[ <]    colid(2B)   colid(2B)
                     7[<=]    colid(2B)   colid(2B)
                     21[ =]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     22[<=>]  colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     23[!=]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     24[ >]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     25[>=]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     26[ <]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     27[<=]   colid(2B)   const_type(1B) len(2B)     bytes...(len)
                     43[LIKE] colid(2B)   len(2B)     bytes...(len)
                     44[!LIKE]colid(2B)   len(2B)     bytes...(len)
                     45[IN]   colid(2B)   const_type(1B)  const_size(2B)  len1(2B)    bytes1...(len1)  len2(2B)  bytes2...(len2) ...
 */
/// Currently only support AND list without OR: a AND b AND c ... AND d
/// filter_buf_len:  length of filter buffer
/// filter_buf:      pointer of filter desc buffer
///                  [sub_filter1] [sub_filter2] ... [sub_filterN]
///                  each subfilter = op(1B) + colid(2B) + (following params, var length)
///                  lowbyte first: (2B) 0100 == 1
struct sfx_smc_row_filter {
  uint32_t filter_buf_len = 0;
  uint8_t* filter_buf = 0x0;
};

/// col_num:         number of columns of each row(the same as row_format::col_num)
/// bitmap:          bitmap that represents the columns to project
///                  a lower bit of a lower byte corresponds to a column of a smaller index
///                  length = (col_num + 7) / 8
struct sfx_smc_column_filter {
  uint16_t col_num = 0;
  uint8_t* bitmap = 0x0;
};

// lba_unit_size: size (in byte) of each lba block
// lba_num: lba entry number for lba_vec
// lba_vec: stores lba entries
struct sfx_smc_lba_vec {
  uint32_t lba_unit_size = 0;
  uint32_t lba_num = 0;
  uint64_t *lba_vec = 0x0;
};

// off: data block offset(to lba_vec[0])
// len: data block length
struct sfx_smc_blk_handle {
  uint64_t off = 0;
  uint64_t len = 0;
};

// blk_num: entry number for blk_vec
// handle_vec: stores sc_blk_handle entries
struct sfx_smc_blk_vec {
  uint32_t blk_num = 0;
  struct sfx_smc_blk_handle *handle_vec = 0x0;
};

// iov_num: entry number for iov
// iov: stores iov entries(host buffer to hold the output data)
struct sfx_smc_query_result {
  uint32_t iov_num = 0;
  struct iovec *iov = 0x0;
};

// return: negative number for error code, other for how many bytes returned.
typedef int (*smc_query_fn) (
    const char *dev_id,
    struct sfx_smc_schema *key_schema,
    struct sfx_smc_schema *value_schema,
    struct sfx_smc_column_filter *column_filter,
    struct sfx_smc_row_filter *row_filter,
    struct sfx_smc_lba_vec *lba_vec,
    struct sfx_smc_blk_vec *blk_vec,
    struct sfx_smc_query_result *query_result);

// return: negative number for error code, otherwise DEV_SMART_SCAN_CMD_SEND_COMPLETED
typedef int (*smc_query_async_fn) (
    const char *dev_id,
    struct sfx_smc_schema *key_schema,
    struct sfx_smc_schema *value_schema,
    struct sfx_smc_column_filter *column_filter,
    struct sfx_smc_row_filter *row_filter,
    struct sfx_smc_lba_vec *lba_vec,
    struct sfx_smc_blk_vec *blk_vec,
    struct sfx_smc_query_result *query_result,
    uint64_t *sid);

// return: negative number for error code, other for how many bytes returned.
typedef int (*smc_query_status_fn) (
    const char *dev_id,
    uint64_t sid);

#ifdef __cplusplus
}
#endif

#endif // __SFX_SMC_PROTO_H__
