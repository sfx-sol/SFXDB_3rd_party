// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_ioctl.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_IOCTL_H__
#define __SFX_IOCTL_H__

#include "sfx_types.h"
#include "sfx_api.h"

#define SFX_TEST_WRITE                  0
#define SFX_TEST_READ                   1
#define SFX_SPI_INIT                    2
#define SFX_SPI_INIT_READ_ONLY          3
#define SFX_SPI_EXIT                    4
#define SFX_SPI_WRITE_DATA              5
#define SFX_SPI_NOR_FLASH_READ          6
#define SFX_SPI_ERASE_DATA              7
#define SFX_SPI_NOR_READ_DID            8
#define SFX_VU_GET_FEAT_DATA            9

#define sfx_cmd_nand_reset              0xf0
#define sfx_cmd_aes_program             0xf1

#define sfx_status_t                    SFX_NVME_CMD_RESULT
#define sfx_qstats_t                    SFX_NVME_QSTATS
//#define sfx_check_status_cmd_t          SFX_CHECK_NVME_STATUS

#define SFX_IOCTL_TEST_CMD              _IOWR('S', 0x10, struct sfx_test_cmd)
#define SFX_IOCTL_SUBMIT_IO             _IOWR('S', 0x11, struct sfx_userio_cmd)
#define SFX_IOCTL_ASYNC_SUBMIT_IO       _IOWR('S', 0x12, struct sfx_userio_cmd)
#define SFX_IOCTL_CHECK_STATUS          _IOWR('S', 0x13, sfx_status_t)  // use sfx_status as signature, since sfx_check_status_cmd is too large
#define SFX_IOCTL_CONFIG_AES             _IOW('S', 0x14, SFX_AES_CONFIG_CMD)
#define SFX_IOCTL_ADMIN_CMD             _IOWR('S', 0x15, struct nvme_admin_cmd)
#define SFX_IOCTL_ERRORINJECT_CMD       _IOWR('S', 0x16, struct sfx_test_cmd)

#define SFX_IOCTL_LOCK_MEM              _IOWR('S', 0x20, sfx_mem_cmd_t)
#define SFX_IOCTL_UNLOCK_MEM            _IOWR('S', 0x21, sfx_mem_cmd_t)
#define SFX_IOCTL_INIT_CMD              _IOWR('S', 0x22, sfx_mem_cmd_t)
#define SFX_IOCTL_SPLIT_TOKEN           _IOWR('S', 0x23, sfx_tk_spl_cmd_t)
#define SFX_IOCTL_SPLIT_TOKEN_RELEASE   _IOWR('S', 0x24, xt_u64)
#define SFX_IOCTL_USER_SET_PGLIST       _IOWR('S', 0x25, sfx_driver_user_set_pglist_cmd_t)
#define SFX_IOCTL_GET_USER_FREESLOT     _IOWR('S', 0x26, sfx_get_user_freeslot_cmd_t)
#define SFX_IOCTL_GET_FEATURE           _IOWR('S', 0x27, sfx_get_feature_t)
#define SFX_IOCTL_GET_PCI_BUS_INFO		_IOWR('S', 0x28, sfx_get_pci_bus_info_t)
#define SFX_IOCTL_BD_PARAMETERS         _IOWR('S', 0x30, bd_param_t)
#define SFX_IOCTL_CREATE_NVMEQ          _IOWR('S', 0x31, sfx_q_info_t)
#define SFX_IOCTL_DELETE_NVMEQ          _IOWR('S', 0x32, sfx_q_info_t)
#define SFX_IOCTL_CHECK_Q_STATUS        _IOWR('S', 0x33, sfx_status_t)
#ifdef USE_KTIME_CTX
#define SFX_IOCTL_GET_QSTATS            _IOWR('S', 0x99, sfx_qstats_t)
#endif

 #pragma pack(push,1)
struct nvme_additional_smart_log_item {
    xt_u8            key;
    xt_u8            _kp[2];
    xt_u8            norm;
    xt_u8            _np;
    union {
        xt_u8        raw[6];
        struct wear_level {
            xt_u16    min;
            xt_u16    max;
            xt_u16    avg;
        } wear_level ;
        struct thermal_throttle {
            xt_u8    pct;
            xt_u32    count;
        } thermal_throttle;
    };
    xt_u8            _rp;
};
#pragma pack(pop)

struct nvme_additional_smart_log {
    struct nvme_additional_smart_log_item    program_fail_cnt;
    struct nvme_additional_smart_log_item    erase_fail_cnt;
    struct nvme_additional_smart_log_item    wear_leveling_cnt;
    struct nvme_additional_smart_log_item    e2e_err_cnt;
    struct nvme_additional_smart_log_item    crc_err_cnt;
    struct nvme_additional_smart_log_item    timed_workload_media_wear;
    struct nvme_additional_smart_log_item    timed_workload_host_reads;
    struct nvme_additional_smart_log_item    timed_workload_timer;
    struct nvme_additional_smart_log_item    thermal_throttle_status;
    struct nvme_additional_smart_log_item    retry_buffer_overflow_cnt;
    struct nvme_additional_smart_log_item    pll_lock_loss_cnt;
    struct nvme_additional_smart_log_item    nand_bytes_written;
    struct nvme_additional_smart_log_item    host_bytes_written;
    struct nvme_additional_smart_log_item    raid_recover_cnt; // errors which can be recovered by RAID
    struct nvme_additional_smart_log_item    prog_timeout_cnt;
    struct nvme_additional_smart_log_item    erase_timeout_cnt;
    struct nvme_additional_smart_log_item    read_timeout_cnt;
    struct nvme_additional_smart_log_item    read_ecc_cnt;//retry cnt
};

typedef struct sfx_test_cmd
{
    xt_u32   opcode;
    xt_u32   address;
    xt_u32   length;
    void    *buffer;
} sfx_test_cmd_t;

typedef struct sfx_get_feature
{
    xt_u16   opcode;
    xt_u32   *data;
    xt_u8    len;
} sfx_get_feature_t;

typedef struct {
    xt_u16	bus_domain;
    xt_u16	bus_number;
    xt_u16	dev_slot;
    xt_u16	dev_func;
}pci_bus_info_t;

typedef struct {
    pci_bus_info_t   *info;
    xt_u8    len;
} sfx_get_pci_bus_info_t;

//#define SIMPLE_TEST
#ifdef SIMPLE_TEST
typedef struct sfx_setup_iod_cmd
{
    void * addr_4k;
    void * addr_32k;
} sfx_setup_iod_cmd_t;

#define SFX_IOCTL_SETUP_IOD             _IOWR('S', 0x14, struct sfx_setup_iod_cmd)
#endif

#endif // __SFX_IOCTL_H__
