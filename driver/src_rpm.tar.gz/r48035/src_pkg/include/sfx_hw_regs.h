// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_hw_regs.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_HW_REGS_H__
#define __SFX_HW_REGS_H__

#define PCIE_MAILBOX                0x5000
#define FIRMWARE_VERSION_REG        0x5010
#define FIRMWARE_LOADED             0x5014

#define FIS_LOCAL_ERROR_COUNTER     0x8070
#define FIS_LOCAL_ERROR_RC          0x8074
#define FIS_CSS_ERROR_COUNTER       0x8078
#define FIS_CSS_ERROR_RC            0x807C
#define REG_CMD_SCHEDULE            0x8280
#define FIS_ERA_CREDIT              0x8290
#define FIS_B2N_CREDIT              0x8294
#define PCIE_PLL_LOST_CNT           0x8390
#define COAL_AGG                    0x20110

#define NVME_CMD_CNT                0x20114
#define NVME_CPL_CNT                0x20118
#define NVME_INT_CNT                0x2011c
// queue specified register, 0x2140c is only for erase que, queue 3, to disable throttling
#define REG_Q3_THROTT_CTRL          0x2140c
#define TCNT_CTL_ADDR               0x21030
#define DBELL_TCNT_ADDR             0x21034
#define CPL_TCNT_ADDR               0x21038
#define INTR_TCNT_ADDR              0x2103c
#define NVME_HW_QSIZE_ADMIN         0x21400
#define NVME_HW_QSIZE_WRITE         0x21404
#define NVME_HW_QSIZE_READ          0x21408

#define SCRATCH_LOW                 0x100000
#define SCRATCH_HI                  0x100004
#define SCRATCH_HI_PF_PATTERN       0xbeefbabe
#define REG_IMAGE_VERSION           0x100008
#define SFX_RST_CTRL                0x100010
#define EPS_SOFT_RST                0x100010
#define RST_STATUS                  0x100014
#define POWER_MASK                  0x10003c
#define REG_INTR_MASK               0x100044
#define REG_INTR_SHADOW             0x10004c
#define INTR_RC                     0x100048
#define REG_DEV_FEATURE             0x100054    // See below for device feature check macros
#define REG_NAND_TYPE               0x100058
#define REG_BOARD_TYPE              0x10005c
#define REG_MISC_CONTROL            0x100070
#define READ_REFRESH_CTRL_0         0x1000e0
#define READ_REFRESH_CTRL_1         0x1000e4
#define READ_REFRESH_STAT           0x1000e8

#define SFX_CHIP_SMON_CSR           0x100400
#define REG_FPGA_OVERHEAT_OT        0x100504
#define REG_FPGA_OVERHEAT_UP        0x10054c

#define REG_POWER_DEBOUNCE_CTRL     0x100e20
#define REG_POWER_DEBOUNCE_STATUS   0x100e24

#define SFX_P1_CTRL                 0x101000
#define SFX_P1_EXT_CTRL             0x101004
#define REG_PF_BACKUP_PBA_BASE      (SFX_P1_CTRL + 0x200)
#define REG_PF_RECOVER_MODE         (SFX_P1_CTRL + 0x28)
#define REG_WR_JOB_CHAN             0x101004
#define BMGR_CONTROL_0              0x101008
#define BMGR_CONTROL_1              0x10100c
#define BMGR_CONTROL_2              0x101010
#define CSS_PWRFAIL_ABORT_CTRL      0x101024
#define CMD_MESSAGE                 0x101060
#define CMD_MSG_COUNT               0x101064
#define STAS_MESSAGE                0x101068
#define STAS_MSG_COUNT              0x10106c
#define VREF_TAB_INDEX              0x101108
#define VREF_VAL_L                  0x10110c
#define VREF_VAL_H                  0x101110
#define SCR_SEED_LUT_DIN_L          0x101144
#define SCR_SEED_LUT_DIN_H          0x101148
#define SCR_SEED_LUT_DIN_P          0x10114c
#define SCR_SEED_LUT_DIN_WADDR      0x101140

#define FCE_CONTROL_0               0x101800
#define FCE_CONTROL_1               0x101804
#define SMEM_ACC_CONTROL            0x101808
#define SMEM_ACC_IO                 0x10180C
#define FCE_CONTROL_2               0x101854
#define REG_ECC_CONTROL_0           0x101880
#define NDPHY_CONTROL_0             0x101820
#define NDPHY_CONTROL_1             0x101824
#define NDPHY_CONTROL_2             0x101828
#define REG_SUSP_CTRL               0x1018bc
#define FCE_STATUS_0                0x101900
#define ERASE_PAGE_THR              0x101930
#define REG_RS_TIMER_CTRL0          0x101840
#define REG_RS_TIMER_CTRL1          0x101844
#define REG_RS_TIMER_CTRL3          0x10184c
#define REG_RS_TIMEOUT_CTRL0        0x1018b0
#define REG_RS_TIMEOUT_CTRL1        0x1018b4
#define NDPHY_PLL_LOST_CNT          0x1018F0

/* I2C CSR, 0x100120 - 0x100140 */
#define I2C_CSR                     0x100120
#define I2C_CSR_HIGH                0x100124
#define I2C_ENABLE                  0x100128
#define I2C_ADDR_FOR_WRITE          0x10012c
#define I2C_ADDR_WRITE              0x100130

#define CHIP_RST_CTL                0x00100010

#define CHIP_I2C_MODE               0x00100120
#define CHIP_I2C_IND_CR             0x00100124
#define CHIP_I2C_IND_WDATA          0x00100128
#define CHIP_I2C_IND_ADDR           0x0010012c
#define CHIP_I2C_IND_SR             0x00100130
#define CHIP_I2C_IND_RDATA          0x00100134

#define CHIP_I2C_DIR_GIE           0x00100C1C
#define CHIP_I2C_DIR_ISR           0x00100C20
#define CHIP_I2C_DIR_IER           0x00100C28
#define CHIP_I2C_DIR_SOFTR         0x00100C40
#define CHIP_I2C_DIR_CR            0x00100D00
#define CHIP_I2C_DIR_SR            0x00100D04
#define CHIP_I2C_DIR_TX_FIFO       0x00100D08
#define CHIP_I2C_DIR_RX_FIFO       0x00100D0C
#define CHIP_I2C_DIR_ADR           0x00100D10
#define CHIP_I2C_DIR_TX_FIFO_OCY   0x00100D14
#define CHIP_I2C_DIR_RX_FIFO_OCY   0x00100D18
#define CHIP_I2C_DIR_TEN_ADR       0x00100D1C
#define CHIP_I2C_DIR_RX_FIFO_PIRQ  0x00100D20
#define SFX_CHIP_I2C_CSR           0x100120
#define SFX_CHIP_I2C_CNTR_CSR      0x100124
#define SFX_CHIP_I2C_ADDR_CSR      0x10012c
#define SFX_CHIP_I2C_STAT_CSR      0x100130
#define SFX_CHIP_I2C_RDATA_CSR     0x100134
#define NVME_MI_BRAM_ADDR          0x100d60
#define NVME_MI_BRAM_DATA          0x100d64


/*
 * ---------------------------------------------------------------------------
    2.20 dev_feature
    Name:           dev_feature
    Address:        0x00000054
    Reset Value:    0x00000080 (undefined is taken as 0)
    Access:         read-only
    Description:    Device Features

    Bits    Field name      Access    Reset Description
    ======= =============== ========= ===== ==================================
    [31:31] golden          read-only None  The image is golden image
    [30:30] fastspi         read-only None  Support fast SPI programming
    [29:29] fastspi         read-only None  Support nvme_mi
    [29:11] rsvd0           read-only None  Reserved
    [10:10] LBA_CHK_4B      read-only None  FIS calculate the LBA CRC only on 4B data, not 8B data
     [9:9]  mu_susp_fix     read-only None  Micron B17A device MLC page suspend issue fix support
     [8:8]  rc              read-only None  Row to Column
     [7:7]  I2C_type        read-only 0x1   New I2C controller with Xilinx IP
     [6:6]  uis             read-only None  Unindexed Search
     [5:5]  lbasig          read-only None  LBA Signature
     [4:4]  colstor         read-only None  Column Store
     [3:3]  snappydecomp    read-only None  SNAPPY De- Compression
     [2:2]  gzipcomp2       read-only None  Gzip Compression II
     [1:1]  gzipcomp1       read-only None  Gzip Compression I
     [0:0]  ec              read-only None  EC
 * ---------------------------------------------------------------------------
 */
#define IS_DEV_FEAT_GOLDEN(regval)      (((xt_u32)(regval) & (xt_u32)(1 << 31)) != 0)
#define IS_DEV_FEAT_FASTSPI(regval)     (((xt_u32)(regval) & (xt_u32)(1 << 30)) != 0)
#define IS_DEV_FEAT_NVME_MI(regval)     (((xt_u32)(regval) & (xt_u32)(1 << 29)) != 0)
#define IS_DEV_FEAT_BIGBUF(regval)      (((xt_u32)(regval) & (xt_u32)(1 << 11)) != 0)
#define IS_DEV_FEAT_LBACHK4B(regval)    (((xt_u32)(regval) & (xt_u32)(1 << 10)) != 0)
#define IS_DEV_FEAT_MUSUSPFIX(regval)   (((xt_u32)(regval) & (xt_u32)(1 <<  9)) != 0)
#define IS_DEV_FEAT_RC(regval)          (((xt_u32)(regval) & (xt_u32)(1 <<  8)) != 0)
#define IS_DEV_FEAT_NEWI2C(regval)      (((xt_u32)(regval) & (xt_u32)(1 <<  7)) != 0)
#define IS_DEV_FEAT_UIS(regval)         (((xt_u32)(regval) & (xt_u32)(1 <<  6)) != 0)
#define IS_DEV_FEAT_LBASIG(regval)      (((xt_u32)(regval) & (xt_u32)(1 <<  5)) != 0)
#define IS_DEV_FEAT_COLSTOR(regval)     (((xt_u32)(regval) & (xt_u32)(1 <<  4)) != 0)
#define IS_DEV_FEAT_SNAPPY(regval)      (((xt_u32)(regval) & (xt_u32)(1 <<  3)) != 0)
#define IS_DEV_FEAT_GZIP2(regval)       (((xt_u32)(regval) & (xt_u32)(1 <<  4)) != 0)
#define IS_DEV_FEAT_GZIP1(regval)       (((xt_u32)(regval) & (xt_u32)(1 <<  1)) != 0)
#define IS_DEV_FEAT_EC(regval)          (((xt_u32)(regval) & (xt_u32)(1 <<  0)) != 0)

#endif // __SFX_HW_REGS_H__
