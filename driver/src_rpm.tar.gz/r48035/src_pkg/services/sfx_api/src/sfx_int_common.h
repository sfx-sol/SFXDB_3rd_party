/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_int_common.h
 * ---------------------------------------------------------------------------
 */

#ifndef __SFX_INT_COMMON_H__
#define __SFX_INT_COMMON_H__

#include "sfx_api.h"
#include "sfx_types.h"

void sfx_fill_iocmd(sfx_userio_cmd_t *userCmd, SFX_NVME_IO_CMD *nvmeCmd);
int sfx_base_init(void);
int sfx_submit_issue_core(union handle *hand, sfx_userio_cmd_t *userio_cmd);
int sfx_lock_mem_core(union handle *hand, sfx_mem_cmd_t *cmd);
void sfx_length_one_token_core(union handle *hand, sfx_tk_spl_cmd_t *cmd);
int sfx_split_token_core(union handle *hand, sfx_tk_spl_cmd_t *cmd, xt_u32 *vaddr, xt_u32 length);
int sfx_set_pagelist_core(union handle *hand, void **list, void **token, unsigned count, int type, int offset);
int sfx_get_free_slot_core(union handle *hand, xt_u32 *slotp);
void sfx_fill_iocmd(sfx_userio_cmd_t *userCmd, SFX_NVME_IO_CMD *nvmeCmd);

#endif // __SFX_INT_COMMON_H__
