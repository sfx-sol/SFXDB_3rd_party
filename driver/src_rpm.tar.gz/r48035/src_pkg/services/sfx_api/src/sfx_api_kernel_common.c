/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_api_kernel_common.c
 * ---------------------------------------------------------------------------
 */

#include "sfx_driver_api.h"

struct sfx_dev;
struct sfx_fd;

struct psdev_fd {
	union handle khand;
	int refcnt;
};

// #define SFXAPI_DEBUG

#define FHANDLE_K_TABLE_INITIALIZER                                                                         \
	{                                                                                                   \
		{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
			{ { (void *)-1 }, 0 }, { { (void *)-1 }, 0 }, { { (void *)-1 }, 0 },                \
		{                                                                                           \
			{ (void *)-1 }, 0                                                                   \
		}                                                                                           \
	}
static struct psdev_fd fhandle_k[] = FHANDLE_K_TABLE_INITIALIZER;
// Let the compiler define the table entries based on the initializer.
// Use the CC_ASSERT to ensure we didn't mess up on the number of initializer.
CC_ASSERT(sizeof(fhandle_k) == sizeof(struct psdev_fd) * MAX_NR_DRIVE);

extern sfx_mutex_t dev_mutex_k;

int init_sfx_fd(int minor, struct psdev_fd *psdev_fd_p)
{
	struct sfx_fd *sfd_k = NULL;

	sfx_get_matched_sdev_fd(minor, NULL, &sfd_k);
	if (sfd_k == NULL) {
		sfx_pr_err("%s: Could not get fd from sfx_device[%d]\n", __FUNCTION__, minor);
		return -ENODEV;
	} else {
		psdev_fd_p->khand.fdk = sfd_k;
		sfx_pr_info("%s: fd 0x%p from pci sfx_device[%d]\n", __FUNCTION__, psdev_fd_p->khand.fdk,
			    minor);
		return 0;
	}
}

xt_32 sfx_device_open(const char *dev_name, union handle *file_handle)
{
	int minor;
	xt_32 retval = 0;

	sfx_mutex_lock((sfx_mutex_t *)&dev_mutex_k);
	if (sscanf(dev_name, "/dev/sfx%d", &minor) != 1) {
		sfx_mutex_unlock((sfx_mutex_t *)&dev_mutex_k);
		sfx_pr_err("%s: Invalid device name %s\n", __FUNCTION__, dev_name);
		return -EINVAL;
	}
	if (fhandle_k[minor].khand.fdk == (void *)-1) {
		struct sfx_fd *sfd_k = NULL;
		sfx_get_matched_sdev_fd(minor, NULL, &sfd_k);
		if (fhandle_k[minor].khand.fdk == NULL) {
			sfx_pr_err("%s: Could not get fd from sfx_device[%d]\n", __FUNCTION__, minor);
			retval = -ENODEV;
		} else {
			fhandle_k[minor].khand.fdk = sfd_k;
#ifdef SFXAPI_DEBUG
			sfx_pr_info("%s: Got first fhandle_k[%d].fdk %p\n", __FUNCTION__, minor,
				    fhandle_k[minor].khand.fdk);
#endif
		}
	} else {
#ifdef SFXAPI_DEBUG
		sfx_pr_info("%s: Got existing fhandle_k[%d].fdk %p\n", __FUNCTION__, minor,
			    fhandle_k[minor].khand.fdk);
#endif
	}
	if (!retval) {
		file_handle->fdk = fhandle_k[minor].khand.fdk;
		fhandle_k[minor].refcnt++;
	}
	sfx_mutex_unlock((sfx_mutex_t *)&dev_mutex_k);
#ifdef SFXAPI_DEBUG
	sfx_pr_info("%s: Got kernel handle %p [%d].refcnt %u\n", __FUNCTION__, file_handle->fdk, minor,
		    fhandle_k[minor].refcnt);
#endif

	return retval;
}

xt_32 sfx_device_close(union handle *file_handle)
{
	int i;
	sfx_bool found = false;

	sfx_mutex_lock((sfx_mutex_t *)&dev_mutex_k);
	if (file_handle->fdk <= 0) {
		sfx_pr_err("%s: Invalid fdk\n", __FUNCTION__);
		sfx_mutex_unlock((sfx_mutex_t *)&dev_mutex_k);
		return -EINVAL;
	} else {
#ifdef SFXAPI_DEBUG
		sfx_pr_info("%s: incoming fdk %p\n", __FUNCTION__, file_handle->fdk);
#endif
	}
	for (i = 0; i < MAX_NR_DRIVE; i++) {
		if (fhandle_k[i].khand.fdk < 0) {
			sfx_pr_info("%s: fhandle_k[%d].khand.fdk: Not initialized.\n", __FUNCTION__, i);
			continue;
		}
		if (file_handle->fdk == fhandle_k[i].khand.fdk) {
			fhandle_k[i].refcnt--;
#ifdef SFXAPI_DEBUG
			sfx_pr_info("%s: matched fdk 0x%p fhandle_k[%d].refcnt %u\n", __FUNCTION__,
				    file_handle->fdk, i, fhandle_k[i].refcnt);
#endif
			if (!fhandle_k[i].refcnt) {
				sfx_fd_destroy((struct sfx_fd *)(file_handle->fdk));
				fhandle_k[i].khand.fdk = (void *)-1;
			}
			found = sfx_true;
			break;
		}
	}
	sfx_mutex_unlock((sfx_mutex_t *)&dev_mutex_k);
	if (!found) {
		sfx_pr_err("%s: Not own fd 0x%p\n", __FUNCTION__, file_handle->fdk);
		return -1;
	} else {
		return 0;
	}
}

xt_32 sfx_check_nvme(union handle *hand, SFX_CHECK_NVME_STATUS *status)
{
	xt_32 ret;

	if ((ret = sfx_kernel_check_status(hand->fdk, status))) {
		return ret;
	}
	return 0;
}

xt_32 sfx_check_nvme_q(union handle *hand, SFX_CHECK_NVME_STATUS *status)
{
	xt_32 ret;

	if ((ret = sfx_kernel_check_q_status(hand->fdk, status))) {
		return ret;
	}
	return 0;
}

#ifdef USE_KTIME_CTX
xt_32 sfx_get_qstats(union handle *hand, SFX_GET_QSTATS *qstats)
{
	xt_32 ret;

	if ((ret = sfx_kernel_get_qstats(hand->fdk, qstats))) {
		return ret;
	}
	return 0;
}
#endif

int sfx_submit_issue_core(union handle *hand, sfx_userio_cmd_t *userio_cmd)
{
	return sfx_submit_nvme_io(hand->fdk, userio_cmd, false, sfx_true);
}

xt_32 sfx_config_aes(union handle *hand, SFX_AES_CONFIG_CMD *cmd)
{
	return 0;
}

xt_32 sfx_nand_reset(union handle *hand, SFX_NAND_RESET_CMD *cmd)
{
	return 0;
}

int sfx_lock_mem_core(union handle *hand, sfx_mem_cmd_t *cmd)
{
	return sfx_lock_user_pages_kernel_api(hand->fdk, cmd);
}

xt_32 sfx_unlock_mem(union handle *hand, xt_u32 *paddr)
{
	sfx_mem_cmd_t cmd;

	cmd.token_addr = paddr;

	return sfx_unlock_user_pages_kernel_api(hand->fdk, &cmd);
}

void sfx_length_one_token_core(union handle *hand, sfx_tk_spl_cmd_t *cmd)
{
	sfx_length_one_token_api(hand->fdk, cmd);
}

int sfx_split_token_core(union handle *hand, sfx_tk_spl_cmd_t *cmd, xt_u32 *vaddr, xt_u32 length)
{
	return sfx_split_token_kernel_api(hand->fdk, cmd);
}

int sfx_split_token_release(union handle *hand, void *token)
{
	return sfx_split_token_release_kernel_api(hand->fdk, token);
}

int sfx_set_pagelist_core(union handle *hand, void **list, void **token, unsigned count, int type, int offset)
{
	return sfx_set_pagelist_kernel_api(hand->fdk, list, token, count, type, offset);
}

xt_u32 sfx_get_pci_bar_csts(union handle *hand)
{
	return sfx_get_pci_bar_cts_api(hand->fdk);
}

void sfx_reg_write(union handle *hand, xt_u32 addr, xt_u32 value)
{
	sfx_indirect_write32(hand->fdk, addr, value);
}

xt_32 sfx_reg_read(union handle *hand, xt_u32 addr)
{
	return sfx_indirect_read32(hand->fdk, addr);
}

int sfx_get_free_slot_core(union handle *hand, xt_u32 *slotp)
{
	return sfx_user_get_freeslot_kernel_api(hand->fdk, slotp);
}

xt_32 sfx_get_card_feature(union handle *hand, xt_u16 feat_op, xt_u32 *feat_data, xt_u8 len)
{
	return sfx_kernel_get_feature(hand->fdk, feat_op, feat_data, len);
}

int sfx_capacitor_issue(union handle *hand, xt_u32 op, xt_u32 para)
{
	return sfx_kernel_capacitor_handle(hand->fdk, op, para);
}

xt_u32 sfx_read_power_consumption(union handle *hand)
{
	return sfx_kernel_read_power(hand->fdk);
}

xt_32 sfx_delete_nvmeq(union handle *hand, xt_u8 qid)
{
	return (sfx_free_nvmeq(hand, qid)) ? 0 : -1;
}

/**get submission nvmeq head */
xt_u32 sfx_get_nvmeq_head(union handle *hand, xt_u32 qid)
{
	return sfx_kernel_get_nvmeq_head(hand->fdk, qid);
}
/**get submission nvmeq tail */
xt_u32 sfx_get_nvmeq_tail(union handle *hand, xt_u32 qid)
{
	return sfx_kernel_get_nvmeq_tail(hand->fdk, qid);
}
/**get submission nvmeq depth */
xt_u32 sfx_get_nvmeq_depth(union handle *hand, xt_u32 qid)
{
	return sfx_kernel_get_nvmeq_depth(hand->fdk, qid);
}
/**set submission nvmeq tail, return error code if it failed */
int sfx_set_nvmeq_tail(union handle *hand, xt_u32 qid, xt_u32 tail)
{
	return sfx_kernel_set_nvmeq_tail(hand->fdk, qid, tail);
}

int sfx_nvmeq_reset(union handle *hand, xt_u32 qid)
{
	return sfx_kernel_nvmeq_reset(hand->fdk, qid);
}

xt_u32 sfx_spi_init(union handle *hand)
{
	return sfx_kernel_spi_init(hand->fdk);
}

xt_u32 sfx_spi_init_read_only(union handle *hand)
{
	return sfx_kernel_spi_init_read_only(hand->fdk);
}

void sfx_spi_exit(union handle *hand)
{
	sfx_kernel_spi_exit(hand->fdk);
}

xt_u32 spi_erase_data(union handle *hand, xt_u32 start_addr, xt_u32 len)
{
	return sfx_kernel_spi_erase_data(hand->fdk, start_addr, len);
}

xt_u32 spi_write_data(union handle *hand, xt_u32 start_addr, xt_u32 len, xt_u32 *trans_data)
{
	return sfx_kernel_spi_write_data(hand->fdk, start_addr, len, trans_data);
}

xt_u32 sfx_nor_flash_read(union handle *hand, xt_u32 start_addr, xt_u32 len, xt_u32 *datao)
{
	return sfx_kernel_nor_flash_read(hand->fdk, start_addr, len, datao);
}

xt_u32 sfx_spi_read_nor_did(union handle *hand, xt_u32 len, xt_u32 *datao)
{
	return sfx_kernel_spi_read_nor_did(hand->fdk, len, datao);
}

void sfx_vu_get_feat_data(union handle *hand, xt_u32 *feat_data)
{
	sfx_kernel_vu_get_feat_data(hand->fdk, feat_data);
	return;
}
