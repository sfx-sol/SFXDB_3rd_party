/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2014-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : osutil_kernel.c
 * ---------------------------------------------------------------------------
 */

#include "osutil.h"

int sfx_initlog(enum sfx_logtype log)
{
	// empty body
	return 0;
}

void sfx_closelog(enum sfx_logtype log)
{
	// empty body
}

void sfx_flushlog(enum sfx_logtype log)
{
	// empty body
}

void sfx_panic(xt_u8 ccs_devID, const char *str)
{
	//panic(str);
	//BUG();
	sfx_printk("PANIC:%s!\n", str);
	while (1) {
		// empty body
	}
}

xt_u64 sfx_gettimeus(void)
{
	return sfx_ktime_to_us(sfx_ktime_get());
}

char *log_level_name[] = {
	"CRASH", "ERR", "WARN", "RUN", "INFO", "NONE",
};

void logfile(int loglevel, char *fp, const char *func, int line, int cnt, const char *fmt, ...)
{
	va_list argList;
	char dev_mod_str[512], *p;
	int ret;

	if (loglevel >= MAX_LOG) {
		return;
	}
	switch (loglevel) {
	case LOG_AST:
	case LOG_ERR:
	case LOG_WRN:
	case LOG_INF:
		p = fp; // get rid of path
		while (*fp != '\0') {
			if (*fp == '/') {
				p = fp;
			}
			fp++;
		}
		if (*p == '/') {
			p++;
		}
		ret = sfx_snprintf(dev_mod_str, sizeof(dev_mod_str), "SFXPK:[%s-%s-%s-%d]%s",
				   log_level_name[loglevel], p, func, line, fmt);
		if (ret < 0) {
			sfx_printk("SFXPK:message format error: [%s]\n", dev_mod_str);
			return;
		} else if (ret >= (sizeof(dev_mod_str) - 1)) {
			sfx_printk("SFXPK:message too long: [%s]\n", dev_mod_str);
			return;
		}
		break;
	default:
		sfx_printk("SFXPK:invalid loglevel message [%s]\n", dev_mod_str);
		break;
	}

	va_start(argList, fmt);
	ret = sfx_vprintk(dev_mod_str, argList);
	va_end(argList);
}

xt_u32 sfx_sync_fetch(xt_u32 *pvar)
{
	return __sync_fetch_and_add(pvar, 0);
}

void sfx_sync_set_32bit(xt_u32 *pvar, xt_u32 var)
{
	xt_u32 old_val = __sync_add_and_fetch(pvar, 0);

	while (!__sync_bool_compare_and_swap(pvar, old_val, var)) {
		old_val = __sync_add_and_fetch(pvar, 0);
	}
}

xt_u8 sfx_1byte_set_by_cas(xt_u8 *addr, xt_u8 old_val, xt_u8 new_val)
{
	return __sync_bool_compare_and_swap(addr, old_val, new_val);
}

xt_u32 sfx_4byte_set_by_cas(xt_u32 *addr, xt_u32 old_val, xt_u32 new_val)
{
	return __sync_bool_compare_and_swap(addr, old_val, new_val);
}
