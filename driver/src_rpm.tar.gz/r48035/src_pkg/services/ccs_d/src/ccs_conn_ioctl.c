/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : ccs_conn_ioctl.c
 * ---------------------------------------------------------------------------
 */

#include <asm-generic/ioctl.h>
#ifndef __KERNEL__
#include <sys/ioctl.h>
#endif
#include "sfx_types.h"
#include "osal.h"
#include "ccs_api.h"
#include "ccs_api_conn.h"

/*
 * Push mode
 * Caller, i.e. client, is in userland, converting msg to ioctl
 * Callee, i.e. server, is in kernel, serving ioctl
 */

#ifndef __KERNEL__

/*
 *---------------------------------------------------------------------------
 * Client side
 *---------------------------------------------------------------------------
 */

#include <errno.h>
#include <fcntl.h>

#define NOLOCK /* there is really no lock when this is defined */
#ifdef NOLOCK
#define CONN_LOCK
#define CONN_UNLOCK
#else
#define CONN_LOCK sfx_mutex_lock(&ccs_conn_cl[ccs_dev_id].lock)
#define CONN_UNLOCK sfx_mutex_unlock(&ccs_conn_cl[ccs_dev_id].lock)
#endif
#define ccs_DEVICE_NAME "css"

typedef struct {
	sfx_mutex_t lock;

	xt_u32 is_device_opened;
	int fd;
	xt_u32 seq_num;
	xt_u8 ccs_dev_id;

	int (*client_call)(int msg_id, ccs_message_t *m, int length);

} ccs_conn_client_t;

/*
 * MAX_NR_DRIVE is currently defined as 16. All fields should be initialized to 0 by default.
 */
static ccs_conn_client_t ccs_conn_cl[MAX_NR_DRIVE];

static inline void get_ccs_dev_name(char *dev_name, xt_u8 ccs_dev_id)
{
	if (ccs_dev_id >= MAX_NR_DRIVE) {
		CCS_ERROR("Unexpected ccs_dev_id = %d received\n", ccs_dev_id);
		sfx_assert(0);
	}

	sprintf(dev_name, "/dev/%s%d", ccs_DEVICE_NAME, ccs_dev_id);
}

int ccs_client_p_start(xt_u8 ccs_dev_id)
{
	char ccs_dev_name[80];

	get_ccs_dev_name(ccs_dev_name, ccs_dev_id);

	if (!ccs_conn_cl[ccs_dev_id].is_device_opened) {
		int i;

		sfx_mutex_init(&ccs_conn_cl[ccs_dev_id].lock);

		/* Connect to Server */
		ccs_conn_cl[ccs_dev_id].fd = open(ccs_dev_name, O_RDWR);

		if (ccs_conn_cl[ccs_dev_id].fd == -1) {
			char cmd[128];
			fprintf(stderr, "Could not open %s (%i)\n", ccs_dev_name, errno);
			perror("open error:");

			/* Debug info for Trac 247 */
			printf("Permissions of %s\n", ccs_dev_name);
			sprintf(cmd, "date -Ins; stat %s; date -Ins", ccs_dev_name);
			system(cmd);

			return 1;
		}

		ccs_conn_cl[ccs_dev_id].is_device_opened = 1;
		ccs_conn_cl[ccs_dev_id].seq_num = 0;

		ccs_conn_init(ccs_dev_id, NULL); /* calling cid_init_queues() etc. */
	}

	return !ccs_conn_cl[ccs_dev_id].is_device_opened;
}

static inline xt_u8 get_ccs_dev_id(ccs_message_t *p_msg)
{
	return p_msg->ccs_dev_id;
}

int ccs_client_call(int msg_id, ccs_message_t *m, int length)
{
	int result = 0;
	xt_u8 ccs_dev_id = get_ccs_dev_id(m);

	/* Checking connection with ccs server */
	if (ccs_client_p_start(ccs_dev_id) != 0) {
		CCS_ERROR("Failed to connect server!\n");
		return -1;
	}
	m->msg_id = msg_id;

	CONN_LOCK;
	m->sequence = ccs_conn_cl[ccs_dev_id].seq_num++;
	result = ioctl(ccs_conn_cl[ccs_dev_id].fd, CCS_IOCTL_REQUEST, m);
	CONN_UNLOCK;

	if (result != 0) {
		CCS_INFO("-----ioctl Client: msg 0x%04x result=%d seq:0x%08x\n", msg_id, result, m->sequence);
	}

	return result;
}

int rc_client_call(int msg_id, void *msg, xt_u8 ccs_dev_id)
{
	long result = 0;

	/* Checking connection with ccs server */
	if (ccs_client_p_start(ccs_dev_id) != 0) {
		CCS_ERROR("Failed to connect server!\n");
		return -1;
	}
	CONN_LOCK;
	switch (msg_id) {
	case ccs_func_CCS_RC_Query_Status_Group:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_QUERY_STATUS_GROUP_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_Query_Status:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_QUERY_STATUS_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_Send_Cmd:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_SEND_CMD_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_Open_Session:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_OPEN_SESSION_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_64_Col_Schema:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_64_COL_SCHEMA_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_128_Col_Schema:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_128_COL_SCHEMA_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_256_Col_Schema:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_256_COL_SCHEMA_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_512_Col_Schema:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_512_COL_SCHEMA_REQUEST, msg);
		break;
	case ccs_func_CCS_RC_1024_Col_Schema:
		result = ioctl(ccs_conn_cl[ccs_dev_id].fd, RC_1024_COL_SCHEMA_REQUEST, msg);
		break;
	default:
		CCS_INFO("Unrecognized message id %d!\n", msg_id);
		break;
	}
	CONN_UNLOCK;

	if (result != 0) {
		CCS_INFO("-----ioctl Client: msg 0x%04x result=%d\n", msg_id, result);
	}

	return (int)result;
}

/*
 *---------------------------------------------------------------------------
 * Server side
 *---------------------------------------------------------------------------
 */
#else
#include <linux/uaccess.h>

typedef struct {
	xt_u32 is_connected;
	ccs_request_handler_t h;
	sfx_mutex_t lock;
} ccs_conn_sv_t;

/*
 * MAX_NR_DRIVE is currently defined as 16. All fields should be initialized to 0 by default.
 */
static ccs_conn_sv_t ccs_conn_sv[MAX_NR_DRIVE];

int ccs_response(int cid, void *data)
{
	ccs_message_t *p_msg = data;
	return p_msg->result;
}

/*
 * If not connected, init and register handler
 */
int ccs_conn_loop(xt_u8 ccs_dev_id, ccs_request_handler_t h)
{
	if (!ccs_conn_sv[ccs_dev_id].is_connected) {
		ccs_conn_init(ccs_dev_id, NULL);
		ccs_conn_sv[ccs_dev_id].is_connected = 1;
		ccs_conn_sv[ccs_dev_id].h = h;
		sfx_mutex_init(&ccs_conn_sv[ccs_dev_id].lock);
	}

	return 0;
}

long ccs_conn_ioctl(struct id_item *item, unsigned int cmd, unsigned long arg)
{
	int result = 0;
	int client_id = item->id;
	xt_u8 ccs_dev_id = item->minor;
	void *msg = NULL;

	switch (cmd) {
	case CCS_IOCTL_REQUEST:
		msg = (ccs_message_t *)sfx_malloc(sizeof(ccs_message_t));
		result = copy_from_user(msg, (void *__user)arg, sizeof(ccs_message_t));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		sfx_mutex_lock(&ccs_conn_sv[ccs_dev_id].lock);
		result = ccs_request_handler(client_id, ((ccs_message_t *)msg)->msg_id, msg);
		sfx_mutex_unlock(&ccs_conn_sv[ccs_dev_id].lock);
		((ccs_message_t *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(ccs_message_t));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_QUERY_STATUS_GROUP_REQUEST:
		msg = (rc_message_query_status_group *)sfx_malloc(sizeof(rc_message_query_status_group));
		result = copy_from_user((rc_message_query_status_group *)msg, (void *__user)arg,
					sizeof(rc_message_query_status_group));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_query_status_group *)msg)->msg_id, msg);
		// ((rc_message_query_status_group *)msg)->result = result;
		result = copy_to_user((void *__user)arg, (rc_message_query_status_group *)msg,
				      sizeof(rc_message_query_status_group));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_QUERY_STATUS_REQUEST:
		msg = (rc_message_query_status *)sfx_malloc(sizeof(rc_message_query_status));
		result = copy_from_user((rc_message_query_status *)msg, (void *__user)arg,
					sizeof(rc_message_query_status));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_query_status *)msg)->msg_id, msg);
		// ((rc_message_query_status *)msg)->result = result;
		result = copy_to_user((void *__user)arg, (rc_message_query_status *)msg,
				      sizeof(rc_message_query_status));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_SEND_CMD_REQUEST:
		msg = (rc_message_send_cmd *)sfx_malloc(sizeof(rc_message_send_cmd));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_send_cmd));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_send_cmd *)msg)->msg_id, msg);
		// ((rc_message_send_cmd *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_send_cmd));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_OPEN_SESSION_REQUEST:
		msg = (rc_message_open_session *)sfx_malloc(sizeof(rc_message_open_session));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_open_session));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_open_session *)msg)->msg_id, msg);
		// ((rc_message_open_session *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_open_session));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_64_COL_SCHEMA_REQUEST:
		msg = (rc_message_64_col_schema *)sfx_malloc(sizeof(rc_message_64_col_schema));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_64_col_schema));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_64_col_schema *)msg)->msg_id, msg);
		// ((rc_message_64_col_schema *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_64_col_schema));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_128_COL_SCHEMA_REQUEST:
		msg = (rc_message_128_col_schema *)sfx_malloc(sizeof(rc_message_128_col_schema));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_128_col_schema));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_128_col_schema *)msg)->msg_id, msg);
		// ((rc_message_128_col_schema *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_128_col_schema));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_256_COL_SCHEMA_REQUEST:
		msg = (rc_message_256_col_schema *)sfx_malloc(sizeof(rc_message_256_col_schema));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_256_col_schema));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_256_col_schema *)msg)->msg_id, msg);
		// ((rc_message_256_col_schema *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_256_col_schema));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_512_COL_SCHEMA_REQUEST:
		msg = (rc_message_512_col_schema *)sfx_malloc(sizeof(rc_message_512_col_schema));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_512_col_schema));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_512_col_schema *)msg)->msg_id, msg);
		// ((rc_message_512_col_schema *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_512_col_schema));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	case RC_1024_COL_SCHEMA_REQUEST:
		msg = (rc_message_1024_col_schema *)sfx_malloc(sizeof(rc_message_1024_col_schema));
		result = copy_from_user(msg, (void *__user)arg, sizeof(rc_message_1024_col_schema));
		if (result != 0) {
			goto copy_from_user_fail;
		}
		result = ccs_request_handler(client_id, ((rc_message_1024_col_schema *)msg)->msg_id, msg);
		// ((rc_message_1024_col_schema *)msg)->result = result;
		result = copy_to_user((void *__user)arg, msg, sizeof(rc_message_1024_col_schema));
		if (result != 0) {
			goto copy_to_user_fail;
		}
		break;
	default:
		SFX_ERROR("Unrecognized ioctl cmd %d!\n", cmd);
		return -EFAULT;
	}

	sfx_mfree(msg);
	return 0;

copy_from_user_fail:
	SFX_ERROR("copy_from_user failed, uio=%016lx\n", arg);
	sfx_mfree(msg);
	return -EFAULT;

copy_to_user_fail:
	SFX_ERROR("%s: copy_to_user failed, returning EFAULT\n", __FUNCTION__);
	sfx_mfree(msg);
	return -EFAULT;
}

#endif
