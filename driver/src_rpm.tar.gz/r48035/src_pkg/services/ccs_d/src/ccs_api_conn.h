/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : ccs_api_conn.h
 * ---------------------------------------------------------------------------
 */

#ifndef __CCS_API_IPC_H__
#define __CCS_API_IPC_H__

#include "sfx_types.h"

#define EC_CHUNK_SIZE               (64*1024)
#define COMP_HW_16KB_SHIFT_BITS     (14)
#define COMP_DATA_UNIT_PG_NUM       (4)     /* 16KB data align */
#define EC_DATA_UNIT_PG_NUM         (4)     /* 16KB data align */
#define R2C_DATA_UNIT_PG_NUM        (4)     /* 16KB data align? TODO */

#ifndef MAX_CLIENTS

#define MAX_CLIENTS                 256
#define MSG_CLIENT_ABORT            0xFFFF
#define MSG_OOB_BASE                0x7F00
#define MSG_OOB_DISCONNECT          (MSG_OOB_BASE+0)

typedef enum {
    MSG_CLIENT_SHUTDOWN = 0,
    MSG_CLIENT_INFO,  //Registration
    MSG_CLIENT_CALL,
    MSG_SERVER_INFO_RESPONSE = 0x100,
    MSG_CLIENT_USER_BASE     = 0x1000,
    MSG_SYSTEM_BASE          = MSG_OOB_BASE,
} message_type_t;

#endif // MAX_CLIENTS

typedef enum {
    //ccs_func_base
    ccs_func_Open_ccs_dev,
    ccs_func_IdentifyDevice,
    ccs_func_AllocateMem,
    ccs_func_AllocateMemType,
    ccs_func_AllocateMemSize,
    ccs_func_SetKey,
    ccs_func_ReleaseKey,
    ccs_func_SnapshotTables,

    /*
     * Multi-driver APIs (not added to ccs_server)
     */
    ccs_func_CCS_IdentifyDevice,
    ccs_func_CCS_AppendMem_Async,
    ccs_func_CCS_AllocateMem,        //not supported
    ccs_func_CCS_AllocateMemType,
    ccs_func_CCS_AppendMem,
    ccs_func_CCS_GetCCSCmdStatus,
    ccs_func_CCS_DeallocateMem,
    ccs_func_CCS_TrimMem,
    ccs_func_CCS_SealMem,
    ccs_func_CCS_ReadMem,
    ccs_func_CCS_ReadMem_Async,

    /* CCS DCE related entries including Compression and EC */
    ccs_func_CCS_Comp_Append_Data_Async,
    ccs_func_CCS_Comp_Get_Data_Async,
    ccs_func_CCS_Comp_Append_Get_Data_Async,
    ccs_func_CCS_Comp_Open_Session,
    ccs_func_CCS_Comp_Close_Session,
    ccs_func_CCS_Get_Dev_Count,
    ccs_func_CCS_Comp_Get_Runtime_Status,

    ccs_func_CCS_EC_Append_Data_Async,
    ccs_func_CCS_EC_Get_Data_Async,
    ccs_func_CCS_EC_Open_Session,
    ccs_func_CCS_EC_Close_Session,
    ccs_func_CCS_EC_Get_Runtime_Status,
    ccs_func_CCS_EC_Append_Get_Data_Async,
    ccs_func_CCS_GetECCmdStatus,

    // Reserve specific ID range 0x30~0x4F for RC
    ccs_func_CCS_RC_Open_Session       = 0x30,
    ccs_func_CCS_RC_Send_Cmd           = 0x31,
    ccs_func_CCS_RC_64_Col_Schema      = 0x32,
    ccs_func_CCS_RC_128_Col_Schema     = 0x33,
    ccs_func_CCS_RC_256_Col_Schema     = 0x34,
    ccs_func_CCS_RC_512_Col_Schema     = 0x35,
    ccs_func_CCS_RC_1024_Col_Schema    = 0x36,
    ccs_func_CCS_RC_Query_Status       = 0x37,
    ccs_func_CCS_RC_Query_Status_Group = 0x38,
    ccs_func_CCS_RC_LBA_PBA            = 0x39,

    ccs_func_CCS_DeleteAllData         = 0x51,
    ccs_func_CCS_GetStats,
    ccs_func_CCS_GetParitySizes,
    ccs_func_CCS_get_feature,
    ccs_func_CCS_GetCardSize,
    ccs_func_CCS_SnapshotTables,
    ccs_func_CCS_Abort_Cmd,
    ccs_func_LockMem,
    ccs_func_UnlockMem,

    ccs_func_last_tag            //not supported
} ccs_func_id_t;

// Callback

int ccs_conn_init(int, void *);
int ccs_conn_uninit(int, void *);

// Client

int ccs_client_call(int msg_id, ccs_message_t *m, int length);
// int rc_client_call(int msg_id, void *msg, xt_u8 dev_id);
// Server

typedef int (*ccs_request_handler_t)(int client_id, int msg_id, void *data );

int ccs_conn_loop(xt_u8 ccs_dev_id, ccs_request_handler_t h);
int ccs_response(int cid, void *data);
int ccs_server_loop(xt_u8 ccs_dev_id);
int ccs_request_handler( int client_id, int msg_id, void *data );

#endif // __CCS_API_IPC_H__
