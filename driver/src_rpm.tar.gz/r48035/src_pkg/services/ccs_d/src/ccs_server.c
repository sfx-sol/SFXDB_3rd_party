/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : ccs_server.c
 * ---------------------------------------------------------------------------
 */

#include "sfx_types.h"
#include "osal.h"
#include "ccs_api.h"
#include "ccs_api_conn.h"

/*
 * CCS Server Thunk Layer (manual version)
 */

#define SFX_TAILQ_ENTRY(type) struct list_head
#define SFX_TAILQ_HEAD(type0, type1) typedef struct list_head type0
#define SFX_TAILQ_INIT(pq) ((pq)->next = (pq)->prev = (pq))
#define SFX_TAILQ_INSERT_TAIL(h, n, field) list_add_tail(&((n)->field), (h))
#define SFX_TAILQ_EMPTY(head) list_empty(head)
#define SFX_TAILQ_FIRST(head) (void *)((head)->next)
#define SFX_TAILQ_REMOVE(head, node, field) list_del(&((node)->field))
#define SFX_TAILQ_FOREACH(item, head, field) list_for_each_entry (item, head, field)

#define FTL_MAX_SLOTS 4096

#ifdef NOLOCK
#define CCS_LOCK
#define CCS_UNLOCK
#else
#define CCS_LOCK ccs_server_lock(ctx_ptr)
#define CCS_UNLOCK ccs_server_unlock(ctx_ptr)
#endif

#ifdef NOLOCK
#define LOCK_Q
#define UNLOCK_Q
#else
#define LOCK_Q sfx_mutex_lock(&ctx_ptr->async_cmd_queues_lock)
#define UNLOCK_Q sfx_mutex_unlock(&ctx_ptr->async_cmd_queues_lock)
#endif

SFX_TAILQ_HEAD(async_cmd_slots_head, async_cmd_slot_s);

enum { CID_STATUS_PENDING = 0,
       CID_STATUS_UPDATED,
};

typedef struct async_cmd_slot_s {
	SFX_TAILQ_ENTRY(async_cmd_slot_s) tailq;
	xt_u16 acid;
	xt_u16 cid;
	xt_u8 status;

	xt_u32 result;
	xt_u32 rlen;
} async_cmd_slot_t;

typedef struct ccs_server_ctx_s {
	sfx_mutex_t lock;
	int isLocked;

	xt_u8 ccs_dev_id;

	xt_u16 cid_map[CCS_CLIENT_MAX_CID_SLOTS * MAX_CLIENTS]; /* index: (client_id<<8) | client_cid */

	async_cmd_slot_t async_cmd_slots[FTL_MAX_SLOTS];
	xt_u32 async_cmd_slot_counter; /* to be initialized with FTL_MAX_SLOTS */

	async_cmd_slots_head free_async_cmd_queue;
	async_cmd_slots_head used_async_cmd_queue;

	sfx_mutex_t async_cmd_queues_lock;

	xt_u32 append_sync_counter;
	xt_u32 read_sync_counter;
	xt_u32 append_counter;
	xt_u32 read_counter;
	xt_u32 completion_counter;
	xt_u64 query_counter;

} ccs_server_ctx_t;

typedef struct ccs_server_ctrl_s {
	ccs_server_ctx_t sv_ctx[MAX_NR_DRIVE];
} ccs_server_ctrl_t;

static ccs_server_ctrl_t sv_ctrl;

int ccs_request_handler(int client_id, int msg_id, void *data);

static void async_cmd_init_queues(ccs_server_ctx_t *ctx_ptr);
static async_cmd_slot_t *async_cmd_get(ccs_server_ctx_t *ctx_ptr);
static void async_cmd_put(ccs_server_ctx_t *ctx_ptr, async_cmd_slot_t *pc);

/*
 * ccs server infrastructure functions
 */
static inline void ccs_server_lock(ccs_server_ctx_t *ctx_ptr)
{
	sfx_mutex_lock(&ctx_ptr->lock);
	ctx_ptr->isLocked = 1;
}

static inline void ccs_server_unlock(ccs_server_ctx_t *ctx_ptr)
{
	ctx_ptr->isLocked = 0;
	sfx_mutex_unlock(&ctx_ptr->lock);
}

void async_cmd_init_queues(ccs_server_ctx_t *ctx_ptr)
{
	int i;

	CCS_INFO("Enter\n");

	sfx_mutex_init(&ctx_ptr->async_cmd_queues_lock);

	LOCK_Q;
	SFX_TAILQ_INIT(&ctx_ptr->free_async_cmd_queue);
	SFX_TAILQ_INIT(&ctx_ptr->used_async_cmd_queue);

	ctx_ptr->async_cmd_slot_counter = FTL_MAX_SLOTS; /* to be initialized with FTL_MAX_SLOTS */

	for (i = 0; i < FTL_MAX_SLOTS; i++) {
		ctx_ptr->async_cmd_slots[i].acid = i;
		ctx_ptr->async_cmd_slots[i].status = CID_STATUS_PENDING;

		SFX_TAILQ_INSERT_TAIL(&ctx_ptr->free_async_cmd_queue, &ctx_ptr->async_cmd_slots[i], tailq);
	}

	memset(ctx_ptr->cid_map, 0xFF, sizeof(ctx_ptr->cid_map));

	UNLOCK_Q;

	CCS_INFO("Exit\n");
}

static async_cmd_slot_t *async_cmd_get(ccs_server_ctx_t *ctx_ptr)
{
	async_cmd_slot_t *pc = NULL;

	LOCK_Q;
	if (!SFX_TAILQ_EMPTY(&ctx_ptr->free_async_cmd_queue)) {
		pc = (async_cmd_slot_t *)SFX_TAILQ_FIRST(&ctx_ptr->free_async_cmd_queue);
		SFX_TAILQ_REMOVE(&ctx_ptr->free_async_cmd_queue, pc, tailq);
		SFX_TAILQ_INSERT_TAIL(&ctx_ptr->used_async_cmd_queue, pc, tailq);
		ctx_ptr->async_cmd_slot_counter--;
	} else {
		/* Ok to be here. Error handling with timeout is handled by the caller */
	}
	UNLOCK_Q;

	return pc;
}

static void async_cmd_put(ccs_server_ctx_t *ctx_ptr, async_cmd_slot_t *pc)
{
	LOCK_Q;
	SFX_TAILQ_REMOVE(&ctx_ptr->used_async_cmd_queue, pc, tailq);
	SFX_TAILQ_INSERT_TAIL(&ctx_ptr->free_async_cmd_queue, pc, tailq);
	ctx_ptr->async_cmd_slot_counter++;
	UNLOCK_Q;
}

static inline void async_cmd_get_with_retry(ccs_server_ctx_t *ctx_ptr, async_cmd_slot_t **cmd_pptr)
{
	while ((*cmd_pptr = async_cmd_get(ctx_ptr)) == NULL) {
		CCS_INFO("!!!!Warning... Out of async cmd slot !!!! Wait for unlock!!!\n");
		SFX_MSLEEP(1);
	}
}

static inline ccs_server_ctx_t *get_ccs_server_ctx(xt_u8 ccs_dev_id)
{
	return &sv_ctrl.sv_ctx[ccs_dev_id];
}

static int ccs_sv_ctx_init(xt_u8 ccs_dev_id)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(ccs_dev_id);

	sfx_mutex_init(&ctx_ptr->lock);
	ctx_ptr->isLocked = 0;

	ctx_ptr->ccs_dev_id = ccs_dev_id;

	async_cmd_init_queues(ctx_ptr);

	ctx_ptr->append_sync_counter = 0;
	ctx_ptr->read_sync_counter = 0;
	ctx_ptr->append_counter = 0;
	ctx_ptr->read_counter = 0;
	ctx_ptr->completion_counter = 0;
	ctx_ptr->query_counter = 0;

	return 0;
}

int ccs_conn_init(int ccs_dev_id, void *p)
{
	ccs_sv_ctx_init((xt_u8)ccs_dev_id);

	return 0;
}

int ccs_conn_uninit(int ccs_dev_id, void *p)
{
#ifndef __KERNEL__
	pthread_mutex_destroy(&sv_ctrl.sv_ctx[ccs_dev_id].lock);
#endif
	return 0;
}

int ccs_server_loop(xt_u8 ccs_dev_id)
{
	return ccs_conn_loop(ccs_dev_id, ccs_request_handler);
}

static inline xt_u8 get_ccs_dev_id(ccs_message_t *p_msg)
{
	return p_msg->ccs_dev_id;
}

/*
 * Following are ccs handlers
 */
sfxError IdentifyDevice_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_IdentifyDevice(p_msg->ccs_dev_id);
	CCS_UNLOCK;

	result = ccs_response(client_id, p_msg);

	CCS_INFO("Identify device results %x\n", result);

	return result;
}

sfxError AllocateMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_AllocateMem(p_msg->ccs_dev_id, &p_msg->params.ccs_param_AllocateMem.mid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError AllocateMemType_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_AllocateMemType(p_msg->ccs_dev_id, &p_msg->params.ccs_param_AllocateMem.mid,
					    p_msg->params.ccs_param_AllocateMem.stream);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError AllocateMemSize_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = AllocateMemSize(p_msg->params.ccs_param_AllocateMemSize.memSize,
					&p_msg->params.ccs_param_AllocateMemSize.mid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError GetCardSize_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->params.ccs_param_GetCardSize.size = CCS_GetCardSize(p_msg->ccs_dev_id);
	p_msg->result = NO_ERROR;
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError AppendMem_Async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = CCS_AppendMem_Async(p_msg->ccs_dev_id, p_msg->params.ccs_param_AppendMem_Async.memID,
				     p_msg->params.ccs_param_AppendMem_Async.host_addr,
				     p_msg->params.ccs_param_AppendMem_Async.append_size,
				     p_msg->params.ccs_param_AppendMem_Async.sdp,
				     p_msg->params.ccs_param_AppendMem_Async.keyid, &pc->cid);

	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->append_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError AppendMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_AppendMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_AppendMem.memID,
				      p_msg->params.ccs_param_AppendMem.host_addr,
				      p_msg->params.ccs_param_AppendMem.append_size,
				      p_msg->params.ccs_param_AppendMem.sdp,
				      p_msg->params.ccs_param_AppendMem.keyid,
				      &p_msg->params.ccs_param_AppendMem.wlen);
	sv_ctrl.sv_ctx[ctx_ptr->ccs_dev_id].append_sync_counter++;
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError GetCCSCmdStatus_handler(int client_id, ccs_message_t *p_msg, int check_ec)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));
	int i;

	p_msg->result = 1; /* PENDING. */

	ctx_ptr->query_counter++;

	/*
     * Batch process for all pending async commands
     */
	for (i = 0; i < CCS_CLIENT_MAX_CID_SLOTS; i++) {
		int acid = ctx_ptr->cid_map[(client_id << 8) | i];

		p_msg->params.ccs_param_GetCCSCmdStatus.result[i] = 1; /* Pending in default */
		if (acid != 0xFFFF) {
			async_cmd_slot_t *pc = &ctx_ptr->async_cmd_slots[acid];
			if (pc->status == CID_STATUS_PENDING) { /* Check it if cmd is still pending */
				xt_u32 rlen;

				CCS_LOCK;

				if (check_ec) {
					result = ccs_ni_ec_get_cmd_status(p_msg->ccs_dev_id, pc->cid, &rlen);
				} else {
					result =
						ccs_ni_comp_get_cmd_status(p_msg->ccs_dev_id, pc->cid, &rlen);
				}
				CCS_UNLOCK;

				if (result != 1) {
					pc->result = result;
					pc->rlen = rlen; /* update this before CID_STATUS_UPDATED */
					pc->status = CID_STATUS_UPDATED;
				}
			}

			/*
             * Case 1: updated in original call
             * Case 2: just updated with GetCCSCmdStatus
             */
			if (pc->status == CID_STATUS_UPDATED) {
				p_msg->params.ccs_param_GetCCSCmdStatus.result[i] =
					pc->result; /* | (pc->rlen << 8); */
				p_msg->params.ccs_param_GetCCSCmdStatus.ret_len[i] = pc->rlen;
				p_msg->result = 0;

				/* Cleanup */
				ctx_ptr->cid_map[(client_id << 8) | i] = 0xFFFF;
				pc->status = CID_STATUS_PENDING;
				//CCS_INFO("Put: id:%d free:%d\n", pc->cid, async_cmd_slot_counter);
				ctx_ptr->completion_counter++;
				async_cmd_put(ctx_ptr, pc);
			}
		}
	}

	return ccs_response(client_id, p_msg);
}

sfxError SealMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_SealMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_SealMem.memID);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError DeallocateMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_DeallocateMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_DeallocateMem.memId);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError TrimMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_TrimMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_TrimMem.memId,
				    p_msg->params.ccs_param_TrimMem.length);

	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ReadMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result =
		CCS_ReadMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_ReadMem.memID,
			    p_msg->params.ccs_param_ReadMem.host_addr, p_msg->params.ccs_param_ReadMem.offset,
			    p_msg->params.ccs_param_ReadMem.length, p_msg->params.ccs_param_ReadMem.sdp,
			    p_msg->params.ccs_param_ReadMem.keyid, &p_msg->params.ccs_param_ReadMem.rlen);
	sv_ctrl.sv_ctx[ctx_ptr->ccs_dev_id].read_sync_counter++;
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError get_feature_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = CCS_get_feature(p_msg->ccs_dev_id, p_msg->params.ccs_param_get_feature.FEAT_OP,
					p_msg->params.ccs_param_get_feature.feat_data);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ReadMem_Async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = CCS_ReadMem_Async(p_msg->ccs_dev_id, p_msg->params.ccs_param_ReadMem_Async.memID,
				   p_msg->params.ccs_param_ReadMem_Async.host_addr,
				   p_msg->params.ccs_param_ReadMem_Async.offset,
				   p_msg->params.ccs_param_ReadMem_Async.length,
				   p_msg->params.ccs_param_ReadMem_Async.sdp,
				   p_msg->params.ccs_param_ReadMem_Async.keyid, &pc->cid);

	if (result != 0) {
		//Failure case
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->read_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError Abort_Cmd_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	xt_u16 *cid_map = ctx_ptr->cid_map;

	async_cmd_slot_t *pc = &ctx_ptr->async_cmd_slots[cid_map[(client_id << 8) | p_msg->client_cid]];

	CCS_LOCK;
	result = CCS_Abort_Cmd(p_msg->ccs_dev_id, pc->cid);

	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	CCS_UNLOCK;

	return result;
}

sfxError SetKey_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = SetKey(&p_msg->params.ccs_param_SetKey.key, &p_msg->params.ccs_param_SetKey.keyid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ReleaseKey_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = ReleaseKey(p_msg->params.ccs_param_ReleaseKey.keyid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError DeleteAllData_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	CCS_DeleteAllData(p_msg->ccs_dev_id, p_msg->params.ccs_param_DeleteAllData.option);

	p_msg->result = 0;
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError GetParitySizes_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));
	// Issue native call
	CCS_LOCK;

	result = CCS_GetParitySizes(p_msg->ccs_dev_id, p_msg->params.ccs_param_CCS_GetParitySizes.memID,
				    p_msg->params.ccs_param_CCS_GetParitySizes.parity_sizes);
	CCS_UNLOCK;
	result = ccs_response(client_id, p_msg);

	return result;
}

sfxError GetStats_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	result = CCS_GetStats(p_msg->ccs_dev_id, p_msg->params.ccs_param_GetStats.memID,
			      &p_msg->params.ccs_param_GetStats.stat);
	CCS_UNLOCK;

	result = ccs_response(client_id, p_msg);

	return result;
}

sfxError ccs_comp_append_get_data_async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = ccs_ni_comp_append_get_data_async(
		p_msg->ccs_dev_id, p_msg->params.ccs_param_Comp_Append_Get_Data_Async.sid, &pc->cid,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.append_addr,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.append_length,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.get_addr,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.get_length,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.fuse_flag);

	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->append_counter++;
	ctx_ptr->read_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError ccs_comp_append_data_async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = ccs_ni_comp_append_data_async(p_msg->ccs_dev_id,
					       p_msg->params.ccs_param_Comp_Append_Data_Async.sid, &pc->cid,
					       p_msg->params.ccs_param_Comp_Append_Data_Async.host_addr,
					       p_msg->params.ccs_param_Comp_Append_Data_Async.length,
					       p_msg->params.ccs_param_Comp_Append_Data_Async.fuse_flag);

	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->append_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError ccs_comp_get_data_async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = ccs_ni_comp_get_data_async(p_msg->ccs_dev_id,
					    p_msg->params.ccs_param_Comp_Get_Data_Async.sid, &pc->cid,
					    p_msg->params.ccs_param_Comp_Get_Data_Async.host_addr,
					    p_msg->params.ccs_param_Comp_Get_Data_Async.length,
					    p_msg->params.ccs_param_Comp_Get_Data_Async.fuse_flag);
	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->read_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError ccs_comp_open_session_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = ccs_ni_comp_open_session(p_msg->ccs_dev_id,
						 &p_msg->params.ccs_param_Comp_Open_Session.sid,
						 p_msg->params.ccs_param_Comp_Open_Session.para_0,
						 p_msg->params.ccs_param_Comp_Open_Session.para_1,
						 p_msg->params.ccs_param_Comp_Open_Session.para_2,
						 p_msg->params.ccs_param_Comp_Open_Session.para_3);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ccs_comp_get_runtime_status_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = ccs_ni_comp_get_runtime_status(
		p_msg->ccs_dev_id, &p_msg->params.ccs_param_Comp_Get_Runtime_Status.rt_status);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ccs_comp_close_session_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result =
		ccs_ni_comp_close_session(p_msg->ccs_dev_id, p_msg->params.ccs_param_Comp_Close_Session.sid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ccs_ec_append_get_data_async_handler(int client_id, ccs_message_t *p_msg)
{
	sfxError result;
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	async_cmd_slot_t *pc;

	async_cmd_get_with_retry(ctx_ptr, &pc);

	ctx_ptr->cid_map[(client_id << 8) | p_msg->client_cid] = pc->acid;

	CCS_LOCK;
	result = ccs_ni_ec_append_get_data_async(
		p_msg->ccs_dev_id, p_msg->params.ccs_param_Comp_Append_Get_Data_Async.sid, &pc->cid,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.append_addr,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.append_length,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.get_addr,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.get_length,
		p_msg->params.ccs_param_Comp_Append_Get_Data_Async.fuse_flag);

	if (result != 0) {
		pc->result = result;
		pc->status = CID_STATUS_UPDATED;
	}
	ctx_ptr->append_counter++;
	ctx_ptr->read_counter++;
	CCS_UNLOCK;

	return result;
}

sfxError ccs_ec_open_session_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = ccs_ni_ec_open_session(p_msg->ccs_dev_id,
					       &p_msg->params.ccs_param_EC_Open_Session.sid,
					       p_msg->params.ccs_param_EC_Open_Session.para_0,
					       p_msg->params.ccs_param_EC_Open_Session.para_1,
					       p_msg->params.ccs_param_EC_Open_Session.para_2,
					       p_msg->params.ccs_param_EC_Open_Session.para_3);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ccs_ec_get_runtime_status_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result = ccs_ni_ec_get_runtime_status(
		p_msg->ccs_dev_id, &p_msg->params.ccs_param_EC_Get_Runtime_Status.rt_status);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError ccs_ec_close_session_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_LOCK;
	p_msg->result =
		ccs_ni_ec_close_session(p_msg->ccs_dev_id, p_msg->params.ccs_param_EC_Close_Session.sid);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

r2cStatus ccs_rc_open_session_handler(int client_id, rc_message_open_session *msg)
{
	msg->result = ccs_ni_r2c_open_session(msg->ccs_dev_id, msg->seq_id_used, msg->is_sync, msg->user_buf,
					      &msg->sid);

	return 0;
}

r2cStatus ccs_rc_64_col_schema_handler(int client_id, rc_message_64_col_schema *msg)
{
	msg->result = ccs_ni_r2c_col_schema(msg->ccs_dev_id, msg->sid, msg->key_meta, msg->val_meta,
					    msg->ncol, msg->col_vld, msg->val_col_map, msg->col_type,
					    msg->nblk, msg->cond_num, msg->filter_buf);
	return 0;
}

r2cStatus ccs_rc_128_col_schema_handler(int client_id, rc_message_128_col_schema *msg)
{
	msg->result = ccs_ni_r2c_col_schema(msg->ccs_dev_id, msg->sid, msg->key_meta, msg->val_meta,
					    msg->ncol, msg->col_vld, msg->val_col_map, msg->col_type,
					    msg->nblk, msg->cond_num, msg->filter_buf);
	return 0;
}

r2cStatus ccs_rc_256_col_schema_handler(int client_id, rc_message_256_col_schema *msg)
{
	msg->result = ccs_ni_r2c_col_schema(msg->ccs_dev_id, msg->sid, msg->key_meta, msg->val_meta,
					    msg->ncol, msg->col_vld, msg->val_col_map, msg->col_type,
					    msg->nblk, msg->cond_num, msg->filter_buf);
	return 0;
}

r2cStatus ccs_rc_512_col_schema_handler(int client_id, rc_message_512_col_schema *msg)
{
	msg->result = ccs_ni_r2c_col_schema(msg->ccs_dev_id, msg->sid, msg->key_meta, msg->val_meta,
					    msg->ncol, msg->col_vld, msg->val_col_map, msg->col_type,
					    msg->nblk, msg->cond_num, msg->filter_buf);
	return 0;
}

r2cStatus ccs_rc_1024_col_schema_handler(int client_id, rc_message_1024_col_schema *msg)
{
	msg->result = ccs_ni_r2c_col_schema(msg->ccs_dev_id, msg->sid, msg->key_meta, msg->val_meta,
					    msg->ncol, msg->col_vld, msg->val_col_map, msg->col_type,
					    msg->nblk, msg->cond_num, msg->filter_buf);
	return 0;
}

r2cStatus ccs_rc_send_cmd_handler(int client_id, rc_message_send_cmd *msg)
{
	msg->result = ccs_ni_r2c_send_cmd(msg->ccs_dev_id, msg->schema_id, msg->ncol, msg->sid,
					  msg->fuse_nvme_read, msg->nvme_read_buf, msg->nvme_read_length,
					  msg->fuse_dce, msg->dce_offset, msg->dce_length, msg->fuse_n2b,
					  msg->page_start, msg->page_end, msg->offset_start, msg->offset_end,
					  &msg->aux, msg->is_sync, msg->send_cmd_status);

	return 0;
}

r2cStatus ccs_rc_query_status_handler(int client_id, rc_message_query_status *msg)
{
	msg->result = ccs_ni_r2c_query_status(msg->ccs_dev_id, msg->sid, &msg->user_buf, &msg->ret_len);

	return 0;
}

r2cStatus ccs_rc_query_status_group_handler(int client_id, rc_message_query_status_group *msg)
{
	xt_u16 i;

	for (i = 0; i < msg->sid_cnt; i++) {
		msg->result_array[i] = ccs_ni_r2c_query_status(msg->ccs_dev_id, msg->sid_time_array[i],
							       &msg->user_buf_array[i],
							       &msg->ret_len_array[i]);
	}

	return 0;
}

sfxError Open_ccs_dev_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));

	CCS_INFO("%s, received dev name: %s\n", __FUNCTION__, p_msg->params.ccs_param_Open_ccs_dev.dev_name);

	CCS_LOCK;
	p_msg->result = CCS_Open_ccs_dev(p_msg->params.ccs_param_Open_ccs_dev.dev_name, &p_msg->ccs_dev_id,
					 INVALID_32BIT, NULL, NULL);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError LockMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));
	xt_u32 rcnt;
	xt_u32 *tp;

	CCS_LOCK;
	rcnt = CCS_LockMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_LockMem.vaddr,
			   p_msg->params.ccs_param_LockMem.count, &tp);
#ifndef __KERNEL__
	/* 0 is good else bad */
	p_msg->result = rcnt;
#else
	if (rcnt == p_msg->params.ccs_param_LockMem.count) {
		p_msg->params.ccs_param_LockMem.paddr = tp;
#ifdef LOCKMEM_DEBUG
		sfx_pr_info("%s: ===tp %p msg->LockMem.paddr %p\n", __FUNCTION__, tp,
			    p_msg->params.ccs_param_LockMem.paddr);
#endif
		p_msg->result = 0;
	} else
		p_msg->result = 1;
#endif
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

sfxError UnlockMem_handler(int client_id, ccs_message_t *p_msg)
{
	ccs_server_ctx_t *ctx_ptr = get_ccs_server_ctx(get_ccs_dev_id(p_msg));
	xt_u32 rcnt;

	CCS_LOCK;
	rcnt = CCS_UnlockMem(p_msg->ccs_dev_id, p_msg->params.ccs_param_UnlockMem.paddr);
#ifndef __KERNEL__
	/* 0 is good else bad */
	p_msg->result = rcnt;
#else
	/* >0 is good else bad */
	if (rcnt > 0)
		p_msg->result = 0;
	else
		p_msg->result = 1;
#endif
	CCS_INFO("%s, client_id %d p_msg ccs_dev_id %d paddr 0x%x result %d\n", __FUNCTION__, client_id,
		 p_msg->ccs_dev_id, p_msg->params.ccs_param_LockMem.paddr, p_msg->result);
	CCS_UNLOCK;

	return ccs_response(client_id, p_msg);
}

/*
 * CCS server side entry point to the request handler
 */
int ccs_request_handler(int client_id, int msg_id, void *data)
{
	int result = 0;

	if (msg_id >= MSG_OOB_BASE) {
		//System message
		if (msg_id == MSG_OOB_DISCONNECT) {
			// client_id is disconnected, check if there is any unhandled command
		}
		return result;
	}

	switch (msg_id) {
#ifndef __KERNEL__
	case MSG_CLIENT_ABORT: //Internal debug only
		printf("MSG_CLIENT_ABORT: client %dn", client_id);
		CCS_SnapshotTables(0);
		abort();
#endif
		break;

	case ccs_func_CCS_RC_Query_Status_Group:
		result = ccs_rc_query_status_group_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_Query_Status:
		result = ccs_rc_query_status_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_Open_Session:
		result = ccs_rc_open_session_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_Send_Cmd:
		result = ccs_rc_send_cmd_handler(client_id, data);
		break;
	case ccs_func_LockMem:
		result = LockMem_handler(client_id, data);
		break;
	case ccs_func_UnlockMem:
		result = UnlockMem_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_64_Col_Schema:
		result = ccs_rc_64_col_schema_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_128_Col_Schema:
		result = ccs_rc_128_col_schema_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_256_Col_Schema:
		result = ccs_rc_256_col_schema_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_512_Col_Schema:
		result = ccs_rc_512_col_schema_handler(client_id, data);
		break;
	case ccs_func_CCS_RC_1024_Col_Schema:
		result = ccs_rc_1024_col_schema_handler(client_id, data);
		break;
	case ccs_func_Open_ccs_dev:
		result = Open_ccs_dev_handler(client_id, data);
		break;

	case ccs_func_IdentifyDevice:
	case ccs_func_CCS_IdentifyDevice:
		result = IdentifyDevice_handler(client_id, data);
		break;

	case ccs_func_AllocateMem:
	case ccs_func_CCS_AllocateMem:
		result = AllocateMem_handler(client_id, data);
		break;

	case ccs_func_AllocateMemType:
	case ccs_func_CCS_AllocateMemType:
		result = AllocateMemType_handler(client_id, data);
		break;

	case ccs_func_AllocateMemSize:
		result = AllocateMemSize_handler(client_id, data);
		break;
	case ccs_func_CCS_GetCardSize:
		result = GetCardSize_handler(client_id, data);
		break;

	case ccs_func_CCS_AppendMem_Async:
		result = AppendMem_Async_handler(client_id, data);
		break;

	case ccs_func_CCS_AppendMem:
		result = AppendMem_handler(client_id, data);
		break;

	case ccs_func_CCS_GetCCSCmdStatus:
		result = GetCCSCmdStatus_handler(client_id, data, 0);
		break;

	case ccs_func_CCS_SealMem:
		result = SealMem_handler(client_id, data);
		break;

	case ccs_func_CCS_DeallocateMem:
		result = DeallocateMem_handler(client_id, data);
		break;

	case ccs_func_CCS_TrimMem:
		result = TrimMem_handler(client_id, data);
		break;

	case ccs_func_CCS_ReadMem:
		result = ReadMem_handler(client_id, data);
		break;

	case ccs_func_CCS_ReadMem_Async:
		result = ReadMem_Async_handler(client_id, data);
		break;

	case ccs_func_CCS_Abort_Cmd:
		result = Abort_Cmd_handler(client_id, data);
		break;

	case ccs_func_SetKey:
		//case ccs_func_CCS_SetKey:
		result = SetKey_handler(client_id, data);
		break;

	case ccs_func_ReleaseKey:
		//case ccs_func_CCS_ReleaseKey:
		result = ReleaseKey_handler(client_id, data);
		break;

	case ccs_func_CCS_DeleteAllData:
		result = DeleteAllData_handler(client_id, data);
		break;

	case ccs_func_SnapshotTables:
	case ccs_func_CCS_SnapshotTables:
#ifndef __KERNEL__
		printf("Message SnapshotTable: client %d\n", client_id);
#endif
		CCS_SnapshotTables(0);
		break;

	case ccs_func_CCS_GetParitySizes:
		result = GetParitySizes_handler(client_id, data);
		break;

	case ccs_func_CCS_GetStats:
		result = GetStats_handler(client_id, data);
		break;

	case ccs_func_CCS_get_feature:
		result = get_feature_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Get_Runtime_Status:
		result = ccs_comp_get_runtime_status_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Open_Session:
		result = ccs_comp_open_session_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Close_Session:
		result = ccs_comp_close_session_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Append_Data_Async:
		result = ccs_comp_append_data_async_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Get_Data_Async:
		result = ccs_comp_get_data_async_handler(client_id, data);
		break;

	case ccs_func_CCS_Comp_Append_Get_Data_Async:
		result = ccs_comp_append_get_data_async_handler(client_id, data);
		break;

	case ccs_func_CCS_EC_Get_Runtime_Status:
		result = ccs_ec_get_runtime_status_handler(client_id, data);
		break;

	case ccs_func_CCS_EC_Open_Session:
		result = ccs_ec_open_session_handler(client_id, data);
		break;

	case ccs_func_CCS_EC_Close_Session:
		result = ccs_ec_close_session_handler(client_id, data);
		break;

	case ccs_func_CCS_EC_Append_Get_Data_Async:
		result = ccs_ec_append_get_data_async_handler(client_id, data);
		break;

	case ccs_func_CCS_GetECCmdStatus:
		result = GetCCSCmdStatus_handler(client_id, data, 1);
		break;

	case ccs_func_CCS_EC_Append_Data_Async:
	case ccs_func_CCS_EC_Get_Data_Async:
		break;
	default:
		break;
	}

	return result;
}

#ifndef __KERNEL__

pthread_t g_monitor_thread;
void *thread_monitor()
{
	/* CCS-MD-TODO */
	xt_u8 ccs_dev_id = 0;

	while (1) {
		sleep(10);
		CCS_INFO("AS:%d RS:%d A:%d R:%d C:%d Q:%ld Free_Cmd_Slots:%d\n",
			 sv_ctrl.sv_ctx[ccs_dev_id].append_sync_counter,
			 sv_ctrl.sv_ctx[ccs_dev_id].read_sync_counter,
			 sv_ctrl.sv_ctx[ccs_dev_id].append_counter, sv_ctrl.sv_ctx[ccs_dev_id].read_counter,
			 sv_ctrl.sv_ctx[ccs_dev_id].completion_counter,
			 sv_ctrl.sv_ctx[ccs_dev_id].query_counter,
			 sv_ctrl.sv_ctx[ccs_dev_id].async_cmd_slot_counter);
	}
}

#endif
