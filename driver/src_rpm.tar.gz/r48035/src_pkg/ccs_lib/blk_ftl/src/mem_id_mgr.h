// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : mem_id_mgr.h
//
// ---------------------------------------------------------------------------

#ifndef __MEM_ID_MGR_H__
#define __MEM_ID_MGR_H__

#include "sfx_types.h"
#include "blk_ftl_multidrive.h"
#include "fifo.h"
#include "ccs_api.h"

//for super blk 0 read/write/erase
#define TOTAL_PAGE_PER_BLK                  (sfx_mdrv->blk_ft_cfg.pages_per_blk) //1024
#define TOTAL_PLANE_PER_WRITE               (sfx_mdrv->card_info.num_hw_pl) // 4
#define FOUR_KB_PER_PAGE                    (sfx_mdrv->card_info.num_hw_pt * sfx_mdrv->card_info.num_of)                                     //   4 it is hardware concept , plane is high level, contain several pages
#define FM_PAGE_BIT_SHIFT                   (sfx_mdrv->card_info.sw_off_pg)
#define FOUR_KB_NUM_TWO_PLANE               8

// setting that will change based on drive size and nand configuration
#define MIM_GMEM_ID_SIZE                    HOT_HEADER_SIZE     // 16// 8   // software define header or footer size 4k unit size for mim_mem_id_t
#define MIM_SECTORS_PER_FOUR_KB             8   // 512 bytes per 4k

////////////////////////////////////////////////////////////////////////////////
// MEM_ID PARAMATER
////////////////////////////////////////////////////////////////////////////////
    #define MIM_TOTAL_BLOCK_ALLOCATE_TOSHIBA    3000    //1478 //adp:temporary
    #define MIM_TOTAL_BLOCK_ALLOCATE_MICRO      1500    //1478 //adp:temporary
#if ENABLE_GC_TRIGGER_FASTER
    #define MIM_TOTAL_USER_MEM_ID           43
    #define FAST_CYCLE_MEM_ID                   60
#else
    #define MIM_TOTAL_USER_MEM_ID           (sfx_mdrv->blk_ft_cfg.num_block)    //548  // number of super blk
    #define FAST_CYCLE_MEM_ID                   42
#endif

// (CFG_NUMBER_OF_BLOCK) should be total super block that used for host data, l2p, and recycle,
#define MIM_TOTAL_MEM_ID                    (MIM_TOTAL_USER_MEM_ID + MIM_TOTAL_SYSTEM_MEM_ID)
#define MIM_TOTAL_MEM_ID_ALLOCATE           (MIM_TOTAL_BLOCK_ALLOCATE_TOSHIBA + MIM_TOTAL_SYSTEM_MEM_ID) // static allocate memory for the biggest value of all kind nand
#define MIM_TOTAL_MEM_ID_ALLOCATE_MICRON    (MIM_TOTAL_BLOCK_ALLOCATE_MICRO +  MIM_TOTAL_SYSTEM_MEM_ID) // static allocate memory for the biggest value of all kind nand

// this is not relate to total block, we use max 12 bits to allocate mem_id number in css layer
#define MIM_MEM_ID_DEFAULT_SIZE             (sfx_mdrv->blk_ft_cfg.default_mem_id_size)  //super block size
#define MIM_MEM_ID_SIZE                     (MIM_MEM_ID_DEFAULT_SIZE - MAP_LOG_SIZE - MIM_GMEM_ID_SIZE)

// for 3.2TB, we have 372 mem_id and at least 30 free mem_id for gc
#define MIM_MINIMUM_TOTAL_USER_MEM_ID       402
#define MIM_MINIMUM_TOTAL_USER_MEM_ID_FAST_CYCLE_MODE       15

// this include all user data and journal data
#define MAP_LOGS_PER_MEM_ID_MAX             (279)       // Max value for 12.8TB
#define FOUR_KB_PER_SIXTY_FOUR_MB           ((64 * 1024 * 1024) / 4096)
#define SHIFT_FOUR_KB_PER_SIXTY_FOUR_MB     (14)
#define MASK_OF_FOUR_KB_PER_SIXTY_FOUR_MB   (0xFFFFC000)
#define SIXTY_FOUR_MB_ALIGN_SIZE            ((MIM_MEM_ID_DEFAULT_SIZE % FOUR_KB_PER_SIXTY_FOUR_MB) ? \
                                                (FOUR_KB_PER_SIXTY_FOUR_MB - \
                                                 (MIM_MEM_ID_DEFAULT_SIZE % FOUR_KB_PER_SIXTY_FOUR_MB)) : 0)
#define MAP_LOGS_PER_MEM_ID                 ((MIM_MEM_ID_DEFAULT_SIZE + SIXTY_FOUR_MB_ALIGN_SIZE) / \
                                                FOUR_KB_PER_SIXTY_FOUR_MB)
#define TOTAL_SEAL_MEM_ID_FIFO              (MIM_TOTAL_USER_MEM_ID + 1)
#define TOTAL_SEAL_MEM_ID_FIFO_ALLOCATE     (MIM_TOTAL_BLOCK_ALLOCATE_TOSHIBA+ 1)

#define FOUR_KB                             4096
#define MAPPING_UNIT                        (FOUR_KB * FOUR_KB_PER_MAPPING_UNIT)    //mapping unit size in bytes
#define SYSTEM_WRITE_UNIT                   128     // 512k
#define SYSTEM_WRITE_UNIT_ORDER             7       // 512k
#define GC_CCS_WR_UNIT                      8
#define SYSTEM_WRITE_UNIT_CNT               (SYSTEM_UNIT / SYSTEM_WRITE_UNIT + ((SYSTEM_UNIT % SYSTEM_WRITE_UNIT != 0) ? 1 : 0))
#define MIM_NUMBER_OF_MEM_ID_BITS_TSB       12      // TSB  //CFG_NUMBER_OF_BLOCK_BITS  // this and offset bits need to fit in to 1 linear pba.
#define MIM_NUMBER_OF_MEM_ID_BITS_MICRON    10      // TSB  //CFG_NUMBER_OF_BLOCK_BITS  // this and offset bits need to fit in to 1 linear pba.
#define MIM_NUMBER_OF_MEM_ID_BITS_MICRON_B17A   9       // Micron B17A,
//#define BYTES_PER_PAGE                    (FOUR_KB * FOUR_KB_PER_PAGE)

// for toshiba nand it should be set 12, and micron 10
#define MIM_MAX_MEM_ID_TSB                  ((1 << MIM_NUMBER_OF_MEM_ID_BITS_TSB) - 1)
#define MIM_MAX_MEM_ID_MICRON               ((1 << MIM_NUMBER_OF_MEM_ID_BITS_MICRON) - 1)


#define MIM_TOTAL_MASTER_MEM_ID             2
#define MIM_TOTAL_SYSTEM_MEM_ID             (MIM_TOTAL_MASTER_MEM_ID)
#define MIM_OPEN_FIFO_WAIT_USEC             10

//minus MIM_GMEM_ID_SIZE because we will alway have at least
//MIM_GMEM_ID_SIZE less from header or 32 less from MAP_LOG_SIZE
#define TOTAL_MAP_LOG_ENTRIES               (FOUR_KB_PER_SIXTY_FOUR_MB / FOUR_KB_PER_MAPPING_UNIT - MIM_GMEM_ID_SIZE + 2)   // number of entries to flush to nand a one time

#define FM_USER_AND_SYSTEM_DATA_PER_LOG     (TOTAL_MAP_LOG_ENTRIES * MAPPING_UNIT)      // in bytes

#define MIM_INVALID_MEM_ID_NUMBER           (MIM_TOTAL_MEM_ID + 1)
#define MIM_INVALID_FLASH_MEM_ID            (0xFFFFFFFF)
#define MIM_INVALID_ADDR                    (~0)
#define MIM_INVALID_ADDR_FROM_TRIM_LOG      ((~0)-1)

#define MIM_TOTAL_COLD_STREAM               2
#define MIM_TOTAL_HOT_STREAM                1
#define MIM_TOTAL_OPEN_MEM_ID               1       // total open mem_id per stream
#define MIM_TOTAL_ALLOCATED_MEM_ID_FIFO     16
#define MIM_START_USER_MEM_ID               MIM_TOTAL_SYSTEM_MEM_ID
#define MIM_START_SYSTEM_MEM_ID             (0)
#define MIM_MAX_CCS_MEM_ID_NUMBER           1024

#define CORRUPTED_MAP_LOG                   0x3adbad

#define GET_MEM_ID(var)                     ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                (var).bt.mem_id : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                (var).bm.mem_id : (var).bm1.mem_id))
#define SET_MEM_ID(var,val)                 ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                ((var).bt.mem_id=(val)) : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                ((var).bm.mem_id=(val)) : ((var).bm1.mem_id=(val))))
#define GET_MEM_OF(var)                     ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                (var).bt.offset : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                (var).bm.offset:(var).bm1.offset))
#define SET_MEM_OF(var,val)                 ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                ((var).bt.offset=(val)) : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                ((var).bm.offset=(val)) : ((var).bm1.offset=(val))))
#define OP_MEM_OF(var,op,val)               ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                ((var).bt.offset = (var).bt.offset op (val)) : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                ((var).bm.offset = (var).bm.offset op (val)) : \
                                                ((var).bm1.offset = (var).bm1.offset op (val))))

#define MAP_FROM_TRIM_LOG_FLAG              ((sfx_mdrv->card_info.nand_type == TSB_BICS) ? \
                                                ((1 << (sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_TSB)) - 2) : \
                                                ((sfx_mdrv->card_info.nand_type == MU_L06B) ? \
                                                ((1 << (sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_MICRON)) - 2) : \
                                                ((1 << (sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_MICRON_B17A)) - 2)))

#define COLD_STREAM_SEQUENCE_NUMBER_BIT     (8)
#define HOT_STREAM_SEQUENCE_NUMBER_BIT      (24)
#define MAX_COLD_STREAM_SEQUENCE_NUMBER     ((1 << COLD_STREAM_SEQUENCE_NUMBER_BIT) - 1)

#define FM_FOOTER_SIZE                      FOUR_KB // round up to 4k, sizeof(mim_mem_id_footer_t) is less than 4k
                                                    // footer to record the map log addresses for faster rebuild

#define NS_MAP_SIZE                         8

// currently support only 4k lba
// less than 16TB drive with 4k LBA size, we can use 32bit lba_t, pba_t.
// If drive is larger than 16TB, 32 bit may not fit.
typedef xt_u32 lba_t;

typedef union flat_map_s
{
    struct bit_field_tsb
    {
        lba_t offset :(sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_TSB);          //offset in to the super block
        lba_t mem_id : MIM_NUMBER_OF_MEM_ID_BITS_TSB;               //mem_id is the super block number
    } bt; //toshiba field
    struct bit_field_micro
    {
        lba_t offset :(sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_MICRON);           //offset in to the super block
        lba_t mem_id : MIM_NUMBER_OF_MEM_ID_BITS_MICRON;               //mem_id is the super block number
    } bm; // micron field
    struct bit_field_micro_b17a
    {
        lba_t offset :(sizeof(lba_t) * 8 - MIM_NUMBER_OF_MEM_ID_BITS_MICRON_B17A);           //offset in to the super block
        lba_t mem_id : MIM_NUMBER_OF_MEM_ID_BITS_MICRON_B17A;               //mem_id is the super block number
    } bm1; // micron field
    lba_t addr;            //linear address contains mem_id and offset, need to convert in to pba
} flat_map_t;

typedef enum
{
    MIM_G_MEM_ID                = 0xCAFED00D,       //!< MIM_G_MEM_ID
} MIM_TABLE_ID_E;

enum {
    MIM_WL_HOT_IS_IDLE                = 0,
    MIM_WL_HOT_IS_GCED,
};
// special number to represent different mem_id types
typedef enum
{
    USER_MEM_ID                 = 0x1CEB00DA,   // used by user and gc
    GC_MEM_ID                   = 0x1CCC00CA,
    WL_HOT_MEM_ID               = 0x1BAD0000,   // wl cold
    L2P_TABLE_MEM_ID            = 0xDABBAD00,
    MASTER_MEM_ID               = 0xB105F00D,
         MASTER_MEM_ID_NEW      = 0xB105F00E,
    PFAIL_MEM_ID                = 0xDABBAD01,
} MEM_ID_TYPE_E;

typedef enum
{
    MIM_INVALID_MEM_ID          = 0,
    MIM_ALLOCATED_MEM_ID,
    MIM_OPEN_HOT_MEM_ID,
    MIM_OPEN_COLD_MEM_ID,
    MIM_OPEN_WL_WEM_ID,
    MIM_OPEN_L2P_TABLE_MEM_ID,      // 5

    MIM_OPEN_MASTER_MEM_ID,                 // system MEM_ID
    MIM_OPEN_PFAIL_MEM_ID,                  // system MEM_ID
    MIM_ERASE_PENDING_MASTER_TABLE_MEM_ID,  // system MEM_ID
    MIM_ERASE_PENDING_PFAIL_MEM_ID,         // system MEM_ID

    MIM_SEAL_PENDING_MEM_ID,        // 10
    MIM_SEALED_MEM_ID,
    MIM_GC_CANDIDATE_MEM_ID,
    MIM_SEALED_MASTER_MEM_ID,
    MIM_SEALED_PFAIL_MEM_ID,
    MIM_SEALED_SNAPSHOT_MEM_ID,     // 15
    MIM_GC_DEALLOC_PENDING_MEM_ID,

    MIM_MAX_FREE_SPACE_MEM_ID,
} MEM_ID_STATE_E;

typedef enum
{
    SEAL_REQUIREMENT_CHECK      = 0,
    SEAL_WAIT_USER_MEM_ID,
    SEAL_AND_FLUSH_MASTER,
    SEAL_WAIT_FLUSH_MASTER,
    SEAL_DONE
} SEAL_MEM_ID_STATE_E;

typedef enum
{
        MIM_HOT_STREAM0             = 0,
        MIM_HOT_STREAM1,
        MIM_HOT_STREAM2,
        MIM_HOT_STREAM3,
        MIM_COLD_STREAM_START       = 4,
        WL_HOT_STREAM               = 5,    // note: does not match with ccs, ccs wl stream         = 0xb
        MIM_COLD_GC                 = 6,
        MIM_PFAIL_L2P               = 7,
        MIM_MASTER,
        MIM_MAX_STREAM,
        MIM_CCS_WL_STREAM           = 11,
} MIM_STREAMS;

typedef enum
{
    MIM_COLD_GC_STREAM_0            = 0,
    MIM_COLD_GC_STREAM_1,
    MIM_COLD_GC_STREAM_2,
    MIM_COLD_GC_STREAM_NOT_ALLOTED  = 3,
} GC_STREAMS;

typedef struct mim_param_s
{
    //0 is not a valid sequence number
    xt_u32 open_sequence_number;    // the time when this mem_id is open. Larger number = latest mem_id

    xt_u32 flash_mgr_mem_id :16;    // ccs mem_id, only need 4K or 12 bit max, can reduce if other need more bits
    MEM_ID_STATE_E state :5;
    MIM_STREAMS stream :4;          //stream number used to separate hot/cold data
    SEAL_MEM_ID_STATE_E seal_state :4;
    GC_STREAMS gc_stream :2;

    xt_u32 :0;
} mim_param_t;

typedef struct mim_param_not_power_safe_s
{
    sfx_atomic_t free_space;        //for gc
    sfx_atomic_t append_point;      // new write append point.--page number
    // may reduce because of padding. total size of the mem_id not include footer and last map log
    sfx_atomic_t size;
    sfx_atomic_t commited_wr_count; // number of 4k finished write to flash
    sfx_atomic_t commited_maplog_offset;
    sfx_atomic_t flush_map_log_pending;
    sfx_atomic_t maplog_smt_offset;
    sfx_atomic_t maplog_count_offset;
    sfx_atomic_t last_ml_stat;
    xt_u32 padding_size;
} mim_param_not_power_safe_t;

typedef enum
{
    MIM_0_INIT,
    MIM_1_IDLE,
    MIM_2_FACTORY_INIT,
    MIM_4_OPEN_MEM_ID,
    MIM_5_SEALING_MEM_ID,
    MIM_8_STOP_MEM_ID_PENDING,
    MIM_9_STOP_MEM_ID_SUCCESS,
} MEM_ID_MGR_STATE_E;

typedef enum
{
    INTERLEAVE_ML = 0,
    COMPACT_ML,
} MAP_LOG_TYPE;

typedef enum
{
    MAP_LOG_TABLE               = 0xABBB10CC,
    MAP_LOG_TABLE_SUPPORT_TYPE  = 0xABBB10CD,

    //bump this value up if you change the footer format to make it backward compatible
    MAP_LOG_ADDRESS_TABLE       = 0xAABB100E,

    L2P_MEM_ID_FOOTER           = 0xAADB100C
} FM_TABLE_ID_E;

typedef struct mim_mem_id_footer_s
{
    FM_TABLE_ID_E id;
    xt_u64 time_stamp;
    flat_map_t map_log[MAP_LOGS_PER_MEM_ID_MAX];
    xt_u32 size[MAP_LOGS_PER_MEM_ID_MAX];
    xt_u32 current_entry;
    //for hot stream ml type, INTERLEAVE or COMPACT
    xt_u8 type[MAP_LOGS_PER_MEM_ID_MAX];
} mim_mem_id_footer_t;

typedef struct mim_free_space_per_map_log_s
{
    //record free space for each 64MB section in mem id
    sfx_atomic_t entry[MAP_LOGS_PER_MEM_ID_MAX + 1];
} mim_free_space_per_map_log_t;

typedef struct hot_rd_s {
    xt_32 hot_rd[MIM_TOTAL_MEM_ID_ALLOCATE];
} sfx_hot_rd_t;

typedef struct mim_mem_id_not_psafe_s
{
    xt_u32 rebuild_system_table_done;
    sfx_mutex_t gseal_lock;
    xt_u32 mim_need_wake_up;
    xt_u32 is_mim_sleeping;
    xt_u32 is_mim_init_done;
    sfx_mutex_t mim_state_lock;
#ifdef __SFX_KERNEL__
    sfx_wait_queue_head_t mem_id_mgr_thread_wait;
#endif

#ifndef __SFX_KERNEL__
    sfx_mutex_t mim_sleep_lock;
#endif
    sfx_percpu_blk_log sfxblk_log;
#ifdef SFX_LINUX
    sfx_hot_rd_t __percpu *hot_rd;
#else
    sfx_atomic_t hot_rd[MIM_TOTAL_MEM_ID_ALLOCATE];     //hot read pending in mem_id, should not dealloc
#endif
#if ENABLE_FREE_SPACE_OPTIMIZE
    mim_free_space_per_map_log_t *pfree_space;
#endif
    xt_u32 total_skip_section;
    xt_u32 *pdummy_data;
    sfx_atomic_t need_alloc[MIM_MAX_STREAM];
    sfx_mutex_t open_sequence_lock;
    sfx_spinlock_t open_fifo_lock;
    xt_u32 seal_mid_master_mid_append_point;
} mim_mem_id_not_psafe_t;

typedef struct map_log_entry_s
{
    lba_t       lba;
    //combine multiple lba that are closed together to 1 entries with size
    //to save space for map_log_entry_t
    xt_u32      size : 15;
    xt_u32      is_trim_range_log: 1;
    //1 = combine map log and use map log to recover lba.
    //0 = no combine map log and use 4k header to recover lba
    xt_u32      map_log_combine: 1;
    xt_u32      lens_trim: 15;
} map_log_entry_t;

// this table will be flush periodically to flash
// maximum size for this table should be 32*1024 = 131072
typedef struct map_log_s
{
    FM_TABLE_ID_E id;
    xt_u32 mem_id;

    xt_u32 current_entry     :16;
    MAP_LOG_TYPE type        : 1;
    xt_u32                   : 0;       //padd to 32 bit aligned

    sfx_atomic_t total_lba;  //total lba in all the entries
    xt_u32 offset;     //offset we will save the map log table
    xt_u32 mem_id_sequence_number;
    //up to this point is 24 bytes total, please update this if add more bytes
    //above this line
    map_log_entry_t entry[TOTAL_MAP_LOG_ENTRIES];   //131024 bytes
} map_log_t;

typedef struct block_map_s
{
    xt_u8 preserve;
    xt_u16 block_memid; /* 15 -- 14 for stream id */
    xt_u32 llsid;
} block_map_t;

typedef struct ns_stream_s
{
    xt_u16 sc_bid;              /* current bid for this stream */
    xt_u64 nvm_cnt;
} ns_stream;

typedef struct ns_entry_s
{
    xt_u64 ns_lba_cnt; /* lba count */
    xt_u64 ns_lba_cap;
    xt_u64 ns_lba_shift; /* start lba */
    block_map_t ns_block_map[512];
    xt_u16 ns_blocks; /* eligible block counts */
    xt_u16 ns_cur_bid;
    xt_u16 ns_kv; /* whether this ns is configured with kv */
    xt_u16 ns_id;
    xt_u16 ns_nvm;
    xt_u16 ns_nvm_cnt;
    xt_u16 ns_stream_cnt;
    ns_stream ns_stream[4];
} ns_entry_t;

typedef struct ns_map_s
{
    xt_u32 ns_cnt;
    xt_u32 ns_bmap;
    xt_u64 ns_bd0_edirty; /* end dirty lba for ns1 */
    ns_entry_t ns_entry[4]; /* support up to 4 ns for now per mdrv */
} ns_map_t;

typedef struct mim_mem_id_s_122
{
    //for mem_id header
    //////////////////////////////////////////////////////////////////
    //add new pfail safe variables below this unused[] and shrink this unused[]
    //please make it aligned when add new variables
    xt_u8 unused[2008];
    MIM_TABLE_ID_E id;
    MEM_ID_TYPE_E type;
    MIM_STREAMS stream_sel;
    xt_u32 mim_put_to_sleep_counter;
    //for checking with master to make sure the link is ok
    lba_t map;
    xt_u32 flash_mgr_mem_id;
    xt_u64 time_stamp;                  //biggest number = oldest time
    //////////////////////////////////////////////////////////////////
    MEM_ID_MGR_STATE_E state;
    xt_u32 cur_virgin_mem_id;
    sfx_atomic_t total_free_mem_id;
    FIFO free_fifo;
    FIFO_TYPE free_fifo_array[MIM_TOTAL_BLOCK_ALLOCATE_MICRO]; // for compatible reason, micro should copy MIM_TOTAL_BLOCK_ALLOCATE_MICRON items
    FIFO open_fifo[MIM_MAX_STREAM];
    FIFO_TYPE open_fifo_array[MIM_MAX_STREAM][MIM_TOTAL_OPEN_MEM_ID];
    mim_param_t param[MIM_TOTAL_MEM_ID_ALLOCATE_MICRON];
    xt_u32 current_open_mem_id_sequence_number;
    xt_u32 current_open_hot_mem_id;

    xt_u32 total_user_mem_id;       // total super blk, MIM_TOTAL_USER_MEM_ID
    xt_u32 pages_per_block;         // pages per physical blk, not super blk
    xt_u32 user_mem_id_size;  // for user mem_id only, not system mem_id, MIM_MEM_ID_DEFAULT_SIZE
    xt_u32 user_mem_id_size_without_footer;  // not including footer and last map log
    sfx_blk_log io_smart_log;
    struct persis_pu_res pu_res;
    ns_map_t ns_recover;
    xt_32 sector_size;
    xt_u32 num_mids_per_stream[MIM_COLD_STREAM_START];
    xt_u32 threshold_per_stream[MIM_COLD_STREAM_START];

    // Any structure below this line is not power failure safe
    //nps = not power safe
    mim_param_not_power_safe_t param_nps[MIM_TOTAL_MEM_ID_ALLOCATE];
    mim_mem_id_not_psafe_t non_psafe;
} mim_mem_id_t122;

struct smart_features_t
{
    //blk_ftl_act_config values
        xt_u32 max_write_cmd_pending;
        xt_u32 fm_max_read_cmd_pending;
        xt_u32 act_mode;
        xt_u32 rwr_me;
        xt_u32 gc_start_trigger;
        xt_u32 gc_stop_trigger;

        xt_u32 gc_max_gather_pending;
        //set_non_gc_stream
        xt_u8 non_gc_stream;
        xt_u8 unused[3];

        //set_overprovisioning
        xt_u64 op_val;
        xt_u32 namespace_id;
        xt_u64 sfx_bd_lba_cnt;  /* ns lba cnt */

        //sfx_io_log
        xt_u32 en_req_log;

        //sfx_io_stat
        xt_u32 en_sts;

        //sfx_u2_mode_config
        xt_u32 u2_mode; //1: performance mode; 2: power save mode

        xt_u32 enable_blk_ftl_act_config        :1;
        xt_u32 enable_set_non_gc_stream         :1;
        xt_u32 enable_set_overprovision         :1;
        xt_u32 enable_sfx_io_log                :1;
        xt_u32 enable_sfx_io_stat               :1;
        xt_u32 enable_sfx_u2_mode_config        :1;
        xt_u32 enable_sfx_hw_cmd_scheduler      :1;
        xt_u32 enable_rwr_me                    :1;
        xt_u32 :0; //padding to 32 bit. please add more enable smart feature above

        //can use this for future smart log
        xt_u32 unused_future_smart[20];
};

//added new feature in this table and check if support feature during
//rebuild
struct enable_t
{
    //new features enable for firmware update feature detection
    xt_u64 free_space_pers	:1;	//free space persistent after power cycle feature
    xt_u64 unused 		:63;
};

typedef struct mim_mem_id_s
{
    //for mem_id header
    //////////////////////////////////////////////////////////////////
    //add new pfail safe variables below this unused[] and shrink this unused[]
    //please make it aligned when add new variables
    struct enable_t enable;
    xt_u8 unused[2000];
    MIM_TABLE_ID_E id;
    MEM_ID_TYPE_E type;
    MIM_STREAMS stream_sel;
    xt_u32 mim_put_to_sleep_counter;
    //for checking with master to make sure the link is ok
    lba_t map;
    xt_u32 flash_mgr_mem_id;
    xt_u64 time_stamp;                  //biggest number = oldest time
    //////////////////////////////////////////////////////////////////
    MEM_ID_MGR_STATE_E state;
    xt_u32 cur_virgin_mem_id;
    sfx_atomic_t total_free_mem_id;
    FIFO free_fifo;
    FIFO_TYPE free_fifo_array[MIM_TOTAL_BLOCK_ALLOCATE_TOSHIBA]; // for compatible reason, micro should copy MIM_TOTAL_BLOCK_ALLOCATE_MICRON items
    FIFO open_fifo[MIM_MAX_STREAM];
    FIFO_TYPE open_fifo_array[MIM_MAX_STREAM][MIM_TOTAL_OPEN_MEM_ID];
    mim_param_t param[MIM_TOTAL_MEM_ID_ALLOCATE];
    xt_u32 current_open_mem_id_sequence_number;
    xt_u32 current_open_hot_mem_id;

    xt_u32 total_user_mem_id;       // total super blk, MIM_TOTAL_USER_MEM_ID
    xt_u32 pages_per_block;         // pages per physical blk, not super blk
    xt_u32 user_mem_id_size;  // for user mem_id only, not system mem_id, MIM_MEM_ID_DEFAULT_SIZE
    xt_u32 user_mem_id_size_without_footer;  // not including footer and last map log
    sfx_blk_log io_smart_log;
    struct persis_pu_res pu_res;
    ns_map_t ns_recover;
    xt_32 sector_size;
    xt_u32 threshold_per_stream[MIM_COLD_STREAM_START];
    xt_u32 num_mids_per_stream[MIM_COLD_STREAM_START];
    xt_u64 :0;  //make it aligned to 64 bytes
    struct smart_features_t smart;
    xt_u32 free_space[MIM_TOTAL_MEM_ID_ALLOCATE];
    xt_u32 sequence;    // open sequence when update trim power failure feature
    xt_u32 offset;    // offset in hot block when update trim power failure feature

    // Any structure below this line is not power failure safe
    //nps = not power safe
    xt_u8 pading[64];
    mim_param_not_power_safe_t param_nps[MIM_TOTAL_MEM_ID_ALLOCATE];
    mim_mem_id_not_psafe_t non_psafe;
} mim_mem_id_t;

typedef struct read_entry_s
{
    xt_u32 mim_mem_id;
    xt_u32 mem_id;
    xt_u32 offset;
    xt_u32 length;
    xt_u32 gc_gather_index;

    xt_u32 merge_read;
    xt_u32 read_mask;
    xt_u32 msk_to_lba[FOUR_KB_NUM_TWO_PLANE];
    xt_u32 ini_pba_base;
    xt_u32 pba_base;
    xt_u32 offset_base;
    xt_u32 lba_seq_off;
    xt_u32 first_lba;
} read_entry_t;

typedef struct read_s
{
    xt_32 index;
    xt_u32 merge_read;
    read_entry_t entry[0];
} read_t;

#define MAX_WRITE_LENGTH                (1030) //need to have some extra entry for flush map log

typedef struct write_entry_s
{
    write_callback_context_t shared;
    xt_u32 gc_gather_index :16;
    xt_u32 is_last_map_log :1;
    xt_u32 gc_lba_index :10;
    xt_u32 log_buff_index :2;
    xt_u32 :0;
    read_t *prd_pending;
    void *pmap;
} write_entry_t;

typedef struct write_s
{
    xt_32 index;
    write_entry_t entry[0];
} write_t;

typedef struct write_callback_entry_s
{
    write_callback_context_t shared;    //shared structure for blk ftl and css layer
#if ENABLE_UNIT_TEST
    sfx_lba_list * lba_list;
#endif
    xt_u32      wr_index;
    xt_u32      fifo_buff_index[SYSTEM_UNIT_ALLOCATE/SYSTEM_WRITE_UNIT + ((SYSTEM_UNIT_ALLOCATE % SYSTEM_WRITE_UNIT != 0) ? 1 : 0)];
    void        *pwr_buffer;
    void        *gc;
    sfx_mul_drv *sfx_mdrv;
    xt_u16      cid;
    xt_u16      is_increment_wr_cb;
    sfxError    status;
} write_callback_entry_t;

/*
*/

typedef struct read_callback_s
{
    xt_u32 valid_count;
    read_callback_entry_t *entry;
} read_callback_t;

typedef struct erase_callback_entry_s
{
    xt_u32 mem_id;
    xt_u32 erased_count;
    sfx_mul_drv *sfx_mdrv;
} erase_callback_entry_t;

//circular increment 1
static inline xt_u32 increment(xt_u32 val, xt_u32 max_size)
{
    return ++val >= max_size ? 0 : val;
}

//circular decrement 1
static inline xt_u32 decrement(xt_u32 val, xt_u32 max_size)
{
    return --val >= max_size ? (max_size - 1) : val;
}

sfxError mim_factory_init(sfx_mul_drv *sfx_mdrv);
void mim_thread_wake_up(sfx_mul_drv *sfx_mdrv, xt_u32 debug_loc);
void mim_start_mem_id_mgr(sfx_mul_drv *sfx_mdrv);
sfxError mim_stop_mem_id_mgr(sfx_mul_drv *sfx_mdrv, xt_u32 is_se);
void mim_lock_seal(sfx_mul_drv *sfx_mdrv);
void mim_unlock_seal(sfx_mul_drv *sfx_mdrv);
void mim_set_state(sfx_mul_drv *sfx_mdrv, MEM_ID_MGR_STATE_E state, xt_u32 location);
sfxError mim_deallocate_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 done_mem_id);
void mem_id_mgm_print(sfx_mul_drv *sfx_mdrv);
void mem_id_read_callback_entry_print(sfx_mul_drv *sfx_mdrv, read_callback_entry_t *e);
void mim_fifo_init(sfx_mul_drv *sfx_mdrv, xt_u32 is_factory_init);
sfxError mim_multidrive_init(sfx_mul_drv *sfx_mdrv);
sfxError mim_update_mem_id_size(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, MIM_STREAMS stream);
sfxError mim_decrement_hot_read_pending(sfx_mul_drv *sfx_mdrv, read_t *pread);
void mim_print_mem_id_parameter(sfx_mul_drv *sfx_mdrv, mim_mem_id_t *gpmem_id);
sfxError mim_update_mem_id_parameter(sfx_mul_drv *sfx_mdrv);
sfxError mim_update_open_mem_id_sequence_number(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
void mem_id_open_map_log_print(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
void fm_reset_blk_smart_log(sfx_mul_drv *sfx_mdrv);
void mim_set_mem_id_state(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, MEM_ID_STATE_E state);
void mim_state_spin_lock(sfx_mul_drv *sfx_mdrv, xt_u32 location, unsigned long *pflags);
void mim_state_spin_unlock(sfx_mul_drv *sfx_mdrv, xt_u32 location, unsigned long *pflags);
FIFO_TYPE mim_pull_open_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 stream, unsigned long *pflags);
sfxError mim_push_open_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 stream, xt_u32 mem_id, unsigned long *pflags);
void mim_open_fifo_remove_blk(sfx_mul_drv *sfx_mdrv, xt_u32 stream, xt_u32 mem_id, unsigned long *pflags);
FIFO_TYPE mim_peek_open_fifo(sfx_mul_drv *sfx_mdrv, xt_u32 stream, unsigned long *pflags);
xt_u32 mim_is_open_fifo_empty(sfx_mul_drv *sfx_mdrv, xt_u32 stream, unsigned long *pflags);
xt_u32 mim_is_open_fifo_full(sfx_mul_drv *sfx_mdrv, xt_u32 stream, unsigned long *pflags);
xt_u32 mim_get_open_mem_id(sfx_mul_drv *sfx_mdrv, MIM_STREAMS stream);
sfxError mim_rebuild_global_sequence_number(sfx_mul_drv *sfx_mdrv);
void mim_sync_all_open_hot_mem_id_sequence_number(sfx_mul_drv *sfx_mdrv);
void mim_update_padded_size(sfx_mul_drv *sfx_mdrv, ccs_stats *pstat, xt_u32 mem_id);

#endif // __MEM_ID_MGR_H__
