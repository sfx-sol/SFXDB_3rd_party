// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : flat_map.h
//
// ---------------------------------------------------------------------------

#ifndef __FLAT_MAP_H__
#define __FLAT_MAP_H__

#include "osal.h"
#include "ccs_api.h"
#include "mem_id_mgr.h"
#include "gc.h"
#include "blk_ftl_multidrive.h"
#include "blk_ftl_ops.h"

#ifdef __SFX_KERNEL__
#include "sfx_bd_dev.h"
#define FM_MAX_PADDED_WR_BUFFER_SIZE            (MAX_REQ_SIZE / 8)  //in 4KB unit
#else
#define FM_MAX_PADDED_WR_BUFFER_SIZE            (64)    //in 4KB unit
#endif

//if you see fm anywhere, fm = flat map
#define FM_MAX_READ_L2P_PENDING                 (256)   // min is 2
#define FM_MAX_GC_WRITE_CMD_PENDING             (32)    // min is 2
#define FM_MAX_READ_CMD_PENDING                 (32)    // min is 2
#define FM_MAX_GC_WRITE_CMD_PENDING_ACT_MODE    (4)     // min is 2
#define FM_MAX_READ_CMD_PENDING_ACT_MODE        (16)        // min is 2
#define FM_REBUILD_SEAL_MEMID_UNIT              (16)    // number of parallel sealed memid rebuild unit
#define L2P_SEG_LOCK_SHIFT                      (22)
#define L2P_LOCK_SEGMENT                        (1024)
#define L2P_LOCK_MASK                           (0x3FF)
#define L2P_MAX_BULK_RD_SIZE                    (16) //equal to GC_READ_1MB
#ifdef __SFX_KERNEL__
#define PARALLEL_REBUILD                        1
#else
#define PARALLEL_REBUILD                        0
#endif
#define REBUILD_ACC   //enable rebuild accelerater

#define REBUILD_SEAL_ELEMENT                    (TOTAL_SEAL_MEM_ID_FIFO / FM_REBUILD_SEAL_MEMID_UNIT)
#define MAX_REBUILD_ELEMENT                     ((MIM_TOTAL_MEM_ID_ALLOCATE+1) / FM_REBUILD_SEAL_MEMID_UNIT) /*REBUILD_SEAL_ELEMENT*/ + FM_REBUILD_SEAL_MEMID_UNIT

#define IS_4K_ALIGNED(p)                        ((((long int)p)&0xFFF) == 0)
#define LBA_TRIM_VALUE                          0xffffffff

//this is still here for backward compatible only
//don't set map log type with this in new code
#define REBUILD_ML_COMPACT                      1  // map log compact
#define REBUILD_ML_INTERLEAVE                   2  // map log interleave

#define INVALID_INDEX                           (~0)
#define INVALID_OFFSET                          (~0)
// currently support only 1 open log per stream, will update later
#define TOTAL_OPEN_LOG                          (MIM_MASTER)
#define INVALID_MASTER_VERSION                  0xFFFFFFFF
#define FIRST_MAP_LOG_OFFSET                    (FOUR_KB_PER_SIXTY_FOUR_MB)
#define FIRST_USER_DATA_OFFSET                  (MIM_GMEM_ID_SIZE)
#define FM_DUMMY_DATA                           0xDEADBEEF
#define FM_MAX_SBLK0_READ_SIZE                  8   // in 4k unit
#define FM_MEM_ID_IS_EMPTY                      0xffffff
#define FM_INVALID_LBA                          MIM_INVALID_ADDR
#define FM_READ_LBA_RAID_HEADER                 5   // should be same as RAID_HEADER from CCS layer

#define MAP_LOG_ENTRY_SIZE                      (sizeof(lba_t) + 4)
#define TOTAL_FIRST_FOUR_K_VALID_ENTRY          ((FOUR_KB - 4 - 2 - 2)/MAP_LOG_ENTRY_SIZE)
#define TOTAL_FIRST_PAGE_VALID_ENTRY            (TOTAL_FIRST_FOUR_K_VALID_ENTRY + (3*FOUR_KB)/MAP_LOG_ENTRY_SIZE)

#define MAP_SECTION_SIZE                        (4 + sizeof(lba_t) + sizeof(flat_map_t) + 4 + 4 + 4 + 4 + 4)
#define MAP_SECTION_PADDING                     (MAPPING_UNIT - MAP_SECTION_SIZE)

#define TOTAL_HOT_STREAM_BUFFER                 128       // 132K*128
#define MAP_LOG_MAX_SIZE                        (MAP_LOG_SIZE * FOUR_KB)

/* --------------  ALERT!!!! ----------------
 * fm_userspace_assert is not used for user space coding
 * In kernel coding, please use sfx_ftl_assert().
 *
 * sfx_ftl_assert() will hang the calling thread if the
 *                  thread is private thread;
 *
 * sfx_ftl_assert() will be passed through if the calling
 *                  therad is not private thread, THEREFORE,
 *                  the caller function MUST do error handle
 *                  for sfx_ftl_assert() in this case
 * --------------------------------------------*/

#define fm_userspace_assert(sfx_mdrv, a)                        \
    do {                                                        \
        if ((a) == 0) {                                         \
            mem_id_mgm_print(sfx_mdrv);                         \
            gc_debug_print(sfx_mdrv, sfx_mdrv->gc);             \
            CCS_SnapshotTables(sfx_mdrv->devId);                \
            sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR,         \
                    "Blk FTL assert at function %s line %d\n",  \
                    __func__, __LINE__);                        \
            while((xt_u64)(a) == 0) {                           \
                fm_set_state(sfx_mdrv, FM_ASSERT_STATE);        \
                sfx_usleep(1000);                               \
            }                                                   \
        };                                                      \
    } while(0);

#define sfx_ftl_assert(sfx_mdrv, a)                             \
    ({                                                          \
        if ((a) == 0 && (!sfx_atomic_read(&sfx_mdrv->surprising_remove))) {                                         \
            map_t *gmap = (map_t *)sfx_mdrv->gmap;              \
            gmap->pmaster->state = FM_ASSERT_STATE;             \
            sfx_print((sfx_mdrv)->devId, BLK_SYS, PL_ERR,       \
                    "Blk FTL assert at function %s line %d\n",  \
                    __func__, __LINE__);                        \
            sfx_blk_assert((sfx_mdrv), (xt_u64)(a));            \
            sfx_print((sfx_mdrv)->devId, BLK_SYS, PL_ERR,       \
                    "Blk FTL assert at function %s line %d\n",  \
                    __func__, __LINE__);                        \
        }                                                       \
        ((a) || (sfx_atomic_read(&sfx_mdrv->surprising_remove))) ? NO_ERROR : ERROR_ASSERT;                          \
    })

enum
{
    REBUILD_WORKER_INIT = 0,
    REBUILD_WORKER_SEAL_MID_ACTIVE,
    REBUILD_WORKER_SEAL_MID_FINISH,
    REBUILD_WORKER_FREE_SPACE_ACTIVE,
    REBUILD_WORKER_FREE_SPACE_FINISH,
    REBUILD_WORKER_DONE,
};

typedef struct master_map_s_micron
{
    MEM_ID_TYPE_E       id;                                //id to make sure it is master table
    FIFO                seal_pending_hot_fifo;
    FIFO_TYPE           seal_pending_hot_fifo_array[MIM_TOTAL_HOT_STREAM*MIM_TOTAL_OPEN_MEM_ID];
    FIFO                seal_pending_cold_fifo;
    FIFO_TYPE           seal_pending_cold_fifo_array[MIM_TOTAL_COLD_STREAM*MIM_TOTAL_OPEN_MEM_ID];

    // version with lowest number is the latest copy in super block 0.
    //0xfffffffe is an invalid version number
    xt_u32              version;
    CRASH_LOCATION_T    state;                             // Use for debugging purpose

    // Secure erase
    xt_u32              se_in_progress;
    flat_map_t          l2p_table[L2P_MAX_CH_MICRON];    //address in flash where we save the full l2p table

    lba_t               lba_per_drive;               //l2p table, biggest table, total 4k entries

    flat_map_t          gpmem_id;
    xt_u32              flash_mgr_mem_id_gmem_id;

    //power fail data variables
    xt_u32              is_graceful_shutdown;
    xt_u32              capacity;
} master_map_t_micron;

typedef struct master_map_s
{
    MEM_ID_TYPE_E       id;                                //id to make sure it is master table
    FIFO                seal_pending_hot_fifo;
    FIFO_TYPE           seal_pending_hot_fifo_array[MIM_TOTAL_HOT_STREAM*MIM_TOTAL_OPEN_MEM_ID];
    FIFO                seal_pending_cold_fifo;
    FIFO_TYPE           seal_pending_cold_fifo_array[MIM_TOTAL_COLD_STREAM*MIM_TOTAL_OPEN_MEM_ID];

    // version with lowest number is the latest copy in super block 0.
    //0xfffffffe is an invalid version number
    xt_u32              version;
    CRASH_LOCATION_T    state;                             // Use for debugging purpose

    // Secure erase
    xt_u32              se_in_progress;
    flat_map_t          l2p_table_old[L2P_MAX_CH_MICRON];    //address in flash where we save the full l2p table

    lba_t               lba_per_drive;               //l2p table, biggest table, total 4k entries

    flat_map_t          gpmem_id;
    xt_u32              flash_mgr_mem_id_gmem_id;

    //power fail data variables
    xt_u32              is_graceful_shutdown;
    xt_u32              capacity;
    flat_map_t          l2p_table[L2P_MAX_CH_ALLOCATE];    //address in flash where we save the full l2p table
} master_map_t;

typedef struct system_tables_s
{
    master_map_t        master;
    mim_mem_id_t        gmim;
} system_tables_t;

typedef struct system_tables_s_micron
{
    master_map_t_micron master;
    mim_mem_id_t122     gmim;
} system_tables_t_micron;

typedef struct fm_reverse_lba_s
{
    flat_map_t          start_map;
    xt_u32              end_offset;
    flat_map_t          map[FOUR_KB_PER_SIXTY_FOUR_MB + 3];
    lba_t               lba[FOUR_KB_PER_SIXTY_FOUR_MB + 3];
    xt_u32              is_trim_range_log[FOUR_KB_PER_SIXTY_FOUR_MB + 3];
    xt_u32              lens_trim[FOUR_KB_PER_SIXTY_FOUR_MB + 3];
} fm_reverse_lba_t;

typedef struct seal_memid_rebuild_ctx
{
    void                        *sfx_mdrv;
    xt_u32                      worker_id;
    xt_u32                      nr_memid;
    xt_u32                      map_log_addr_index;
    sfx_atomic_t                worker_state; //0:idle, 1:active, 2:finish
    FIFO                        seal_fifo;
    FIFO_TYPE                   seal_fifo_array[MAX_REBUILD_ELEMENT];
    fm_reverse_lba_t            *preverse;
    struct sfx_blk_ftl_thread   rebuild_worker_thread;
} seal_memid_rebuild_ctx;

typedef struct rebuild_s
{
    xt_32               map_log_addr_index;
    xt_u32              gsd;

    FIFO                seal_fifo;
    FIFO_TYPE           seal_fifo_array[TOTAL_SEAL_MEM_ID_FIFO_ALLOCATE];

    FIFO                open_or_partial_size_fifo;
    FIFO_TYPE           open_or_partial_size_fifo_array[TOTAL_SEAL_MEM_ID_FIFO_ALLOCATE];
    xt_u32              footer_is_corrupted[TOTAL_SEAL_MEM_ID_FIFO_ALLOCATE];

    FIFO                open_fifo[MIM_MAX_STREAM];
    FIFO_TYPE           open_fifo_array[MIM_MAX_STREAM][MIM_TOTAL_OPEN_MEM_ID];
    sfx_atomic_t        count_preverse;
    fm_reverse_lba_t    *preverse;
    xt_u32              num_seal_memid;
    sfx_atomic_t        start_seal_memid;
    sfx_atomic_t        flat_init_preverse;
    seal_memid_rebuild_ctx rebuild_ctx[FM_REBUILD_SEAL_MEMID_UNIT];
    xt_u32              factory_init;
} rebuild_t;

typedef struct fm_log_s
{
    xt_u32              buffer_index;   //for gc only, fixme: need to remove and make same as hot stream
    xt_u32              is_valid;   //for last open map log if it is valid
    xt_u32              is_last_map_log;
    map_log_t           *plog;
} fm_log_t;

typedef struct full_region_trim_record_s
{
    xt_u32              valid;
    xt_u32              mem_id;
    void                *record;
} full_region_trim_record_t;

typedef struct map_s
{
        // pointer to largest flat map table.  Example 2TB drive has about 2GB table size
        // use lba as index into the table, content of table is the mem_id and offset
        void **             pl2p;
        flat_map_t          *g_trim_memid_table;
        sfx_atomic_t        *g_trim_rangle_count;
        full_region_trim_record_t g_full_trim_record[MAX_TRIM_REGION_COUNT];

        xt_u32              fm_max_read_cmd_pending;
        xt_u32              total_rd_cmd_pending;
        xt_u32              total_wr_cmd_pending;
        xt_u32              total_wl_wr_cmd_pending;
        xt_u32              max_write_cmd_pending;
        xt_u32              init_max_read_pending;

#ifndef __SFX_KERNEL__
        sfx_mutex_t         meta_data_thread_lock;
#endif
        sfx_spinlock_t      gl2p_table_mutex;
        sfx_spinlock_t      open_map_log_mutex;
        sfx_spinlock_t      *gl2p_seg_lock;
        sfx_spinlock_t      trim_lock;
        sfx_spinlock_t      *trim_record_lock;
        sfx_spinlock_t      total_rd_cmd_pending_spin_lock;
        sfx_spinlock_t      total_wr_cmd_pending_spin_lock;
        sfx_spinlock_t      total_wl_wr_cmd_pending_spin_lock;
        // Mutex declarations
        sfx_mutex_t         gwr_cmd_lock;
        sfx_mutex_t         fm_buffer_mutex;
        sfx_mutex_t         master_table_mutex;
        sfx_spinlock_t      fm_buffer_sp_lock;
        // log is use to record delta map changes in all open mem_id
        // we will flush when reach some threshold, only use for gc. fixme: need to remove
        // and clean up like in hot stream
        fm_log_t            *popen[TOTAL_OPEN_LOG];

        xt_u32              gc_index;
        xt_u32              wl_cold_index;
        sfx_atomic_t        pending_hot_log_cnt;
        FIFO                flush_pending_hot_log;
        FIFO                flush_pending_last_hot_log;

        FIFO                flush_pending_gc_log;
        FIFO                flush_pending_wl_cold_log;

        FIFO_TYPE           flush_pending_hot_log_array[MAP_LOGS_PER_MEM_ID_MAX];
        FIFO_TYPE           flush_pending_last_hot_log_array[MAP_LOGS_PER_MEM_ID_MAX];
        FIFO_TYPE           flush_pending_gc_log_array[MAP_LOGS_PER_MEM_ID_MAX];
        FIFO_TYPE           flush_pending_wl_cold_array[MAP_LOGS_PER_MEM_ID_MAX];
        xt_u32             *phot_flush_pending[MAP_LOGS_PER_MEM_ID_MAX];
        fm_log_t           *pgc_flush_pending[MAP_LOGS_PER_MEM_ID_MAX];
        fm_log_t           *pwl_cold_flush_pending[MAP_LOGS_PER_MEM_ID_MAX];

        xt_u8              *pbuff[TOTAL_HOT_STREAM_BUFFER];
        FIFO                buffer_index_fifo;
        FIFO_TYPE           buffer_index_fifo_array[TOTAL_HOT_STREAM_BUFFER];

        mim_mem_id_footer_t *popen_footer[MIM_TOTAL_MEM_ID_ALLOCATE];
        // each mem_id contains 1 open maplog to record all the lba inside 1 64MB
        fm_log_t            *popen_map_log[MIM_TOTAL_MEM_ID_ALLOCATE];

        xt_u32              master_mem_id;
        master_map_t        *pmaster;   // master table use for map recovery when power loss
        rebuild_t *         rebuild;
        xt_u32              is_rebuild_done;   //1 = rebuild is done, 0 = not done
        mim_mem_id_footer_t *pfooter[MIM_PFAIL_L2P];  //contains footer for hot stream, gc stream and wl stream
        mim_mem_id_t        *pheader[MIM_PFAIL_L2P];  //contains header for hot stream, gc stream and wl stream
        sfx_atomic_t         meta_data_thread_need_wakeup;
        xt_u32               cur_l2p_memid;
        void                *padded_wr_buff;
} map_t;

typedef enum MASTER_MEM_ID_S
{
    MMI0_1_6TB_or_3_2_TB_MICRON = 0x200,    //blk: 0  pg: 0  lun: 0  ce: 2  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_1_6TB_or_3_2_TB_MICRON = 0x300,    //blk: 0  pg: 0  lun: 0  ce: 3  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI0_6_4_TB_MICRON          = 0x400,    //blk: 0  pg: 0  lun: 0  ce: 4  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_6_4_TB_MICRON          = 0x500,    //blk: 0  pg: 0  lun: 0  ce: 5  ch: 0  page_type: 0  plane: 0  offset: 0

    MMI0_1_6TB_or_3_2_TB_TSB    = 0x400,    //blk: 0  pg: 0  lun: 0  ce: 2  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_1_6TB_or_3_2_TB_TSB    = 0x600,    //blk: 0  pg: 0  lun: 0  ce: 3  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI0_6_4_TB_TSB             = 0x400,    //blk: 0  pg: 0  lun: 0  ce: 2  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_6_4_TB_TSB             = 0x600,    //blk: 0  pg: 0  lun: 0  ce: 3  ch: 0  page_type: 0  plane: 0  offset: 0

    MMI0_1_6TB_B17              = 0x80,     //blk: 0  pg: 0  lun: 0  ce: 2  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_1_6TB_B17              = 0x180,    //blk: 0  pg: 0  lun: 0  ce: 3  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI0_3_2TB_B17              = 0x200,    //blk: 0  pg: 0  lun: 0  ce: 2  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_3_2TB_B17              = 0x300,    //blk: 0  pg: 0  lun: 0  ce: 3  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI0_6_4TB_B17              = 0x400,    //blk: 0  pg: 0  lun: 1  ce: 0  ch: 0  page_type: 0  plane: 0  offset: 0
    MMI1_6_4TB_B17              = 0x500,    //blk: 0  pg: 0  lun: 1  ce: 1  ch: 0  page_type: 0  plane: 0  offset: 0
} MASTER_MEM_ID_E;

typedef enum OP_SETTING_S
{
    OP_DEFAULT,
    OP_FACTORY_INIT,
    OP_NORMAL
} OP_SETTING_E;

typedef enum FLUSH_META_TYPE_S
{
    FM_FLUSH_MAP_LOG_OR_FOOTER = 1,
    FM_FLUSH_HEADER,
} FLUSH_META_TYPE_E;

typedef enum SBLK_0_WRITE_TYPE_S
{
    WRITE_WITH_MIRROR,
    WRITE_MIRROR_ONLY,
    WRITE_ORIGINAL_ONLY,
} SBLK_0_WRITE_TYPE_E;

sfxError fm_init(sfx_mul_drv *sfx_mdrv);
sfxError fm_factory_init(sfx_mul_drv *sfx_mdrv);
sfxError fm_flush_master_table(sfx_mul_drv *sfx_mdrv, CRASH_LOCATION_T state);
int fm_start_rebuild(sfx_mul_drv *sfx_mdrv);
sfxError fm_open_user_mem_id(sfx_mul_drv *sfx_mdrv, write_entry_t *pwrite);
sfxError fm_seal_user_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 mode);
void fm_update_mid_num(sfx_mul_drv *sfx_mdrv, xt_u32 normal_mode, xt_u32 tot_grown_bbd);
sfxError fm_flush_map_log(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 is_last_map_log,
            xt_u32 flush_off, xt_u32 rebuild_open_maplog, xt_u32 ml_type);
CRASH_LOCATION_T fm_get_current_state(sfx_mul_drv *sfx_mdrv);
sfxError fm_blk_write(sfx_mul_drv *sfx_mdrv, lba_t lba, xt_u32 length, write_t *pwrite, MIM_STREAMS stream, xt_u32 nvm);
sfxError fm_blk_write_commit(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 length);
sfxError fm_blk_read(sfx_mul_drv *sfx_mdrv, lba_t lba, xt_u32 length, read_t *pread, xt_u8 compute_mode);
flat_map_t fm_map_lookup(sfx_mul_drv *sfx_mdrv, lba_t lba, xt_u32 is_increment_hot_rd, xt_u8 compute_mode);
sfxError fm_append_mem(sfx_mul_drv *sfx_mdrv, xt_u32 debug_loc, xt_u32 mem_id, xt_u32* host_addr,
        xt_u32 append_size, xt_u32 append_off, xt_u32 sdp, xt_u16 keyid,
        ccs_callback_t cb, void *context, xt_u16 *cid, xt_u8 off_chk, void *lbactx);
sfxError fm_cold_stream_map_log_update(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, void *gc, lba_t start_lba,
        xt_u32 size, xt_u8 map_log_combine, xt_u32 is_trim_range_log, xt_u32 lens_trim);
void fm_create_rebuild_thread(sfx_mul_drv *sfx_mdrv);
void fm_create_meta_data_flush_thread(sfx_mul_drv *sfx_mdrv);
sfxError fm_seal_master_table(sfx_mul_drv *sfx_mdrv);
sfxError fm_start_sealing_snapshot_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
map_t * fm_get_gmap(sfx_mul_drv *sfx_mdrv);
void fm_decrement_pending_wr_cmd(sfx_mul_drv *sfx_mdrv, xt_u32 is_wl);
void fm_decrement_pending_rd_cmd(sfx_mul_drv *sfx_mdrv);
sfxError fm_read_mem(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32* host_addr, xt_u32 offset,
        xt_u32 length, xt_u32 sdp, xt_u16 keyid, ccs_callback_t cb,
        void *context, xt_u16 *cid);
sfxError fm_erase_in_super_blk0_cb(sfxError cmpl_status, void *context);
sfxError fm_erase_in_super_blk0(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, ccs_callback_t cb);
sfxError fm_recover_mem_id_footer(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
xt_u32 fm_allocate_open_map_log_index(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
sfxError fm_flush_mem_id_footer(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
void fm_kernel_schedule(sfx_mul_drv *sfx_mdrv, xt_u32 usec, xt_u32 debug_loc);
void fm_allocate_master_mem_id(sfx_mul_drv *sfx_mdrv);
sfxError fm_wait_for_all_rd_cmd_done(sfx_mul_drv *sfx_mdrv);
void fm_flush_pfail_data(sfx_mul_drv *sfx_mdrv);
void fm_allocate_pfail_mem_id(sfx_mul_drv *sfx_mdrv);
sfxError fm_seal_mem(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 mode);
void fm_set_state(sfx_mul_drv *sfx_mdrv, CRASH_LOCATION_T state);
sfxError fm_wait_for_wr_done(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
void fm_wait_for_available_open_mem_id(sfx_mul_drv *sfx_mdrv, MIM_STREAMS stream);
void fm_stop_flat_map(sfx_mul_drv *sfx_mdrv);
sfxError fm_blk_write_non_atomic(sfx_mul_drv *sfx_mdrv, lba_t lba, xt_u32 length,
    write_t *pwrite, MIM_STREAMS stream, xt_u32 nvm, xt_u32 trim_unalign_write_len);
sfxError fm_read_mem_no_limit(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 *host_addr,
        xt_u32 offset, xt_u32 length, xt_u32 sdp,
        xt_u16 keyid, ccs_callback_t cb, void *context, xt_u16 *cid);
sfxError fm_append_mem_no_limit(sfx_mul_drv *sfx_mdrv, xt_u32 debug_loc, xt_u32 mem_id,
        xt_u32 *host_addr, xt_u32 append_size, xt_u32 append_off,
        xt_u32 sdp, xt_u16 keyid, ccs_callback_t cb, void *context,
        xt_u16 *cid, void *lbactx);

sfxError fm_rebuild_done(sfx_mul_drv *sfx_mdrv);
sfxError fm_rebuild_l2p_table_or_open_mem_id_sequence(sfx_mul_drv *sfx_mdrv);
sfxError fm_map_invalid(sfx_mul_drv *sfx_mdrv, lba_t lba, sfx_range_op *range_op);
sfxError fm_rebuild_system_tables(sfx_mul_drv *sfx_mdrv);
void map_footer_print(sfx_mul_drv *sfx_mdrv);
void map_footer_print_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
void introduce_assert(sfx_mul_drv *sfx_mdrv);
void open_maplog_context_print(sfx_mul_drv *sfx_mdrv);

void *lookup_flat_map(lba_t lba, void **map_array);

void fm_init_system_mem_id(sfx_mul_drv *sfx_mdrv);
void fm_multi_drive_init(sfx_mul_drv *sfx_mdrv);
sfxError fm_wait_for_all_wr_cmd_done(sfx_mul_drv *sfx_mdrv);
sfxError fm_flush_master_table(sfx_mul_drv *sfx_mdrv, CRASH_LOCATION_T state);
sfxError fm_wait_flush_master_done(sfx_mul_drv *sfx_mdrv);
sfxError fm_open_l2p_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
#ifdef TRIM_PF_SUPPORT
sfxError fm_gc_map_update(sfx_mul_drv *sfx_mdrv, lba_t lba,
        flat_map_t new_map, flat_map_t candidate_map, xt_u8 type);
#else
sfxError fm_gc_map_update(sfx_mul_drv *sfx_mdrv, lba_t lba,
        flat_map_t new_map, flat_map_t candidate_map);
#endif
#define IS_CONSECUTIVE_LBA(lba_arr, lba)            ((lba_arr.lba + lba_arr.nr_seg_lba) == (lba))

static inline xt_u32 fm_get_segment_lock_index(lba_t lba)
{
    return ((lba >> L2P_SEG_LOCK_SHIFT) & L2P_LOCK_MASK);
}

static inline void fm_segment_lock_l2p_table(sfx_mul_drv *sfx_mdrv, lba_t lba, unsigned long *pflags)
{
    map_t *gmap = (map_t *)sfx_mdrv->gmap;
    xt_u32 seg_lock_index = ((lba >> L2P_SEG_LOCK_SHIFT) & L2P_LOCK_MASK);
    sfx_spin_lock_irqsave(&gmap->gl2p_seg_lock[seg_lock_index], *pflags);
}

static inline void fm_segment_unlock_l2p_table(sfx_mul_drv *sfx_mdrv, lba_t lba, unsigned long *pflags)
{
    map_t *gmap = (map_t *)sfx_mdrv->gmap;
    xt_u32 seg_lock_index = ((lba >> L2P_SEG_LOCK_SHIFT) & L2P_LOCK_MASK);
    sfx_spin_unlock_irqrestore(&gmap->gl2p_seg_lock[seg_lock_index], *pflags);
}

static inline xt_u32 fm_get_system_mem_id_size(sfx_mul_drv *sfx_mdrv)
{
    mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
    return (gpmem_id->pages_per_block * FOUR_KB_PER_PAGE * TOTAL_PLANE_PER_WRITE);
}
static inline xt_u32 fm_get_system_mem_id_size_blk0(sfx_mul_drv *sfx_mdrv)
{
    return ((sfx_mdrv->card_info.nand_type == MU_B17A)?sfx_mdrv->card_info.b17_logic_page_num * FOUR_KB_PER_PAGE * TOTAL_PLANE_PER_WRITE
                        :sfx_mdrv->card_info.num_pg* FOUR_KB_PER_PAGE * TOTAL_PLANE_PER_WRITE);
}

static inline xt_u32 fm_get_user_mem_id_size(sfx_mul_drv *sfx_mdrv, xt_u32 memid, xt_u64 *size)
{
    mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

    if (memid >= MIM_TOTAL_MEM_ID) {
        return 1;
    }
    *size = sfx_atomic_read(&gpmem_id->param_nps[memid].size);
    return 0;
}

static inline void update_lba_list(sfx_lba_list *lba_list, lba_t lba, xt_u32 len, int next_seg)
{
    if (!lba_list->nr_lba) {  //lba_list is empty
        lba_list->lba_arr[0].lba = lba;
        lba_list->nr_seg++;
    } else {
        if (next_seg    // force to next segment
                || !IS_CONSECUTIVE_LBA(lba_list->lba_arr[lba_list->nr_seg - 1], lba)
                || (lba_list->lba_arr[lba_list->nr_seg - 1].lba == INVALID_32BIT)) {
            // if disconsecutive, assign to new seg
            lba_list->lba_arr[lba_list->nr_seg].lba = lba;
            lba_list->nr_seg++;
        }
    }
    lba_list->lba_arr[lba_list->nr_seg - 1].nr_seg_lba += len;
    lba_list->nr_lba += len;
}

static inline void blk_ftl_handle_freeze_normal_thread(sfx_atomic_t handle_action, xt_u8 devId,
        struct sfx_blk_ftl_thread *sfx_thread)
{
    if (sfx_atomic_read(&handle_action) == SFX_RDONLY_TO_NORMAL
            || sfx_atomic_read(&handle_action) == SFX_FREEZE_TO_NORMAL) {
        sfx_print(devId, BLK_SYS, PL_INF, "%s: To turn thread pid=%u from freeze to normal\n",
                __FUNCTION__, sfx_thread->pid);
    } else {
        sfx_print(devId, BLK_SYS, PL_INF, "%s: To stop thread pid=%u\n",
                __FUNCTION__, sfx_thread->pid);
    }

    sfx_thread_handle_freeze_to_normal(handle_action, sfx_thread);
}

sfxError fm_rebuild_with_reversed_lba_lookup(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id,
          xt_u32 map_index, void *preverse_in, xt_u32 debug_loc);
sfxError fm_allocate_system_mem_id(sfx_mul_drv *sfx_mdrv, MEM_ID_TYPE_E type);
void fm_verify_reverse_lba(sfx_mul_drv *sfx_mdrv, void **pl2p);
sfxError fm_gc_map_log_update(sfx_mul_drv *sfx_mdrv, flat_map_t current_map, gc_t *gc);
void fm_check_free_space_debug(sfx_mul_drv *sfx_mdrv);
sfxError fm_rebuild_read_reversed_lba(sfx_mul_drv *sfx_mdrv, flat_map_t map,
        xt_u32 index, fm_reverse_lba_t *preverse, xt_u32 is_enable_print);
sfxError fm_rebuild_map_log_using_reserved_lba_lookup(sfx_mul_drv *sfx_mdrv,
        map_log_entry_t *pmap_log, flat_map_t map);
xt_u32 fm_linear_search_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 memid);
xt_u32 fm_print_mem_id_in_l2p(sfx_mul_drv *sfx_mdrv, void **ppl2p, xt_u32 suspected_mem_id);
sfxError fm_flush_mem_id_header(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id);
sfxError fm_hot_stream_map_log_update(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, void *pgc,
        lba_t start_lba, xt_u32 size, xt_u8 map_log_combine, xt_u32 offset,
        xt_u32 is_trim_range_log, xt_u32 lens_trim);
sfxError fm_blk_write_callback(sfx_mul_drv *sfx_mdrv, write_callback_context_t *cb);
void fm_meta_data_thread_sleep(sfx_mul_drv *sfx_mdrv, xt_u32 debug_loc);
void fm_meta_data_thread_wake_up(sfx_mul_drv *sfx_mdrv, xt_u32 debug_loc, FLUSH_META_TYPE_E wakeup_type);
void fm_init_open_map_log(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 offset);
xt_u32 fm_find_mim_mem_id_from_ccs_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 css_mem_id, xt_u32 stream);
sfxError fm_verify_total_lba(map_log_t* map_log, sfx_mul_drv* sfx_mdrv);
void fm_debug_map_log_print(sfx_mul_drv *sfx_mdrv, map_log_t *pmap_log, xt_u32 total_lba);
xt_u32 is_secure_erase(sfx_mul_drv *sfx_mdrv);
void fm_print_footer(sfx_mul_drv *sfx_mdrv, mim_mem_id_footer_t *pfooter);
sfxError fm_get_lba(sfx_mul_drv *sfx_mdrv, void *arg);
void fm_append_zero(sfx_mul_drv *sfx_mdrv, xt_u32 open_mem_id, xt_u32 wait_done);
sfxError fm_verify_free_space_in_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 debug_loc);
void fm_flush_dummy_user_data_with_maplog(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id,
                        xt_u32 flag_inc_ap, xt_u32 pf_odd_padding);
sfxError mim_free_trim_record(sfx_mul_drv *sfx_mdrv);
void sfx_compact_maplog(sfx_mul_drv *sfx_mdrv, map_log_t *pmap_log);
void fm_set_fm_max_read_cmd_pending(sfx_mul_drv *sfx_mdrv, xt_u32 value);
void sfx_retrieve_log(sfx_mul_drv *sfx_mdrv);
void fm_set_sfx_io_log(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void fm_set_sfx_io_stat(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void fm_set_u2_mode_config(sfx_mul_drv *sfx_mdrv, xt_u32 val);
void fm_print_smart(sfx_mul_drv *sfx_mdrv);
sfxError fm_verify_op(sfx_mul_drv *sfx_mdrv, xt_u32 namespace_id, xt_u64 val, xt_u64 tot_lba);
sfxError fm_ReadMem(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id,
                           xt_u32* host_addr, xt_u32 offset, xt_u32 length,
                           xt_u32 sdp, xt_u16 keyid, xt_u32 *rlen);
sfxError fm_linear_search_latest_master_mem_id(sfx_mul_drv *sfx_mdrv, xt_u32 *latest_mem_id);
sfxError fm_verify_map_log(sfx_mul_drv *sfx_mdrv, map_log_t *pmap_log, xt_u32 mem_id, xt_u32 location, xt_u32 offset);
sfxError fm_hot_padded_write(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 size);
MAP_LOG_TYPE fm_is_map_log_compact(sfx_mul_drv *sfx_mdrv, xt_u32 mem_id, xt_u32 map_index, sfxError *pstatus);
sfxError fm_sync_mem_id_info_with_ccs(sfx_mul_drv *sfx_mdrv, xt_u32 mim_mem_id);

#endif // __FLAT_MAP_H__
