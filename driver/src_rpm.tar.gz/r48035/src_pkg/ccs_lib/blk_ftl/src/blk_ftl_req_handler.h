// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_req_handler.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_REQ_HANDLER_H__
#define __BLK_FTL_REQ_HANDLER_H__

#include "blk_ftl_coh.h"

void blk_ftl_print_bio_info(sfx_mul_drv *sfx_mdrv, sfx_bio *bio);
sfxError blk_ftl_handle_req(sfx_bd_device *sfx_bd, sfx_bio_request *req, xt_u32 flag);

#endif // __BLK_FTL_REQ_HANDLER_H__
