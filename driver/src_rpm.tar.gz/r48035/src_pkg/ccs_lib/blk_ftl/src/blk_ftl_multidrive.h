// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_multidrive.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_MULTIDRIVE_H__
#define __BLK_FTL_MULTIDRIVE_H__

#include "osal.h"
#include "osutil.h"
#include "ccs_api.h"
#ifndef __KERNEL__
#include "sfx_user_space.h"
#endif

#define KERNEL_PHY_ADDR_FLAT_MAP_BEGIN      (0x100000000UL)
#define OFFSET_4GB                          (0x100000000UL)
#define CRASH_TRIGGER
#define MEASURE_FUNC_TIME                   0
#define FOUR_KB_PER_MAPPING_UNIT            1        // mapping unit size in 4k

#define IPAGE_THROUGHPUT_4KB_1MS_64DIE      ((14 * 1024 * 1024) / (4 * 1024 * 10))
#define IPAGE_THROUGHPUT_4KB_4MS_64DIE      (IPAGE_THROUGHPUT_4KB_1MS_64DIE * 4)
#define IPAGE_THROUGHPUT_4KB_1MS_128DIE     ((17 * 1024 * 1024) / (4 * 1024 * 10))
#define IPAGE_THROUGHPUT_4KB_4MS_128DIE     (IPAGE_THROUGHPUT_4KB_1MS_128DIE * 4)
#define GC_THROUGHPUT_4KB_1MS               ((20 * 1024 * 1024) / (4 * 1024 * 10))
#define GC_THROUGHPUT_4KB_60MS              (GC_THROUGHPUT_4KB_1MS * 4)

#define IPAGE_THROUGHPUT_4KB_1MS_64DIE_BBUF     ((20 * 1024 * 1024) / (4 * 1024 * 10))
#define IPAGE_THROUGHPUT_4KB_4MS_64DIE_BBUF     (IPAGE_THROUGHPUT_4KB_1MS_64DIE_BBUF * 4)
#define IPAGE_THROUGHPUT_4KB_1MS_128DIE_BBUF    ((22 * 1024 * 1024) / (4 * 1024 * 10))
#define IPAGE_THROUGHPUT_4KB_4MS_128DIE_BBUF    (IPAGE_THROUGHPUT_4KB_1MS_128DIE_BBUF * 4)
#define GC_THROUGHPUT_4KB_1MS_BBUF              ((22 * 1024 * 1024) / (4 * 1024 * 10))
#define GC_THROUGHPUT_4KB_60MS_BBUF             (GC_THROUGHPUT_4KB_1MS_BBUF * 4)

// PLEASE NOTE:
// The bio->bi_flags member changed in kernel 4.8.0, reduced from 32-bit into 16-bit unsigned int.
// Also changed was the top 4 bits of the bi_flags - they were also repurposed as an enum field.
// This is the sad and ugly truth in Linux kernel - so the STREAM_ID() macro is disabled for now.
// Using internal structure sfx_request instead.

#define SFX_DSM_DISCARD			5758
#define STREAM_ID_SHIFT                     (22)
#define STREAM_ID_MASK                      (0x3)
#define KV_NVM_ENABLE_OFF                   (20)
#define KV_NVM_INDEX_OFF                    (21)
#define KV_STREAM_OFF                       (22)
#define KV_NVM_ENABLE                       (1 << KV_NVM_ENABLE_OFF)
#define KV_NVM_INDEX                        (1 << KV_NVM_INDEX_OFF)
#define KV_STREAM                           (1 << KV_STREAM_OFF)
#define STREAM_ID(coh_bio)                  (((coh_bio->cb_para->kv_flag) >> STREAM_ID_SHIFT) & STREAM_ID_MASK)

#define EXTRA_PREAD_WRITE                   (6)
#define PAGE_SECTORS_SHIFT                  (SFX_PAGE_SHIFT - SECTOR_SHIFT) // 3
#define PAGE_SECTORS                        (1 << PAGE_SECTORS_SHIFT)       // 8
#define PAGE_SECTORS_MASK                   (PAGE_SECTORS - 1)              // 8
#define KERNEL_SECTOR_SIZE                  (512)
#define THIRTYTWOK_PAGE_SHIFT               (15)
#define THIRTYTWOK_PAGE_SECTORS_SHIFT       (THIRTYTWOK_PAGE_SHIFT - SECTOR_SHIFT)                //6
#define THIRTYTWOK_PAGE_PAGE_SHIFT          (THIRTYTWOK_PAGE_SECTORS_SHIFT - PAGE_SECTORS_SHIFT)  //6-3=3
#define SIZE_APP_COMMAND_TABLE              (4096 - 512)
#define BYTES_PER_CHUNK                     (4096)
#define SECTOR_TO_CHUNK_SHIFT               (3)

#define COH_END_REQ_THRD                    (0)
#define READ_MODE_MIM_THRD                  (480)
#define COH_END_REQUEST_THRD                (5)

#if FOUR_KB_PER_MAPPING_UNIT == 1
#define FM_32K_MAPPING_UNIT                 (0)
#else
#define FM_32K_MAPPING_UNIT                 (1)
#endif

#if FM_32K_MAPPING_UNIT
#define MAPPING_UNIT_TO_SECTOR_SHIFT        THIRTYTWOK_PAGE_SECTORS_SHIFT   // 6
#define MAPPING_UNIT_TO_PAGE_SHIFT          THIRTYTWOK_PAGE_PAGE_SHIFT      // 3
#else
#define MAPPING_UNIT_TO_SECTOR_SHIFT        PAGE_SECTORS_SHIFT              // 3
#define MAPPING_UNIT_TO_PAGE_SHIFT          (0)
#endif

//=========PRINT===================
#define TURN_ON_PRINT_THROTTLE              0
#define TURN_ON_PRINT_COH                   0
#define TURN_ON_PRINT_OPS                   0
//=========PERFORMANCE=============
#define PERFORMANCE                         0
//========COH======================
//#define COH_DEBUG
//=======RAMDISK===================
#define PARTIAL_RAMDISK_TEST                0

/* IOCTL */
#define BLKFTL_4K                           4096
#define BLKFTL_MAXB_PERREQ                  1048576
#define BLKFTL_IOCTL_PHY_PAGE_SIZE          16384
#define BLKFTL_IOCTL_DIE_NR                 128
#define BLKFTL_RARAGE                       16    // multiply page size = 4M

#if ENABLE_GC_TRIGGER_FASTER
#define NRSEC_110G                          220000000
#define NRSEC_230G                          483000000
//#define NRSEC_500G                        1000000000
#define DRIVE_SIZE                          NRSEC_230G
#else
// use this macro to setup any drive size
#define DRIVE_SIZE                          (sfx_mdrv->blk_ft_cfg.drive_size_in_nsec)
#endif // ENABLE_GC_TRIGGER_FASTER

/* Map page memory */
#define MAP_SIZE                            (sfx_mdrv->blk_ft_cfg.map_size)             // 4294967296, 4G, hard code map size, should be .1% of card cap
#define MAP_LEVEL                           (4)                                         // memory mapping level number
#define MAP_L4_NR_PAGE                      (MAP_SIZE / SFX_PAGE_SIZE)
#define MAP_L3_NR_PAGE                      ((MAP_L4_NR_PAGE * 8 / SFX_PAGE_SIZE) + (((MAP_L4_NR_PAGE * 8) % SFX_PAGE_SIZE) ? 1 : 0))
#define MAP_L2_NR_PAGE                      ((MAP_L3_NR_PAGE * 8 / SFX_PAGE_SIZE) + (((MAP_L3_NR_PAGE * 8) % SFX_PAGE_SIZE) ? 1 : 0))
#define MAP_L1_SIZE                         (MAP_L2_NR_PAGE * 8)                        // 8:pointer size
#define MAP_PTR_PAGE_NR                     (SFX_PAGE_SIZE / 8)                         // number of pointers in one page
#define US_TO_NS                            (1000)
#define MS_TO_NS                            (1000000)
#define S_TO_NS                             (1000000000)

#define MAX_NS_PER_DRIVE                    8
#define NVME_MAX_ERR_LOG_ENTRY              (0x10)

struct sfx_poll_ctx
{
    sfx_atomic_t wr_poll_sched;
    sfx_atomic_t rd_poll_sched;
    sfx_atomic_t wr_poll_qid;
    sfx_atomic_t rd_poll_qid;
    sfx_atomic_t wr_poll_cpuid;
    sfx_atomic_t rd_poll_cpuid;
    sfx_atomic_t mask_set;
    sfx_atomic_t polled_cmpl;
    sfx_atomic64_t wr_poll_time;
    sfx_atomic64_t rd_poll_time;
    xt_u64 thrd_direct_smt;
};

typedef struct coh_thread_ctx
{
    void *sfx_mdrv;
    xt_u32 tidx;
    xt_u32 numa_node;
} coh_thread_ctx;

typedef struct blk_ftl_config_table_s
{
    xt_u64 real_drive_size;                 // flash drive size in binary format, not decimal format
    xt_u32 default_mem_id_size_in_gigabyte;
    xt_u32 drive_size_in_gigabyte;          // Reported user size
    xt_u64 drive_size_in_nsec;              // Reported user size. 512 bytes per sector
    // Physical capacity is total flash minus 7.37% reserved spare space in nand
    xt_u32 physical_capacity_in_gigabyte;
    xt_u64 default_mem_id_size;
    xt_u64 map_size;
    xt_u32 gc_parity_buffers;
    xt_u32 pages_per_blk;
    xt_u32 num_block;
    xt_u32 l2p_max_chan;                    // how many blocks l2p table needed
} blk_ftl_config_table_t;

struct req_ready_list
{
#ifdef __SFX_KERNEL__
    //list head declarations
    struct sfx_list_head        r_list;     // used in blk_ftl_coh.c
    struct sfx_list_head        w_list;    // used in blk_ftl_coh.c
#endif
    sfx_spinlock_t              r_list_lock;       // used in blk_ftl_coh.c
    sfx_spinlock_t              w_list_lock;       // used in blk_ftl_coh.c
    sfx_atomic_t                r_list_cnt;
    sfx_atomic_t                w_list_cnt;

};

#define FM_MININUM_SBLK0_APPEND_SIZE        (sfx_mdrv->card_info.page_data_unit)    // each write 24*4K(1page)
#define SYSTEM_TABLE_ALLOCATE               (sizeof(system_tables_t))               // FM_MININUM_SBLK0_APPEND_SIZE*FOUR_KB*3)

#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
// ---------------------------------------------------------------------------
// The following segment of macros and typedef are designed to ensure the
// sfx_mul_drv struct is of constant size regardless whether it is built on
// host that supports SFX_BLK_MQ or not.  This is necessary so that the
// linux-vesion-independent libraries may be created for the Source RPM package.
// ---------------------------------------------------------------------------

// In Linux 5.0.0, sizeof(struct blk_mq_tag_set) = 160, which is the max size for now.
// It may need to be adjusted when porting to new linux releases/versions.
#define MAX_MQ_TAG_SET_SIZE                 (160)

// Please use this sfx_mdrv accessor macro to access the mq_tag_set member.
#define sfx_mdrv_mq_tag_set(sfx_mdrv)       ((struct blk_mq_tag_set *)(void *)(&(sfx_mdrv)->mq_tag_set))

struct sfx_mq_tag_set
{
    xt_u64 ___pad___[MAX_MQ_TAG_SET_SIZE / sizeof(xt_u64)];
};

// Check to ensure the reserved space is sufficient for all Linux versions.
#ifdef __SFX_KERNEL__
CC_ASSERT(sizeof(struct blk_mq_tag_set) <= sizeof(struct sfx_mq_tag_set));
#endif
#endif

struct sfx_nvme_feature
{
    xt_u32 arb;
    xt_u32 pm;
    xt_u16 overts[9];
    xt_u16 underts[9];
    xt_u32 err_recover;
    xt_u16 ncqr;
    xt_u16 nsqr;
    xt_u32 int_coales;
    xt_u32 int_vec;
    xt_u32 aer;
};

struct nvme_error_log_page {
    xt_u64    error_count;
    xt_u16    sqid;
    xt_u16    cmdid;
    xt_u16    status_field;
    xt_u16    parm_error_location;
    xt_u64    lba;
    xt_u32    nsid;
    xt_u8    vs;
    xt_u8    resv[35];
};
#ifdef SFX_LINUX
//sibling array for each core
struct sfx_cpu_map {
        xt_u16 sibling_num;
        xt_u16 sibling_id[0];
};
//cpu info array for each core inside a processor package
struct sfx_core_map {
        xt_u8 filled;
        xt_u8 cpu_map_size;
        xt_u16 valid_core_num;
        xt_u16 core_num;
        struct sfx_cpu_map cpu_map[0];
};
struct sfx_phys_proc_map {
        xt_u32 core_num;
        xt_u16 cores[0];
};
//cpu map contains a cpu info array for each processor package
struct sfx_proc_map {
        xt_u8 filled;
        xt_u8 proc_map_size;
        xt_u16 phys_proc_num;
        struct sfx_phys_proc_map phys_proc_map[0];
};
struct sfx_cpu_map_mgm {
        struct sfx_proc_map *proc_map;
        struct sfx_core_map *core_map;
        xt_u8 cpu_pinning;
        xt_u8 cgroup;
        xt_u8 cgroup_step;
        xt_u8 app_pin;
};
extern struct sfx_cpu_map_mgm g_cpu_map_mgm;
#endif
typedef struct sfx_mul_drv_s
{
#ifdef __SFX_KERNEL__
    struct sfx_list_head        sfx_bd_list;
    struct sfx_list_head        sfx_mdrv_list;
#if (SFX_BLK_QUEUE_TYPE == SFX_BLK_MQ)
    struct sfx_mq_tag_set       mq_tag_set;
#endif
#endif // __SFX_KERNEL__
#ifdef REBUILD_ACC_MEASURE
    xt_u64                      start_time;//rebuildacc collect info
#endif
    xt_u64                      ttr_time;//
    char                        *dev_name;
    xt_u8                       num_stream;
    xt_u8                       isolate;
    xt_u32                      num_outlier;
    xt_u32                      en_req_log;
    xt_u32                      en_outlier_print;
    xt_u32                      wr_outlier_thrd;
    xt_u32                      rd_outlier_thrd;

    /*One 64B cacheline*/
    sfx_atomic_t                flag_dev_freeze CACHELINE_ALIGNED;
    sfx_atomic_t                surprising_remove; //8B
#ifdef SFX_LINUX
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
    xt_u64  __percpu            *disable_irq_time; //16B
    sfx_atomic_t                outstanding_size;  //20B         /* outstanding bio size, in unit of 4k */
    xt_32   __percpu            *tot_read_bio; //24B
    xt_32   __percpu            *tot_write_bio; //28B
#else
    sfx_atomic64_t              disable_irq_time;
    sfx_atomic_t                outstanding_size;           /* outstanding bio size, in unit of 4k */
    sfx_atomic_t                tot_read_bio;
    sfx_atomic_t                tot_write_bio;
#endif
#else
    sfx_atomic64_t              disable_irq_time;
    sfx_atomic_t                tot_read_bio;
    sfx_atomic_t                tot_write_bio;
    sfx_atomic_t                outstanding_size;           /* outstanding bio size, in unit of 4k */
#endif //#ifdef SFX_LINUX
    sfx_atomic_t                outstanding_req; //32B
    void                        *gpmem_id; //40B
    void                        *gmap; //48B
    void                        *g_coh_table; //56B
    xt_u32                      single_job_metric; //60B
    xt_u8                       multi_stream_mode;
    xt_u8                       en_sts;
    xt_u16                      pad;
    /*End of 64B cacheline used in IO processing*/
    /*for performance debugging*/
    xt_u64                      num_req_sc;
    xt_u64                      num_noise_req;
#if PERFORMANCE
    sfx_atomic_t                active_host_rd_req;
    sfx_atomic_t                active_host_wr_req;
#endif
#if MEASURE_TIME
    sfx_atomic64_t              req_num;
#endif
#if (MEASURE_TIME || ENABLE_FTL_MONITER)
    xt_u64                      total_write;
    xt_u64                      total_read;
#ifdef __SFX_KERNEL__
    sfx_ktime_t                 prev_time_linux_perf;
#endif
    xt_u32 open_measure_time;
    sfx_atomic_t req_proc_num;
    sfx_atomic_t req_call_num;
    sfx_atomic_t req_end_num;
    sfx_atomic_t req_end_num_linux;
    sfx_atomic_t req_time;
    sfx_atomic_t req_handle_time;
    sfx_atomic_t req_time_max;
    sfx_atomic_t req_handle_time_max;
    sfx_atomic_t req_proc_time;
    sfx_atomic_t req_end_time;
    sfx_atomic_t bio_cb_time;
    sfx_atomic_t bio_callback_num;
    sfx_atomic_t req_handle_coh_time;
    sfx_atomic_t req_handle_coh_num;
#endif //#if MEASURE_TIME
    /*performance debugging end*/
    union handle                dev_handle;
    unsigned int                *cpu2wrqid_map; /* cpu to wr qid mapping for each stream */
    unsigned int                *cpu2rdqid_map; /* cpu to rd qid mapping for each unit */
    ftl_mq_ctx                  *ftl_mq_ctx;
    struct sfx_ioq_config       ioq_config;
    sfx_atomic_t                read_mode;
    xt_u8                       devId;
#ifdef CRASH_TRIGGER
    xt_u32                      crash_loc;
#endif
    struct sfx_poll_ctx         poll_ctx;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
    sfx_atomic64_t              num_fresh_cmd;
    sfx_atomic64_t              num_fresh_cmd_100;
#endif

    xt_u8                       device_gone;
    xt_u64                      l2p_address;
    xt_u32                      act_mode;
    xt_u32                      gc_start_trigger;
    xt_u32                      gc_stop_trigger;
    xt_u32                      nr_queues; //may be useful later for mq

    sfx_atomic64_t              gc_upper_speed;
    sfx_atomic64_t              temp_gc_upper_speed;
    sfx_atomic64_t              invalid_page_budget_per_4ms;
    sfx_atomic64_t              invalid_page_budget_per_60ms;
    sfx_atomic64_t              curr_invalid_page_budget;
    sfx_atomic64_t              gc_credit;
    sfx_atomic64_t              perf_validpages;
    sfx_atomic64_t              perf_freespace;
    sfx_atomic_t                min_hot_speed;
    sfx_atomic_t                max_hot_speed;
    sfx_atomic_t                gc_credit_set;
    sfx_atomic_t                blk_ftl_throttle_is_on;
    sfx_atomic_t                invalid_pages;
    sfx_atomic_t                no_bg_gc; // stop background gc
    xt_u32                      rwr_me;
    xt_u32                      num_blks_ns[3]; // capacity of a drive in terms of num_of_blks
    xt_u8                       sfx_bd_cnt;
    xt_u32                      sfx_bd_bmap;
    xt_u32                      numa_id;
    xt_u64                      lba_per_drv;
    void                        *sfx_bd0;
    sfx_atomic64_t              coh_thread_wake;
    void                        *sfx_bd;
    void                        *gc;
    int                         gmap_init;
    sfx_spinlock_t              wl_gc_spin_lock;
    sfx_atomic_t                wl_gc_ready_flag;
    void                        *wl;
    char                        opn[32];
    char                        sn[32];
    char                        firmware_rev[9];
    xt_u16                      pci_vender_id;
    xt_u8                       rab;
    sfx_spinlock_t              nvme_elp_lock;
    xt_u32                      nvme_elp_wptr;
    struct nvme_error_log_page  nvme_elp[NVME_MAX_ERR_LOG_ENTRY];
    struct sfx_nvme_feature	feature;
    struct sfx_perf_opt_ctx     perf_ctx;
#ifdef __SFX_KERNEL__
#ifdef SFX_LINUX
    blk_io_stat                 rd_io_stat[IO_NUM_ENTRY];
    blk_io_stat                 wr_io_stat[IO_NUM_ENTRY];
    blk_io_log_ctx              io_log_ctx;
#endif
#endif
    sfx_atomic_t                device_state;
    sfx_atomic_t                assert_handle_action;
    //TODO:QI change to non-atomic and move them close to
    //other variables used at the same time to reduce
    //cacheline polution
    sfx_atomic_t                assert_handled;
    sfx_atomic_t                rd_cmpl_direc;
    sfx_atomic_t                rd_cmpl_percpu;
    sfx_atomic_t                rd_cmpl_coh;
    sfx_atomic_t                rd_num_req;

    sfx_atomic_t                bg_cmd_cmpl;
    sfx_atomic_t                state_remove;
    sfx_atomic_t                is_masked;
    sfx_atomic_t                queue_stop;
    sfx_atomic_t                active_bgworker;
    xt_u64                      polling_hold;
    xt_u32                      enable_adp_polling;
    sfx_spinlock_t              io_acct_flag;
    void                        *g_mdata_vfy; //mdv: meta_data_verify
    struct sfx_pu_res_manager   *pu_res_mgr;
    sfx_spinlock_t              poll_lock;
    sfx_spinlock_t              blk_rd_debug_lock;
    xt_u64                      blk_rd_debug_idx;
    blk_rd_debug_entry          **blk_rd_debug_table;
#ifdef __SFX_KERNEL__
    sfx_wait_queue_head_t       gc_read_thread_wait;
    sfx_wait_queue_head_t       gc_write_thread_wait;
    sfx_wait_queue_head_t       wl_background_process_wait;
    sfx_wait_queue_head_t       g_mim_thread_wait;
    sfx_wait_queue_head_t       g_map_thread1_wait;
    sfx_wait_queue_head_t       meta_data_thread_wait;
    sfx_wait_queue_head_t       polling_thread_sync;
#ifdef SFX_LINUX
    sfx_bio_list                sq_cong;
    sfx_wait_queue_t            sq_cong_wait;
    sfx_wait_queue_head_t       sq_full;
    sfx_spinlock_t              sq_cong_lock;
#endif
#endif
    // this variable is used only to initialze the similar variable present
    // inside master_map_t struct.
    // this variable will be initialized to 0xFFFFFFFE in sfx_bd_probe and
    // will be changed during secure erase operation only, inside fm_rebuild_system_tables.
    xt_u32                      version;
    blk_ftl_config_table_t      blk_ft_cfg;
    sfx_board_nand_type         card_info;      // config parameter of board parameter
    xt_u32                      assert_debug;
    xt_u32                      num_direct_cmpl;

    sfx_thread_pool             priv_thrds; //record all created private thread
    xt_u32                      coh_thd_num;
    xt_u32                      thd_per_numa;
    sfx_atomic64_t              command_cnt;
    sfx_mutex_t                 ccs_access_lock;
    xt_u64                      gmap_addr_checker;
    xt_u64                      gmap_l2p_addr_checker;
    xt_u64                      sfx_bd_checker[MAX_NS_PER_DRIVE];
#if HOT_READ_PERF || HOT_WRITE_PERF
    struct {
        sfx_atomic64_t          func_req_handle_lat;
        sfx_atomic64_t          coh_process_time;
        sfx_atomic64_t          coh_bio_init_time;
        sfx_atomic64_t          coh_bio_proc_time;
        sfx_atomic64_t          coh_thread_wake_time;
        sfx_atomic64_t          req_init_time;
        sfx_atomic64_t          hot_rd_req_intval;
        sfx_atomic64_t          hot_wr_req_intval;
        sfx_atomic64_t          last_req_time;
        sfx_atomic64_t          req_interval_max;
        sfx_atomic64_t          num_rd_req;
        sfx_atomic64_t          num_wr_req;
        xt_u64                  set_wait;
        xt_u64                  num_wait;
        xt_u64                  wr_start_wait;
        xt_u64                  wr_end_wait;
        xt_u64                  wr_wait_max;
        xt_u64                  wr_tot_wait;
        xt_u64                  wr_max_wait;
    };
#endif
#if MEASURE_FUNC_TIME
    struct {
        sfx_atomic64_t          nr_ccs_cb;
        sfx_atomic64_t          nr_cb_enqueue;
        sfx_atomic64_t          time_ccs_cb;
        sfx_atomic64_t          time_cb_enqueue;
    };
#endif
#if PERFORMANCE
    struct {
        sfx_atomic_t            tot_act_read_from_blk;
        sfx_atomic_t            tot_act_read_from_map;
    };
#endif
    sfx_atomic_t                direct_cb;
    sfx_atomic_t                queue_cb;
    sfx_atomic_t                flag_coh_thread_init;
    sfx_atomic_t                ref_cnt_ioctl;

    xt_u32                      tot_pglist_entry;
    xt_u32                      u2_mode; //1: performance mode; 2: power save mode
#ifdef __SFX_KERNEL__
    struct sfx_list_head        blk_ftl_cb_queue;            // used in blk_ftl_callback.c
#endif
    struct req_ready_list*      ready_list;
    // Mutex declarations
    //sfx_mutex_t               fm_visit_lock;              // used in blk_ftl_ops.c
    sfx_spinlock_t              blk_ftl_cb_mutex;               // used in blk_ftl_callback.c
    sfx_spinlock_t              blk_ftl_err_handle_spin_lock;   // used in error handling
    sfx_spinlock_t              blk_ftl_read_distb_spin_lock;   // used in raed disturb
    sfx_spinlock_t              blk_ftl_maplog_eh_spin_lock;   // used in maplog eh
    // Atomic_t declarations
    sfx_atomic_t                end_req_list_number;        // used in blk_ftl_coh.c                   // used in blk_ftl_coh.c and blk_ftl_throttle.c
    sfx_atomic_t                tot_ent_coh;
    sfx_atomic_t                se_in_progress;             // secure erase marker

    sfx_atomic_t                blk_ftl_cb_queue_number;
    sfx_atomic_t                nvme_fw_download;
    sfx_atomic_t                nvme_reg_put;
    sfx_atomic_t                tot_grown_bbd;
    sfx_atomic_t                mdrv_removing;
    sfx_spinlock_t              grown_bbd_lock;
    sfx_spinlock_t              mdrv_remove_lock;
    void                        *nvme_reg_mem;

#ifdef __SFX_KERNEL__
    // wait Q head declarations
    sfx_wait_queue_head_t       blk_ftl_cb_thread_wait;
    sfx_wait_queue_head_t       blk_ftl_throttle_thread_wait;
    sfx_wait_queue_head_t       blk_ftl_err_handle_thread_wait;
    sfx_wait_queue_head_t       blk_ftl_maplog_eh_thread_wait;
#endif

    // Global strcutures declared as void pointers
    void                        *g_blk_ftl_throttle;
    void                        *g_blk_ftl_err_handle;
    void 						*g_blk_ftl_maplog_eh_ctxt;
    void                        *g_blk_ftl_read_distb;
    void                        *err_cntx;
    void                        *read_distb_cntx;
    void                        *map;

    xt_u32                      gc_distribution_check;
    xt_u32                      half_pages;
    xt_u32                      page_got;
    xt_u32                      kv_get_lba;
    sfx_heap_id                 heapid1;
    sfx_heap_id                 heapid2;
    void                        *heap1;
    void                        *heap2;
    xt_u64                      heapsz1;
    xt_u64                      heapsz2;
    xt_u8                       goldimg_dev;
    xt_u8                       comp_only;
    xt_u8                       discard_write_zeros;
    xt_u8                       blk_ftl_eh_exiting;
    xt_u32                      disable_wl_seq_chk;
    xt_u32                      atomic_write;   //enable atomic write group
    sfx_atomic_t                key_bg_tasks_enabled;
    sfx_atomic_t                is_eh_halt_for_sync;
        xt_u8 single_job_pin;
        struct task_struct *single_job_task;
#ifdef SFX_LINUX
    #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,11)
        xt_u64  __percpu            *total_wr_cmds_sent_to_ccs_req;
        xt_u64  __percpu            *total_wr_cmds_rcvd_from_host_req;
    #else
        sfx_atomic64_t            total_wr_cmds_sent_to_ccs_req;
        sfx_atomic64_t            total_wr_cmds_rcvd_from_host_req;
    #endif
#else
    sfx_atomic64_t            total_wr_cmds_sent_to_ccs_req;
    sfx_atomic64_t            total_wr_cmds_rcvd_from_host_req;
#endif
} sfx_mul_drv;

#ifdef CRASH_TRIGGER

//comments on each crash point show how to trigger the crash point
typedef enum CRASH_LOCATION_E
{
    // initcard.sh --cl --blk or factory init the card
    // crash in function fm_rebuild_system_tables
    FM_0_FACTORY_INIT = 0,

    //rebuild thread
    // power cycle the device, will trigger when power on init
    // crash in function fm_multi_drive_init
    FM_0_INIT,

    // power cycle the device, will trigger when power on init
    // crash in function fm_linear_search_first_valid_page
    FM_1_REBUILD_SYSTEM_TABLE,

    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_system_tables
    FM_2_REBUILD_L2P_OR_MEM_ID_SEQUENCE,

    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_l2p_table_or_open_mem_id_sequence
    FM_3_REBUILD_SEALED_MEM_ID,

    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_sealed_mem_id_wait
    FM_REBUILD_FINISH_SEALED_MEM_ID,

    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_l2p_table_or_open_mem_id_sequence or
    //fm_rebuild_sealed_mem_id or fm_rebuild_sealed_mem_id_wait
    FM_4_REBUILD_OPEN_MEM_ID,

    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_open_mem_id
    FM_6_REBUILD_SEAL_OPEN_MEM_ID,

    FM_8_PU_ALLOCATION,                         // Parallel unit allocation
    FM_9_PU_DEALLOCATION,                       // Parallel unit deallocation

    // keep writing random hot traffic
    // crash in function fm_rebuild_flush_map_log
    FM_REBUILD_IN_MIDDLE_OF_FLUSH_MAP_LOG,

    // power cycle the device, will trigger when power on init
    // crash in function fm_flush_master_table or fm_factory_init or
    //fm_rebuild_seal_open_mem_id
    FM_7_REBUILD_DONE,

    //////////////////////////////////////////////////////////
    // power cycle the device, will trigger when power on init
    // crash in function fm_rebuild_done
    FM_NORMAL,

    //mem_id_mgr thread
    // keep writing hot traffic
    // crash in function mim_allocate_open_mem_id
    FM_ALLOCATE_MEM_ID,

    // keep writing hot traffic
    // crash in function mim_allocate_open_mem_id
    FM_MIM_HOT_STREAM0_OPEN_MEMID,

    // keep writing hot traffic
    // crash in function fm_flush_master_table
    FM_MIM_SEAL,

    // trigger gc
    // crash in function mim_allocate_open_mem_id
    FM_MIM_COLD_STREAM_GC_OPEN_MEMID,

    // power cycle the device, will trigger when power on init
    // crash in function mim_allocate_open_mem_id
    FM_MIM_COLD_STREAM_SNAPSHOT_OPEN_MEMID,

#if ENABLE_UNIT_TEST == 0
    //hot stream thread
    // required hot traffic write
    // crash in function blk_ftl_fresh_write_handler
    FRESH_WRITE_BLK_WRITE,
#endif

    // keep writing hot traffic
    // crash in function fm_populate_header
    FM_HOT_STREAM0_FLUSH_HEADER,

    // keep writing hot traffic
    // crash in function fm_flush_master_table
    FM_HOT_STREAM0_FLUSH_MASTER_DURING_HEADER,

    // keep writing hot traffic
    // crash in function fm_flush_map_log
    FM_HOT_STREAM0_FLUSH_MAP_LOG,

    // keep writing random hot traffic
    // not implemented yet, need to do it in ccs crash point, cannot do in blk_ftl
    FM_HOT_STREAM0_IN_MIDDLE_OF_FLUSH_MAP_LOG,

    // keep writing hot traffic
    // crash in function fm_flush_map_log
    FM_HOT_STREAM0_FLUSH_LAST_MAP_LOG,

    // keep writing hot traffic
    // crash in function fm_flush_mem_id_footer
    FM_HOT_STREAM0_FLUSH_FOOTER,

    // keep writing hot traffic
    // not implemented yet, need to do it in ccs crash point, cannot do in blk_ftl
    FM_HOT_STREAM0_DURING_FLUSH_HEADER_OR_FOOTER,

    // keep writing hot traffic
    // crash in function fm_blk_write
    FM_HOT_STREAM0_APPEND,

    // issue trim
    // crash in function fm_map_invalid
    FM_HOT_STREAM0_TRIM,

    // keep reading lba
    // crash in function fm_blk_read
    FM_HOT_STREAM0_READ,

    //gc thread
    // do graceful shutdown
    // crash in function mim_stop_mem_id_mgr
    FM_GC_PFAIL_DATA_FLUSH_MASTER,

    // trigger gc
    // crash in function gc_write
    FM_GC_APPEND,

    // trigger gc
    // crash in function gc_move_data
    FM_GC_APPEND_ZERO,

    // trigger gc
    // crash in function fm_gc_map_log_update
    FM_GC_FLUSH_MAP_LOG,

    // trigger gc
    // crash in function gc_start_sealing
    FM_GC_START_SEALING_STATE,

    // trigger gc
    // crash in function gc_gather_cold_data
    FM_GC_GATHER_COLD_DATA,

    // trigger gc
    // crash in function gc_background_deallocate
    FM_GC_DEALLOCATE_START,

    // trigger gc
    // crash in function gc_background_deallocate
    FM_GC_DEALLOCATE_DONE,

    // do graceful shutdown
    // crash in function fm_flush_entire_l2p_table
    FM_PFAIL_FLUSH_L2P_TABLE,

    // do graceful shutdown
    // crash in function fm_flush_entire_l2p_table
    FM_PFAIL_FLUSH_L2P_TABLE2,

    // keep writing hot traffic
    // crash in function fm_flush_master_table
    FM_FLUSH_MASTER_STATE,

    // keep writing hot traffic
    // crash in function mim_update_open_mem_id_sequence_number
    FM_UPDATE_SEQUENCE_NUMBER,

    //do not use this as crash point, only for unit test
    FM_MAX_UNIT_TEST_STATE,

    // Secure erase
    // trigger secure erase
    // crash in function set_secure_erase_marker
    FM_SET_SECURE_ERASE,

    // trigger wl
    // crash in function mim_allocate_open_mem_id
    FM_MIM_WL_HOT_STREAM_OPEN_MEMID,

    // do not use as crash point
    FM_MAX_STATE,

    // when assert we set to this state
    FM_ASSERT_STATE,
} CRASH_LOCATION_T;
#endif

/** @brief: This function gets called during secure erase.
 *          Set the sfx_mdrv->priv_thrds.threads[] value to zero for the thread
             that is being quit.
 *          The number of threads should not be greater than 16.
 */
static inline void reset_thread_occupied_bit(sfx_mul_drv *sfx_mdrv, struct sfx_blk_ftl_thread *priv_thrd)
{
#ifdef __SFX_KERNEL__
    xt_u32 i;

    for (i = 0; i < SFX_PRIV_THREAD_SLOT_TOTAL; i++) {
        if (priv_thrd->pid == sfx_mdrv->priv_thrds.threads[i].thread_pid) {
            sfx_mdrv->priv_thrds.threads[i].thread_pid = 0;
            break;
        }
    }
#endif
}

static inline void blk_ftl_thread_init(sfx_mul_drv *sfx_mdrv, struct sfx_blk_ftl_thread *priv_thrd, int slot_id)
{
#ifdef __SFX_KERNEL__
    sfxError status = NO_ERROR;

    status = sfx_blk_assert(sfx_mdrv, slot_id >= 0 && slot_id < SFX_PRIV_THREAD_SLOT_TOTAL);
    if (status == ERROR_ASSERT) {
        sfx_print(sfx_mdrv->devId, BLK_SYS, PL_ERR, "Err: %s slot_id %d out of range [%d, %d].\n",
            __FUNCTION__, slot_id, SFX_PRIV_THREAD_SLOT_ASSERT, SFX_PRIV_THREAD_SLOT_TOTAL);
        return;
    }
    sfx_priv_thread_init(&sfx_mdrv->priv_thrds, priv_thrd, slot_id);
    /*sfx_print(sfx_mdrv->devId, BLK_SYS, PL_LOG,
        "%s: Init private thread: pid %u, assert cmpl %p, thread %p, parked %p, slot_id: %d\n",
        __FUNCTION__, priv_thrd->pid, sfx_mdrv->priv_thrds.threads[slot_id].assert_cmpl, priv_thrd,
        &(priv_thrd->parked), slot_id);*/
#endif
}
#ifdef SFX_LINUX
static inline void sfx_set_core_mask(xt_u16 core_id, sfx_cpumask_var_t mask)
{
        struct sfx_cpu_map *cpu_map;
        xt_u32 i;
        cpu_map = (struct sfx_cpu_map *)
                ((xt_u8*)(&g_cpu_map_mgm.core_map->cpu_map) +
                        g_cpu_map_mgm.core_map->cpu_map_size * core_id);
        for (i = 0; i < cpu_map->sibling_num; i++) {
                sfx_cpumask_set_cpu(cpu_map->sibling_id[i], mask);
        }
}

static inline xt_u32 sfx_get_proc_pos(xt_u32 dev_id, xt_u16 *proc_idx, xt_u16 *proc_off)
{
        xt_u16 valid_core_num = g_cpu_map_mgm.core_map->valid_core_num;
        xt_u16 phys_proc_num = g_cpu_map_mgm.proc_map->phys_proc_num;
        xt_u16 core_per_proc = valid_core_num / phys_proc_num;
        xt_u16 num_dev_per_proc;

        num_dev_per_proc = core_per_proc / g_cpu_map_mgm.cgroup_step;
        if (num_dev_per_proc == 0) {
                //the total cores on one processor is not even enough
                //for a cgroup step, there is no meaning to pin CPU anymore
                sfx_print(-1, BLK_SYS, PL_INF,
                        "core_per_proc %d\n", core_per_proc);
                return 1;
        }
        *proc_idx = dev_id / num_dev_per_proc;
        *proc_off = (dev_id % num_dev_per_proc) * g_cpu_map_mgm.cgroup_step;

        return 0;

}

static inline xt_u32 sfx_cgroup_config(xt_u32 dev_id, sfx_cpumask_var_t mask)
{
        struct sfx_phys_proc_map *phys_proc_map;
        xt_u16 proc_idx;
        xt_u16 proc_off;
        xt_u16 i;

        if (g_cpu_map_mgm.cgroup_step < 3) {
                //If cgroup_step is too small, it is meanling to pin CPU
                //since multiple internal heave threads are going to share
                //one CPU.
                return 1;
        }

        if (sfx_get_proc_pos(dev_id, &proc_idx, &proc_off)) {
                return 1;
        }

        phys_proc_map = (struct sfx_phys_proc_map *)
                ((xt_u8*)(&g_cpu_map_mgm.proc_map->phys_proc_map) +
                        g_cpu_map_mgm.proc_map->proc_map_size * proc_idx);

        sfx_print(-1, BLK_SYS, PL_LOG,
                "proc_idx %d, dev_id %d, proc_off %d\n",
                proc_idx, dev_id, proc_off);
        sfx_cpumask_clear(mask);
        for (i = 0; i < g_cpu_map_mgm.cgroup_step; i++) {
                struct sfx_cpu_map *cpu_map;
                xt_u16 core_id;
                xt_u16 j;
                core_id = phys_proc_map->cores[proc_off + i];

                sfx_print(-1, BLK_SYS, PL_LOG,
                        "core_id %d\n", core_id);
                cpu_map = (struct sfx_cpu_map *)
                        ((xt_u8*)(&g_cpu_map_mgm.core_map->cpu_map) +
                        g_cpu_map_mgm.core_map->cpu_map_size * core_id);
                for (j = 0; j < cpu_map->sibling_num; j++) {
                        xt_u16 sid = cpu_map->sibling_id[j];
                        sfx_cpumask_set_cpu(sid, mask);
                        sfx_print(-1, BLK_SYS, PL_LOG,
                                "sid %d\n", sid);
                }
        }

        return 0;
}

static inline xt_32 sfx_set_thd_cpu_mask(xt_u32 dev_id, xt_u32 thd_idx)
{
    sfx_cpumask_var_t mask;
    if (!sfx_alloc_cpumask_var(&mask, GFP_ATOMIC)) {
        return SFX_ERR_ENOMEM;
    }

        if (!sfx_cgroup_config(dev_id, mask)) {
                if (g_cpu_map_mgm.cgroup) {
                        //if cgroup is set, all internal heavy
                        //lifting threads are bound to same CPU
                        //group
                    sfx_set_cpus_allowed_ptr(sfx_get_current(),
                                        mask);

                } else {
                        //if cpu_pinning is set but not cgroup,
                        //all internal heavy lifting threads are
                        //bound to a specific CPU inside a cgroup

                        //get the first cpu in a cgroup
                        //first CPU is for gc_write_process
                        //second CPU is for gc_read_process
                        //third CPU is for blk_ftl_coh
                        struct sfx_phys_proc_map *phys_proc_map;
                        xt_u32 core_id;
                        xt_u16 proc_idx = 0, proc_off = 0;
                        sfx_get_proc_pos(dev_id, &proc_idx, &proc_off);
                        phys_proc_map = (struct sfx_phys_proc_map *)
                                ((xt_u8*)(&g_cpu_map_mgm.proc_map->phys_proc_map) +
                                        g_cpu_map_mgm.proc_map->proc_map_size * proc_idx);
                        core_id = phys_proc_map->cores[proc_off + thd_idx];

                        sfx_print(-1, BLK_SYS, PL_LOG,
                                "Pin thread idx %d of card %d to core_id %d\n",
                                thd_idx, dev_id, core_id);
                    sfx_cpumask_clear(mask);
                        //set CPU mask for all the siblings in a core
                        sfx_set_core_mask(core_id, mask);
                    sfx_set_cpus_allowed_ptr(sfx_get_current(),
                                        mask);
                }
        }
        sfx_free_cpumask_var(mask);
        return NO_ERROR;
}
#endif
// exports from gc.c
struct gc_s;
void gc_debug_print(sfx_mul_drv *sfx_mdrv, struct gc_s *gc);

void blk_ftl_gpmap_checker(sfx_mul_drv *sfx_mdrv, int entry_flag);
sfxError init_pu_res_manager(sfx_mul_drv *sfx_mdrv);
int alloc_pu_internal(sfx_mul_drv *sfx_mdrv, int isolation_level, sfx_pu_res *pu_res);
void dealloc_pu_internal(sfx_mul_drv *sfx_mdrv, xt_u32 pu_id);
sfxError sfx_pu_res_recover(sfx_mul_drv *sfx_mdrv);
void sfx_pu_free(sfx_mul_drv *sfx_mdrv);

#endif // __BLK_FTL_MULTIDRIVE_H__
