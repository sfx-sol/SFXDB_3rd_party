/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2016-2918, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_bd_dev_exp.h
 *
 * The list of ScaleFlux Block FTL device driver exported symbols.
 * ---------------------------------------------------------------------------
 */

#ifndef __SFX_BD_DEV_EXP_H__
#define __SFX_BD_DEV_EXP_H__

#include "sfx_os_headers.h"

#ifdef __SFX_KERNEL__

// ---------------------------------------------------------------------------
// From ftl/src/compression.c
// ---------------------------------------------------------------------------
EXPORT_SYMBOL(ccs_ni_comp_open_session);
EXPORT_SYMBOL(ccs_ni_comp_get_runtime_status);
EXPORT_SYMBOL(ccs_ni_comp_close_session);
EXPORT_SYMBOL(ccs_ni_comp_append_data_async);
EXPORT_SYMBOL(ccs_ni_comp_get_data_async);
EXPORT_SYMBOL(ccs_ni_comp_append_get_data_async);
EXPORT_SYMBOL(ccs_ni_comp_get_cmd_status);

// ---------------------------------------------------------------------------
// From ftl/src/erasurecode.c
// ---------------------------------------------------------------------------
EXPORT_SYMBOL(ccs_ni_ec_open_session);
EXPORT_SYMBOL(ccs_ni_ec_close_session);
EXPORT_SYMBOL(ccs_ni_ec_append_get_data_async);
EXPORT_SYMBOL(ccs_ni_ec_get_cmd_status);

// ---------------------------------------------------------------------------
// From ftl/src/init.c
// ---------------------------------------------------------------------------
EXPORT_SYMBOL(CCS_Open_ccs_dev);
EXPORT_SYMBOL(CCS_DestroyTable);

// ---------------------------------------------------------------------------
// From ftl/src/r2c.c
// ---------------------------------------------------------------------------
EXPORT_SYMBOL(ccs_ni_r2c_col_schema);
EXPORT_SYMBOL(ccs_ni_r2c_send_cmd);
EXPORT_SYMBOL(ccs_ni_r2c_open_session);
EXPORT_SYMBOL(ccs_ni_r2c_close_session);

// ---------------------------------------------------------------------------
// From ftl/src/scheduler.c
// ---------------------------------------------------------------------------
EXPORT_SYMBOL(CCS_GetCCSCmdStatus);

#endif // __SFX_KERNEL__

#endif // __SFX_BD_DEV_EXP_H__
