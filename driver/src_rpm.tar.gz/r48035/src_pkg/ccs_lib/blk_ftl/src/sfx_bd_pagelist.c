/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_bd_pagelist.c
 * ---------------------------------------------------------------------------
 */

#include "flat_map.h"
#include "sfx_bd_dev.h"
#include "blk_ftl_coh.h"
#include "sfx_api.h"
/*
 * Init bio page buf for unaligned case
 * size: number of page used in coh_bio
 */
int blk_ftl_init_bio_page_buf(sfx_bio *bio, blk_ftl_coh_bio *coh_bio, xt_u32 size)
{
	int i;
	xt_u64 sect_start_lba_iter = 0, sect_end_lba_iter = 0;
	xt_u64 start_lba_tmp = 0, end_lba_tmp = 0;
	xt_u32 len = 0, off = 0, data = 0, buf_init_idx;
	xt_u32 tot_trim_buf = 0, max_trim_buf = 2;
	bio_page_buf *buf_iter;
	sfx_mul_drv *sfx_mdrv = coh_bio->sfx_bd->sfx_mdrv;

	if (!coh_bio->is_trim || size <= 2) {
		if (size * sizeof(bio_page_buf *) >= MAX_KMEM_CACHE_SIZE)
			coh_bio->bio_buf_list = sfx_malloc(size * sizeof(bio_page_buf *));
		else
			coh_bio->bio_buf_list = kmem_malloc(sfx_mdrv->devId, size * sizeof(bio_page_buf *));
	} else {
		coh_bio->bio_buf_list = kmem_malloc(sfx_mdrv->devId, 2 * sizeof(bio_page_buf *));
	}

	if (ENABLE_UNALIGN_TRIM_DEBUG) {
		if (coh_bio->is_trim) {
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_INF,
				  "UT->%s, bio_buf_list %x size %x coh_bio %x\n", __FUNCTION__,
				  coh_bio->bio_buf_list, size, coh_bio);
		}
	}
	if (!coh_bio->bio_buf_list) {
		sfx_print(-1, CCS_SYS, PL_WRN, "%s: Out of memory, require size %x\n", __FUNCTION__,
			  size * sizeof(bio_page_buf *));
		return 1;
	}
	/* 4kB aligned sector_lba */
	if (sfx_op_is_write(bio)) {
		sect_start_lba_iter = coh_bio->coh_bio_lba.map_start_lba << MAPPING_UNIT_TO_SECTOR_SHIFT;
	} else {
		sect_start_lba_iter = coh_bio->coh_bio_lba.page_start_lba << PAGE_SECTORS_SHIFT;
	}
	if (sfx_irqs_disabled()) {
		sfx_local_irq_enable();
	}
	if (ENABLE_UNALIGN_TRIM_DEBUG) {
		if (coh_bio->is_trim) {
			sfx_print(-1, BLK_REQ, PL_INF, "UT-> size %d\n", size);
		}
	}
	for (i = 0; i < size; i++) {
		xt_u32 buf_iter_alloc = 0;
		sect_end_lba_iter = sect_start_lba_iter + PAGE_SECTORS - 1;

		start_lba_tmp = (coh_bio->coh_bio_lba.sect_start_lba <= sect_start_lba_iter) ?
					sect_start_lba_iter :
					((coh_bio->coh_bio_lba.sect_start_lba > sect_end_lba_iter) ?
						 0xFFFFFFFFFFFFFFFF :
						 coh_bio->coh_bio_lba.sect_start_lba);

		end_lba_tmp = (coh_bio->coh_bio_lba.sect_end_lba >= sect_end_lba_iter) ?
				      sect_end_lba_iter :
				      ((coh_bio->coh_bio_lba.sect_end_lba < sect_start_lba_iter) ?
					       0 :
					       coh_bio->coh_bio_lba.sect_end_lba);

		if ((!end_lba_tmp && coh_bio->coh_bio_lba.sect_end_lba) ||
		    0xFFFFFFFFFFFFFFFF == start_lba_tmp) {
			if (1 != coh_bio->is_trim) {
				len = 0;
				data = 0;
			}
		} else {
			if (1 != coh_bio->is_trim) {
				len = (end_lba_tmp - start_lba_tmp + 1) << SECTOR_SHIFT;
				off = (start_lba_tmp - sect_start_lba_iter) << SECTOR_SHIFT;
				data = 1;
			} else {
				if (ENABLE_UNALIGN_TRIM_DEBUG) {
				}
				if ((start_lba_tmp % PAGE_SECTORS != 0) ||
				    ((end_lba_tmp + 1) % PAGE_SECTORS != 0)) {
					len = (end_lba_tmp - start_lba_tmp + 1) << SECTOR_SHIFT;
					off = (start_lba_tmp - sect_start_lba_iter) << SECTOR_SHIFT;
					data = 1;
					tot_trim_buf++;

					if (ENABLE_UNALIGN_TRIM_DEBUG) {
						sfx_print(-1, BLK_REQ, PL_INF, "UT-> len %d, off %d, %d\n",
							  len / 512, off / 512, i);
					}
				} else {
					len = 0;
					data = 0;
				}
			}
		}

		if (coh_bio->is_trim && (tot_trim_buf > max_trim_buf)) {
			sfx_print(sfx_mdrv->devId, BLK_REQ, PL_ERR,
				  "%s: sector lba %llxh <-> %llxh"
				  "sector_iter_lba %llxh->%llxh wrong\n",
				  __FUNCTION__, coh_bio->coh_bio_lba.sect_start_lba,
				  coh_bio->coh_bio_lba.sect_end_lba, start_lba_tmp, end_lba_tmp);
			sfx_ftl_assert(sfx_mdrv, 0);
		}

		/* unaligned trim: buf init of the first and last LBA keeps the same */
		if (1 == coh_bio->is_trim && size > 2) {
			if ((i != 0) && (i != size - 1)) {
				sect_start_lba_iter += PAGE_SECTORS;
				continue;
			}
		}

		if (!coh_bio->is_trim) {
			buf_init_idx = i;
		} else {
			if (i == 0) {
				buf_init_idx = 0;
			} else {
				buf_init_idx = 1;
			}
		}

		buf_iter_alloc = ((1 == coh_bio->is_trim) && (0 == data));
		buf_iter = alloc_bio_page_buf(sfx_mdrv,
					      buf_iter_alloc); // trim align sector not allocate page buf
		if (!buf_iter) {
			sfx_print(-1, CCS_SYS, PL_WRN, "%s: Out of memory, fail to get buf page\n",
				  __FUNCTION__);
			return 1;
		}
		if (!((1 == coh_bio->is_trim) && (0 == data))) {
			if (!buf_iter->page_buf) {
				free_bio_page_buf(buf_iter);
				sfx_print(-1, CCS_SYS, PL_WRN, "%s: Out of memory, fail to get buf page\n",
					  __FUNCTION__);
				return 1;
			}
		}
		coh_bio->bio_buf_list[buf_init_idx] = buf_iter;

		buf_iter->len = len;
		buf_iter->off = off;
		buf_iter->data = data;

		sect_start_lba_iter += PAGE_SECTORS;
	}
	if (!sfx_irqs_disabled()) {
		sfx_local_irq_disable();
	}
	return 0;
}

void blk_ftl_coh_bio_init_bio_pages(blk_ftl_coh_bio *coh_bio, sfx_bio *bio)
{
	sfx_bio_vec bvec;
	sfx_bvec_iter iter;
	xt_u32 i = 0;
	sfx_bio_for_each_segment(bvec, bio, iter)
	{
		coh_bio->bio_pages[i] = sfx_bvecpage(bvec);
		i++;
	}
}

static inline void _check_page(sfx_page *pages)
{
	if ((unsigned long)pages & 0x03 || !pages) {
		sfx_dump_stack();
	}
}

static inline void _page_copy(void *des, xt_u32 des_off, void *src, xt_u32 src_off, xt_u32 len)
{
	sfx_memcpy(des + des_off, src + src_off, len);
}

static void bd_page_copy(void *des, void *src, sfx_bio_vec bvec, xt_u32 *cp_len, xt_u32 bio_page_off,
			 xt_u32 *buf_page_off, xt_u32 stage, xt_u32 coh_to_bio)
{
	xt_u32 src_off = 0, des_off = 0;
	bio_page_off = sfx_bvecoff(bvec);
	if (1 == stage) {
		(*cp_len) = (sfx_bveclen(bvec) > (FOUR_KB - (*buf_page_off))) ? (FOUR_KB - (*buf_page_off)) :
										sfx_bveclen(bvec);
		if (coh_to_bio) {
			des_off = bio_page_off;
			src_off = (*buf_page_off);
		} else {
			des_off = (*buf_page_off);
			src_off = bio_page_off;
		}
		_page_copy(des, des_off, src, src_off, *cp_len);
		(*buf_page_off) += (*cp_len);
	} else if (2 == stage) {
		if (sfx_bveclen(bvec) > (*cp_len)) {
			bio_page_off += (*cp_len);
			if (coh_to_bio) {
				des_off = bio_page_off;
				src_off = (*buf_page_off);
			} else {
				des_off = (*buf_page_off);
				src_off = bio_page_off;
			}
			_page_copy(des, des_off, src, src_off, sfx_bveclen(bvec) - (*cp_len));
			(*buf_page_off) = sfx_bveclen(bvec) - (*cp_len);
		}
	}
}

void blk_ftl_copy_coh_buffer_to_bio_pages(blk_ftl_coh_bio *coh_bio, sfx_page **pages, xt_u32 arr_len)
{
	sfx_bio *bio = coh_bio->bio;
	xt_u32 index = 0;
	sfx_bio_vec bvec;
	sfx_bvec_iter iter;
	xt_u32 bio_page_off = 0, buf_page_off = 0, cp_len = 0;

	buf_page_off = coh_bio->bio_buf_list[0]->off;
	sfx_bio_for_each_segment(bvec, bio, iter)
	{
		bd_page_copy(sfx_page_address(sfx_bvecpage(bvec)), sfx_page_address(pages[index]), bvec,
			     &cp_len, bio_page_off, &buf_page_off, 1, 1);
		if ((1 << SFX_PAGE_SHIFT) == buf_page_off) {
			index++;
			buf_page_off = 0;
		}
		bd_page_copy(sfx_page_address(sfx_bvecpage(bvec)), sfx_page_address(pages[index]), bvec,
			     &cp_len, bio_page_off, &buf_page_off, 2, 1);
	}
}

void blk_ftl_prepare_pglist_para(xt_u16 *pread_mask, xt_u16 *ccs_rd_len, xt_u32 *msk_start_loc,
				 xt_u16 prd_rd_len)
{
	xt_u16 rd_mask = *pread_mask;
	xt_u32 i = 0;
	if (((rd_mask & 0xF) == 0) || ((rd_mask & 0xF0) == 0)) { //sigle plane read <= 16KB
		if (prd_rd_len > 1) {
			*ccs_rd_len = 4; //READ_LENGTH_FOR_16_KB; //4 * 4KB
			if ((rd_mask & 0xF) == 0) {
				rd_mask = rd_mask >> 4; //READ_LENGTH_FOR_16_KB;
				i = 4;
			}
			if (((rd_mask == 0x3) || (rd_mask == 0xc))) {
				*ccs_rd_len = 2; //READ_LENGTH_FOR_8_KB; //2 * 4KB
				if (rd_mask == 0xc) {
					rd_mask >>= 2;
					i += 2;
				}
			}
		} else {
			while ((rd_mask & 0x1) != 0x1) {
				rd_mask >>= 1;
				i++;
			}
			*ccs_rd_len = 1; //READ_LENGTH_FOR_4_KB; //4KB
		}
	} else { //for 32KB read
		*ccs_rd_len = 8; //READ_LENGTH_FOR_32_KB;
	}
	*msk_start_loc = i;
	*pread_mask = rd_mask;
}
/**
 * @brief: create a token range from a bio page range
 *
 * @para[in]  bio   : pointer to the kernel data structure bio
 * @para[out] token : expected output
 * @para[in]  start : start lba point (4k)
 * @para[in]  end   : end lba point (4k)
 *
 * @retv: none.
 */
xt_u32 sfx_bd_create_token_range_from_bio(sfx_mul_drv *sfx_mdrv, union handle *bhand,
					  blk_ftl_coh_bio *coh_bio, void **token, xt_u32 start, xt_u32 end,
					  read_entry_t *prd_entry)
{
	sfx_page **pages;
	sfx_page **pages1;
	xt_u32 i = 0, index = 0, uend = end;
	xt_u32 bio_start = coh_bio->coh_bio_lba.page_start_lba;
	sfx_bio *bio = coh_bio->bio;
	sfx_bio_vec bvec;
	sfx_bvec_iter iter;
	xt_u16 offset, valid_seq = 0;
	xt_u16 len = 0, length = 0;

	if (coh_bio->mem_unaligned) {
		uend++;
	}
	pages = kmem_malloc(coh_bio->sfx_bd->sfx_mdrv->devId, (uend - start + 1) * sizeof(*pages));

	sfx_bio_for_each_segment(bvec, bio, iter)
	{
		if ((i + bio_start >= start) && (i + bio_start <= uend)) {
			pages[index++] = sfx_bvecpage(bvec);
#if KV_DEBUG
			sfx_print(-1, CCS_SYS, PL_INF, "%s: pages[%d] %p\n", __FUNCTION__, index - 1,
				  pages[index - 1]);
#endif
			_check_page(pages[index - 1]);
		}
		i++;
	}
	if (prd_entry->merge_read == 1) {
		xt_u16 rd_mask = prd_entry->read_mask;
		blk_ftl_prepare_pglist_para(&rd_mask, &length, &i, prd_entry->length);
		pages1 = kmem_malloc(sfx_mdrv->devId, (length) * sizeof(*pages));
		len = length;
		index = 0;
		prd_entry->lba_seq_off = 0;
		while (length) {
			if (rd_mask & 0x1) {
				prd_entry->lba_seq_off |=
					((prd_entry->msk_to_lba[i] - prd_entry->first_lba) << 4 * valid_seq);
				offset = prd_entry->msk_to_lba[i] - start;
				pages1[index++] = pages[offset];
				valid_seq++;
			} else {
				pages1[index++] =
					(sfx_page *)sfx_virt_to_page(((gc_t *)(sfx_mdrv->gc))->prd_buff, 0);
			}
			rd_mask >>= 1;
			length--;
			i++;
		}
		if (pages != NULL) {
			kmem_mfree(pages);
		}
		return sfx_user_set_pagelist(bhand, (void **)pages1, (void **)token, len, 1,
					     sfx_bio_offset(coh_bio->bio)) == (len) ?
			       NO_ERROR :
			       ERROR_CODE;
	} else {
		return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, uend - start + 1, 1,
					     sfx_bio_offset(coh_bio->bio)) == (uend - start + 1) ?
			       NO_ERROR :
			       ERROR_CODE;
	}
}

/**
 * @brief: create token from page list range [start, end]
 *
 * @para[in]  list    : pointer to page list
 * @para[out] token
 * @para[in]  start   : start point (4k unit)
 * @para[in]  end     : end point   (4k unit)
 */
xt_u32 sfx_bd_create_token_range_from_pages(sfx_mul_drv *sfx_mdrv, union handle *bhand, sfx_page **list,
					    void **token, xt_u32 coh_start_lba, xt_u32 start, xt_u32 end,
					    blk_ftl_coh_bio *coh_bio, read_entry_t *prd_entry)
{
	sfx_page **pages;
	xt_u32 i = 0;
	xt_u16 lba_off, index = 0;
	xt_u16 len = 0, length = 0;
	xt_u16 valid_seq = 0;
	if (prd_entry->merge_read == 1) {
		xt_u16 rd_mask = prd_entry->read_mask;
		blk_ftl_prepare_pglist_para(&rd_mask, &length, &i, prd_entry->length);
		if (sfx_irqs_disabled()) {
			sfx_local_irq_enable();
		}
		pages = kmem_malloc(sfx_mdrv->devId, (length) * sizeof(*pages));
		if (!sfx_irqs_disabled()) {
			sfx_local_irq_disable();
		}
		len = length;
		prd_entry->lba_seq_off = 0;
		while (length) {
			if (rd_mask & 0x1) {
				prd_entry->lba_seq_off |=
					((prd_entry->msk_to_lba[i] - prd_entry->first_lba) << 4 * valid_seq);
				lba_off = prd_entry->msk_to_lba[i] - coh_start_lba;
				pages[index++] = list[lba_off];
				valid_seq++;
			} else {
				//dummy
				pages[index++] =
					(sfx_page *)sfx_virt_to_page(((gc_t *)(sfx_mdrv->gc))->prd_buff, 0);
			}
			rd_mask >>= 1;
			length--;
			i++;
		}
	} else {
		if (sfx_irqs_disabled()) {
			sfx_local_irq_enable();
		}
		pages = kmem_malloc(sfx_mdrv->devId, (end - start + 1) * sizeof(*pages));
		if (!sfx_irqs_disabled()) {
			sfx_local_irq_disable();
		}

		for (i = start; i <= end; i++) {
			sfx_bug_on(!list[i]);
			if (!coh_bio) {
				pages[i - start] = list[i];
				_check_page(pages[i - start]);
			} else {
				xt_u32 list_idx;
				// from rmw
				if (!coh_bio->rmw_page_idx) {
					sfx_print(
						-1, CCS_SYS, PL_FATAL,
						"%s: BUG!! sector: %x, 4k lba %x, bio_size %x, bvec off %x, bvec len %x, bvec_nr %u\n",
						__FUNCTION__, sfx_bsec(coh_bio->bio),
						(sfx_bsec(coh_bio->bio) >> 3), sfx_bsz(coh_bio->bio),
						sfx_bvec_off(coh_bio->bio), sfx_bvec_len(coh_bio->bio),
						sfx_bvcnt(coh_bio->bio));
					sfx_ftl_assert(sfx_mdrv, 0);
					return ERROR_ASSERT;
				}
				if (!start) {
					if ((coh_bio->rmw_page_idx == FIRST_PAGE_RMW) ||
					    (coh_bio->rmw_page_idx == BOTH_PAGE_RMW)) {
						pages[i - start] = list[0];
						_check_page(pages[i - start]);
					} else if (coh_bio->rmw_page_idx == LAST_PAGE_RMW) {
						if (!coh_bio->is_trim || coh_bio->coh_bio_pnr <= 2) {
							list_idx = coh_bio->coh_bio_pnr - 1;
						} else {
							list_idx = 1;
						}
						pages[i - start] = list[list_idx];
						_check_page(pages[i - start]);
					}
				} else {
					if (!coh_bio->is_trim || coh_bio->coh_bio_pnr <= 2) {
						list_idx = coh_bio->coh_bio_pnr - 1;
					} else {
						list_idx = 1;
					}
					pages[i - start] = list[list_idx];
					_check_page(pages[i - start]);
				}
			}
		}
	}
	if (prd_entry->merge_read == 1) {
		return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, len, 1, 0) == (len) ?
			       NO_ERROR :
			       ERROR_CODE;
	} else {
		return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, end - start + 1, 1, 0) ==
				       (end - start + 1) ?
			       NO_ERROR :
			       ERROR_CODE;
	}
}

xt_u32 sfx_bd_create_r2c_seq_off(sfx_mul_drv *sfx_mdrv, union handle *bhand, xt_u32 start, xt_u32 end,
				 blk_ftl_coh_bio *coh_bio, read_entry_t *prd_entry)
{
	// sfx_page **pages;
	xt_u32 i = 0;
	// xt_u16 lba_off, index = 0;
	xt_u16 len = 0, length = 0;
	xt_u16 valid_seq = 0;
	if (prd_entry->merge_read == 1) {
		xt_u16 rd_mask = prd_entry->read_mask;

		// Borrow this function to set variables though inproper function name
		blk_ftl_prepare_pglist_para(&rd_mask, &length, &i, prd_entry->length);
		// if (sfx_irqs_disabled()) {
		// 	sfx_local_irq_enable();
		// }
		// pages = kmem_malloc(sfx_mdrv->devId, (length) * sizeof(*pages));
		// if (!sfx_irqs_disabled()) {
		// 	sfx_local_irq_disable();
		// }
		len = length;
		prd_entry->lba_seq_off = 0;
		while (length) {
			if (rd_mask & 0x1) {
				prd_entry->lba_seq_off |=
					((prd_entry->msk_to_lba[i] - prd_entry->first_lba) << 4 * valid_seq);
				// lba_off = prd_entry->msk_to_lba[i] - coh_start_lba;
				// pages[index++] = list[lba_off];
				valid_seq++;
			} else {
				//dummy
				// pages[index++] =
				// 	(sfx_page *)sfx_virt_to_page(((gc_t *)(sfx_mdrv->gc))->prd_buff, 0);
			}
			rd_mask >>= 1;
			length--;
			i++;
		}
	} else {
		/*
		if (sfx_irqs_disabled()) {
			sfx_local_irq_enable();
		}
		pages = kmem_malloc(sfx_mdrv->devId, (end - start + 1) * sizeof(*pages));
		if (!sfx_irqs_disabled()) {
			sfx_local_irq_disable();
		}

		for (i = start; i <= end; i++) {
			sfx_bug_on(!list[i]);
			if (!coh_bio) {
				pages[i - start] = list[i];
				_check_page(pages[i - start]);
			} else {
				xt_u32 list_idx;
				// from rmw
				if (!coh_bio->rmw_page_idx) {
					sfx_print(
						-1, CCS_SYS, PL_ERR,
						"%s: BUG!! sector: %x, 4k lba %x, bio_size %x, bvec off %x, bvec len %x, bvec_nr %u\n",
						__FUNCTION__, sfx_bsec(coh_bio->bio),
						(sfx_bsec(coh_bio->bio) >> 3), sfx_bsz(coh_bio->bio),
						sfx_bvec_off(coh_bio->bio), sfx_bvec_len(coh_bio->bio),
						sfx_bvcnt(coh_bio->bio));
					sfx_ftl_assert(sfx_mdrv, 0);
					return ERROR_ASSERT;
				}
				if (!start) {
					if ((coh_bio->rmw_page_idx == FIRST_PAGE_RMW) ||
					    (coh_bio->rmw_page_idx == BOTH_PAGE_RMW)) {
						pages[i - start] = list[0];
						_check_page(pages[i - start]);
					} else if (coh_bio->rmw_page_idx == LAST_PAGE_RMW) {
						if (!coh_bio->is_trim || coh_bio->coh_bio_pnr <= 2) {
							list_idx = coh_bio->coh_bio_pnr - 1;
						} else {
							list_idx = 1;
						}
						pages[i - start] = list[list_idx];
						_check_page(pages[i - start]);
					}
				} else {
					if (!coh_bio->is_trim || coh_bio->coh_bio_pnr <= 2) {
						list_idx = coh_bio->coh_bio_pnr - 1;
					} else {
						list_idx = 1;
					}
					pages[i - start] = list[list_idx];
					_check_page(pages[i - start]);
				}
			}
		}
        */
	}
	/*
	if (prd_entry->merge_read == 1) {
		return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, len, 1, 0) == (len) ?
			       NO_ERROR :
			       ERROR_CODE;
	} else {
		return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, end - start + 1, 1, 0) ==
				       (end - start + 1) ?
			       NO_ERROR :
			       ERROR_CODE;
	}
    */

	// Always return NO_ERROR
	return NO_ERROR;
}

/**
 * @brief: helper function to get the page corresponding to lba range in a bio_extra_pages
 *
 * @para[in]  bio       -- a pointer to the data structure bio_extra_pages
 * @para[in]  start     -- lba starting point (4k)
 * @para[int] end       -- lba ending point   (4k)
 */
static sfx_page **blk_ftl_bio_page(blk_ftl_coh_bio *coh_bio, xt_u32 start, xt_u32 end)
{
	xt_u32 lba, index, start_lba;
	sfx_page **pages = kmem_malloc(coh_bio->sfx_bd->sfx_mdrv->devId, (end - start + 1) * sizeof(*pages));

#ifdef SFX_LINUX
#ifdef KMALLOC_MAX_CACHE_SIZE
	if ((end - start + 1) * sizeof(*pages) > KMALLOC_MAX_CACHE_SIZE) {
		sfx_print(
			-1, BLK_SCHD, PL_ERR,
			"%s %d: Memory allocation size is too large: "
			"end=%u, start=%u, unit=%u, max_cache_size=%u bio_sector=%xh, bio_size=%xh, bio_flag=%xh\n",
			__FUNCTION__, __LINE__, end, start, sizeof(*pages), KMALLOC_MAX_CACHE_SIZE,
			sfx_bsec(coh_bio->bio), sfx_bsz(coh_bio->bio), sfx_bflag(coh_bio->bio));
	}
#endif
#endif

#ifdef ENABLE_KMEM_CACHE
	if (1 == coh_bio->is_trim && (end - start > 1)) {
		sfx_print(coh_bio->sfx_bd->sfx_mdrv->devId, BLK_REQ, PL_ERR,
			  "%s: Trim "
			  "page buf is wrong sector lba %llxh <-> %llxh page lba "
			  "%llxh <-> %llxh pass-in lba %xh <-> %xh unaligned %u\n",
			  __FUNCTION__, coh_bio->coh_bio_lba.sect_start_lba,
			  coh_bio->coh_bio_lba.sect_end_lba, coh_bio->coh_bio_lba.page_start_lba,
			  coh_bio->coh_bio_lba.page_end_lba, start, end, coh_bio->unaligned);
		sfx_ftl_assert(coh_bio->sfx_bd->sfx_mdrv, 0);
	}
#endif

	start_lba = coh_bio->coh_bio_lba.map_start_lba << MAPPING_UNIT_TO_PAGE_SHIFT;
	index = 0;
	for (lba = start; lba <= end; lba++, index++) {
		xt_u32 page_idx;
#ifdef COH_DEBUG
		if ((lba - start_lba) > coh_bio->bio_pages_range) {
			sfx_print(-1, BLK_SCHD, PL_ERR,
				  "%s %d: bio_pages index is out of range: lba %x, "
				  "coh_bio address %p, start_lba %x, idx %d, range %d, bio_pages_loc %d\n",
				  __FUNCTION__, __LINE__, lba, coh_bio, start_lba, index,
				  coh_bio->bio_pages_range, coh_bio->bio_pages_loc);
			print_coh(coh_bio->sfx_bd->sfx_mdrv);
		}
#endif
		if ((1 != coh_bio->is_trim) || coh_bio->coh_bio_pnr <= 2) {
			page_idx = lba - start_lba;
		} else {
			if (lba == start_lba) {
				page_idx = 0;
			} else {
				page_idx = 1;
			}
		}
		pages[index] = coh_bio->bio_pages[page_idx];
		_check_page(pages[index]);
	}
	return pages;
}

/**
 * @brief: convert from extra to the token data structure
 *
 * @para[in]  extra : pointer to the structure bio_extra_pages
 * @para[out] token : expected output containing token
 * @para[in]  start : start lba(4k) point
 * @para[in]  uend  : ending lba(4k) point
 * @retv:
 */
xt_u32 sfx_bd_create_token_range(union handle *bhand, blk_ftl_coh_bio *coh_bio, void **token, xt_u32 start,
				 xt_u32 uend)
{
	sfx_page **pages;
	int offset = 0;
	if (!coh_bio->unaligned && coh_bio->mem_unaligned) {
		uend++;
		offset = sfx_bio_offset(coh_bio->bio);
	}
	pages = blk_ftl_bio_page(coh_bio, start, uend);

	return sfx_user_set_pagelist(bhand, (void **)pages, (void **)token, uend - start + 1, 1, offset) ==
			       (uend - start + 1) ?
		       NO_ERROR :
		       ERROR_CODE;
}

/*
 * Copy one bvec_page to coh_bio page buf
 */
static void _copy_bio_page_to_coh_buf(blk_ftl_coh_bio *coh_bio, bio_page_buf *buf_iter, void *tmp_buf,
				      xt_u32 *remain_size, xt_u32 *buf_off, xt_u32 *buf_cp_len,
				      xt_u32 *idx_bvec, sfx_bvec_iter *bvec_iter, struct bio_vec *bvec)
{
	xt_u32 cp_len = 0;
	xt_u32 bvec_cp_off = 0, bvec_cp_len = 0;
	xt_u32 remain_only = (coh_bio->bvec_cnt > (*idx_bvec)) ? 0 : 1;
	struct bio_vec *bv = NULL;
	sfx_bio *bio = coh_bio->bio;

	if (!remain_only) {
		bv = sfx_next_bvec(bio, idx_bvec, bvec_iter, bvec);
		bvec_cp_off = bv->bv_offset;
	}

	if ((*remain_size) > 0) {
		sfx_memcpy((void *)(buf_iter->page_buf + (xt_u64)(*buf_off)), tmp_buf, *remain_size);
		(*buf_off) += (*remain_size);
		(*buf_cp_len) += (*remain_size);
	}

	if (!remain_only) {
		cp_len = (bv->bv_len > (SFX_PAGE_SIZE - (*buf_off))) ? (SFX_PAGE_SIZE - (*buf_off)) :
								       bv->bv_len;
		if (cp_len) {
			sfx_memcpy((void *)(buf_iter->page_buf + (xt_u64)(*buf_off)),
				   (void *)(sfx_page_address(bv->bv_page) + (xt_u64)bvec_cp_off), cp_len);
			(*buf_off) += cp_len;
			(*buf_cp_len) += cp_len;
			bvec_cp_off += cp_len;
			bvec_cp_len += cp_len;
		}
		/* bvec_page has data left */
		if (bv->bv_len > bvec_cp_len) {
			(*remain_size) = bv->bv_len - bvec_cp_len;
			sfx_memcpy(tmp_buf, (void *)(sfx_page_address(bv->bv_page) + (xt_u64)bvec_cp_off),
				   (*remain_size));
		} else {
			/* bvec_page has been copied out*/
			(*remain_size) = 0;
		}
	}
}

void blk_ftl_rmw_copy_bvec_to_coh_buf(blk_ftl_coh_bio *coh_bio)
{
	bio_page_buf *buf_iter = NULL;
	xt_u32 idx_bvec = 0, remain_size = 0;
	void *tmp_buf;
	struct bio_vec bvec;
	sfx_bvec_iter bvec_iter;
	int i;
	if (sfx_irqs_disabled()) {
		sfx_local_irq_enable();
	}
	tmp_buf = kmem_malloc(coh_bio->sfx_bd->sfx_mdrv->devId, SFX_PAGE_SIZE);
	if (!sfx_irqs_disabled()) {
		sfx_local_irq_disable();
	}

	if (1 != coh_bio->is_trim) {
		sfx_init_bvec_iter(coh_bio->bio, &bvec_iter, &bvec);
	}
	if (!tmp_buf) {
		sfx_print(-1, CCS_SYS, PL_WRN, "%s: Out of memory, one page request\n", __FUNCTION__);
		return;
	}
	for (i = 0; i < coh_bio->coh_bio_pnr; i++) {
		if (1 == coh_bio->is_trim && coh_bio->coh_bio_pnr > 2) {
			if (i == 2) {
				break;
			}
		}

		buf_iter = coh_bio->bio_buf_list[i];
		if (buf_iter->data) {
			xt_u32 buf_off = buf_iter->off;
			xt_u32 buf_cp_len = 0;
			if (ENABLE_UNALIGN_TRIM_DEBUG) {
				if (coh_bio->is_trim) {
					sfx_print(
						-1, BLK_REQ, PL_INF,
						"UT->%s, i %x, data %x, off %x, len %x, page_buf %x, coh %x\n",
						__FUNCTION__, i, buf_iter->data, buf_iter->off, buf_iter->len,
						buf_iter->page_buf, coh_bio);
				}
			}
			if (1 != coh_bio->is_trim) {
				do {
					// copy bvec_page one by one
					_copy_bio_page_to_coh_buf(coh_bio, buf_iter, tmp_buf, &remain_size,
								  &buf_off, &buf_cp_len, &idx_bvec,
								  &bvec_iter, &bvec);
				} while (buf_cp_len < buf_iter->len);
			} else {
				//trim unalign sector
				sfx_memset((void *)((xt_u8 *)buf_iter->page_buf + buf_iter->off), 0,
					   buf_iter->len);
			}
		}
	}
	kmem_mfree(tmp_buf);
}

/**
 * @brief: print out coh for debugging
 */
xt_u32 print_coh(sfx_mul_drv *sfx_mdrv)
{
	blk_ftl_coh_entry *g_coh_table = (blk_ftl_coh_entry *)sfx_mdrv->g_coh_table;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u32 i = 0;
	xt_u32 active_count = 0, block_count = 0, tot_outstanding_size = 0;
	map_t *gpmap = fm_get_gmap(sfx_mdrv);
	flat_map_t *map_entry = NULL;
	lba_t lba, last_lba = 0xFFFFFFFF;
	xt_u32 cnt = 0;

	tot_outstanding_size = sfx_atomic_read(&sfx_mdrv->outstanding_size);
	if (g_coh_table && gpmem_id && gpmap) {
		sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
			  "-------------- coh table print-----------------\n");
		sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
			  "loc : state  block_type  RW  TRIM  bio  bio sector  bio size  lba"
			  "sfx req  mim mem_id  mem_id  offset\n");
		for (i = 0; i < COH_TBL_SIZE; i++) {
			if (!sfx_list_empty(&g_coh_table[i].list_vertical)) {
				blk_ftl_coh_entry *iter;
				sfx_list_for_each_entry(iter, &g_coh_table[i].list_vertical, list_vertical)
				{
					if (iter == NULL) {
						break;
					}
					if (!iter->bio) {
						break;
					}
					if (iter->cur_state) {
						active_count++;
					} else {
						block_count++;
					}
					if (iter->bio->bio == NULL) {
						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "%s: iter->bio->bio, NULL pointer, continue...\n",
							  __func__);
						continue;
					}
					lba = (lba_t)(sfx_bsec(iter->bio->bio) >> PAGE_SECTORS_SHIFT);
					if (lba == last_lba)
						break;
					else {
						last_lba = lba;
						if (lba < gpmap->pmaster->lba_per_drive) {
							map_entry =
								lookup_flat_map(lba, (void **)gpmap->pl2p);
						}
						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "%x: %s, %s, %s, %s, %p, %d, "
							  "%d, %x, %p, %x, %x, %x\n",
							  i, iter->cur_state ? "A" : "B",
							  (iter->block_type == COH_BLOCK_LBA) ?
								  "LBA" :
								  (iter->block_type == COH_BLOCK_TRIM) ?
								  "TRIM" :
								  (iter->block_type == COH_BLOCK_BOTH) ?
								  "BOTH" :
								  "UNBLOCK",
							  iter->rw ? "W" : "R",
							  iter->bio->is_trim ? "T" : "NT", iter->bio->bio,
							  sfx_bsec(iter->bio->bio), sfx_bsz(iter->bio->bio),
							  lba, iter->bio->cb_para,
							  (map_entry == NULL) ? 0 : GET_MEM_ID(*map_entry),
							  (map_entry == NULL) ?
								  0 :
								  gpmem_id->param[GET_MEM_ID(*map_entry)]
									  .flash_mgr_mem_id,
							  (map_entry == NULL) ? 0 : GET_MEM_OF(*map_entry));
#ifdef COH_DEBUG
						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "coh_bio %p, state %u, tot_len %d, ost_len %d,"
							  "org_bio_size %d, org_bio_sec %xh, "
							  "bvec_cnt %d\n",
							  iter->bio, iter->bio->state, iter->bio->tot_len,
							  sfx_atomic_read(&iter->bio->outstanding_len),
							  iter->bio->org_bio_size, iter->bio->org_bio_sector,
							  iter->bio->bvec_cnt);

						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "req bvec remain cnt %d, req bvec tot len %d,"
							  "ost_len_to_act %d, ost_len_to_gc_buf %d, "
							  "rev_len_from_act %d, rev_len_from_ccs %d\n ",
							  iter->bio->cb_para->bvec_remain_count,
							  iter->bio->cb_para->bvec_tot_len,
							  iter->bio->ost_len_to_act,
							  iter->bio->ost_len_to_gc_buf,
							  sfx_atomic_read(&iter->bio->rev_len_from_act),
							  sfx_atomic_read(&iter->bio->rev_len_from_ccs));

						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "rev_len_from_gc %d, direct_handle %d, "
							  "start %d, end %d, blk offset %d\n",
							  iter->bio->rev_len_from_gc,
							  iter->bio->direct_handle, iter->bio->start,
							  iter->bio->end, iter->bio->offset_blk);
#endif
						//for reduce print, only print the first unblock entry for each vertical list
						break;
					}
				}
				sfx_udelay(10);
				if (cnt++ == 3200) {
					sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
						  "Too many prints! Quit!\n");
					break;
				}
			}
		}
		sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
			  " The COH table entry has %x active elements, "
			  "%x blocked elements, %x outstanding 4k request cur loc %x\n",
			  active_count, block_count, tot_outstanding_size, i);
		{
			xt_u32 index = 0;
			xt_u32 i;
			blk_ftl_coh_bio *iter;
			for (i = 0; i < sfx_mdrv->coh_thd_num; i++) {
				struct sfx_blk_ftl_thread *coh_thd =
					sfx_mdrv->priv_thrds.blk_ftl_coh_thread[i];
				struct req_ready_list *r_l = (struct req_ready_list *)coh_thd->private_data;
				sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
					  "------sfx_coh%d ready list stats------\n", i);
				sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF, "read ready lists len %d\n",
					  r_l->r_list_cnt);
				sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF, "blk ftl outstanding: %d %d\n",
					  sfx_atomic_read(&sfx_mdrv->outstanding_req),
					  sfx_atomic_read(&sfx_mdrv->ftl_mq_ctx->osd_req_num));
				sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF, "read readylist:\n");
				sfx_list_for_each_entry(iter, &r_l->r_list, readylist)
				{
					if (iter && iter->bio) {
						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "r %x , header %p, lba %lx, "
							  "len %lx,pointer %p,  prev %p and next %p\n",
							  index++, &r_l->r_list,
							  (unsigned long)sfx_bsec(iter->bio) >>
								  PAGE_SECTORS_SHIFT,
							  (unsigned long)(iter->bio->bi_vcnt),
							  &(iter->readylist), sfx_list_prev(iter->readylist),
							  sfx_list_next(iter->readylist));
					}
				}
				sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF, "write readylist:\n");
				sfx_list_for_each_entry(iter, &r_l->w_list, readylist)
				{
					if (iter && iter->bio) {
						sfx_print(sfx_mdrv->devId, BLK_COH, PL_INF,
							  "w header %p lba %lx, len %lx, "
							  "pointer %p prev %p and next %p\n",
							  &r_l->w_list,
							  sfx_bsec(iter->bio) >> PAGE_SECTORS_SHIFT,
							  (unsigned long)(iter->bio->bi_vcnt),
							  &(iter->readylist), sfx_list_prev(iter->readylist),
							  sfx_list_next(iter->readylist));
					}
				}
			}
		}
	}
	return active_count;
}
