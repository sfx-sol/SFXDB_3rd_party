// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfx_sysfs.h
//
// ---------------------------------------------------------------------------

#ifndef __SFX_SYSFS_H__
#define __SFX_SYSFS_H__

#include "sfx_bd_dev.h"

#define NUM_WL_OPT                      (2)    // number of wear leveling algorithm options

extern struct kobj_type smart_feature_ktype;
extern struct kobj_type debug_ktype;
extern struct kobj_type debug_level_ktype;
extern struct kobj_type vendor_ktype;
extern struct kobj_type model_ktype;
extern struct kobj_type firmware_ktype;
extern struct kobj_type software_ktype;
extern struct kobj_type nvme_ns_id_ktype;
extern struct attribute *dev_info[];
extern struct attribute *smart_feature_attrs[];
extern struct attribute *debug_attrs[];
extern struct attribute *debug_level_attrs[];

int sfx_init_sysfs(struct sfx_kobj *kobj, struct kobject *k_parent, struct kobj_type *ktype, char *name);
void sfx_exit_sysfs(struct sfx_kobj *kobj);
int sfx_add_dev_info(struct kobject *dev_kobj);
void sfx_prepare_dev_info(void);

#endif // __SFX_SYSFS_H__
