// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : blk_ftl_callback.h
//
// ---------------------------------------------------------------------------

#ifndef __BLK_FTL_CALLBACK_H__
#define __BLK_FTL_CALLBACK_H__

#include "osal.h"
#include "sfx_bd_dev.h"

typedef struct blk_ftl_callback_s
{
    ccs_callback_t              cb;
    void                        *context;
    struct sfx_mul_drv_s        *sfx_mdrv;
} blk_ftl_callback;

typedef struct blk_ftl_callback_t
{
    struct ccs_callback_context context;
    struct sfx_list_head        list;
    ccs_callback_t cb;
} blk_ftl_callback_elem;

typedef struct write_trim_range_log_cbct_s
{
    write_callback_context_t wr_cb;
    struct ccs_callback_context *trim_cmd_context;
    sfx_mul_drv *sfx_mdrv;
    xt_u32 *host_addr;
    xt_u32 mim_mem_id;
    xt_u32 start_lba_trim;
    xt_u32 lens_trim;
    void *pwrite;
} write_trim_range_log_cbct_t;

typedef struct
{
    struct sfx_mul_drv_s        *sfx_mdrv;
    struct read_s               *pread;
    xt_u32                      len;
    xt_u32                      mim_mem_id;
    xt_u16                      error;
    xt_u8                       background;
} blk_ftl_r2c_callback_elem;

/*
 * Initialize the blk ftl callback thread
 */
void blk_ftl_cb_init(struct sfx_mul_drv_s *sfx_mdrv);

/*
 * Release the blk ftl callback thread
 */
void blk_ftl_cb_free(struct sfx_mul_drv_s *sfx_mdrv);

sfxError blk_ftl_cb_callback(sfxError cmpl_status, void *context);

#endif // __BLK_FTL_CALLBACK_H__
