/*
 * ---------------------------------------------------------------------------
 *
 * Portions Copyright (c) 2015-2019, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * Filename : sfx_sysfs.c
 * ---------------------------------------------------------------------------
 */

#include "flat_map.h"
#include "gc.h"
#include "blk_ftl_coh.h"
#include "sfx_sysfs.h"
#include "sfx_driver_api.h"
#include "version_tmp.h"
#include "sfx_vdev.h"

#if defined(RHEL_RELEASE_CODE) || defined(CENTOS_TLINUX) || defined(UBUNTU12_OS)
#ifndef __ATTR_RW
#define __ATTR_RW(_name) __ATTR(_name, (S_IWUSR | S_IRUGO), _name##_show, _name##_store)
#endif
#endif

#define SFX_SYSFS_ATTR_RW(name) static struct sfx_sysfs_attr sfx_sysfs_attr_##name = __ATTR_RW(name)
#define SFX_SYSFS_ATTR_RO(name) static struct sfx_sysfs_attr sfx_sysfs_attr_##name = __ATTR_RO(name)
#define ATTR_LIST(name) (&sfx_sysfs_attr_##name.attr)

struct sfx_sysfs_attr {
	struct attribute attr;
	ssize_t (*show)(char *buf, sfx_bd_device *sfx_bd);
	ssize_t (*store)(const char *buf, size_t count, sfx_bd_device *sfx_bd);
};

static inline struct sfx_kobj *to_kobj(struct kobject *kobject)
{
	return container_of(kobject, struct sfx_kobj, kobject);
}

static inline void sfx_sysfs_release(struct kobject *kobject)
{
	struct sfx_kobj *kobj = to_kobj(kobject);
	sfx_complete(&kobj->complete);
}

static inline struct sfx_sysfs_attr *to_attr(struct attribute *attr)
{
	return container_of(attr, struct sfx_sysfs_attr, attr);
}

static inline sfx_bd_device *smart_to_sfx_bd_dev(struct kobject *kobject)
{
	struct sfx_kobj *kobj = to_kobj(kobject);
	return container_of(kobj, sfx_bd_device, smart_kobj);
}

static inline sfx_bd_device *debug_to_sfx_bd_dev(struct kobject *kobject)
{
	struct sfx_kobj *kobj = to_kobj(kobject);
	return container_of(kobj, sfx_bd_device, debug_kobj);
}

static inline sfx_bd_device *debug_level_to_sfx_bd_dev(struct kobject *kobject)
{
	struct sfx_kobj *kobj = to_kobj(kobject);
	return container_of(kobj, sfx_bd_device, debug_level_kobj);
}

static ssize_t bg_gc_timer_range_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Low: %llu\nHigh: %llu\n", sfx_bd->smart.bg_gc_timer_range_l,
			    sfx_bd->smart.bg_gc_timer_range_h);
}
SFX_SYSFS_ATTR_RO(bg_gc_timer_range);

static ssize_t sfx_write_outlier_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\n Outlier print is %s\n Write "
			    "outlier threshold %u ms\n \"echo [write_outlier_threshold_in_ms] > "
			    "sfx_read_outlier\" to change threshold (0 means disable outlier print)\n",
			    (sfx_mdrv->en_outlier_print ? "enable" : "disable"), sfx_mdrv->wr_outlier_thrd);
}

static ssize_t sfx_write_outlier_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u64 val;
	int ret;

	ret = kstrtoull(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (!val) {
		sfx_mdrv->en_outlier_print = 0;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "Disable outlier print\n");
	} else {
		sfx_mdrv->en_outlier_print = 1;
		sfx_mdrv->wr_outlier_thrd = val;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
			   "Set write outlier threshold"
			   " as %llu ms\n",
			   val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_write_outlier);

static ssize_t sfx_read_outlier_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\n Outlier print is %s\n Read "
			    "outlier threshold %u ms\n \"echo [read_outlier_threshold_in_ms] > "
			    "sfx_read_outlier\" to chagne threshold (0 means disable outlier print)\n",
			    (sfx_mdrv->en_outlier_print ? "enable" : "disable"), sfx_mdrv->rd_outlier_thrd);
}

static ssize_t sfx_read_outlier_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u64 val;
	int ret;

	ret = kstrtoull(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (!val) {
		sfx_mdrv->en_outlier_print = 0;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "Disable outlier print\n");
	} else {
		sfx_mdrv->en_outlier_print = 1;
		sfx_mdrv->rd_outlier_thrd = val;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
			   "Set read outlier threshold"
			   " as %llu ms\n",
			   val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_read_outlier);

static ssize_t bg_gc_timer_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%llu\n", sfx_bd->smart.bg_gc_timer);
}

static ssize_t bg_gc_timer_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	struct sfx_bd_smart *smart = &sfx_bd->smart;
	xt_u64 val;
	int ret;

	ret = kstrtoull(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val < smart->bg_gc_timer_range_l || val > smart->bg_gc_timer_range_h) {
		return -EINVAL;
	}
	smart->bg_gc_timer = val;

	return count;
}
SFX_SYSFS_ATTR_RW(bg_gc_timer);

static ssize_t bg_gc_threshold_range_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%u\n", sfx_bd->smart.bg_gc_threshold_range);
}
SFX_SYSFS_ATTR_RO(bg_gc_threshold_range);

static ssize_t bg_gc_threshold_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%u\n", sfx_bd->smart.bg_gc_threshold);
}

static ssize_t bg_gc_threshold_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	struct sfx_bd_smart *smart = &sfx_bd->smart;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > smart->bg_gc_threshold_range) {
		return -EINVAL;
	}
	smart->bg_gc_threshold = val;

	return count;
}
SFX_SYSFS_ATTR_RW(bg_gc_threshold);

static ssize_t reset_log_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "RESET LOG\n");
}

static ssize_t reset_log_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;
	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (val == 1) {
		fm_reset_blk_smart_log(sfx_mdrv);
		ccs_reset_log(sfx_mdrv->devId);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(reset_log);

static ssize_t flip_adaptive_read_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Flip the adaptive read mode \n");
}

static ssize_t flip_adaptive_read_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;
	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (val == 1) {
		ccs_flip_adaptive_read(sfx_mdrv->devId);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(flip_adaptive_read);

static ssize_t wear_leveling_opt_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->comp_only) {
		switch (get_wear_leveling_opt(sfx_mdrv->devId)) {
		case 0:
			return snprintf(buf, PAGE_SIZE, "constant \n");
		case 1:
			return snprintf(buf, PAGE_SIZE, "progressive \n");
		case 2:
			return snprintf(buf, PAGE_SIZE, "fast trigger \n");
		default:
			return snprintf(buf, PAGE_SIZE, "error! \n");
		}
	} else {
		return snprintf(buf, PAGE_SIZE, "comp only \n");
	}
}

static ssize_t wear_leveling_opt_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (!sfx_mdrv->comp_only)
		set_wear_leveling_opt(sfx_mdrv->devId, (xt_u8)val);
	return count;
}

SFX_SYSFS_ATTR_RW(wear_leveling_opt);

static ssize_t wl_target_endurance_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->comp_only)
		print_wl_info(sfx_mdrv->devId);
	return 1;
}

static ssize_t wl_target_endurance_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (!sfx_mdrv->comp_only)
		set_wl_target_endurance(sfx_mdrv->devId, val);
	return count;
}

SFX_SYSFS_ATTR_RW(wl_target_endurance);

static ssize_t wl_default_threshold_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->comp_only)
		print_wl_info(sfx_mdrv->devId);
	return 1;
}

static ssize_t wl_default_threshold_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (!sfx_mdrv->comp_only)
		set_wl_default_threshold(sfx_mdrv->devId, val);
	return count;
}

SFX_SYSFS_ATTR_RW(wl_default_threshold);

static ssize_t wl_stop_show(char *buf, sfx_bd_device *sfx_bd)
{
	return snprintf(buf, PAGE_SIZE, "stop wl \n");
}

static ssize_t wl_stop_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (!sfx_mdrv->comp_only)
		stop_wl(sfx_mdrv->devId);
	return count;
}
SFX_SYSFS_ATTR_RW(wl_stop);

static ssize_t trigger_wl_early_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->comp_only && is_wl_trigger_early(sfx_mdrv->devId))
		return snprintf(buf, PAGE_SIZE, "wl is triggered early \n");
	else
		return snprintf(buf, PAGE_SIZE, "wl is not triggered early \n");
}

static ssize_t trigger_wl_early_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (!sfx_mdrv->comp_only)
		trigger_wl_early(sfx_mdrv->devId, (xt_u8)val);
	return count;
}
SFX_SYSFS_ATTR_RW(trigger_wl_early);

static ssize_t wl_default_gap_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->comp_only)
		print_wl_info(sfx_mdrv->devId);
	return 1;
}

static ssize_t wl_default_gap_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (!sfx_mdrv->comp_only)
		set_wl_default_gap(sfx_mdrv->devId, val);
	return count;
}

SFX_SYSFS_ATTR_RW(wl_default_gap);

static ssize_t wear_leveling_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%u\n", sfx_bd->smart.wear_leveling);
}

static ssize_t wear_leveling_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	struct sfx_bd_smart *smart = &sfx_bd->smart;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > (NUM_WL_OPT - 1)) {
		return -EINVAL;
	}
	smart->wear_leveling = val;

	return count;
}
SFX_SYSFS_ATTR_RW(wear_leveling);

static ssize_t read_scrub_range_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Low: %llu\nHigh: %llu\n", sfx_bd->smart.read_scrub_range_l,
			    sfx_bd->smart.read_scrub_range_h);
}
SFX_SYSFS_ATTR_RO(read_scrub_range);

static ssize_t read_scrub_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%llu\n", sfx_bd->smart.read_scrub);
}

static ssize_t read_scrub_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	struct sfx_bd_smart *smart = &sfx_bd->smart;
	xt_u64 val;
	int ret;

	ret = kstrtoull(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val < smart->read_scrub_range_l || val > smart->read_scrub_range_h) {
		return -EINVAL;
	}
	smart->read_scrub = val;

	return count;
}
SFX_SYSFS_ATTR_RW(read_scrub);

static ssize_t sfx_feature_stat_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv;
	xt_u32 ms = 0, aw = 0;

	sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	ms = (sfx_mdrv->multi_stream_mode == SINGLE_STREAM_MODE) ? 0 : 1;
	aw = sfx_mdrv->atomic_write ? 1 : 0;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "SFX SW Multi-Stream mode is %s\n"
			    "SFX SW Atomic-Write mode is %s\n",
			    (ms ? "on" : "off"), (aw ? "on" : "off"));
}
static ssize_t sfx_feature_stat_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	return count;
}
SFX_SYSFS_ATTR_RW(sfx_feature_stat);

static ssize_t blk_ftl_gc_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_gc\" to dump block"
			    " ftl gc internal status to /var/log/sfx_messages");
}
static ssize_t blk_ftl_gc_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv;
	gc_t *gc;
	wl_t *wl;
	gc_t *wgc;
	xt_u8 val;
	int ret;

	if (sfx_bd == NULL) {
		return count;
	}

	sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (sfx_mdrv == NULL) {
		return count;
	}
	gc = sfx_mdrv->gc;
	wl = (wl_t *)sfx_mdrv->wl;
	if (wl) {
		wgc = (gc_t *)wl->gc;
	} else {
		wgc = NULL;
	}

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		gc_debug_print(sfx_mdrv, gc);
		gc_debug_print(sfx_mdrv, wgc);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_gc);

static ssize_t blk_ftl_act_config_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "ACT Mode: %s\n",
			    (sfx_mdrv->act_mode == 1) ? "On" :
							((sfx_mdrv->act_mode == 0) ? "Off" : "Not Set"));
}

static ssize_t blk_ftl_act_config_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	map_t *gmap = fm_get_gmap(sfx_mdrv);
	gc_t *gc = sfx_mdrv->gc;

	xt_u8 val;
	xt_32 ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		gmap->max_write_cmd_pending = FM_MAX_GC_WRITE_CMD_PENDING_ACT_MODE;
		gmap->fm_max_read_cmd_pending = FM_MAX_READ_CMD_PENDING_ACT_MODE;
		sfx_mdrv->act_mode = 1;
		sfx_mdrv->gc_start_trigger = GC_START_TRIGGER + 4;
		sfx_mdrv->gc_stop_trigger = GC_STOP_TRIGGER + 4;
		gc->gc_read_size = 16;
		gc->gc_max_gather_pending = 2;
	} else if (val == 0) {
		gmap->max_write_cmd_pending = FM_MAX_GC_WRITE_CMD_PENDING;
		gmap->fm_max_read_cmd_pending = FM_MAX_READ_CMD_PENDING;
		sfx_mdrv->act_mode = 0;
		sfx_mdrv->gc_start_trigger = GC_START_TRIGGER;
		sfx_mdrv->gc_stop_trigger = GC_STOP_TRIGGER;
		gc->gc_read_size = 16;
		gc->gc_max_gather_pending = 2;
	}

	if (val == 1 || val == 0) {
		gpmem_id->smart.max_write_cmd_pending = gmap->max_write_cmd_pending;
		gpmem_id->smart.fm_max_read_cmd_pending = gmap->fm_max_read_cmd_pending;
		gpmem_id->smart.act_mode = sfx_mdrv->act_mode;
		gpmem_id->smart.gc_start_trigger = sfx_mdrv->gc_start_trigger;
		gpmem_id->smart.gc_stop_trigger = sfx_mdrv->gc_stop_trigger;
		gpmem_id->smart.gc_max_gather_pending = gc->gc_max_gather_pending;
		gpmem_id->smart.enable_blk_ftl_act_config = 1;
		fm_flush_master_table(sfx_mdrv, FM_NORMAL);
		fm_print_smart(sfx_mdrv);
		fm_wait_flush_master_done(sfx_mdrv);
	}

	ccs_actmode_config(sfx_mdrv->devId, val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_act_config);

static ssize_t sfx_rwr_me_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Low write latency: %s\n",
			    (sfx_mdrv->rwr_me == 1) ? "On" : ((sfx_mdrv->rwr_me == 0) ? "Off" : "Not Set"));
}

static ssize_t sfx_rwr_me_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

	xt_u8 val;
	xt_32 ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		sfx_mdrv->rwr_me = 1;
	} else if (val == 0) {
		sfx_mdrv->rwr_me = 0;
	}

	if (val == 1 || val == 0) {
		gpmem_id->smart.rwr_me = sfx_mdrv->rwr_me;
		gpmem_id->smart.enable_rwr_me = 1;
		fm_flush_master_table(sfx_mdrv, FM_NORMAL);
		fm_print_smart(sfx_mdrv);
		fm_wait_flush_master_done(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_rwr_me);

static ssize_t sfx_u2_mode_config_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "U.2 Mode: %s\n",
			    (sfx_mdrv->u2_mode == 1) ?
				    "Performance " :
				    ((sfx_mdrv->u2_mode == 2) ? "Power Saving" : "Not Set"));
}
static ssize_t sfx_u2_mode_config_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	gpmem_id->smart.u2_mode = sfx_mdrv->u2_mode;
	gpmem_id->smart.enable_sfx_u2_mode_config = 1;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	fm_print_smart(sfx_mdrv);
	fm_wait_flush_master_done(sfx_mdrv);

	fm_set_u2_mode_config(sfx_mdrv, val);

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_u2_mode_config);

/*
 * Check whether I/O has been locked.
 */
static ssize_t lock_status_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n",
			    sfx_atomic_read(&sfx_bd->sfx_mdrv->device_state) ==
					    SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS ||
				    sfx_atomic_read(&sfx_bd->sfx_mdrv->surprising_remove) > 0 ||
				    sfx_atomic_read(&sfx_bd->sfx_mdrv->flag_dev_freeze) > 0);
}
SFX_SYSFS_ATTR_RO(lock_status);

static ssize_t pfail_lock_status_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n",
			    sfx_atomic_read(&sfx_bd->sfx_mdrv->device_state) ==
					    SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS ||
				    ccs_is_data_loss_mode(sfx_bd->sfx_mdrv->devId));
}
SFX_SYSFS_ATTR_RO(pfail_lock_status);

static ssize_t pfail_lock_override_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "Echo 1 to resume I/O without data erase.\n"
			    "Current Status: %s (I/O), %s (device).\n",
			    sfx_atomic_read(&sfx_bd->sfx_mdrv->read_mode) > 0 ? "readonly" : "normal",
			    sfx_device_state_get(sfx_atomic_read(&sfx_bd->sfx_mdrv->device_state)));
}
static ssize_t pfail_lock_override_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}
	if (val != 1) {
		goto out;
	}
	/* Only override pfail dataloss lock. */
	if (sfx_atomic_read(&sfx_bd->sfx_mdrv->device_state) != SFX_DEVICE_STATE_RWLOCK_BY_DATALOSS) {
		goto out;
	}

	sfx_print(sfx_bd->sfx_mdrv->devId, CCS_SYS, PL_INF, "Cleaning up pfail readonly lock from sysfs.\n");
	sfx_mdrv_state_machine(sfx_bd->sfx_mdrv, SFX_DEVICE_STATE_RUNNING);

out:
	return count;
}
SFX_SYSFS_ATTR_RW(pfail_lock_override);

static ssize_t ccs_erase_config_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_erase_config\" to change "
			    " erase point [p0<<4 | p1]");
}
static ssize_t ccs_erase_config_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 p0, p1;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	p0 = val & 0xFF;
	p1 = (val >> 16) & 0xFF;
	sfx_print(sfx_mdrv->devId, CCS_SYS, PL_DBG, "%s: p0 %u, p1 %u\n", p0, p1);
	if (val == 1) {
		ccs_erase_point_config(sfx_mdrv->devId, p0, p1, 0);
	} else if (val == 2) {
		ccs_erase_point_config(sfx_mdrv->devId, p0, p1, 1);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_erase_config);

static ssize_t blk_ftl_schedule_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_schedule\" to dump block"
			    " ftl scheduler internal status to /var/log/sfx_messages");
}
static ssize_t blk_ftl_schedule_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		blk_ftl_schedule_print(sfx_mdrv);
		blk_ftl_throttle_debug(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_schedule);

static ssize_t blk_ftl_perf_enable_show(char *buf, sfx_bd_device *sfx_bd)
{
#if MEASURE_TIME
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n", sfx_mdrv->open_measure_time);
#else
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n", 0);
#endif
}
static ssize_t blk_ftl_perf_enable_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	req_handle_perf_debug_enable(sfx_mdrv, val);

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_perf_enable);

static ssize_t gc_distribution_enable_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n", sfx_mdrv->gc_distribution_check);
}
static ssize_t gc_distribution_enable_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	enable_gc_distribution_check(sfx_mdrv, val);

	return count;
}
SFX_SYSFS_ATTR_RW(gc_distribution_enable);

static ssize_t blk_ftl_perf_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_perf\" to dump block"
			    " ftl performance info to /var/log/sfx_messages");
}
static ssize_t blk_ftl_perf_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		blk_ftl_schedule_print(sfx_mdrv);
		gc_perf_debug(sfx_mdrv);
		req_handle_perf_debug(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_perf);

static ssize_t blk_ftl_set_bg_gc_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_no_bg_gc\" to start/stop background gc");
}
static ssize_t blk_ftl_set_bg_gc_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	blk_ftl_no_bg_gc(sfx_mdrv, val);

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_set_bg_gc);

static ssize_t blk_ftl_gc_iops_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_gc_iops\" to dump block"
			    " ftl performance info to /var/log/sfx_messages");
}
static ssize_t blk_ftl_gc_iops_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		gc_perf_iops(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_gc_iops);

static ssize_t blk_ftl_perf_linux_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_linux_perf\" to dump block"
			    " ftl performance info to /var/log/sfx_messages");
}
static ssize_t blk_ftl_perf_linux_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		blk_ftl_perf_linux_print(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_perf_linux);

static ssize_t sfx_l2p_table_dump_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/sfx_l2p_table_dump\" "
			    "to start dump the l2p table in sfx_l2p_table_dump_.dat");
}

static ssize_t sfx_l2p_table_dump_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		l2p_table_dump(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_l2p_table_dump);

static ssize_t blk_ftl_erase_secure_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_erase_secure\" to start secure erase process");
}

static ssize_t blk_ftl_erase_secure_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		secure_erase(sfx_mdrv, 1);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_erase_secure);

static ssize_t read_disturb_set_values_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/read_disturb_set_values\" to set the read disturb lower threshold value."
		"Higher threshold will be calculated accordingly. Valid threshold is between 10000 and 2500000");
}

static ssize_t read_disturb_set_values_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val < 10000 || val > 2500000) {
		return 0;
	}
	ccs_set_read_distb_values(sfx_mdrv->devId, val);

	return count;
}
SFX_SYSFS_ATTR_RW(read_disturb_set_values);

static ssize_t set_overprovisioning_cap_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u32 namespace_id = sfx_bd->sfx_bd_id - 1;
	xt_u64 mem_id_size_in_mb;
	xt_u64 nsectors = sfx_bd->sfx_bd_lba_cnt;
	xt_u64 num_blks_ns;

	mem_id_size_in_mb = ((sfx_mdrv->blk_ft_cfg.default_mem_id_size * 4096) / (1024 * 1024));

	num_blks_ns = (xt_u32)((nsectors / (xt_u64)MIM_SECTORS_PER_FOUR_KB) /
			       sfx_mdrv->blk_ft_cfg.default_mem_id_size);

	if (sfx_mdrv->sfx_bd_cnt == 1) {
		return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", "No namespace id");
	}

	if (namespace_id > sfx_mdrv->sfx_bd_cnt) {
		return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", "Entered namespace_id is wrong");
	}

	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "size reserved is: %llu\n",
		(xt_u64)((gpmem_id->threshold_per_stream[namespace_id] - num_blks_ns) * mem_id_size_in_mb));
}

static ssize_t set_overprovisioning_cap_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u64 val;
	int ret;

	ret = kstrtoull(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val) {
		xt_u32 namespace_id = sfx_bd->sfx_bd_id - 1;
		mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
		sfxError status;

		status = fm_verify_op(sfx_mdrv, namespace_id, val, sfx_bd->sfx_bd_lba_cnt);
		if (status == NO_ERROR) {
			count = set_stream_gc_threshold(sfx_mdrv, namespace_id, val, sfx_bd->sfx_bd_lba_cnt);
			gpmem_id->smart.op_val = val;
			gpmem_id->smart.namespace_id = namespace_id;
			gpmem_id->smart.sfx_bd_lba_cnt = sfx_bd->sfx_bd_lba_cnt;
			gpmem_id->smart.enable_set_overprovision = 1;
			fm_flush_master_table(sfx_mdrv, FM_NORMAL);
			fm_print_smart(sfx_mdrv);
			fm_wait_flush_master_done(sfx_mdrv);
		}
	}

	return count;
}
SFX_SYSFS_ATTR_RW(set_overprovisioning_cap);

static ssize_t set_non_gc_stream_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo #val > /sys/block/#dev_name/sfx_smart_feature\" "
			    "/set_non_gc_stream to ignor GC credit control.");
}

static ssize_t set_non_gc_stream_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	gpmem_id->smart.non_gc_stream = val;
	gpmem_id->smart.enable_set_non_gc_stream = 1;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	fm_print_smart(sfx_mdrv);
	fm_wait_flush_master_done(sfx_mdrv);

	ccs_set_non_gc_stream(sfx_mdrv->devId, val);

	return count;
}
SFX_SYSFS_ATTR_RW(set_non_gc_stream);

static ssize_t hw_cmd_scheduler_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%d\n", ccs_get_hw_cmd_sched(sfx_mdrv->devId));
}

static ssize_t hw_cmd_scheduler_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val != 0 && val != 1) {
		goto out;
	}

	gpmem_id->smart.enable_sfx_hw_cmd_scheduler = val;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	fm_print_smart(sfx_mdrv);
	fm_wait_flush_master_done(sfx_mdrv);
	ccs_set_hw_cmd_sched(sfx_mdrv->devId, val);
out:
	return count;
}
SFX_SYSFS_ATTR_RW(hw_cmd_scheduler);

static ssize_t sfx_assert_restore_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	sfx_device_state device_state = sfx_atomic_read(&sfx_mdrv->device_state);
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "Current SFX device state: %u[%s].\n"
			    "echo %u to set device from freeze mode to read-only mode;\n"
			    "echo %u to set device from freeze mode to normal state.\n"
			    "echo %u to set device from read-only mode to normal state.\n",
			    device_state, sfx_device_state_get(device_state), SFX_FREEZE_TO_RDONLY,
			    SFX_FREEZE_TO_NORMAL, SFX_RDONLY_TO_NORMAL);
}
static ssize_t sfx_assert_restore_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	sfx_thread_pool *priv_thrds = &sfx_mdrv->priv_thrds;
	xt_u8 val;
	int i, ret;

	/* Sanity Check: input. */
	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s: cannot convert input value.\n",
			  __FUNCTION__);

		return ret;
	}
	if (val != SFX_FREEZE_TO_RDONLY && val != SFX_FREEZE_TO_NORMAL && val != SFX_RDONLY_TO_NORMAL) {
		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN, "%s: unsupported input value %u.\n", val,
			  __FUNCTION__);

		goto fail;
	}

	/* Sanity Check: every thread should be parked. */
	for (i = 0; i < SFX_PRIV_THREAD_SLOT_TOTAL; i++) {
		/*
         * Skip some possibly empty ones.
         *
         * Note: add new exception threads here.
         */
		if (&priv_thrds->thread_array[i] == &priv_thrds->polling_thread ||
		    &priv_thrds->thread_array[i] == &priv_thrds->g_map_thread1) {
			continue;
		}

		if (sfx_atomic_read(&priv_thrds->thread_array[i].state) != SFX_THRD_PARKING) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
				  "%s: private thread[%d] %p state \"%s\"(%d) is not parked.\n", __FUNCTION__,
				  i, &priv_thrds->thread_array[i],
				  current_thread_state(sfx_atomic_read(&priv_thrds->thread_array[i].state)),
				  sfx_atomic_read(&priv_thrds->thread_array[i].state));

			goto fail;
		}
	}

	switch (val) {
	case SFX_FREEZE_TO_RDONLY:
	case SFX_FREEZE_TO_NORMAL:
		if (sfx_atomic_read(&sfx_mdrv->device_state) != SFX_DEVICE_STATE_READONLY_BY_DATALOSS ||
		    !sfx_atomic_read(&sfx_mdrv->flag_dev_freeze)) {
			goto state_check_fail;
		}

		if (val == SFX_FREEZE_TO_RDONLY) {
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF,
				  "%s: turn CCS from freeze to read-only.\n", __FUNCTION__);
			sfx_atomic_set(&sfx_mdrv->device_state, SFX_DEVICE_STATE_READONLY);
			sfx_atomic_set(&sfx_mdrv->read_mode, 1);
		} else { /* val == SFX_FREEZE_TO_NORMAL */
			sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: turn CCS from freeze to normal.\n",
				  __FUNCTION__);
			sfx_atomic_set(&sfx_mdrv->device_state, SFX_DEVICE_STATE_RUNNING);
			sfx_atomic_set(&sfx_mdrv->read_mode, 0);
		}

		break;
	case SFX_RDONLY_TO_NORMAL:
		if (sfx_atomic_read(&sfx_mdrv->device_state) != SFX_DEVICE_STATE_READONLY &&
		    !sfx_atomic_read(&sfx_mdrv->flag_dev_freeze)) {
			goto state_check_fail;
		}

		sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: turn CCS from read-only to normal.\n",
			  __FUNCTION__);
		sfx_atomic_set(&sfx_mdrv->read_mode, 0);
		sfx_atomic_set(&sfx_mdrv->device_state, SFX_DEVICE_STATE_RUNNING);

		break;
	}

	sfx_atomic_set(&sfx_mdrv->flag_dev_freeze, 0);
	sfx_atomic_set(&sfx_mdrv->assert_handle_action, val);
	set_ccs_assert_handle(sfx_mdrv->devId, val);
	blk_ftl_wakeup_priv_thrd(sfx_mdrv);
	blk_ftl_cleanup_priv_thrd(sfx_mdrv);

	return count;

state_check_fail:
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_WRN,
		  "%s: devices status check failed: device_state %s[%u], flag_dev_freeze %u.\n", __FUNCTION__,
		  sfx_device_state_get(sfx_atomic_read(&sfx_mdrv->device_state)),
		  sfx_atomic_read(&sfx_mdrv->device_state), sfx_atomic_read(&sfx_mdrv->flag_dev_freeze));

	goto fail;

fail:
	sfx_print(sfx_mdrv->devId, BLK_SYS, PL_INF, "%s: SFX device cannot be recovered at this point\n",
		  __FUNCTION__);

	return count;
}
SFX_SYSFS_ATTR_RW(sfx_assert_restore);

static ssize_t blk_ftl_mdata_vfy_scan_l2p_table_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_mdata_vfy_scan_l2p_table\" "
			    "to start l2p scan process");
}

static ssize_t blk_ftl_mdata_vfy_scan_l2p_table_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		mdata_vfy_scan_l2p_table(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_mdata_vfy_scan_l2p_table);

static ssize_t blk_ftl_mdata_vfy_scan_valid_mem_ids_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_mdata_vfy_scan_valid_mem_ids\" to start l2p scan process");
}

static ssize_t blk_ftl_mdata_vfy_scan_valid_mem_ids_store(const char *buf, size_t count,
							  sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		mdata_vfy_scan_all_valid_mem_ids(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_mdata_vfy_scan_valid_mem_ids);

static ssize_t blk_ftl_mdata_get_reverse_lba_show(char *buf, sfx_bd_device *sfx_bd)
{
	return snprintf(buf, PAGE_SIZE, "%s\n",
			"\"echo \"string\" in the form of \"memid_offset\""
			" > /sys/block/sfx_bd/sfx_debug/blk_ftl_mdata_get_reverse_lba\" to "
			"get the reverse lba");
}

static ssize_t blk_ftl_mdata_get_reverse_lba_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	mdata_get_reverse_lba_from_mem_id_offset(sfx_mdrv, buf);

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_mdata_get_reverse_lba);

static ssize_t blk_ftl_coherency_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_coherency\" to dump block"
			    " ftl coherency table to /var/log/sfx_messages");
}

static ssize_t blk_ftl_coherency_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		print_coh(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_coherency);

static ssize_t blk_ftl_mim_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/blk_ftl_mim\" to dump block"
		" ftl memID manager status to /var/log/sfx_messages\n"
		"\"echo #mem_id > /sys/block/sfx_bd/sfx_debug/blk_ftl_mim\" to dump mem_id footer");
}
static ssize_t blk_ftl_mim_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		mem_id_mgm_print(sfx_mdrv);
		//map_footer_print(sfx_mdrv);
	}

	if (val == 2) {
		map_footer_print_mem_id(sfx_mdrv, val);
	}

	if (val == 3) {
		open_maplog_context_print(sfx_mdrv);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_mim);

static ssize_t ccs_stats_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_stats\" to dump ccs"
			    " internal control data structures to /var/log/sfx_messages");
}
static ssize_t ccs_stats_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_Internal_status(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_stats);

static ssize_t inject_messages_show(char *buf, sfx_bd_device *sfx_bd)
{
	return snprintf(buf, PAGE_SIZE, "%s\n",
			"\"echo \"string\" > /sys/block/sfx_bd/sfx_debug/inject_messages\" to"
			" inject \"string\" to /var/log/sfx_messages");
}
static ssize_t inject_messages_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	ccs_inject_messages(sfx_mdrv->devId, buf);
	return count;
}
SFX_SYSFS_ATTR_RW(inject_messages);

static ssize_t sfx_assert_debug_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	struct sfx_blk_ftl_thread *assert_thread = &sfx_mdrv->priv_thrds.assert_thread;
	struct sfx_blk_ftl_thread *g_map_thread1 = &sfx_mdrv->priv_thrds.g_map_thread1;
	struct sfx_blk_ftl_thread *meta_data_thread = &sfx_mdrv->priv_thrds.meta_data_thread;
	struct sfx_blk_ftl_thread *gc_write_thread = &sfx_mdrv->priv_thrds.gc_write_thread;
	struct sfx_blk_ftl_thread *gc_read_thread = &sfx_mdrv->priv_thrds.gc_read_thread;
	struct sfx_blk_ftl_thread *wl_thread = &sfx_mdrv->priv_thrds.wl_thread;
	struct sfx_blk_ftl_thread *g_mim_thread = &sfx_mdrv->priv_thrds.g_mim_thread;
	struct sfx_blk_ftl_thread *ccs_thread = &sfx_mdrv->priv_thrds.ccs_thread;
	struct sfx_blk_ftl_thread *defer_smt_thread = &sfx_mdrv->priv_thrds.defer_smt_thread;
	struct sfx_blk_ftl_thread *blk_ftl_cb_thread = &sfx_mdrv->priv_thrds.blk_ftl_cb_thread;
	struct sfx_blk_ftl_thread *blk_ftl_err_handle_thread =
		&sfx_mdrv->priv_thrds.blk_ftl_err_handle_thread;
	struct sfx_blk_ftl_thread *blk_ftl_read_distb_thread =
		&sfx_mdrv->priv_thrds.blk_ftl_read_distb_thread;
	struct sfx_blk_ftl_thread *blk_ftl_throttle_thread = &sfx_mdrv->priv_thrds.blk_ftl_throttle_thread;
	struct sfx_blk_ftl_thread *blk_ftl_bg_thread = &sfx_mdrv->priv_thrds.blk_ftl_bg_thread;
	struct sfx_blk_ftl_thread *polling_thread = &sfx_mdrv->priv_thrds.polling_thread;
	struct sfx_blk_ftl_thread *blk_ftl_maplog_eh_thread = &sfx_mdrv->priv_thrds.blk_ftl_maplog_eh_thread;

	return sfx_snprintf(
		buf, SFX_PAGE_SIZE,
		"     assert_thread pid: %7u, state: %10s[%u]\n"
		"     g_map_thread1 pid: %7u, state: %10s[%u]\n"
		"  meta_data_thread pid: %7u, state: %10s[%u]\n"
		"   gc_write_thread pid: %7u, state: %10s[%u]\n"
		"    gc_read_thread pid: %7u, state: %10s[%u]\n"
		"         wl_thread pid: %7u, state: %10s[%u]\n"
		"      g_mim_thread pid: %7u, state: %10s[%u]\n"
		"        ccs_thread pid: %7u, state: %10s[%u]\n"
		"  defer_smt_thread pid: %7u, state: %10s[%u]\n"
		"        _cb_thread pid: %7u, state: %10s[%u]\n"
		" err_handle_thread pid: %7u, state: %10s[%u]\n"
		" read_distb_thread pid: %7u, state: %10s[%u]\n"
		"   throttle_thread pid: %7u, state: %10s[%u]\n"
		"         bg_thread pid: %7u, state: %10s[%u]\n"
		"    polling_thread pid: %7u, state: %10s[%u]\n"
		"  maplog_eh_thread pid: %7u, state: %10s[%u]\n",

		assert_thread->pid, current_thread_state(sfx_atomic_read(&assert_thread->state)),
		sfx_atomic_read(&assert_thread->state),

		g_map_thread1->pid, current_thread_state(sfx_atomic_read(&g_map_thread1->state)),
		sfx_atomic_read(&g_map_thread1->state),

		meta_data_thread->pid, current_thread_state(sfx_atomic_read(&meta_data_thread->state)),
		sfx_atomic_read(&meta_data_thread->state),

		gc_write_thread->pid, current_thread_state(sfx_atomic_read(&gc_write_thread->state)),
		sfx_atomic_read(&gc_write_thread->state),

		gc_read_thread->pid, current_thread_state(sfx_atomic_read(&gc_read_thread->state)),
		sfx_atomic_read(&gc_read_thread->state),

		wl_thread->pid, current_thread_state(sfx_atomic_read(&wl_thread->state)),
		sfx_atomic_read(&wl_thread->state),

		g_mim_thread->pid, current_thread_state(sfx_atomic_read(&g_mim_thread->state)),
		sfx_atomic_read(&g_mim_thread->state),

		ccs_thread->pid, current_thread_state(sfx_atomic_read(&ccs_thread->state)),
		sfx_atomic_read(&ccs_thread->state),

		defer_smt_thread->pid, current_thread_state(sfx_atomic_read(&defer_smt_thread->state)),
		sfx_atomic_read(&defer_smt_thread->state),

		blk_ftl_cb_thread->pid, current_thread_state(sfx_atomic_read(&blk_ftl_cb_thread->state)),
		sfx_atomic_read(&blk_ftl_cb_thread->state),

		blk_ftl_err_handle_thread->pid,
		current_thread_state(sfx_atomic_read(&blk_ftl_err_handle_thread->state)),
		sfx_atomic_read(&blk_ftl_err_handle_thread->state),

		blk_ftl_read_distb_thread->pid,
		current_thread_state(sfx_atomic_read(&blk_ftl_read_distb_thread->state)),
		sfx_atomic_read(&blk_ftl_read_distb_thread->state),

		blk_ftl_throttle_thread->pid,
		current_thread_state(sfx_atomic_read(&blk_ftl_throttle_thread->state)),
		sfx_atomic_read(&blk_ftl_throttle_thread->state),

		blk_ftl_bg_thread->pid, current_thread_state(sfx_atomic_read(&blk_ftl_bg_thread->state)),
		sfx_atomic_read(&blk_ftl_bg_thread->state),

		polling_thread->pid, current_thread_state(sfx_atomic_read(&polling_thread->state)),
		sfx_atomic_read(&polling_thread->state),

		blk_ftl_maplog_eh_thread->pid,
		current_thread_state(sfx_atomic_read(&blk_ftl_maplog_eh_thread->state)),
		sfx_atomic_read(&blk_ftl_maplog_eh_thread->state));
}
static ssize_t sfx_assert_debug_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	xt_u8 val;
	int ret;
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		sfx_mdrv->assert_debug = 1;
	}
	return count;
}
SFX_SYSFS_ATTR_RW(sfx_assert_debug);
static ssize_t ccs_snapshot_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_snapshot\" to dump ccs"
			    " all internal tables to /var/log/sfx_messages");
}
static ssize_t ccs_snapshot_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_SnapshotTables(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_snapshot);

static ssize_t ccs_app_q_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE, "%s\n",
		"\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_act\" to dump ccs act table to /var/log/sfx_messages");
}

static ssize_t ccs_app_q_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if ((char)val >= 0) {
#if MEASURE_FUNC_TIME
		if (sfx_atomic64_read(&sfx_mdrv->nr_ccs_cb)) {
			sfx_print(sfx_mdrv->devId, CCS_SYS, PL_DBG,
				  "BLK_FTL function latency: ccs callback(): %lu, %lu, %lu ns\n",
				  sfx_atomic64_read(&sfx_mdrv->nr_ccs_cb),
				  sfx_atomic64_read(&sfx_mdrv->time_ccs_cb),
				  sfx_atomic64_read(&sfx_mdrv->time_ccs_cb) /
					  sfx_atomic64_read(&sfx_mdrv->nr_ccs_cb));
			sfx_print(sfx_mdrv->devId, CCS_SYS, PL_DBG,
				  "BLK_FTL function latency: ccs callback enqueue(): %lu, %lu, %lu ns\n",
				  sfx_atomic64_read(&sfx_mdrv->nr_cb_enqueue),
				  sfx_atomic64_read(&sfx_mdrv->time_cb_enqueue),
				  sfx_atomic64_read(&sfx_mdrv->time_cb_enqueue) /
					  sfx_atomic64_read(&sfx_mdrv->nr_cb_enqueue));
		}
		sfx_atomic64_set(&sfx_mdrv->nr_ccs_cb, 0);
		sfx_atomic64_set(&sfx_mdrv->nr_cb_enqueue, 0);
		sfx_atomic64_set(&sfx_mdrv->time_ccs_cb, 0);
		sfx_atomic64_set(&sfx_mdrv->time_cb_enqueue, 0);
#endif
		ccs_dump_app_q(sfx_mdrv->devId, val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_app_q);

static ssize_t ccs_nvme_q_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_fcq\" to dump ccs"
			    " fcq table to /var/log/sfx_messages");
}
static ssize_t ccs_nvme_q_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if ((char)val >= 0) {
		ccs_dump_nvme_q(sfx_mdrv->devId, val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_nvme_q);

static ssize_t ccs_remap_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_remap\" to dump ccs"
			    " remap table to /var/log/sfx_messages");
}
static ssize_t ccs_remap_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		/*TODO*/
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_remap);

static ssize_t ccs_map_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_map\" to dump ccs"
			    " map table to /var/log/sfx_messages");
}
static ssize_t ccs_map_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_DumpMap(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_map);

static ssize_t ccs_write_session_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_write_session\" to dump ccs"
			    " write session table to /var/log/sfx_messages");
}
static ssize_t ccs_write_session_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_DumpWS(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_write_session);

static ssize_t blk_rd_debug_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Current blk debug table idx = %llu\n",
			    sfx_mdrv->blk_rd_debug_idx);
}

static ssize_t blk_rd_debug_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		xt_u64 i;
		for (i = 0; i < HOT_RD_DEBUG_TABLE_ENTRY_NUM; i++) {
			if ((sfx_mdrv->blk_rd_debug_table[i]->lba == 0) &&
			    (sfx_mdrv->blk_rd_debug_table[i]->len == 0) &&
			    (sfx_mdrv->blk_rd_debug_table[i]->mid == 0) &&
			    (sfx_mdrv->blk_rd_debug_table[i]->off == 0)) {
			} else {
				sfd_dbgmsg(sfx_mdrv->devId, BLK_SYS, PL_INF,
					   "blk entry %llu lba=%xh "
					   "len=%u mid=%xh off=%x\n",
					   i, sfx_mdrv->blk_rd_debug_table[i]->lba,
					   sfx_mdrv->blk_rd_debug_table[i]->len,
					   sfx_mdrv->blk_rd_debug_table[i]->mid,
					   sfx_mdrv->blk_rd_debug_table[i]->off);
				sfx_usleep(20);
			}
		}
	}

	return count;
}
SFX_SYSFS_ATTR_RW(blk_rd_debug);

static ssize_t ccs_rd_debug_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u64 idx = ccs_rd_debug_func(sfx_mdrv->devId, 0);

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Current debug table idx = %llu\n", idx);
}
static ssize_t ccs_rd_debug_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		ccs_rd_debug_func(sfx_mdrv->devId, 1);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_rd_debug);

static ssize_t ccs_sblock_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_sblock\" to dump ccs"
			    " sblock table to /var/log/sfx_messages");
}
static ssize_t ccs_sblock_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_DumpSBlock(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_sblock);

static ssize_t ccs_thermal_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_thermal\" to dump ccs"
			    " temperature histogram to /var/log/sfx_messages");
}
static ssize_t ccs_thermal_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		ccs_dump_temperature(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_thermal);

static ssize_t ccs_nvme_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_nvme\" to dump ccs"
			    " nvme command queue to /var/log/sfx_messages");
}
static ssize_t ccs_nvme_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_DumpNvme(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_nvme);

static ssize_t ccs_perf_debug_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_perf_debug\" to dump ccs"
			    " performance debug information to /var/log/sfx_messages");
}
static ssize_t ccs_perf_debug_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		CCS_PerfDebug(sfx_mdrv->devId);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_perf_debug);

static ssize_t ccs_iops_test_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_iops_test\" to trigger"
			    " ccs iops test and the resutls go to /var/log/sfx_messages");
}
static ssize_t ccs_iops_test_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		iops_read_test();
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_iops_test);

static ssize_t ccs_iops_test_set_qd_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_iops_test_set_qd\" to setup"
			    " queue depth for ccs iops test");
}
static ssize_t ccs_iops_test_set_qd_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	unsigned long val;
	int ret;

	ret = kstrtoul(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > 0 && val <= 512) {
		set_test_qd(val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_iops_test_set_qd);

static ssize_t ccs_iops_test_set_wbs_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_iops_test_set_wbs\" to setup"
			    " write request size for ccs iops test");
}
static ssize_t ccs_iops_test_set_wbs_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	unsigned long val;
	int ret;

	ret = kstrtoul(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > 0 && val <= 1024 * 1024 && !(val % 4096)) {
		set_test_wbs(val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_iops_test_set_wbs);

static ssize_t ccs_iops_test_set_rbs_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_iops_test_set_rbs\" to setup"
			    " read request size for ccs iops test");
}
static ssize_t ccs_iops_test_set_rbs_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	unsigned long val;
	int ret;

	ret = kstrtoul(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > 0 && val <= 1024 * 1024 && !(val % 4096)) {
		set_test_rbs(val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_iops_test_set_rbs);

static ssize_t ccs_iops_test_set_data_length_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo 1 > /sys/block/sfx_bd/sfx_debug/ccs_iops_test_set_data_length\" to setup"
			    " test data length for ccs iops test");
}
static ssize_t ccs_iops_test_set_data_length_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	unsigned long val;
	int ret;

	ret = kstrtoul(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val > 0 && val <= 2048 /*2TB*/) {
		set_data_length(val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_iops_test_set_data_length);

static ssize_t ccs_compression_threshold_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo #num > /sys/block/sfd0n1/sfx_debug/ccs_compression_threshold\" to set"
			    " ccs compression write queue threshold");
}
static ssize_t ccs_compression_threshold_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val <= DCE_FIFO_SIZE) {
		ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;

		sfx_compressionq_throttle(ftl_cntx->driver_handle, ftl_cntx->comp_base_qid, val);
		// undecided yet for EC
		//        sfx_ecq_throttle(ftl_cntx->driver_handle, ftl_cntx->ec_base_qid, 16 - val);
		sfd_dbgmsg(sfx_mdrv->devId, CCS_COMP, PL_INF, "set compression threshold to %d\n", val);
	}

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_compression_threshold);

static ssize_t ccs_comp_read_threshold_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo #num > /sys/block/sfd0n1/sfx_debug/ccs_comp_read_threshold\" to set"
			    " ccs compression read queue threshold");
}

static ssize_t ccs_comp_read_threshold_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	ftl_mq_ctx *ftl_cntx = sfx_mdrv->ftl_mq_ctx;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	sfx_comp_readq_throttle(ftl_cntx->driver_handle, ftl_cntx->comp_base_qid, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_COMP, PL_INF, "set compression read threshold to %d\n", val);

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_comp_read_threshold);

static ssize_t ccs_compression_flush_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n",
			    "\"echo #num > /sys/block/sfd0n1/sfx_debug/ccs_compression_flush\" to set"
			    " ccs compression flush time (in millisecond)");
}

static ssize_t ccs_compression_flush_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	comp_flush_time = val * 1000;
	sfd_dbgmsg(sfx_mdrv->devId, CCS_COMP, PL_INF, "set compression flush time to %d ms\n", val);

	return count;
}
SFX_SYSFS_ATTR_RW(ccs_compression_flush);

static ssize_t nand_rebuild_time_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%llu us\n", sfx_mdrv->ttr_time);
}

static ssize_t nand_rebuild_time_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	return 0;
}
SFX_SYSFS_ATTR_RW(nand_rebuild_time);

static ssize_t debug_pf_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%u\n", 0);
}
static ssize_t debug_pf_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		/*TODO: open power failure debug message*/
	}
	return count;
}
SFX_SYSFS_ATTR_RW(debug_pf);

static ssize_t trigger_crash_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/trigger_crash\""
			    "to trigger a crash at specific location. Valid #num is between 1 and 2000."
			    "#num 1 - 1000 is used to trigger crash in block FTL"
			    "#num 1001 - 2000 is used to trigger crash in CCS");
}
static ssize_t trigger_crash_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val && val <= 1000) {
		blk_ftl_crash_trigger(sfx_mdrv, val);
	}
	if (val && val > 1000 && val <= 3000) {
		CCS_crash_trigger(sfx_mdrv->devId, val);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(trigger_crash);

static ssize_t comp_error_inject_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/comp_error_inject\""
			    "to inject error to compression engine\n"
			    "0x1000 - turn off error injection\n"
			    "0x1001 - ccs_ni_comp_open_session\n"
			    "0x1002 - ccs_ni_comp_close_session\n"
			    "0x1003 - ccs_ni_comp_append_data_async\n"
			    "0x1004 - ccs_ni_comp_get_data_async\n"
			    "0x1005 - ccs_ni_comp_append_get_data_async\n"
			    "0x1006 - inject error to all the APIs\n");
}
static ssize_t comp_error_inject_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val && val >= 0x1000 && val <= 0x1006) {
		CCS_crash_trigger(sfx_mdrv->devId, val);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(comp_error_inject);

static ssize_t fpga_temp_thrd_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE,
		"\"echo #num > /sys/block/sfdx/sfx_debug/fpga_temp_thrd\""
		"to set trigger temp for thermal throttling. Valid #num is >= 40 and <= 100 degree (not F or K).");
}
static ssize_t fpga_temp_thrd_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if ((val >= 40) && (val <= 100)) {
		ccs_set_fpga_temp_thrd(sfx_mdrv->devId, val);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(fpga_temp_thrd);

static ssize_t nand_temp_thrd_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(
		buf, SFX_PAGE_SIZE,
		"\"echo #num > /sys/block/sfdx/sfx_debug/nand_temp_thrd\""
		"to set trigger temp for thermal throttling. Valid #num is >= 40 and <= 68 degree (not F or K).");
}
static ssize_t nand_temp_thrd_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if ((val >= 40) && (val <= 68)) {
		ccs_set_nand_temp_thrd(sfx_mdrv->devId, val);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(nand_temp_thrd);

static ssize_t power_mode_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/power_mode\""
			    "to set power mode to control power consumption. Valid #num is < 2.");
}
static ssize_t power_mode_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u32 val;
	int ret;

	ret = kstrtou32(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val <= 1) {
		ccs_set_power_mode(sfx_mdrv->devId, val);
	}
	return count;
}
SFX_SYSFS_ATTR_RW(power_mode);

static ssize_t ccs_act_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_act_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_ACT));
}

static ssize_t ccs_act_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_ACT, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_ACT, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_act_level);

static ssize_t ccs_fm_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_fm_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_FLASHM));
}

static ssize_t ccs_fm_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_FLASHM, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_FLASHM, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_fm_level);

static ssize_t ccs_schd_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_schd_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_SCHDL));
}

static ssize_t ccs_schd_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_SCHDL, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_SCHDL, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_schd_level);

static ssize_t ccs_raid_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_raid_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_RAID));
}

static ssize_t ccs_raid_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_RAID, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_RAID, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_raid_level);

static ssize_t ccs_rcycle_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_rcycle_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_RCYCLE));
}

static ssize_t ccs_rcycle_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_RCYCLE, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_RCYCLE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_rcycle_level);

static ssize_t ccs_pf_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_pf_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_PF));
}

static ssize_t ccs_pf_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_PF, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_PF, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_pf_level);

static ssize_t ccs_wl_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_wl_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_WL));
}

static ssize_t ccs_wl_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_WL, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WL, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_wl_level);

static ssize_t ccs_rscrub_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_rscrub_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_RSCRUB));
}

static ssize_t ccs_rscrub_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_RSCRUB, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_RSCRUB, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_rscrub_level);

static ssize_t ccs_eh_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_eh_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_EH));
}

static ssize_t ccs_eh_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_EH, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_EH, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_eh_level);

static ssize_t ccs_map_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_map_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_MAP));
}

static ssize_t ccs_map_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_MAP, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_MAP, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_map_level);

static ssize_t ccs_rdis_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_rdis_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_RDIS));
}

static ssize_t ccs_rdis_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_RDIS, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_RDIS, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_rdis_level);

static ssize_t ccs_perf_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_perf_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_PERF));
}

static ssize_t ccs_perf_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_PERF, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_PERF, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_perf_level);

static ssize_t ccs_read_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_read_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_READ));
}

static ssize_t ccs_read_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_READ, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_read_level);

static ssize_t ccs_write_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_write_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_WRITE));
}

static ssize_t ccs_write_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_WRITE, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_write_level);

static ssize_t ccs_blk_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_blk_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_BLK));
}

static ssize_t ccs_blk_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_BLK, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_blk_level);

static ssize_t ccs_free_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_free_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_FREE));
}

static ssize_t ccs_free_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_FREE, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_free_level);

static ssize_t ccs_log_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_log_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_WRITE));
}

static ssize_t ccs_log_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_LOG, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_log_level);

static ssize_t ccs_sys_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_sys_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, CCS_WRITE));
}

static ssize_t ccs_sys_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_SYS, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_sys_level);

static ssize_t ccs_init_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_init_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, CCS_INIT));
}

static ssize_t ccs_init_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_INIT, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_INIT, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_init_level);

static ssize_t ccs_comp_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_comp_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, CCS_COMP));
}

static ssize_t ccs_comp_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_COMP, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_COMP, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_comp_level);

static ssize_t ccs_ec_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_ec_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, CCS_EC));
}

static ssize_t ccs_ec_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_EC, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_EC, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_ec_level);

static ssize_t ccs_model_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_model_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, CCS_MODEL));
}

static ssize_t ccs_model_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_MODEL, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_MODEL, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_model_level);

static ssize_t ccs_r2c_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/ccs_r2c_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, CCS_R2C));
}

static ssize_t ccs_r2c_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, CCS_R2C, val);
	sfd_dbgmsg(sfx_mdrv->devId, CCS_R2C, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(ccs_r2c_level);

static ssize_t nand_print_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/nand_print_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, NAND_PRINT));
}

static ssize_t nand_print_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, NAND_PRINT, val);
	sfd_dbgmsg(sfx_mdrv->devId, NAND_PRINT, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(nand_print_level);

static ssize_t blk_schd_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_schd_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_SCHD));
}

static ssize_t blk_schd_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_SCHD, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_SCHD, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_schd_level);

static ssize_t blk_coh_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_coh_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_COH));
}

static ssize_t blk_coh_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_COH, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_COH, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_coh_level);

static ssize_t blk_req_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_req_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_REQ));
}

static ssize_t blk_req_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_REQ, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_req_level);

static ssize_t blk_perf_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_perf_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_PERF));
}

static ssize_t blk_perf_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_PERF, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_PERF, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_perf_level);

static ssize_t blk_gc_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_gc_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_GC));
}

static ssize_t blk_gc_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_GC, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_GC, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_gc_level);

static ssize_t blk_th_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_th_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_TH));
}

static ssize_t blk_th_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_TH, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_TH, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_th_level);

static ssize_t blk_pf_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_pf_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_PF));
}

static ssize_t blk_pf_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_PF, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_PF, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_pf_level);

static ssize_t blk_map_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_map_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_MAP));
}

static ssize_t blk_map_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_MAP, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_MAP, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_map_level);

static ssize_t blk_mim_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_mim_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_MIM));
}

static ssize_t blk_mim_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_MIM, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_MIM, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_mim_level);

static ssize_t blk_sys_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_sys_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, BLK_SYS));
}

static ssize_t blk_sys_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_SYS, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_SYS, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_sys_level);

static ssize_t blk_securerse_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_securerse_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, BLK_SECURERSE));
}

static ssize_t blk_securerse_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_SECURERSE, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_SECURERSE, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_securerse_level);

static ssize_t blk_erh_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_erh_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, BLK_ERH));
}

static ssize_t blk_erh_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_ERH, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_ERH, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_erh_level);

static ssize_t blk_rdistb_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return snprintf(buf, PAGE_SIZE,
			"\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_rdistb_level\""
			" to set debug print level, current level is: %d\n",
			ccs_get_debug_level(sfx_mdrv->devId, BLK_RDISTB));
}

static ssize_t blk_rdistb_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_RDISTB, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_RDISTB, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_rdistb_level);

static ssize_t blk_pu_level_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "\"echo #num > /sys/block/sfdx/sfx_debug/debug_level/blk_pu_level\""
			    " to set debug print level, current level is: %d\n",
			    ccs_get_debug_level(sfx_mdrv->devId, BLK_PU));
}

static ssize_t blk_pu_level_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	ccs_set_debug_level(sfx_mdrv->devId, BLK_PU, val);
	sfd_dbgmsg(sfx_mdrv->devId, BLK_PU, PL_INF, "set debug level to %d\n", val);
	return count;
}
SFX_SYSFS_ATTR_RW(blk_pu_level);

static ssize_t blk_ftl_debug_read_show(char *buf, sfx_bd_device *sfx_bd)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "Hello Jimmy\n");
}

static ssize_t blk_ftl_debug_read_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val; /* val=1 -> print read queue; val=2 ->print write queue; */
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	if (val == 1) {
		sfx_mdrv->ftl_mq_ctx->debug_read = 1;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_SYS, PL_INF, "enable debug read\n");
	} else if (val == 9) {
		sfx_mdrv->ftl_mq_ctx->debug_assert = 9;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_SYS, PL_INF, "enable debug assert\n");
	} else {
		sfx_mdrv->ftl_mq_ctx->debug_read = 0;
		sfd_dbgmsg(sfx_mdrv->devId, BLK_SYS, PL_INF, "disable debug read\n");
	}
	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_debug_read);

static ssize_t vendor_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%04x\n", PCI_VENDOR_ID_SFX);
}

sfx_mul_drv *sfx_get_mdrv_from_dev(struct device *dev)
{
	if (NULL == dev) {
		return NULL;
	} else {
		struct gendisk *gdisk = dev_to_disk(dev);
		sfx_bd_device *sfx_bd;

		if (NULL == gdisk) {
			return NULL;
		}
		sfx_bd = GET_SFX_BD_FROM_DISK(gdisk);
		if (NULL == sfx_bd) {
			return NULL;
		}
		return (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	}
}

static ssize_t model_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfx_mul_drv *sfx_mdrv = sfx_get_mdrv_from_dev(dev);
	if (!sfx_mdrv) {
		return -EIO;
	}

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", sfx_mdrv->opn);
}

static ssize_t serial_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfx_mul_drv *sfx_mdrv = sfx_get_mdrv_from_dev(dev);
	if (!sfx_mdrv) {
		return -EIO;
	}

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", sfx_mdrv->sn);
}

static ssize_t firmware_rev_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfx_mul_drv *sfx_mdrv = sfx_get_mdrv_from_dev(dev);
	if (!sfx_mdrv) {
		return -EIO;
	}

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", sfx_mdrv->firmware_rev);
}

static ssize_t software_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", sfx_sw_version_str);
}

static ssize_t wwid_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *gdisk = dev_to_disk(dev);
	sfx_bd_device *sfx_bd;
	sfx_mul_drv *sfx_mdrv;

	sfx_bd = GET_SFX_BD_FROM_DISK(gdisk);
	if (!sfx_bd) {
		return -EIO;
	}
	sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%04x-%s-%s-%04x\n", PCI_VENDOR_ID_SFX, sfx_mdrv->sn,
			    sfx_mdrv->opn, sfx_bd->sfx_bd_id);
}

static ssize_t bus_info_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfx_mul_drv *sfx_mdrv = sfx_get_mdrv_from_dev(dev);
	if (!sfx_mdrv) {
		return -EIO;
	}
	dev = sfx_mdrv->ftl_mq_ctx->pdev;

	return sfx_snprintf(buf, SFX_PAGE_SIZE, "%s\n", kobject_name(&dev->kobj));
}

static void _print_statistics(sfx_mul_drv *sfx_mdrv, blk_io_stat *io_stat)
{
	xt_u64 tot_num, tot_lat, tot_smt, tot_ccs, tot_2ms, tot_8ms;
	xt_u64 tot_ccs_1ms, tot_ccs_8ms, tot_smt_1ms, tot_smt_8ms;
	xt_u32 iter = 0;
	for (; iter < IO_NUM_ENTRY; iter++) {
		tot_num = 0;
		tot_lat = 0;
		tot_smt = 0;
		tot_ccs = 0;
		tot_2ms = 0;
		tot_8ms = 0;
		tot_ccs_1ms = 0;
		tot_ccs_8ms = 0;
		tot_smt_1ms = 0;
		tot_smt_8ms = 0;
		sum_per_cpu64(io_stat[iter].tot_num, &tot_num);
		sum_per_cpu64(io_stat[iter].tot_lat, &tot_lat);
		sum_per_cpu64(io_stat[iter].tot_smt, &tot_smt);
		sum_per_cpu64(io_stat[iter].tot_ccs, &tot_ccs);
		sum_per_cpu64(io_stat[iter].num_2ms, &tot_2ms);
		sum_per_cpu64(io_stat[iter].num_8ms, &tot_8ms);
		sum_per_cpu64(io_stat[iter].num_ccs_1ms, &tot_ccs_1ms);
		sum_per_cpu64(io_stat[iter].num_ccs_8ms, &tot_ccs_8ms);
		sum_per_cpu64(io_stat[iter].num_smt_1ms, &tot_smt_1ms);
		sum_per_cpu64(io_stat[iter].num_smt_8ms, &tot_smt_8ms);
		if (iter == IO_SECS) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "Smaller than 4kB IO statistics:\n");
		} else if (iter == IO_unalign) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
				   "Larger than 4kB unaligned IO statistics:\n");
		} else if (iter == IO_LARGE) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "Larger than 256kB IO statistics:\n");
		} else if (iter == IO_4K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "4kB IO statistics:\n");
		} else if (iter == IO_8K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "8kB IO statistics:\n");
		} else if (iter == IO_16K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "12kB-16kB aligned IO statistics:\n");
		} else if (iter == IO_32K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "20kB-32kB aligned IO statistics:\n");
		} else if (iter == IO_64K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "36kB-64kB aligned IO statistics:\n");
		} else if (iter == IO_256K) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "70kB-256kB aligned IO statistics:\n");
		}
		if (tot_num > 0) {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
				   "Tot_req_num=%llu; avg "
				   " lat=%llu us; avg ccs_lat=%llu us; avg blk_smt_lat=%llu us\n",
				   tot_num, tot_lat / tot_num, tot_ccs / tot_num, tot_smt / tot_num);
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
				   "Latency ratio: larger "
				   "than 8ms %llu/%llu; larger than 2ms %llu/%llu; ccs larger than "
				   "8ms %llu/%llu; ccs_larger than 1ms %llu/%llu; blk_smt larger "
				   "than 8ms %llu/%llu, blk_smt larger than 1ms %llu/%llu\n",
				   tot_8ms, tot_num, tot_2ms, tot_num, tot_ccs_8ms, tot_num, tot_ccs_1ms,
				   tot_num, tot_smt_8ms, tot_num, tot_smt_1ms, tot_num);
		} else {
			sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "Total request number is zero.\n");
		}
	}
}

static ssize_t sfx_io_stat_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	if (!sfx_mdrv->en_sts) {
		return sfx_snprintf(buf, SFX_PAGE_SIZE, "IO statistics is disabled\n");
	} else {
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF, "\n                         Read statistics:\n");
		_print_statistics(sfx_mdrv, sfx_mdrv->rd_io_stat);
		sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
			   "\n                         Write statistics:\n");
		_print_statistics(sfx_mdrv, sfx_mdrv->wr_io_stat);
		return sfx_snprintf(buf, SFX_PAGE_SIZE,
				    "Please check dmesg or "
				    "sfx_messages for statistic results\n");
	}
}

static ssize_t sfx_io_stat_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	gpmem_id->smart.en_sts = val;
	gpmem_id->smart.enable_sfx_io_stat = 1;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	fm_print_smart(sfx_mdrv);
	fm_wait_flush_master_done(sfx_mdrv);
	fm_set_sfx_io_stat(sfx_mdrv, val);

	return count;
}

SFX_SYSFS_ATTR_RW(sfx_io_stat);

static ssize_t sfx_io_log_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "echo 0 to disable io log;"
			    "echo 1 to enable io log, then echo x to print last xMB log 1<=x<=128;"
			    "en_io_log=%u buf_idx=%u log_entry_idx=%u\n",
			    sfx_mdrv->en_req_log, sfx_mdrv->io_log_ctx.buf_idx,
			    sfx_mdrv->io_log_ctx.inner_idx);
}

static ssize_t sfx_io_log_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val;
	int ret;
	mim_mem_id_t *gpmem_id = (mim_mem_id_t *)sfx_mdrv->gpmem_id;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

	gpmem_id->smart.en_req_log = val;
	gpmem_id->smart.enable_sfx_io_log = 1;
	fm_flush_master_table(sfx_mdrv, FM_NORMAL);
	fm_print_smart(sfx_mdrv);
	fm_wait_flush_master_done(sfx_mdrv);

	fm_set_sfx_io_log(sfx_mdrv, val);
	return count;
}

SFX_SYSFS_ATTR_RW(sfx_io_log);

static ssize_t blk_ftl_mq_perf_show(char *buf, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	struct sfx_ioq_config *ioq_config = &sfx_mdrv->ioq_config;
	xt_u8 idx_hctx = NON_IO_QUEUE, idx_stream = 0;
	xt_u8 num_rd_stream = ioq_config->isolation ? ioq_config->num_stream : 1;
	xt_u8 num_rdq = ioq_config->rdq_per_unit * num_rd_stream;
	struct sfx_poll_ctx *poll_ctx = &sfx_mdrv->poll_ctx;
	sfd_dbgmsg(sfx_mdrv->devId, BLK_REQ, PL_INF,
		   "ref cnt ioctl %u, "
		   "outstanding process cmd %u\n",
		   sfx_atomic_read(&sfx_mdrv->ref_cnt_ioctl), sfx_atomic_read(&sfx_mdrv->outstanding_req));

#if HOT_READ_PERF || HOT_WRITE_PERF
	sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
		   "num fresh write %u, "
		   "larger than 100us %u\n",
		   sfx_atomic64_read(&sfx_mdrv->num_fresh_cmd),
		   sfx_atomic64_read(&sfx_mdrv->num_fresh_cmd_100));

	ccs_get_ctx(sfx_mdrv->devId);

	sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF, "num irq %u, larger than 100 us %u\n",
		   sfx_atomic64_read(&sfx_mdrv->ftl_mq_ctx->num_irq),
		   sfx_atomic64_read(&sfx_mdrv->ftl_mq_ctx->num_irq_100));
#endif
#if MEASURE_TIME
	sfx_atomic64_set(&sfx_mdrv->req_num, 0);
#endif
	sfx_atomic_set(&poll_ctx->polled_cmpl, 0);
	for (idx_hctx = HOT_RD_QID_BASE; idx_hctx < HOT_RD_QID_BASE + num_rdq; idx_hctx++) {
		SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
		sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[idx_hctx].sfx_nvme_cmd_queue;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
		sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
			   "hot read queue_id=%u, "
			   "tot_submit_cmd=%u tot_polled_cmd=%u active_qd=%u tot_qd=%u "
			   "num_req=%llu avg_qd=%u \n",
			   idx_hctx, sfx_atomic64_read(&sfx_nvmeq->num_smt),
			   sfx_atomic64_read(&sfx_nvmeq->num_polled), sfx_atomic_read(&sfx_nvmeq->q_depth),
			   sfx_nvmeq->tot_qd, sfx_nvmeq->num_rd_req,
			   sfx_nvmeq->num_rd_req ? (sfx_nvmeq->tot_qd / sfx_nvmeq->num_rd_req) : 0);
		sfx_nvmeq->tot_qd = 0;
		sfx_nvmeq->num_rd_req = 0;
#else
		sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
			   "hot read queue id=%u, "
			   "current qd=%u\n",
			   idx_hctx, sfx_atomic_read(&sfx_nvmeq->q_depth));
#endif
	}

	idx_hctx = HOT_RD_QID_BASE + num_rdq;
	for (idx_stream = 0; idx_stream < ioq_config->num_stream; idx_stream++) {
		xt_u8 wr_qid_base;
		idx_hctx += QID_OFF_WR_BASE;
		wr_qid_base = idx_hctx;
		sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
			   "thread=%u hot write streamid=%u, queueid_start=%u\n",
			   sfx_atomic_read(&sfx_mdrv->perf_ctx.active_io_thread), idx_stream, idx_hctx);
		for (; idx_hctx < wr_qid_base + ioq_config->wrq_per_stream; idx_hctx++) {
			SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
			sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[idx_hctx].sfx_nvme_cmd_queue;
#if (HOT_READ_PERF || HOT_WRITE_PERF)
			sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
				   "hot write qid=%u "
				   "tot_submit_cmd=%u tot_polled_cmd=%u active_qd=%u tot_qd=%u "
				   "num_req=%llu avg qd=%u\n",
				   idx_hctx, sfx_atomic64_read(&sfx_nvmeq->num_smt),
				   sfx_atomic64_read(&sfx_nvmeq->num_polled),
				   sfx_atomic_read(&sfx_nvmeq->q_depth), sfx_nvmeq->tot_qd,
				   sfx_nvmeq->num_wr_req,
				   sfx_nvmeq->num_wr_req ? (sfx_nvmeq->tot_qd / sfx_nvmeq->num_wr_req) : 0);
			sfx_nvmeq->tot_qd = 0;
			sfx_nvmeq->num_wr_req = 0;
#else
			sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
				   "hot write qid=%u "
				   "current qd=%u\n",
				   idx_hctx, sfx_atomic_read(&sfx_nvmeq->q_depth));
#endif
		}
	}
	return sfx_snprintf(buf, SFX_PAGE_SIZE,
			    "ref cnt ioctl %u, "
			    "outstanding process cmd %u\n",
			    sfx_atomic_read(&sfx_mdrv->ref_cnt_ioctl),
			    sfx_atomic_read(&sfx_mdrv->outstanding_req));
}

static ssize_t blk_ftl_mq_perf_store(const char *buf, size_t count, sfx_bd_device *sfx_bd)
{
	sfx_mul_drv *sfx_mdrv = (sfx_mul_drv *)sfx_bd->sfx_mdrv;
	xt_u8 val; /* val=1 -> print read queue; val=2 ->print write queue; */
	int ret;

	ret = kstrtou8(buf, 0, &val);
	if (ret) {
		return ret;
	}

#if (HOT_READ_PERF || HOT_WRITE_PERF)
	{
		struct sfx_ioq_config *ioq_config = &sfx_mdrv->ioq_config;
		xt_u8 idx_hctx = NON_IO_QUEUE, idx_stream = 0;
		xt_u8 num_rd_stream = ioq_config->isolation ? ioq_config->num_stream : 1;
		xt_u8 num_rdq = ioq_config->rdq_per_unit * num_rd_stream;

		sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
			   "num fresh request %u, "
			   "submit latency larger than 100us %u\n",
			   sfx_atomic64_read(&sfx_mdrv->num_fresh_cmd),
			   sfx_atomic64_read(&sfx_mdrv->num_fresh_cmd_100));

		sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
			   "num irq %u, larger than "
			   "100 us %u\n",
			   sfx_atomic64_read(&sfx_mdrv->ftl_mq_ctx->num_irq),
			   sfx_atomic64_read(&sfx_mdrv->ftl_mq_ctx->num_irq_100));

		if (1 == val) {
			xt_u64 local_num_req = sfx_atomic64_read(&sfx_mdrv->num_rd_req);
			if (local_num_req > 0) {
				sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
					   "num read req %llu, "
					   "average linux interval %llu, max %llu\n",
					   local_num_req,
					   (sfx_atomic64_read(&sfx_mdrv->hot_rd_req_intval) / local_num_req),
					   sfx_atomic64_read(&sfx_mdrv->req_interval_max));
			}

			sfx_atomic64_set(&sfx_mdrv->hot_rd_req_intval, 0);
			sfx_atomic64_set(&sfx_mdrv->num_rd_req, 0);
			sfx_atomic64_set(&sfx_mdrv->req_interval_max, 0);

			for (idx_hctx = HOT_RD_QID_BASE; idx_hctx < HOT_RD_QID_BASE + num_rdq; idx_hctx++) {
				SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
				xt_u64 tot_rd_cmd, tot_drv_rd, tot_req_rd;

				sfx_nvmeq = sfx_mdrv->ftl_mq_ctx->drvg_ctx[idx_hctx].sfx_nvme_cmd_queue;
				tot_rd_cmd = sfx_nvmeq->num_hot_read;
				tot_drv_rd = sfx_nvmeq->num_drv_read;
				tot_req_rd = sfx_nvmeq->num_rd_req;
				sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
					   "hot read queue_id=%u, "
					   "tot_rd=%u tot_driver_rd=%u tot_req_rd=%u tot_submit_cmd=%u "
					   "tot_polled_cmd=%u active qd=%u\n",
					   idx_hctx, tot_rd_cmd, tot_drv_rd, tot_req_rd,
					   sfx_atomic64_read(&sfx_nvmeq->num_smt),
					   sfx_atomic64_read(&sfx_nvmeq->num_polled),
					   sfx_atomic_read(&sfx_nvmeq->q_depth));
				sfd_dbgmsg(
					sfx_mdrv->devId, CCS_WRITE, PL_INF,
					" DRIVER_LAYER: "
					"max drv init2smt=%u ns; max drv smt2rtn=%u ns; max drv cmpl_cb=%u ns; "
					"max drv irq func=%u ns \n",
					sfx_nvmeq->drv_init2smt_max, sfx_nvmeq->drv_smt2rtn_max,
					sfx_nvmeq->drv_cmb_cb_max,
					sfx_atomic64_read(&sfx_mdrv->ftl_mq_ctx->max_irq_time));
				if (tot_rd_cmd) {
					sfd_dbgmsg(
						sfx_mdrv->devId, CCS_READ, PL_INF,
						"queue_id=%u, "
						"average latency statistics for 4k hot read: tot ftl[drv][req] "
						"rd %lu[%lu][%lu], queue depth %u\n",
						idx_hctx - 2, tot_rd_cmd, tot_drv_rd, tot_req_rd,
						sfx_atomic_read(&sfx_nvmeq->q_depth));
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "blk layer top level submit:"
						   " avarage_lat=%u ns, max_lat=%u ns\n",
						   sfx_nvmeq->hot_blk_req_end2end_proc / tot_rd_cmd,
						   sfx_nvmeq->blk_end2end_max);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "blk req init to submit end "
						   " %u ns\n",
						   sfx_nvmeq->hot_req_init2smt_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "blk layer bio smt latency  "
						   " %u ns\n",
						   sfx_nvmeq->hot_blk_cmd_smt_end2end_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "blk cmd init to submit     "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_blk_cmd_init2smt_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "blk cmd return to cmpl     "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_blk_cmd_rtn2cmpl_lat / tot_rd_cmd);

					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "ftl cmd init to submit     "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_ftl_init2smt_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "ftl cmd submit to return   "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_ftl_smt2rtn_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "ftl cmd return to cmplblk  "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_ftl_rtn2cmplblk_lat / tot_rd_cmd);
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
						   "ftl cmd cmplblk to cmpl    "
						   " %u ns\n",
						   sfx_nvmeq->hot_rd_ftl_cmplblk2cmpl_lat / tot_rd_cmd);
					if (tot_drv_rd) {
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd init to submit"
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_drv_cmd_init2smt_lat /
								   tot_drv_rd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd submit to irq "
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_drv_cmd_smt2irq_lat /
								   tot_drv_rd);
#if (READ_HW_LAT)
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd hwcnt dbell to cpl "
							   " %u us\n",
							   sfx_nvmeq->hot_rd_drv_hwcnt_smt2irq_lat /
								   tot_drv_rd);
#endif
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd irq to cb     "
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_drv_cmd_irq2cb_lat / tot_drv_rd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd cb            "
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_drv_cmd_cb_lat / tot_drv_rd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "driver cmd cb to cmpl    "
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_drv_cmd_cb2cmpl_lat /
								   tot_drv_rd);
					}
					if (tot_req_rd) {
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "blk req init to return   "
							   " avg=%u ns, max=%u ns\n",
							   sfx_nvmeq->hot_rd_req_init2rtn_lat / tot_req_rd,
							   sfx_nvmeq->req_init2rtn_max);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF,
							   "blk req return to cmpl   "
							   " %u ns\n",
							   sfx_nvmeq->hot_rd_req_rtn2cmpl_lat / tot_req_rd);
					}
					sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF, " ----------------\n");
				}
				sfx_nvmeq->hot_rd_blk_cmd_init2smt_lat = 0;
				sfx_nvmeq->hot_rd_ftl_init2smt_lat = 0;
				sfx_nvmeq->hot_rd_ftl_smt2rtn_lat = 0;
				sfx_nvmeq->hot_rd_blk_cmd_rtn2cmpl_lat = 0;
				sfx_nvmeq->hot_rd_ftl_rtn2cmplblk_lat = 0;
				sfx_nvmeq->hot_rd_ftl_cmplblk2cmpl_lat = 0;
				sfx_nvmeq->hot_req_init2smt_lat = 0;
				sfx_nvmeq->hot_blk_cmd_smt_end2end_lat = 0;
				sfx_nvmeq->hot_blk_req_end2end_proc = 0;
				sfx_nvmeq->num_hot_read = 0;

				sfx_nvmeq->hot_rd_drv_cmd_init2smt_lat = 0;
				sfx_nvmeq->hot_rd_drv_cmd_smt2irq_lat = 0;
#if (READ_HW_LAT)
				sfx_nvmeq->hot_rd_drv_hwcnt_smt2irq_lat = 0;
#endif
				sfx_nvmeq->hot_rd_drv_cmd_irq2cb_lat = 0;
				sfx_nvmeq->hot_rd_drv_cmd_cb_lat = 0;
				sfx_nvmeq->hot_rd_drv_cmd_cb2cmpl_lat = 0;
				sfx_nvmeq->num_drv_read = 0;

				sfx_nvmeq->hot_rd_req_intval = 0;
				sfx_nvmeq->hot_rd_req_init2rtn_lat = 0;
				sfx_nvmeq->hot_rd_req_rtn2cmpl_lat = 0;
				sfx_nvmeq->num_rd_req = 0;
				sfx_nvmeq->req_interval_max = 0;
				sfx_nvmeq->req_init2rtn_max = 0;
				sfx_atomic64_set(&sfx_nvmeq->num_smt, 0);
				sfx_atomic64_set(&sfx_nvmeq->num_polled, 0);
				sfx_nvmeq->drv_init2smt_max = 0;

				sfx_nvmeq->drv_smt2rtn_max = 0;
				sfx_nvmeq->drv_cmb_cb_max = 0;
				sfx_atomic64_set(&sfx_mdrv->ftl_mq_ctx->max_irq_time, 0);
			}
		} else if (2 == val) {
			idx_hctx = HOT_RD_QID_BASE + num_rdq;
			for (idx_stream = 0; idx_stream < ioq_config->num_stream; idx_stream++) {
				xt_u8 wr_qid_base;
				xt_u32 total_write_issued = 0;
				idx_hctx += QID_OFF_WR_BASE;
				wr_qid_base = idx_hctx;
				sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
					   "hot write "
					   "streamid=%u, queueid_start=%u\n",
					   idx_stream, idx_hctx);
				for (; idx_hctx < wr_qid_base + ioq_config->wrq_per_stream; idx_hctx++) {
					SFX_NVME_CMD_QUEUE_STRUCT *sfx_nvmeq;
					xt_u64 tot_wr_cmd, tot_drv_wr, tot_req_wr;

					sfx_nvmeq =
						sfx_mdrv->ftl_mq_ctx->drvg_ctx[idx_hctx].sfx_nvme_cmd_queue;
					tot_wr_cmd = sfx_nvmeq->num_hot_write;
					tot_drv_wr = sfx_nvmeq->num_drv_write;
					tot_req_wr = sfx_nvmeq->num_wr_req;
					total_write_issued += tot_req_wr;
					sfd_dbgmsg(
						sfx_mdrv->devId, CCS_WRITE, PL_INF,
						"hot write qid=%u "
						"tot_wr=%u tot_driver_wr=%u tot_req_wr=%u tot_submit_cmd=%u "
						"tot_polled_cmd=%u active qd=%u\n",
						idx_hctx, tot_wr_cmd, tot_drv_wr, tot_req_wr,
						sfx_atomic64_read(&sfx_nvmeq->num_smt),
						sfx_atomic64_read(&sfx_nvmeq->num_polled),
						sfx_atomic_read(&sfx_nvmeq->q_depth));
					if (sfx_atomic64_read(&sfx_mdrv->req_num))
						sfd_dbgmsg(
							sfx_mdrv->devId, CCS_WRITE, PL_INF,
							"req_handle lat "
							" %u ns; req_init func lat %u ns; coh_bio_init %u ns; coh_bio_proc %u ns "
							" coh func lat %u, thread_wake_time %u\n",
							sfx_atomic64_read(&sfx_mdrv->func_req_handle_lat) /
								sfx_atomic64_read(&sfx_mdrv->req_num),
							sfx_atomic64_read(&sfx_mdrv->req_init_time) /
								sfx_atomic64_read(&sfx_mdrv->req_num),
							sfx_atomic64_read(&sfx_mdrv->coh_bio_init_time) /
								sfx_atomic64_read(&sfx_mdrv->req_num),
							sfx_atomic64_read(&sfx_mdrv->coh_bio_proc_time) /
								sfx_atomic64_read(&sfx_mdrv->req_num),
							sfx_atomic64_read(&sfx_mdrv->coh_process_time) /
								sfx_atomic64_read(&sfx_mdrv->req_num),
							sfx_atomic64_read(&sfx_mdrv->coh_thread_wake_time) /
								sfx_atomic64_read(&sfx_mdrv->req_num));

					sfd_dbgmsg(
						sfx_mdrv->devId, CCS_WRITE, PL_INF,
						"max req init2cmpl=%u ns;\n "
						"max req interval=%u ns; \n max blkftl init2smt=%u ns; \n "
						"max smt =%u ns; \n max blk coh=%u ns; \n max blk wr handle=%u ns;\n "
						"max blk wr proc=%u ns\n avg_wait = %u ns\n max_wait = %u ns\n",
						sfx_nvmeq->req_init2rtn_max, sfx_nvmeq->req_interval_max,
						sfx_nvmeq->blk_init2smt_max, sfx_nvmeq->blk_end2end_max,
						sfx_nvmeq->blk_coh_max, sfx_nvmeq->blk_handle2smt_max,
						sfx_nvmeq->blk_proc_wr_max,
						(sfx_mdrv->num_wait ?
							 (sfx_mdrv->wr_tot_wait / sfx_mdrv->num_wait) :
							 0),
						sfx_mdrv->wr_max_wait);

					if (tot_wr_cmd) {
						sfd_dbgmsg(
							sfx_mdrv->devId, CCS_WRITE, PL_INF,
							"queue_id=%u, "
							"average latency statistics for 4k hot write: tot ftl[drv][req] "
							"write %lu[%lu][%lu], queue depth %u\n",
							idx_hctx, tot_wr_cmd, tot_drv_wr, tot_req_wr,
							sfx_atomic_read(&sfx_nvmeq->q_depth));
						sfd_dbgmsg(
							sfx_mdrv->devId, CCS_WRITE, PL_INF,
							"max req init2cmpl=%u ns;\n "
							"max req interval=%u ns; \n max blkftl init2smt=%u ns; \n "
							"max smt =%u ns; \n max blk coh=%u ns; \n max blk wr handle=%u ns;\n "
							"max blk wr proc=%u ns\n avg_wait = %u ns\n max_wait = %u ns\n",
							sfx_nvmeq->req_init2rtn_max,
							sfx_nvmeq->req_interval_max,
							sfx_nvmeq->blk_init2smt_max,
							sfx_nvmeq->blk_end2end_max, sfx_nvmeq->blk_coh_max,
							sfx_nvmeq->blk_handle2smt_max,
							sfx_nvmeq->blk_proc_wr_max,
							(sfx_mdrv->num_wait ? (sfx_mdrv->wr_tot_wait /
									       sfx_mdrv->num_wait) :
									      0),
							sfx_mdrv->wr_max_wait);
						sfd_dbgmsg(
							sfx_mdrv->devId, CCS_WRITE, PL_INF,
							" max ccs init2smt=%u ns; \n"
							"max ccs smt2rtn=%u ns; \n max ccs rtn2blkcbcmpl=%u ns\n max barrier time=%u ns \n",
							sfx_nvmeq->ftl_init2smt_max,
							sfx_nvmeq->ftl_smt2rtn_max,
							sfx_nvmeq->ftl_rtn2cmplblk_max,
							sfx_mdrv->ftl_mq_ctx->ba_max);
						sfd_dbgmsg(
							sfx_mdrv->devId, CCS_WRITE, PL_INF,
							" max drv init2smt=%u ns; \n"
							"max drv smt2rtn=%u ns; \n max drv cmpl_cb=%u ns; \n max drv irq func=%u ns \n",
							sfx_nvmeq->drv_init2smt_max,
							sfx_nvmeq->drv_smt2rtn_max, sfx_nvmeq->drv_cmb_cb_max,
							sfx_atomic64_read(
								&sfx_mdrv->ftl_mq_ctx->max_irq_time));
						sfx_nvmeq->req_interval_max = 0;

						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "blk layer top level handle "
							   " %u ns\n",
							   sfx_nvmeq->hot_blk_req_end2end_proc / tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "blk req init to submit end "
							   " %u ns\n",
							   sfx_nvmeq->hot_req_init2smt_lat / tot_wr_cmd);

						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "blk layer bio smt latency  "
							   " %u ns\n",
							   sfx_nvmeq->hot_blk_cmd_smt_end2end_lat /
								   tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "blk cmd init to submit     "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_blk_cmd_init2smt_lat /
								   tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "ftl cmd init to submit     "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_ftl_init2smt_lat / tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "ftl cmd submit to return   "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_ftl_smt2rtn_lat / tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "blk cmd return to cmpl     "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_blk_cmd_rtn2cmpl_lat /
								   tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "ftl cmd return to cmplblk  "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_ftl_rtn2cmplblk_lat /
								   tot_wr_cmd);
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   "ftl cmd cmplblk to cmpl    "
							   " %u ns\n",
							   sfx_nvmeq->hot_wr_ftl_cmplblk2cmpl_lat /
								   tot_wr_cmd);
						if (tot_drv_wr) {
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "driver cmd init to submit"
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_drv_cmd_init2smt_lat /
									   tot_drv_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "driver cmd submit to irq "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_drv_cmd_smt2irq_lat /
									   tot_drv_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "driver cmd irq to cb     "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_drv_cmd_irq2cb_lat /
									   tot_drv_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "driver cmd cb            "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_drv_cmd_cb_lat /
									   tot_drv_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "driver cmd cb to cmpl    "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_drv_cmd_cb2cmpl_lat /
									   tot_drv_wr);
						}
						if (tot_req_wr) {
							//sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "blk req handle interval  "
							//    " %u ns\n", sfx_nvmeq->hot_wr_req_intval/tot_req_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "blk req init to return   "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_req_init2rtn_lat /
									   tot_req_wr);
							sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
								   "blk req return to cmpl   "
								   " %u ns\n",
								   sfx_nvmeq->hot_wr_req_rtn2cmpl_lat /
									   tot_req_wr);
						}
						sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF,
							   " ----------------\n");
					}

					sfx_nvmeq->hot_blk_req_end2end_proc = 0;
					sfx_nvmeq->hot_req_init2smt_lat = 0;
					sfx_nvmeq->hot_wr_blk_cmd_init2smt_lat = 0;
					sfx_nvmeq->hot_wr_ftl_init2smt_lat = 0;
					sfx_nvmeq->hot_wr_ftl_smt2rtn_lat = 0;
					sfx_nvmeq->hot_wr_blk_cmd_rtn2cmpl_lat = 0;
					sfx_nvmeq->hot_wr_ftl_rtn2cmplblk_lat = 0;
					sfx_nvmeq->hot_wr_ftl_cmplblk2cmpl_lat = 0;
					sfx_nvmeq->num_hot_write = 0;

					sfx_nvmeq->hot_wr_drv_cmd_init2smt_lat = 0;
					sfx_nvmeq->hot_wr_drv_cmd_smt2irq_lat = 0;
					sfx_nvmeq->hot_wr_drv_cmd_irq2cb_lat = 0;
					sfx_nvmeq->hot_wr_drv_cmd_cb_lat = 0;
					sfx_nvmeq->hot_wr_drv_cmd_cb2cmpl_lat = 0;
					sfx_nvmeq->num_drv_write = 0;

					sfx_nvmeq->hot_wr_req_intval = 0;
					sfx_nvmeq->hot_wr_req_init2rtn_lat = 0;
					sfx_nvmeq->hot_wr_req_rtn2cmpl_lat = 0;
					sfx_nvmeq->num_wr_req = 0;
					sfx_nvmeq->req_interval_max = 0;
					sfx_nvmeq->req_init2rtn_max = 0;
					sfx_nvmeq->ftl_init2smt_max = 0;
					sfx_nvmeq->ftl_smt2rtn_max = 0;
					sfx_nvmeq->ftl_rtn2cmplblk_max = 0;
					sfx_atomic64_set(&sfx_nvmeq->num_smt, 0);
					sfx_atomic64_set(&sfx_nvmeq->num_polled, 0);
					sfx_nvmeq->drv_init2smt_max = 0;

					sfx_nvmeq->drv_smt2rtn_max = 0;
					sfx_nvmeq->drv_cmb_cb_max = 0;
					sfx_mdrv->ftl_mq_ctx->ba_max = 0;
					sfx_atomic64_set(&sfx_mdrv->ftl_mq_ctx->max_irq_time, 0);
				}
				sfd_dbgmsg(sfx_mdrv->devId, CCS_WRITE, PL_INF, "Total hot write issued %d\n",
					   total_write_issued);
			}
			sfx_atomic64_set(&sfx_mdrv->req_init_time, 0);
			sfx_atomic64_set(&sfx_mdrv->coh_process_time, 0);
			sfx_atomic64_set(&sfx_mdrv->coh_bio_init_time, 0);
			sfx_atomic64_set(&sfx_mdrv->coh_bio_proc_time, 0);
			sfx_atomic64_set(&sfx_mdrv->coh_thread_wake_time, 0);
			sfx_atomic64_set(&sfx_mdrv->func_req_handle_lat, 0);
			sfx_atomic64_set(&sfx_mdrv->req_num, 0);
		}
	}
#else
	if (val > 0) {
		sfx_mdrv->num_direct_cmpl = val;
		sfd_dbgmsg(sfx_mdrv->devId, CCS_READ, PL_INF, " set direct cmpl num to %u\n",
			   sfx_mdrv->num_direct_cmpl);
	}
#endif
	return count;
}
SFX_SYSFS_ATTR_RW(blk_ftl_mq_perf);

static ssize_t sfx_smart_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfx_bd_device *sfx_bd_dev = smart_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->show ? sfx_attr->show(buf, sfx_bd_dev) : 0;
}

static ssize_t sfx_smart_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
				    size_t count)
{
	sfx_bd_device *sfx_bd_dev = smart_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->store ? sfx_attr->store(buf, count, sfx_bd_dev) : 0;
}

static const struct sysfs_ops sfx_smart_ops = {
	.show = sfx_smart_attr_show,
	.store = sfx_smart_attr_store,
};

static ssize_t sfx_debug_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfx_bd_device *sfx_bd_dev = debug_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->show ? sfx_attr->show(buf, sfx_bd_dev) : 0;
}

static ssize_t sfx_debug_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
				    size_t count)
{
	sfx_bd_device *sfx_bd_dev = debug_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->store ? sfx_attr->store(buf, count, sfx_bd_dev) : 0;
}

static const struct sysfs_ops sfx_debug_ops = {
	.show = sfx_debug_attr_show,
	.store = sfx_debug_attr_store,
};

static ssize_t debug_level_attr_show(struct kobject *kobject, struct attribute *attr, char *buf)
{
	sfx_bd_device *sfx_bd_dev = debug_level_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->show ? sfx_attr->show(buf, sfx_bd_dev) : 0;
}

static ssize_t debug_level_attr_store(struct kobject *kobject, struct attribute *attr, const char *buf,
				      size_t count)
{
	sfx_bd_device *sfx_bd_dev = debug_level_to_sfx_bd_dev(kobject);
	struct sfx_sysfs_attr *sfx_attr = to_attr(attr);

	return sfx_attr->store ? sfx_attr->store(buf, count, sfx_bd_dev) : 0;
}

static const struct sysfs_ops debug_level_ops = {
	.show = debug_level_attr_show,
	.store = debug_level_attr_store,
};

struct attribute *smart_feature_attrs[] = {
	ATTR_LIST(blk_ftl_act_config),
	ATTR_LIST(sfx_rwr_me),
	ATTR_LIST(sfx_u2_mode_config),
	ATTR_LIST(lock_status),
	ATTR_LIST(pfail_lock_status),
	ATTR_LIST(pfail_lock_override),
	ATTR_LIST(sfx_io_stat),
	ATTR_LIST(sfx_io_log),
	ATTR_LIST(set_overprovisioning_cap),
	ATTR_LIST(set_non_gc_stream),
	ATTR_LIST(hw_cmd_scheduler),
	ATTR_LIST(sfx_write_outlier),
	ATTR_LIST(sfx_read_outlier),
	ATTR_LIST(sfx_assert_restore),
	ATTR_LIST(sfx_feature_stat),
	NULL,
};

struct kobj_type smart_feature_ktype = {
	.sysfs_ops = &sfx_smart_ops,
	.default_attrs = smart_feature_attrs,
	.release = sfx_sysfs_release,
};

struct attribute *debug_attrs[] = {
	ATTR_LIST(bg_gc_timer_range), /*valid timer value range*/
	ATTR_LIST(bg_gc_timer),
	ATTR_LIST(bg_gc_threshold_range), /*valid threshold range*/
	ATTR_LIST(bg_gc_threshold), /*background GC will stop once
                                       free space percentage hits this value*/
	ATTR_LIST(reset_log), /*reset log and mark bad block*/
	ATTR_LIST(flip_adaptive_read), /*turn on and off of the adaptive read */
	ATTR_LIST(wl_target_endurance), /*set wl endurance target value*/
	ATTR_LIST(wl_default_threshold), /*set wl default threshold*/
	ATTR_LIST(wl_default_gap), /*set wl default gap*/
	ATTR_LIST(wl_stop), /*stop wl*/
	ATTR_LIST(trigger_wl_early), /*trigger wl early for testing*/
	ATTR_LIST(wear_leveling_opt), /*wear leveling algorithm options*/
	ATTR_LIST(wear_leveling), /*wear leveling algorithm choose*/
	ATTR_LIST(read_scrub_range), /*read scrub time interval range*/
	ATTR_LIST(read_scrub), /*read scrub time interval*/
	ATTR_LIST(blk_ftl_gc),
	ATTR_LIST(blk_ftl_schedule),
	ATTR_LIST(blk_ftl_perf),
	ATTR_LIST(blk_ftl_gc_iops),
	ATTR_LIST(blk_ftl_set_bg_gc),
	ATTR_LIST(blk_ftl_perf_enable),
	ATTR_LIST(gc_distribution_enable),
	ATTR_LIST(blk_ftl_perf_linux),
	ATTR_LIST(blk_ftl_coherency),
	ATTR_LIST(blk_ftl_mim),
	ATTR_LIST(blk_ftl_erase_secure),
	ATTR_LIST(sfx_l2p_table_dump),
	ATTR_LIST(read_disturb_set_values),
	ATTR_LIST(set_overprovisioning_cap),
	ATTR_LIST(blk_ftl_mdata_vfy_scan_l2p_table),
	ATTR_LIST(blk_ftl_mdata_vfy_scan_valid_mem_ids),
	ATTR_LIST(blk_ftl_mdata_get_reverse_lba),
	ATTR_LIST(blk_ftl_act_config),
	ATTR_LIST(sfx_rwr_me),
	ATTR_LIST(blk_rd_debug),
	ATTR_LIST(ccs_stats),
	ATTR_LIST(ccs_snapshot),
	ATTR_LIST(ccs_erase_config),
	ATTR_LIST(ccs_app_q),
	ATTR_LIST(ccs_nvme_q),
	ATTR_LIST(ccs_remap),
	ATTR_LIST(ccs_map),
	ATTR_LIST(ccs_write_session),
	ATTR_LIST(ccs_sblock),
	ATTR_LIST(ccs_thermal),
	ATTR_LIST(ccs_rd_debug),
	ATTR_LIST(ccs_nvme),
	ATTR_LIST(ccs_perf_debug),
	ATTR_LIST(ccs_iops_test),
	ATTR_LIST(ccs_iops_test_set_qd),
	ATTR_LIST(ccs_iops_test_set_wbs),
	ATTR_LIST(ccs_iops_test_set_rbs),
	ATTR_LIST(ccs_iops_test_set_data_length),
	ATTR_LIST(ccs_compression_threshold),
	ATTR_LIST(ccs_comp_read_threshold),
	ATTR_LIST(debug_pf),
	ATTR_LIST(trigger_crash),
	ATTR_LIST(comp_error_inject),
	ATTR_LIST(fpga_temp_thrd),
	ATTR_LIST(nand_temp_thrd),
	ATTR_LIST(power_mode),
	ATTR_LIST(sfx_assert_debug),
	ATTR_LIST(inject_messages),
	ATTR_LIST(blk_ftl_mq_perf),
	ATTR_LIST(blk_ftl_debug_read),
	ATTR_LIST(ccs_compression_flush),
	ATTR_LIST(nand_rebuild_time),
	NULL,
};

struct kobj_type debug_ktype = {
	.sysfs_ops = &sfx_debug_ops,
	.default_attrs = debug_attrs,
	.release = sfx_sysfs_release,
};

struct attribute *debug_level_attrs[] = {
	ATTR_LIST(ccs_act_level),    ATTR_LIST(ccs_fm_level),	ATTR_LIST(ccs_schd_level),
	ATTR_LIST(ccs_raid_level),   ATTR_LIST(ccs_rcycle_level),    ATTR_LIST(ccs_pf_level),
	ATTR_LIST(ccs_wl_level),     ATTR_LIST(ccs_rscrub_level),    ATTR_LIST(ccs_eh_level),
	ATTR_LIST(ccs_map_level),    ATTR_LIST(ccs_rdis_level),      ATTR_LIST(ccs_perf_level),
	ATTR_LIST(ccs_read_level),   ATTR_LIST(ccs_write_level),     ATTR_LIST(ccs_blk_level),
	ATTR_LIST(ccs_free_level),   ATTR_LIST(ccs_log_level),       ATTR_LIST(ccs_sys_level),
	ATTR_LIST(ccs_init_level),   ATTR_LIST(ccs_comp_level),      ATTR_LIST(ccs_ec_level),
	ATTR_LIST(ccs_model_level),  ATTR_LIST(ccs_r2c_level),       ATTR_LIST(nand_print_level),
	ATTR_LIST(blk_schd_level),   ATTR_LIST(blk_coh_level),       ATTR_LIST(blk_req_level),
	ATTR_LIST(blk_perf_level),   ATTR_LIST(blk_gc_level),	ATTR_LIST(blk_th_level),
	ATTR_LIST(blk_pf_level),     ATTR_LIST(blk_map_level),       ATTR_LIST(blk_mim_level),
	ATTR_LIST(blk_sys_level),    ATTR_LIST(blk_securerse_level), ATTR_LIST(blk_erh_level),
	ATTR_LIST(blk_rdistb_level), ATTR_LIST(blk_pu_level),	NULL,
};

struct kobj_type debug_level_ktype = {
	.sysfs_ops = &debug_level_ops,
	.default_attrs = debug_level_attrs,
	.release = sfx_sysfs_release,
};

int sfx_init_sysfs(struct sfx_kobj *kobj, struct kobject *k_parent, struct kobj_type *ktype, char *name)
{
	sfx_init_completion(&kobj->complete);
	return sfxdriver_kobject_init_and_add(&kobj->kobject, ktype, k_parent, "%s", name);
}

void sfx_exit_sysfs(struct sfx_kobj *kobj)
{
	kobject_del(&kobj->kobject);
	kobject_put(&kobj->kobject);
	sfx_wait_for_completion(&kobj->complete);
}

static ssize_t sfxstat_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	sfx_mul_drv *sfx_mdrv = sfx_get_mdrv_from_dev(dev);
	if (!sfx_mdrv) {
		return -EIO;
	}

	return CSS_DCEStat(sfx_mdrv->devId, buf);
}

static ssize_t sfxstat_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count)
{
	int n;

	sscanf(buf, "%du", &n);
	// maybe reset current stats ?
	return count;
}

static DEVICE_ATTR(vendor, S_IWUSR | S_IRUGO, vendor_show, NULL);
static DEVICE_ATTR(model, S_IWUSR | S_IRUGO, model_show, NULL);
static DEVICE_ATTR(serial, S_IWUSR | S_IRUGO, serial_show, NULL);
static DEVICE_ATTR(firmware_rev, S_IWUSR | S_IRUGO, firmware_rev_show, NULL);
static DEVICE_ATTR(software, S_IWUSR | S_IRUGO, software_show, NULL);
static DEVICE_ATTR(wwid, S_IWUSR | S_IRUGO, wwid_show, NULL);
static DEVICE_ATTR(sfxstat, S_IWUSR | S_IRUGO, sfxstat_show, sfxstat_store);
static DEVICE_ATTR(bus_info, S_IWUSR | S_IRUGO, bus_info_show, NULL);
static struct attribute_group dev_attr_group;
struct attribute *dev_info[9];

int sfx_add_dev_info(struct kobject *dev_kobj)
{
	dev_info[0] = &dev_attr_vendor.attr;
	dev_info[1] = &dev_attr_model.attr;
	dev_info[2] = &dev_attr_serial.attr;
	dev_info[3] = &dev_attr_firmware_rev.attr;
	dev_info[4] = &dev_attr_software.attr;
	dev_info[5] = &dev_attr_wwid.attr;
	dev_info[6] = &dev_attr_sfxstat.attr;
	dev_info[7] = &dev_attr_bus_info.attr;
	dev_info[8] = NULL;
	dev_attr_group.attrs = dev_info;
	return sfxdriver_sysfs_create_group(dev_kobj, &dev_attr_group);
}

#if ENABLE_VDEV
void sfx_prepare_dev_info(void)
{
	dev_info[0] = &dev_attr_vendor.attr;
	dev_info[1] = &dev_attr_model.attr;
	dev_info[2] = &dev_attr_serial.attr;
	dev_info[3] = &dev_attr_firmware_rev.attr;
	dev_info[4] = &dev_attr_software.attr;
	dev_info[5] = &dev_attr_wwid.attr;
	dev_info[6] = &dev_attr_sfxstat.attr;
	dev_info[7] = &dev_attr_bus_info.attr;
	dev_info[8] = NULL;
}
#endif

void sfx_remove_dev_info(struct kobject *dev_kobj)
{
	sfxdriver_sysfs_remove_group(dev_kobj, &dev_attr_group);
}
