// ---------------------------------------------------------------------------
//
// Copyright 2015-2019 - ScaleFlux, Inc.
//
// ALL RIGHTS RESERVED. These coded instructions and program statements are
// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
// They may not be modified, copied, reproduced, distributed, or disclosed to
// third parties in any manner, medium, or form, in whole or in part.
//
// Filename : sfv_sysfs.h
//
// ---------------------------------------------------------------------------

#ifndef __SFV_SYSFS_H__
#define __SFV_SYSFS_H__

extern struct device_attribute *sfxstat;

void sfv_exit_sysfs(struct sfv_kobj *kobj);
int sfv_add_dev_info(struct kobject *dev_kobj, struct vdev_register *reg);
int sfv_add_dev_smart(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg);
int sfv_add_dev_debug(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg);
int sfv_add_dev_debug_level(struct sfv_kobj *kobj, struct kobject *k_parent, struct vdev_register *reg);
void sfv_clear_sysfs_callbacks(void);
void sfv_refill_sysfs_callbacks(struct vdev_register *reg);

#endif // __SFV_SYSFS_H__
