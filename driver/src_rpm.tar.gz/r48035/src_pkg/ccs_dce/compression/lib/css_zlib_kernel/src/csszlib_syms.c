/*
 * Copyright (c) 2015-2018, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */
#include <linux/types.h>
#include <linux/version.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/const.h>
#include <linux/types.h>
#include "sfx_types.h"
#include "csszlib.h"
#include "sfx_wrapper.h"
#include "version_tmp.h"

// The following two global variables will be set to the generated driver version, version_tmp.h
char *sfx_sw_version_str = SFX_SW_VERSION;
xt_u32 sfx_driver_version = SFX_DRIVER_VERSION;

EXPORT_SYMBOL(inflateReset);

pid_t sfx_get_current_pid(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,5,0)
    return percpu_read_stable(current_task)->pid;
#else
    return this_cpu_read_stable(current_task)->pid;
#endif
}

int csszlib_create_key(int *is_dev_open)
{
    static DEFINE_MUTEX(cssz_mutex);

    /* inside a thread */
    mutex_lock(&cssz_mutex);

    if (0 != *is_dev_open) {
        mutex_unlock(&cssz_mutex);
        return csszlib_select_css_dev();
    }

    csszlib_discover_css_dev();

    *is_dev_open = 1;
    mutex_unlock(&cssz_mutex);

    return csszlib_select_css_dev();
}

int init_module(void)
{
    struct sfx_csszlib_callbacks csszlib_cb;

    printk(KERN_INFO "Scaleflux CSSZLIB module init\n");

    csszlib_cb.deflateInit	= css_deflateInit;
    csszlib_cb.deflate		= css_deflate;
    csszlib_cb.deflateReset	= css_deflateReset;
    csszlib_cb.deflateEnd	= css_deflateEnd;
    csszlib_cb.inflateInit	= css_inflateInit;
    csszlib_cb.inflate		= css_inflate;
    csszlib_cb.inflateEnd	= css_inflateEnd;

    sfx_wrapper_register(&csszlib_cb);

    /*
     * A non 0 return means init_module failed; module can't be loaded.
     */
    return 0;
}

void cleanup_module(void)
{
    sfx_wrapper_unregister();
    printk(KERN_INFO "Scaleflux CSSZLIB module exit\n");
}

MODULE_LICENSE("Proprietary");
