/*
 * Copyright (c) 2015-2018, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */
#ifndef __SFX_WRAPPER_H__
#define __SFX_WRAPPER_H__

#include "csszlib.h"

struct sfx_csszlib_callbacks
{
    int (*deflateInit)(z_stream *strm, int level);
    int (*deflate)(z_stream *strm, int flush);
    int (*deflateReset)(z_stream *strm);
    int (*deflateEnd)(z_stream *strm);
    int (*inflateInit)(z_stream *strm);
    int (*inflate)(z_stream *strm, int flush);
    int (*inflateEnd)(z_stream *strm);
};

extern void sfx_wrapper_register(struct sfx_csszlib_callbacks *csszlib_cb);
extern void sfx_wrapper_unregister(void);
int csszlib_create_key(int *is_dev_open);
int csszlib_select_css_dev(void);
void csszlib_discover_css_dev(void);

#endif // __SFX_WRAPPER_H__
