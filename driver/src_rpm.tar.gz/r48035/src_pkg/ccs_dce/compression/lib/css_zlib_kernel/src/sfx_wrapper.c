/*
 * Copyright (c) 2015-2017, ScaleFlux, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */

#include <linux/module.h>
#include "csszlib.h"
#include "sfx_wrapper.h"

static int g_sfx_registered = 0;
static struct sfx_csszlib_callbacks g_sfx_csszlib;

int css_deflateInit(z_stream *stream, int level)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_deflateInit(stream, level);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_deflateInit);

int css_deflate(z_stream *stream, int flush)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_deflate(stream, flush);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_deflate);

int css_deflateReset(z_stream *stream)
{
        if (g_sfx_registered) {
                return g_sfx_csszlib.css_deflateReset(stream);
        }
        return Z_ERRNO;
}
EXPORT_SYMBOL(css_deflateReset);

int css_deflateEnd(z_stream *stream)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_deflateEnd(stream);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_deflateEnd);

int css_inflateInit(z_stream *stream)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_inflateInit(stream);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_inflateInit);

int css_inflate(z_stream *stream, int flush)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_inflate(stream, flush);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_inflate);

int css_inflateEnd(z_stream *stream)
{
    if (g_sfx_registered) {
        return g_sfx_csszlib.css_inflateEnd(stream);
    }
    return Z_ERRNO;
}
EXPORT_SYMBOL(css_inflateEnd);

void sfx_wrapper_register(struct sfx_csszlib_callbacks *csszlib_cb)
{
    g_sfx_csszlib.deflateInit	= csszlib_cb->deflateInit;
    g_sfx_csszlib.deflate		= csszlib_cb->deflate;
    g_sfx_csszlib.deflateReset	= csszlib_cb->deflateReset;
    g_sfx_csszlib.deflateEnd	= csszlib_cb->deflateEnd;
    g_sfx_csszlib.inflateInit	= csszlib_cb->inflateInit;
    g_sfx_csszlib.inflate		= csszlib_cb->inflate;
    g_sfx_csszlib.inflateEnd	= csszlib_cb->inflateEnd;
    g_sfx_registered = 1;
    printk(KERN_INFO "Scaleflux CSSZLIB module registered\n");
}
EXPORT_SYMBOL(sfx_wrapper_register);

void sfx_wrapper_unregister(void)
{
    g_sfx_registered = 0;
    printk(KERN_INFO "Scaleflux CSSZLIB module unregistered\n");
}
EXPORT_SYMBOL(sfx_wrapper_unregister);

static int __init sfx_wrapper_init(void)
{
    printk(KERN_INFO "Scaleflux CSSZLIB wrapper module started\n");
    return 0;
}

static void __exit sfx_wrapper_exit(void)
{
    printk(KERN_INFO "Scaleflux CSSZLIB wrapper module exited\n");
}

module_init(sfx_wrapper_init);
module_exit(sfx_wrapper_exit);

MODULE_LICENSE("Proprietary");
MODULE_DESCRIPTION("Scaleflux CSSZLIB Wrapper Module");
