#!/usr/bin/env bash

wget https://github.com/scalefluxcss/referencedata/raw/master/csszlib/testfiles.tar.gz
