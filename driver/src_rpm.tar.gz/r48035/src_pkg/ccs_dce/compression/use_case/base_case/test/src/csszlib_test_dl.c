#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/time.h>
#include <dlfcn.h>

#ifdef ORIG_ZLIB
#include "zlib.h"
#else
#include "csszlib.h"
#endif

int (*zlib_deflateInit)(z_streamp, int, const char *, int);
int (*zlib_deflate)(z_streamp, int);
int (*zlib_deflateEnd)(z_streamp);
int (*zlib_inflateInit2)(z_streamp, int, const char *, int);
int (*zlib_inflateReset)(z_streamp);
int (*zlib_inflate)(z_streamp, int);
int (*zlib_inflateEnd)(z_streamp);
void *handle;

void load_ccsz(char path[])
{
    handle = dlopen (path, RTLD_LAZY);
    void *error;

    if (!handle) {
        fputs (dlerror(), stderr);
        exit(1);
    }

#ifdef ORIG_ZLIB
    zlib_deflateInit = dlsym(handle, "deflateInit_");
    zlib_deflate = dlsym(handle, "deflate");
    zlib_deflateEnd = dlsym(handle, "deflateEnd");
    zlib_inflateInit2 = dlsym(handle, "inflateInit2_");
    zlib_inflateReset = dlsym(handle, "inflateReset");
    zlib_inflate = dlsym(handle, "inflate");
    zlib_inflateEnd = dlsym(handle, "inflateEnd");
#else
    zlib_deflateInit = dlsym(handle, "css_deflateInit_");
    zlib_deflate = dlsym(handle, "css_deflate");
    zlib_deflateEnd = dlsym(handle, "css_deflateEnd");
    zlib_inflateInit2 = dlsym(handle, "css_inflateInit2_");
    zlib_inflateReset = dlsym(handle, "css_inflateReset");
    zlib_inflate = dlsym(handle, "css_inflate");
    zlib_inflateEnd = dlsym(handle, "css_inflateEnd");
#endif
    if ((error = dlerror()) != NULL)  {
        fputs(error, stderr);
        dlclose(handle);
        exit(1);
    }
}

#define CSS_BLOCK_SIZE 65535
#define CSSZLIB_COMP_BOUND(x) (x*2 + (x/CSS_BLOCK_SIZE+1) * 656)

unsigned long get_time_diff(struct timeval *start, struct timeval *end)
{
    unsigned long secs  = end->tv_sec - start->tv_sec;
    unsigned long usecs = secs * 1000000 + end->tv_usec - start->tv_usec;

    return usecs;
}

unsigned long get_file_size(char *file_name)
{
    unsigned long fsz;

    FILE* infp;

    infp = fopen(file_name, "r");
    if(!infp) {
        printf("Could not open file %s\n", file_name);
        assert(0);
    }

    fseek(infp, 0L, SEEK_END);
    fsz = ftell(infp);

    if(!fsz) {
        printf("Error: Test File Size is 0. \n");
        assert(0);
    }
    fclose(infp);
    return fsz;
}

int compress_test(z_streamp strm, Bytef *raw_data, uLong raw_size, Bytef *comp_data, uLong *comp_size)
{
    int ret;

    strm->zalloc = Z_NULL;
    strm->zfree = Z_NULL;
    strm->opaque = Z_NULL;

    /* initialize zlib stream, which is defined in zlib.h */
    ret = zlib_deflateInit(strm, -1, ZLIB_VERSION, (int)sizeof(z_stream));
    if (ret != Z_OK) 
        return ret;

    /* start compress data from input data */
    strm->avail_in = raw_size;
    strm->next_in = (Bytef *) raw_data;

    strm->avail_out = CSSZLIB_COMP_BOUND(raw_size);
    strm->next_out = (Bytef *) comp_data;

    ret = zlib_deflate(strm, Z_FINISH);
    assert(ret == Z_STREAM_END);
    *comp_size = strm->total_out;

    /* clean up zlib stream */
    (void)zlib_deflateEnd(strm);

    return Z_OK;
}

int decomp_test(Byte *comp, uLong comp_len, Byte *uncomp, uLong uncomp_len)
{
    int err = 0;
    uLong file_total_in = 0;
    uLong file_total_out = 0;
    z_stream strm; /* decompression stream */

    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;

    err = zlib_inflateInit2(&strm, 47, ZLIB_VERSION, (int)sizeof(z_stream));
    if (err != Z_OK) return err;

    do {
        strm.avail_in = comp_len - file_total_in;
        strm.next_in = (Bytef *) comp + file_total_in;

        strm.avail_out = uncomp_len-file_total_out;
        strm.next_out = uncomp + file_total_out;

        err = zlib_inflate(&strm, Z_NO_FLUSH);

        switch (err) {
            case Z_STREAM_ERROR:
            case Z_DATA_ERROR:
            case Z_MEM_ERROR:
                (void)zlib_inflateEnd(&strm);
                return err;
        }

        if (err == Z_STREAM_END) {
            file_total_out += strm.total_out;
            assert(uncomp_len >= file_total_out);
            file_total_in += strm.total_in;
            zlib_inflateReset(&strm);
        }
    } while (file_total_in < comp_len);

    (void)zlib_inflateEnd(&strm);
    assert(file_total_out == uncomp_len);

    return Z_OK;
}

/* report a zlib or i/o error */
void zerr(int ret)
{
    fputs("csszlib: ", stderr);
    switch (ret) {
    case Z_ERRNO:
        if (ferror(stdin))
            fputs("error reading stdin\n", stderr);
        if (ferror(stdout))
            fputs("error writing stdout\n", stderr);
        break;
    case Z_STREAM_ERROR:
        fputs("invalid compression level\n", stderr);
        break;
    case Z_DATA_ERROR:
        fputs("invalid or incomplete deflate data\n", stderr);
        break;
    case Z_MEM_ERROR:
        fputs("out of memory\n", stderr);
        break;
    case Z_VERSION_ERROR:
        fputs("zlib version mismatch!\n", stderr);
        break;
#ifndef ORIG_ZLIB
    case Z_CSS_DEV_OPEN_ERROR:
        fputs("open css device error!\n", stderr);
        break;
#endif
    }
}

int main(int argc, char *argv[])
{

    if (argc <= 1) {
        printf("csszlib_test input_file\n");
        exit(0);
    }

    z_stream strm;
    unsigned long comp_time, decomp_time;
    unsigned long comp_size;
    unsigned long max_raw_size = 2147483648;
    struct timeval start, end;
    int ret;

    unsigned long raw_size = get_file_size(argv[1]);
    if (max_raw_size < raw_size) {
        fprintf(stderr, "Please don't use file that is larger than 2GB for this test program!\n");
        exit(1);
    }

    FILE *in = fopen(argv[1], "r");

    if (in == NULL) {
        printf("Can't open file %s\n", argv[1]);
        exit(1);
    }

    Bytef *raw_data = (Bytef *) malloc(raw_size);
    Bytef *comp_data = (Bytef *) malloc(CSSZLIB_COMP_BOUND(raw_size));
    Bytef *uncomp_data = (Bytef *) malloc(raw_size);
    if (fread(raw_data, 1, raw_size, in) != raw_size) {
        fprintf(stderr, "Read file error!");
        exit(1);
    }

#ifdef ORIG_ZLIB
    fprintf(stderr, "================ Standard Zlib ================\n");
#else
    fprintf(stderr, "=================== CSSZlib ===================\n");
#endif

#ifdef ORIG_ZLIB
    load_ccsz("liborigz.so");
#else
    load_ccsz("libcssz.so");
#endif

    // compress data
    gettimeofday(&start, 0);
    ret = compress_test(&strm, raw_data, raw_size, comp_data, &comp_size);
    gettimeofday(&end, 0);
    if (ret != Z_OK) {
        zerr(ret);
        exit(1);
    }
    comp_time = get_time_diff(&start, &end);


    // decompress data
    gettimeofday(&start, 0);
    ret = decomp_test(comp_data, comp_size, uncomp_data, raw_size);
    gettimeofday(&end, 0);
    if (ret != Z_OK) {
        zerr(ret);
        exit(1);
    }
    decomp_time = get_time_diff(&start, &end);

    printf("Raw data size: %lu, Compressed size: %lu, Compression ratio = %.1f%%\n", raw_size, comp_size, 100.0*comp_size/raw_size);
    printf("Compression time = %f, Decompression time = %f\n", comp_time / 1000000.0, decomp_time / 1000000.0);

    free(raw_data);
    free(comp_data);
    free(uncomp_data);
    fclose(in);
    dlclose(handle);
    return 0;
}
