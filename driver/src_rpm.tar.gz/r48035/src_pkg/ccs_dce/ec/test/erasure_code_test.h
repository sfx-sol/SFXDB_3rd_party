/// @par Copyright:
/// Copyright (c) by ScaleFlux, Inc.
///
/// ALL RIGHTS RESERVED. These coded instructions and program statements are
/// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
/// They may not be modified, copied, reproduced, distributed, or disclosed to
/// third parties in any manner, medium, or form, in whole or in part.
///
/// @par Description:
/// Sample test program for Erasure Code

#ifndef _ERASURE_CODER_TEST_H_
#define _ERASURE_CODER_TEST_H_

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#define LENGTH                      16384
#define WAIT_STATUS                 100000

#define MMAX                        14
#define KMAX                        10

typedef struct _IsalCoder
{
    int verbose;
    int numParityUnits;
    int numDataUnits;
    int numAllUnits;
} IsalCoder;

typedef struct _IsalEncoder
{
    IsalCoder coder;
    unsigned char gftbls[MMAX * KMAX * 32];
    unsigned char encodeMatrix[MMAX * KMAX];
} IsalEncoder;

typedef struct _IsalDecoder
{
    IsalCoder coder;
    unsigned char encodeMatrix[MMAX * KMAX];
    // Below are per decode call
    unsigned char gftbls[MMAX * KMAX * 32];
    unsigned int decodeIndex[MMAX];
    unsigned char tmpMatrix[MMAX * KMAX];
    unsigned char invertMatrix[MMAX * KMAX];
    unsigned char decodeMatrix[MMAX * KMAX];
    unsigned char erasureFlags[MMAX];
    int erasedIndexes[MMAX];
    int numErased;
    int numErasedDataUnits;
    unsigned char* realInputs[MMAX];
} IsalDecoder;

int cssec_encode(int data_length, int numDataUnits, int numParityUnits,
        unsigned char ** destInputs, unsigned char ** destOutputs);

int cssec_decode(int chunkSize, unsigned char** allUnits, int* erasedIndexes,
        unsigned char* decodingOutput[], int numErased, int numDataUnits, int numParityUnits);

int decode(IsalDecoder* decoder, unsigned char** allUnits,
        int* erasedIndexes, int numErased,
        unsigned char** recoveredUnits, int chunkSize);

#endif // _ERASURE_CODER_TEST_H_
