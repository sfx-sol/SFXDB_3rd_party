/// @par Copyright:
/// Copyright (c) by ScaleFlux, Inc.
///
/// ALL RIGHTS RESERVED. These coded instructions and program statements are
/// copyrighted works and confidential proprietary information of ScaleFlux, Inc.
/// They may not be modified, copied, reproduced, distributed, or disclosed to
/// third parties in any manner, medium, or form, in whole or in part.
///
/// @par Description:
/// Sample test program for Erasure Code

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "erasure_code_test.h"

#define SHOW_DETAIL

int main(int argc, char *argv[])
{
    int i, j;
    char err[256];
    size_t err_len = sizeof(err);
    int chunkSize = 1024;
    int numDataUnits = 6;
    int numParityUnits = 3;
    unsigned char** dataUnits;
    unsigned char** parityUnits;
    unsigned char** parityUnits2;
    IsalEncoder* pEncoder;
    int erasedIndexes[2];
    unsigned char* allUnits[MMAX];
    IsalDecoder* pDecoder;
    unsigned char* decodingOutput[2];
    unsigned char** backupUnits;

    if (0 == build_support_erasurecode()) {
        printf("The native library isn't available, skipping this test\n");
        return 0;  // Normal, not an error
    }

    load_erasurecode_lib(err, err_len);
    if (strlen(err) > 0) {
        printf("Loading erasurecode library failed: %s\n", err);
        return -1;
    }

    printf("Performing erasure code test\n");

    dataUnits = calloc(numDataUnits, sizeof(unsigned char*));
    parityUnits = calloc(numParityUnits, sizeof(unsigned char*));
    parityUnits2 = calloc(numParityUnits, sizeof(unsigned char*));
    backupUnits = calloc(numParityUnits, sizeof(unsigned char*));

    // Allocate and generate data units
    srand(135);
    for (i = 0; i < numDataUnits; i++) {
        dataUnits[i] = calloc(chunkSize, sizeof(unsigned char));
        for (j = 0; j < chunkSize; j++) {
            dataUnits[i][j] = rand();
        }
    }

    // Allocate and initialize parity units
    for (i = 0; i < numParityUnits; i++) {
        parityUnits[i] = calloc(chunkSize, sizeof(unsigned char));
        parityUnits2[i] = calloc(chunkSize, sizeof(unsigned char));
        for (j = 0; j < chunkSize; j++) {
            parityUnits[i][j] = 0;
            parityUnits2[i][j] = 0;
        }
    }

    /************CSSEC encode*************/
    if (0 != cssec_encode(chunkSize, numDataUnits, numParityUnits, dataUnits, parityUnits2)) {
        printf("****cannot css encode********");
        return 1;
    }  //CSSEC encode ends

    /************ISAL encode*************/
    pEncoder = (IsalEncoder*)malloc(sizeof(IsalEncoder));
    memset(pEncoder, 0, sizeof(*pEncoder));
    initEncoder(pEncoder, numDataUnits, numParityUnits);
    encode(pEncoder, dataUnits, parityUnits, chunkSize);
    //ISAL encode ends

#ifdef SHOW_DETAIL
    printf("------------encoding isal result----------------------\n");
    int _i;
    for (_i = 0; _i < numParityUnits; _i++) {
        int _j;
        for (_j = 0; _j < chunkSize; _j++) {
            printf("%d ", parityUnits[_i][_j]);
        }
        printf("\n");
    }

    printf("-------------ending isal result--------------------\n");

    printf("------------encoding css result----------------------\n");
    for (_i = 0; _i < numParityUnits; _i++) {
        int _j;
        for (_j = 0; _j < chunkSize; _j++) {
            printf("%d ", parityUnits2[_i][_j]);
        }
        printf("\n");
    }

    printf("-------------ending css result--------------------\n");
#endif

    /************CSSEC decode************/
    pDecoder = (IsalDecoder*)malloc(sizeof(IsalDecoder));
    memset(pDecoder, 0, sizeof(*pDecoder));
    initDecoder(pDecoder, numDataUnits, numParityUnits);

    memcpy(allUnits, dataUnits, numDataUnits * (sizeof(unsigned char*)));
    memcpy(allUnits + numDataUnits, parityUnits2,
            numParityUnits * (sizeof(unsigned char*)));

    erasedIndexes[0] = 1;
    erasedIndexes[1] = 6;

    backupUnits[0] = allUnits[1];
    backupUnits[1] = allUnits[6];
    //backupUnits[1] = allUnits[8];

    allUnits[0] = NULL;  // Not to read
    allUnits[1] = NULL;
    allUnits[6] = NULL;

    decodingOutput[0] = malloc(chunkSize);
    decodingOutput[1] = malloc(chunkSize);

    // isa-l decoder
    //decode(pDecoder, allUnits, erasedIndexes, 2, decodingOutput, chunkSize);

    /**************CSSEC decode**************/
    if (0 != cssec_decode(chunkSize, allUnits, erasedIndexes, decodingOutput,
            2, numDataUnits, numParityUnits)) {
        printf("********cannot do css decode*********8");
        return -1;
    }
    //CSSEC decode ends

    for (i = 0; i < pDecoder->numErased; i++) {
        if (0 != memcmp(decodingOutput[i], backupUnits[i], chunkSize)) {
            fprintf(stderr, "Decoding failed\n\n");
            dumpDecoder(pDecoder);
            return -1;
        }
    }

#ifdef SHOW_DETAIL
    printf("EncodeMatrix readable version:\n");

    int wx;
    for (wx = 0; wx < 6; wx++) {
        int _j;
        for (_j = 0; _j < 6; _j++) {
            printf(" %d", pEncoder->encodeMatrix[(wx * 6 + _j)]);
        }
        for (_j = 0; _j < 3; _j++) {
            printf(" %d", pEncoder->encodeMatrix[(6 * 6) + (_j * 6) + wx]);
        }
        printf("\n");
    }
#endif
    printf("\n");

    //dumpDecoder(pDecoder);
    fprintf(stdout, "Successfully done, passed!\n\n");

    return 0;
}
