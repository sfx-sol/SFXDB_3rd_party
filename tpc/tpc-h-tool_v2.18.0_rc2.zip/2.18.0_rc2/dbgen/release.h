/*
 * release.h
 */
#define VERSION 2
#define RELEASE 18
#define PATCH 0
#define BUILD 0
